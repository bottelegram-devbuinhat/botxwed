"""cPanel entry point for the Telegram bot (long polling).

Passenger imports this file and calls `application` as a WSGI app.
The bot runs in a background thread with its own asyncio event loop,
so the WSGI app can answer immediately while polling continues.
Pattern already used for bot1 (passenger_wsgi.py -> main() in a thread).
"""

import asyncio
import os
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import main as bot_main  # noqa: E402


def _run_bot() -> None:
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(bot_main())
    except BaseException:
        # main() logs its own errors (missing BOT_TOKEN, 409 conflict...).
        # The thread just ends; the WSGI app below keeps answering.
        pass
    finally:
        try:
            loop.close()
        except Exception:
            pass


_thread = threading.Thread(target=_run_bot, name="telegram-bot", daemon=True)
_thread.start()


def application(environ, start_response):
    status = "200 OK"
    body = "Bot is running".encode("utf-8")
    headers = [
        ("Content-Type", "text/plain; charset=utf-8"),
        ("Content-Length", str(len(body))),
    ]
    start_response(status, headers)
    return [body]
