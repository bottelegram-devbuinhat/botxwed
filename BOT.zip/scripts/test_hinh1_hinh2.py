import asyncio
import sys

sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")

from database.session import init_db
from database.models import User
from services import shop_service
import handlers.shop as shop_handlers
from keyboards.shop import info_list, account_detail

async def test():
    await init_db()
    dummy_user = User(id=1, shop_balance=10000, coins=10000, vip_level=0)
    
    # 1. Test Info Listing (HÌNH 2)
    accounts, total = await shop_service.list_accounts(page=0, per_page=5, kind="info")
    assert len(accounts) > 0, "No info accounts!"
    a0 = accounts[0]
    
    # Check button text in info_list keyboard
    kb = info_list(accounts, 0, 1)
    btn_texts = [btn.text for row in kb.inline_keyboard for btn in row]
    assert any(btn.startswith("◇ Acc #") for btn in btn_texts), f"Expected '◇ Acc #' in buttons, got {btn_texts}"
    print("[TEST HÌNH 2 KEYBOARD PASSED] Button format: '◇ Acc #...'")

    # 2. Test Info Detail Text (HÌNH 1)
    detail_text = await shop_handlers._detail_text(a0, dummy_user, a0.price, 5.0)
    print("\n--- DETAIL TEXT (HÌNH 1) ---")
    print(detail_text[:350])
    print("----------------------------\n")
    
    assert f"ACC #{a0.code}" in detail_text, "Missing ACC #code in detail view"
    assert ("Acc Thông Tin Xấu · Còn hàng" in detail_text) or ("Acc Sẵn Thông Tin · Còn hàng" in detail_text), "Missing status in detail view"
    assert "Số điện thoại:" in detail_text, "Missing Số điện thoại in detail view"
    assert "Email:" in detail_text, "Missing Email in detail view"
    assert "CCCD:" in detail_text, "Missing CCCD in detail view"
    assert "Loại acc:" in detail_text and "Tài khoản Liên Quân" in detail_text, "Missing Loại acc in detail view"
    assert "Skin nổi bật:" in detail_text, "Missing Skin nổi bật in detail view"
    assert "THÔNG TIN CHI TIẾT (RAW):" in detail_text, "Missing RAW line in detail view"
    
    print("[TEST HÌNH 1 PASSED] Detail view matches HÌNH 1 perfectly!")
    print("ALL TESTS PASSED!")

if __name__ == "__main__":
    asyncio.run(test())
