import asyncio
import sys
import os

# Add BOT folder to sys.path
sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")

from database.session import init_db, session_scope
from database.models import User, Account, Giftcode, GiftcodeUse, Transaction, Order
from services import shop_service, rewards_service, wallet_service as wallet, crypto_service
from keyboards.shop import shop_menu, random_list, info_list, white_list, account_detail
import handlers.shop as shop_handlers

async def run_tests():
    print("=== STARTING FULL TEST SUITE ===")
    await init_db()

    # TEST 1: Counts & Stock Organization (Task 2 & 3)
    counts = await shop_service.count_by_kind()
    print(f"[TEST 1] Account counts by kind: {counts}")
    assert counts["info"] > 0, "No info accounts found!"
    assert counts["random"] > 0, "No random accounts found!"
    assert counts["white"] > 0, "No white accounts found!"
    total = counts["info"] + counts["random"] + counts["white"]
    print(f"[TEST 1 PASSED] Total available accounts: {total}")

    # TEST 2: Pagination (Task 4 & 5)
    random_accs, r_total = await shop_service.list_accounts(page=0, per_page=5, kind="random")
    assert len(random_accs) == 5, f"Expected 5 random accs, got {len(random_accs)}"
    print(f"[TEST 2 PASSED] Random pagination: page 0 has {len(random_accs)} accounts (total {r_total})")

    info_accs, i_total = await shop_service.list_accounts(page=0, per_page=5, kind="info")
    assert len(info_accs) == 5, f"Expected 5 info accs, got {len(info_accs)}"
    print(f"[TEST 2 PASSED] Info pagination: page 0 has {len(info_accs)} accounts (total {i_total})")

    white_accs, w_total = await shop_service.list_accounts(page=0, per_page=5, kind="white")
    assert len(white_accs) > 0, f"Expected white accs, got {len(white_accs)}"
    print(f"[TEST 2 PASSED] White pagination: page 0 has {len(white_accs)} accounts (total {w_total})")

    # TEST 3: Search function across full fields (Task 4)
    # Search for "Bijan"
    res_bijan, cnt_bijan = await shop_service.list_accounts(page=0, per_page=5, kind="info", search="Bijan")
    print(f"[TEST 3] Search 'Bijan': found {cnt_bijan} accounts")
    assert cnt_bijan > 0, "Search for 'Bijan' returned 0 results!"

    # Search for "T.Anh"
    res_tanh, cnt_tanh = await shop_service.list_accounts(page=0, per_page=5, kind="info", search="T.Anh")
    print(f"[TEST 3] Search 'T.Anh': found {cnt_tanh} accounts")
    assert cnt_tanh > 0, "Search for 'T.Anh' returned 0 results!"

    # Search by code
    sample_code = info_accs[0].code
    acc_by_code = await shop_service.get_account_by_code(sample_code)
    assert acc_by_code is not None and acc_by_code.code == sample_code
    print(f"[TEST 3 PASSED] Search by code {sample_code} OK")

    # TEST 4: Raw Checker Info Preservation in VIP Account (Task 4)
    assert acc_by_code.extra is not None and len(acc_by_code.extra) > 20, "VIP extra info is missing!"
    print(f"[TEST 4 PASSED] Full raw line preserved: {acc_by_code.extra[:80]}...")

    # TEST 5: Create Test User & Buy with VND (Task 5 & 6)
    test_uid = 999988881
    async with session_scope() as session:
        u = await session.get(User, test_uid)
        if not u:
            u = User(id=test_uid, full_name="Test Buyer", shop_balance=100000, coins=100000)
            session.add(u)
        else:
            u.shop_balance = 100000
            u.coins = 100000
        await session.flush()

    # Buy a random account with VND
    target_random = random_accs[0].code
    buy_res = await shop_service.buy_account(test_uid, target_random, currency="vnd")
    assert buy_res["ok"], f"Buy random failed: {buy_res}"
    print(f"[TEST 5 PASSED] Purchased {target_random} with VND: user received {buy_res['username']} / {buy_res['password']}")

    # Verify target_random disappeared from available listings
    acc_after = await shop_service.get_account_by_code(target_random)
    assert acc_after.status == "sold", "Account status was not updated to sold!"
    r_accs_after, _ = await shop_service.list_accounts(page=0, per_page=10, kind="random")
    assert all(a.code != target_random for a in r_accs_after), f"{target_random} still appears in available list!"
    print(f"[TEST 5 PASSED] {target_random} successfully marked sold and removed from active list")

    # TEST 6: Buy with Coins (Task 6: 4x for info, 5x for random)
    target_info = info_accs[0].code
    info_price = info_accs[0].price
    expected_coins = info_price * 4
    buy_coin_res = await shop_service.buy_account(test_uid, target_info, currency="coin")
    assert buy_coin_res["ok"], f"Buy info with coins failed: {buy_coin_res}"
    assert buy_coin_res["price"] == expected_coins, f"Expected {expected_coins} coins, got {buy_coin_res['price']}"
    print(f"[TEST 6 PASSED] Purchased {target_info} with {expected_coins} coins (rate 4x). Creds: {buy_coin_res['username']}")

    # TEST 7: Giftcodes - Coin & Money (Task 7)
    # Admin creates coin giftcode
    gc_coin = await rewards_service.create_giftcode("TESTCOIN100", amount=5000, currency="coin", max_uses=2, expires_days=7, created_by=test_uid)
    assert gc_coin is not None, "Failed to create coin giftcode"
    print(f"[TEST 7] Created coin giftcode: {gc_coin.code} (5,000 xu)")

    # User redeems coin giftcode
    u_before = await wallet.get_user(test_uid)
    coins_before = u_before.coins
    redeem_coin_res = await rewards_service.redeem_giftcode(test_uid, "TESTCOIN100")
    assert redeem_coin_res["ok"], f"Redeem coin giftcode failed: {redeem_coin_res}"
    u_after = await wallet.get_user(test_uid)
    assert u_after.coins == coins_before + 5000, f"Expected {coins_before + 5000} coins, got {u_after.coins}"
    print(f"[TEST 7 PASSED] Coin giftcode redeemed: +5000 coins verified")

    # Admin creates money giftcode
    gc_vnd = await rewards_service.create_giftcode("TESTVND50K", amount=50000, currency="vnd", max_uses=2, expires_days=7, created_by=test_uid)
    assert gc_vnd is not None, "Failed to create vnd giftcode"
    print(f"[TEST 7] Created vnd giftcode: {gc_vnd.code} (50,000đ)")

    # User redeems vnd giftcode
    bal_before = u_after.shop_balance
    redeem_vnd_res = await rewards_service.redeem_giftcode(test_uid, "TESTVND50K")
    assert redeem_vnd_res["ok"], f"Redeem vnd giftcode failed: {redeem_vnd_res}"
    u_final = await wallet.get_user(test_uid)
    assert u_final.shop_balance == bal_before + 50000, f"Expected {bal_before + 50000} VND, got {u_final.shop_balance}"
    print(f"[TEST 7 PASSED] Money giftcode redeemed: +50,000đ verified")

    print("=== ALL 7 TASKS FULLY VERIFIED AND WORKING PERFECTLY! ===")

if __name__ == "__main__":
    asyncio.run(run_tests())
