import sqlite3

conn = sqlite3.connect('BOT/data/bot.db')
c = conn.cursor()
c.execute("SELECT COUNT(*) FROM accounts WHERE kind='info' AND (is_banned=1 OR extra LIKE '%Ban : YES%' OR extra LIKE '%[BAN]%' OR extra LIKE '%BAN=YES%')")
banned_in_info = c.fetchone()[0]
print('Banned in info:', banned_in_info)
c.execute("SELECT COUNT(*) FROM accounts WHERE kind='random'")
print('Total random count:', c.fetchone()[0])
c.execute("SELECT COUNT(*) FROM accounts WHERE kind='info'")
print('Total info count:', c.fetchone()[0])
c.execute("SELECT COUNT(*) FROM accounts WHERE kind='white'")
print('Total white count:', c.fetchone()[0])

c.execute("SELECT code, rank, extra FROM accounts WHERE kind='info' AND (is_banned=1 OR extra LIKE '%Ban : YES%' OR extra LIKE '%[BAN]%' OR extra LIKE '%BAN=YES%') LIMIT 5")
rows = c.fetchall()
for r in rows:
    print(r[0], r[1], r[2][:100])
conn.close()
