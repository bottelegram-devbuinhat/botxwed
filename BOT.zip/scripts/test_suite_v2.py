import asyncio
import sys
import os

# Add BOT folder to sys.path
sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")

from database.session import init_db, session_scope
from database.models import User, Account, Giftcode, GiftcodeUse, Transaction, Order
from services import shop_service, rewards_service, wallet_service as wallet, crypto_service
from keyboards.shop import shop_menu, random_list, info_list, white_list, account_detail
import handlers.shop as shop_handlers

async def run_tests():
    print("=== STARTING FULL TEST SUITE ===")
    await init_db()

    # TEST 1: Counts & Stock Organization
    counts = await shop_service.count_by_kind()
    print(f"[TEST 1] Account counts by kind: {counts}")
    assert counts["info"] == 867, f"Expected 867 info accounts, got {counts['info']}"
    assert counts["random"] == 11246, f"Expected 11246 random accounts, got {counts['random']}"
    assert counts["white"] == 13, f"Expected 13 white accounts, got {counts['white']}"
    total = counts["info"] + counts["random"] + counts["white"]
    assert total == 12126, f"Expected total 12126 accounts, got {total}"
    print(f"[TEST 1 PASSED] Total available accounts: {total}")

    # TEST 2: Verify NO banned accounts remain in info
    async with session_scope() as session:
        from sqlalchemy import select
        banned_in_info = (
            await session.execute(
                select(Account).where(
                    Account.kind == "info",
                    Account.is_banned.is_(True)
                )
            )
        ).scalars().all()
        assert len(banned_in_info) == 0, f"Found {len(banned_in_info)} banned accounts in info!"
    print("[TEST 2 PASSED] 0 banned accounts in info (all 701 banned moved to random)!")

    # TEST 3: Verify Random Detail Text only shows code, no extra info
    sample_random = (await shop_service.list_accounts(page=0, per_page=1, kind="random"))[0][0]
    dummy_user = User(id=1, shop_balance=10000, coins=10000, vip_level=0)
    detail_text = await shop_handlers._detail_text(sample_random, dummy_user, sample_random.price, 5.0)
    print(f"[TEST 3] Random account detail text:\n{detail_text}")
    assert f"Mã số: <b>{sample_random.code}</b>" in detail_text
    assert "Rank:" not in detail_text
    assert "Skin:" not in detail_text
    assert "Tướng:" not in detail_text
    assert "UID:" not in detail_text
    print("[TEST 3 PASSED] Random account only shows code and price, no photos/info!")

    # TEST 4: Verify Random Account Detail Keyboard has NO photos button
    kb = account_detail(sample_random, sample_random.price, False, "vi")
    button_texts = [btn.text for row in kb.inline_keyboard for btn in row]
    assert "🖼 Xem ảnh" not in button_texts, "Photos button should NOT be in random account keyboard!"
    print(f"[TEST 4 PASSED] Random account keyboard buttons: {button_texts}")

    # TEST 5: Verify Info Account Detail STILL has full raw checker line
    sample_info = (await shop_service.list_accounts(page=0, per_page=1, kind="info"))[0][0]
    info_detail_text = await shop_handlers._detail_text(sample_info, dummy_user, sample_info.price, 5.0)
    assert "THÔNG TIN CHI TIẾT ĐẦY ĐỦ:" in info_detail_text
    print(f"[TEST 5 PASSED] Info account detail text correctly shows full raw info:\n{info_detail_text[:200]}...")

    print("=== ALL TESTS PASSED WITH 100% SUCCESS! ===")

if __name__ == "__main__":
    asyncio.run(run_tests())
