import sqlite3

conn = sqlite3.connect(r"c:\Users\Admin\Videos\New folder (2)\BOT\data\bot.db")
cur = conn.cursor()
cur.execute('SELECT code, kind, price, extra FROM accounts WHERE kind="info" LIMIT 2')
for row in cur.fetchall():
    print("CODE:", row[0], "KIND:", row[1], "PRICE:", row[2])
    print("EXTRA:", row[3][:120] if row[3] else None)
conn.close()
