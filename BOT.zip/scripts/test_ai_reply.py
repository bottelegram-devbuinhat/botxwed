import asyncio
import sys

sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")
from services import ai_service
from database.session import init_db

async def test():
    await init_db()
    ai_service.reset_cooldowns()
    
    print("--- Test 1: Ask about kho acc ---")
    res1 = await ai_service.reply(
        user_id=1,
        message="Shop có những acc nào giá bao nhiêu?",
        history=[],
        name="Tester"
    )
    print("Response 1:\n", res1)
    assert res1 is not None and "Kho" in res1, "Response 1 failed!"

    print("\n--- Test 2: Ask about wallet ---")
    res2 = await ai_service.reply(
        user_id=1,
        message="Kiểm tra số dư ví của tôi",
        history=[],
        name="Tester"
    )
    print("Response 2:\n", res2)
    assert res2 is not None and "Số dư" in res2, "Response 2 failed!"

    print("\nAI test passed completely! No more 'Trợ lý đang bận'!")

if __name__ == "__main__":
    asyncio.run(test())
