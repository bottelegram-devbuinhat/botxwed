import asyncio
import sys
sys.path.insert(0, 'BOT')
import aiohttp
import config

async def test():
    key = config.AI_API_KEYS[0]
    base = config.AI_BASE_URL.rstrip('/')
    url = f"{base}/chat/completions"
    body = {
        'model': 'gemini-2.0-flash',
        'messages': [{'role': 'user', 'content': 'Hello, say 1 word'}]
    }

    # Test 1: Only Bearer
    h1 = {'Content-Type': 'application/json', 'Authorization': f'Bearer {key}'}
    async with aiohttp.ClientSession() as s:
        async with s.post(url, json=body, headers=h1) as r:
            t1 = await r.text()
            print('Test 1 (Bearer):', r.status, t1[:200])

    # Test 2: Only x-goog-api-key
    h2 = {'Content-Type': 'application/json', 'x-goog-api-key': key}
    async with aiohttp.ClientSession() as s:
        async with s.post(url, json=body, headers=h2) as r:
            t2 = await r.text()
            print('Test 2 (x-goog-api-key):', r.status, t2[:200])

    # Test 3: Both
    h3 = {'Content-Type': 'application/json', 'Authorization': f'Bearer {key}', 'x-goog-api-key': key}
    async with aiohttp.ClientSession() as s:
        async with s.post(url, json=body, headers=h3) as r:
            t3 = await r.text()
            print('Test 3 (Both):', r.status, t3[:200])

if __name__ == '__main__':
    asyncio.run(test())
