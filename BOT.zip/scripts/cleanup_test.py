import asyncio
import sys
sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")

from database.session import init_db, session_scope
from database.models import User, Account, Giftcode, GiftcodeUse, Transaction, Order
from sqlalchemy import update, delete

async def cleanup():
    await init_db()
    async with session_scope() as session:
        # Reset test accounts back to available
        await session.execute(
            update(Account)
            .where(Account.code.in_(["LQ12126", "LQ1568"]))
            .values(status="available", sold_at=None)
        )
        # Delete test orders and transactions
        test_uid = 999988881
        await session.execute(delete(Order).where(Order.user_id == test_uid))
        await session.execute(delete(Transaction).where(Transaction.user_id == test_uid))
        await session.execute(delete(GiftcodeUse).where(GiftcodeUse.user_id == test_uid))
        # Delete test giftcodes
        await session.execute(delete(Giftcode).where(Giftcode.code.in_(["TESTCOIN100", "TESTVND50K"])))
        await session.execute(delete(User).where(User.id == test_uid))
    print("Cleanup completed! All accounts back to available.")

if __name__ == "__main__":
    asyncio.run(cleanup())
