import asyncio
import aiohttp
import sys

sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")
from config import AI_API_KEYS, AI_BASE_URL, AI_MODEL

async def test():
    key = AI_API_KEYS[0]
    print(f"Testing Key 1 (prefix {key[:8]}..., len={len(key)}):")
    
    # Test A: OpenAI-compatible endpoint with x-goog-api-key only (NO Bearer)
    url_openai = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
    body_openai = {
        "model": "gemini-2.0-flash",
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 10
    }
    async with aiohttp.ClientSession() as s:
        h = {"x-goog-api-key": key, "Content-Type": "application/json"}
        async with s.post(url_openai, json=body_openai, headers=h) as r:
            print("Test A (x-goog-api-key only, OpenAI endpoint):", r.status, (await r.text())[:300])

    # Test B: Native Gemini endpoint with ?key= (NO Bearer)
    url_native = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}"
    body_native = {
        "contents": [{"parts": [{"text": "Hello"}]}]
    }
    async with aiohttp.ClientSession() as s:
        h = {"Content-Type": "application/json"}
        async with s.post(url_native, json=body_native, headers=h) as r:
            print("Test B (Native endpoint with ?key):", r.status, (await r.text())[:300])

    # Test C: Native endpoint with x-goog-api-key header (NO Bearer)
    url_native_c = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
    async with aiohttp.ClientSession() as s:
        h = {"x-goog-api-key": key, "Content-Type": "application/json"}
        async with s.post(url_native_c, json=body_native, headers=h) as r:
            print("Test C (Native endpoint with x-goog-api-key):", r.status, (await r.text())[:300])

if __name__ == "__main__":
    asyncio.run(test())
