"""Đẩy toàn bộ số dư ví lên Cloudflare một lần (kiểm tra cấu hình / chạy tay).

Cách dùng (trong thư mục bot, .env đã có CLOUDFLARE_SYNC_URL/TOKEN):

    python scripts/sync_balances.py            # chỉ đẩy ví đã thay đổi
    python scripts/sync_balances.py --force    # đẩy tất cả

Job full sync trong scheduler vẫn tự chạy mỗi 5 phút khi bot hoạt động; script
này chỉ để test end-to-end hoặc chạy từ cron của hosting.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from database.session import init_db  # noqa: E402
from services import cloud_sync  # noqa: E402


async def main() -> int:
    if not cloud_sync.enabled():
        print(
            "Chưa cấu hình sync. Thêm CLOUDFLARE_SYNC_URL và CLOUDFLARE_SYNC_TOKEN "
            "vào .env (xem CLOUDFLARE_SETUP.md)."
        )
        return 1
    await init_db()
    force = "--force" in sys.argv
    pushed = await cloud_sync.full_sync(force=force)
    print(f"Đã đẩy {pushed} ví lên {cloud_sync.CLOUDFLARE_SYNC_URL} (force={force}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
