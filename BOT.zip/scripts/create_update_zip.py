import zipfile, os

files_to_zip = [
    "handlers/shop.py",
    "handlers/ai.py",
    "handlers/wallet.py",
    "keyboards/shop.py",
    "services/ai_service.py",
    "services/payment_service.py",
    "services/shop_service.py",
    "config.py",
    "main.py",
]

zip_path = "BOT/bot-update.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in files_to_zip:
        abs_p = os.path.join("BOT", rel)
        if os.path.exists(abs_p):
            z.write(abs_p, rel)
            print("Added:", rel)

print("Created:", zip_path, os.path.getsize(zip_path), "bytes")
