import asyncio
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from database.models import User
from services import shop_service, wallet_service, ai_service
from handlers.shop import _SEARCH_SESSIONS, _detail_text
from keyboards.shop import search_list_kb, info_list


async def main():
    print("--- 1. Testing AI Service Reply & Fallback ---")
    reply = await ai_service.reply(
        user_id=123456789,
        message="Shop có những acc nào giá bao nhiêu?",
        history=[],
        is_admin=False,
        name="TestUser"
    )
    print("AI reply snippet:", reply[:200] if reply else "None")
    assert reply is not None, "AI reply should never be None"
    assert "Liên Quân" in reply or "acc" in reply.lower() or "kho" in reply.lower(), "AI reply should be relevant"
    print("AI Service: PASS")

    print("\n--- 2. Testing Search Function & Multi-page Pagination ---")
    query = "T.Anh"
    accounts, total = await shop_service.list_accounts(page=0, per_page=5, kind="info", search=query)
    search_kind = "info"
    if not accounts:
        accounts, total = await shop_service.list_accounts(page=0, per_page=5, search=query)
        search_kind = None

    print(f"Found {total} accounts for '{query}', kind={search_kind}")
    assert total > 5, "Should find multiple accounts"
    pages = max(1, (total + 5 - 1) // 5)
    print(f"Total pages: {pages}")
    assert pages > 1, "Should have more than 1 page"

    qid = "testq123"
    _SEARCH_SESSIONS[qid] = {"query": query, "kind": search_kind}

    # Generate keyboard for page 0
    kb_p0 = search_list_kb(accounts, 0, pages, qid, language="vi")
    # Verify pagination buttons exist
    callbacks = [btn.callback_data for row in kb_p0.inline_keyboard for btn in row]
    print("Page 0 callbacks:", [c for c in callbacks if c.startswith("shop:sp:")])
    assert f"shop:sp:{qid}:1" in callbacks, "Page 0 should have link to page 1"

    # Simulate pagination to page 1
    accounts_p1, total_p1 = await shop_service.list_accounts(page=1, per_page=5, kind=search_kind, search=query)
    assert len(accounts_p1) == 5
    assert accounts_p1[0].code != accounts[0].code, "Page 1 should have different accounts than page 0"
    kb_p1 = search_list_kb(accounts_p1, 1, pages, qid, language="vi")
    callbacks_p1 = [btn.callback_data for row in kb_p1.inline_keyboard for btn in row]
    print("Page 1 callbacks:", [c for c in callbacks_p1 if c.startswith("shop:sp:")])
    assert f"shop:sp:{qid}:0" in callbacks_p1, "Page 1 should have link back to page 0"
    print("Search & Pagination: PASS")

    print("\n--- 3. Testing Detail Text Format (HÌNH 1) ---")
    first_acc = accounts[0]
    dummy_user = User(id=123, username="test", shop_balance=100000, coins=500000, vip_level=1, language="vi")
    detail = await _detail_text(first_acc, dummy_user, price=first_acc.price, rating=5.0)
    print("Detail text preview:\n", detail[:350])
    assert f"ACC #{first_acc.code}" in detail
    assert "Số điện thoại:" in detail
    assert "Email:" in detail
    assert "CCCD:" in detail
    assert "Loại acc:</b> Tài khoản Liên Quân" in detail
    assert ("THÔNG TIN CHI TIẾT ĐẦY ĐỦ:" in detail) or ("THÔNG TIN CHI TIẾT (RAW):" in detail)
    # Ensure "ảnh 2" description is NOT in detail either
    assert "• Dùng dành test map" not in detail
    print("Detail Text Format (Hình 1): PASS")

    print("\n--- 4. Verify Random Account Detail Format ---")
    random_accs, _ = await shop_service.list_accounts(page=0, per_page=1, kind="random")
    assert random_accs, "Should have random accounts"
    rand_detail = await _detail_text(random_accs[0], dummy_user, price=random_accs[0].price, rating=5.0)
    print("Random detail text:\n", rand_detail)
    assert "ACC RANDOM" in rand_detail
    assert "ẩn hoàn toàn thông tin" in rand_detail
    assert "Số điện thoại:" not in rand_detail
    print("Random Account Detail: PASS")

    print("\nALL VERIFICATION CHECKS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    asyncio.run(main())
