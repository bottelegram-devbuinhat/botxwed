import asyncio
import aiohttp
import sys

sys.path.insert(0, r"c:\Users\Admin\Videos\New folder (2)\BOT")
from config import AI_API_KEYS, AI_BASE_URL, AI_MODEL

async def test():
    print("AI_BASE_URL:", AI_BASE_URL)
    print("AI_MODEL:", AI_MODEL)
    print("Number of keys:", len(AI_API_KEYS))
    if not AI_API_KEYS:
        print("No keys!")
        return
    
    body = {
        "model": AI_MODEL or "gemini-2.0-flash",
        "messages": [{"role": "user", "content": "Xin chao"}],
        "max_tokens": 10
    }
    
    url = f"{AI_BASE_URL.rstrip('/')}/chat/completions"
    
    for idx, key in enumerate(AI_API_KEYS):
        print(f"\n--- Testing Key #{idx+1} (prefix: {key[:8]}...) ---")
        
        # Test 1: Standard Bearer
        try:
            async with aiohttp.ClientSession() as s:
                h = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
                async with s.post(url, json=body, headers=h) as r:
                    res1 = await r.text()
                    print(f"  Attempt 1 (Bearer): HTTP {r.status} -> {res1[:150]}")
        except Exception as e:
            print("  Attempt 1 error:", e)

        # Test 2: With x-goog-api-key header and query parameter ?key=
        try:
            async with aiohttp.ClientSession() as s:
                h = {
                    "Authorization": f"Bearer {key}",
                    "x-goog-api-key": key,
                    "Content-Type": "application/json"
                }
                async with s.post(f"{url}?key={key}", json=body, headers=h) as r:
                    res2 = await r.text()
                    print(f"  Attempt 2 (x-goog-api-key & ?key): HTTP {r.status} -> {res2[:150]}")
        except Exception as e:
            print("  Attempt 2 error:", e)

if __name__ == "__main__":
    asyncio.run(test())
