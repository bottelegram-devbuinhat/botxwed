import sqlite3

db_path = r"c:\Users\Admin\Videos\New folder (2)\BOT\data\bot.db"
conn = sqlite3.connect(db_path)
cur = conn.cursor()

# Check before
cur.execute("""
    SELECT count(*) FROM accounts 
    WHERE kind = 'info' AND (
        is_banned = 1 
        OR extra LIKE '%Ban : YES%' 
        OR extra LIKE '%BAN=YES%' 
        OR extra LIKE '%BAN: YES%' 
        OR extra LIKE '%[BAN]%'
        OR ban_note LIKE '%BAN%'
    )
""")
banned_count = cur.fetchone()[0]
print(f"Found {banned_count} banned accounts in info. Moving to random...")

# Update
cur.execute("""
    UPDATE accounts 
    SET kind = 'random', price = 3000, category = 'Random'
    WHERE kind = 'info' AND (
        is_banned = 1 
        OR extra LIKE '%Ban : YES%' 
        OR extra LIKE '%BAN=YES%' 
        OR extra LIKE '%BAN: YES%' 
        OR extra LIKE '%[BAN]%'
        OR ban_note LIKE '%BAN%'
    )
""")
conn.commit()

# Check after
cur.execute("SELECT kind, count(*) FROM accounts WHERE status='available' GROUP BY kind")
counts = cur.fetchall()
print("New counts by kind:", dict(counts))
conn.close()
