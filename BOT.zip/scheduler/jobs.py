"""Scheduled jobs: release held accounts, backups and weekly leaderboard prizes.

MERGE (repo: src/scheduler.js + src/utils/orderExpiry.js): two new jobs —
order_expiry_job (cancel unpaid direct orders every 30s, like the repo's
order-expiry checker) and subscription_reminder_job (warn buyers 7 days
before a subscription product expires, like the repo's scheduler)."""

from __future__ import annotations

import shutil
from datetime import datetime, timedelta

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from config import BACKUP_KEEP_DAYS, BACKUP_DIR, DATA_DIR, TIMEZONE
from services import order_service, ranking_service, shop_service
from services import wallet_service as wallet
from utils.logger import get_logger
from utils.logs import log_action

log = get_logger(__name__)

WEEKLY_PRIZES = [(1, 5000), (2, 2500), (3, 1000)]


async def release_holds_job() -> None:
    try:
        released = await shop_service.release_expired_holds()
        if released:
            log.info("Released %s expired account holds", released)
    except Exception as exc:
        log.error("release_holds_job failed: %s", exc)


async def backup_job() -> None:
    source = DATA_DIR / "bot.db"
    if not source.exists():
        return
    try:
        target = BACKUP_DIR / f"backup-{datetime.now():%Y%m%d-%H%M%S}.db"
        shutil.copy2(source, target)
        cutoff = datetime.now() - timedelta(days=BACKUP_KEEP_DAYS)
        for old in BACKUP_DIR.glob("backup-*.db"):
            if datetime.fromtimestamp(old.stat().st_mtime) < cutoff:
                old.unlink(missing_ok=True)
        log.info("Database backup written to %s", target.name)
    except Exception as exc:
        log.error("backup_job failed: %s", exc)


async def weekly_prizes_job(bot) -> None:
    """Award the top 3 by weekly wins with bonus coins."""
    try:
        top = await ranking_service.top("wins", "week", limit=3)
        for position, (user_id, _name, _value) in enumerate(top, start=1):
            reward = dict(WEEKLY_PRIZES).get(position, 0)
            if reward <= 0:
                continue
            await wallet.add_balance(
                user_id,
                reward,
                "weekly_prize",
                "coin",
                f"Thưởng BXH tuần hạng {position}",
                ref=f"weekly:{datetime.utcnow():%G-W%V}:{user_id}",
            )
            try:
                await bot.send_message(
                    user_id,
                    f"🏆 Chúc mừng! Bạn đạt hạng <b>{position}</b> bảng thắng tuần và nhận "
                    f"<b>{reward:,} xu</b>.".replace(",", "."),
                    parse_mode="HTML",
                )
            except Exception:
                pass
        await log_action("ranking", f"Trao thưởng BXH tuần cho {len(top)} người")
    except Exception as exc:
        log.error("weekly_prizes_job failed: %s", exc)


async def order_expiry_job(bot) -> None:
    """Cancel unpaid direct orders (ORD) and release their held accounts
    (repo: orderExpiry checks every 30s)."""
    try:
        expired = await order_service.expire_orders(bot)
        if expired:
            log.info("Expired %s unpaid direct orders", expired)
    except Exception as exc:
        log.error("order_expiry_job failed: %s", exc)


async def subscription_reminder_job(bot) -> None:
    """Remind buyers whose subscription product expires within 7 days
    (repo: scheduler.js hourly subscription-expiry reminders)."""
    from datetime import datetime as _dt

    from sqlalchemy import select

    from database.models import Order
    from database.session import session_scope

    try:
        now = _dt.utcnow()
        horizon = now + timedelta(days=7)
        async with session_scope() as session:
            rows = (
                await session.execute(
                    select(Order).where(
                        Order.status == "delivered",
                        Order.subscription_expires_at.is_not(None),
                        Order.subscription_expires_at <= horizon,
                        Order.subscription_expires_at > now,
                        Order.expiry_reminded.is_(False),
                    )
                )
            ).scalars().all()
            for order in rows:
                order.expiry_reminded = True
        for order in rows:
            try:
                await bot.send_message(
                    order.user_id,
                    f"⏰ <b>Gói {order.product_name} của bạn sắp hết hạn</b> "
                    f"(<b>{order.subscription_expires_at:%d/%m/%Y}</b>).\n"
                    "Hãy gia hạn để không bị gián đoạn dịch vụ!",
                    parse_mode="HTML",
                )
            except Exception:
                pass
        if rows:
            log.info("Sent %s subscription expiry reminders", len(rows))
    except Exception as exc:
        log.error("subscription_reminder_job failed: %s", exc)


def start_scheduler(bot) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone=TIMEZONE)
    scheduler.add_job(release_holds_job, IntervalTrigger(seconds=60), id="release_holds", replace_existing=True)
    # MERGE: direct-order expiry every 30s (repo: orderExpiry) + subscription reminders hourly.
    scheduler.add_job(
        order_expiry_job,
        IntervalTrigger(seconds=30),
        args=[bot],
        id="order_expiry",
        replace_existing=True,
    )
    scheduler.add_job(
        subscription_reminder_job,
        IntervalTrigger(hours=1),
        args=[bot],
        id="subscription_reminders",
        replace_existing=True,
    )
    scheduler.add_job(backup_job, CronTrigger(hour=3, minute=0), id="backup", replace_existing=True)
    scheduler.add_job(
        weekly_prizes_job,
        CronTrigger(day_of_week="mon", hour=0, minute=5),
        args=[bot],
        id="weekly_prizes",
        replace_existing=True,
    )
    scheduler.start()
    log.info("Scheduler started with %s jobs", len(scheduler.get_jobs()))
    return scheduler
