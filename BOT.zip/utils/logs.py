"""Persist admin action logs and read them back."""

from __future__ import annotations

from sqlalchemy import select

from database.models import LogEntry
from database.session import session_scope
from utils.logger import get_logger

log = get_logger(__name__)


async def log_action(kind: str, message: str) -> None:
    try:
        async with session_scope() as session:
            session.add(LogEntry(kind=kind[:32], message=message[:2000]))
    except Exception as exc:
        log.error("Cannot write action log: %s", exc)


async def recent_logs(limit: int = 20):
    async with session_scope() as session:
        return (
            await session.execute(select(LogEntry).order_by(LogEntry.created_at.desc()).limit(limit))
        ).scalars().all()
