"""Formatting and parsing helpers for money and coins."""

from __future__ import annotations


def fmt_vnd(amount: int | float) -> str:
    """Format an integer VND amount with dots: 10000 -> '10.000đ'."""
    value = int(round(float(amount)))
    sign = "-" if value < 0 else ""
    return f"{sign}{abs(value):,}".replace(",", ".") + "đ"


def fmt_coin(amount: int | float) -> str:
    """Format a coin amount: 1200 -> '1.200 xu'."""
    value = int(round(float(amount)))
    sign = "-" if value < 0 else ""
    return f"{sign}{abs(value):,}".replace(",", ".") + " xu"


def fmt_amount(amount: int, currency: str = "vnd") -> str:
    return fmt_coin(amount) if currency == "coin" else fmt_vnd(amount)


def parse_amount(raw: str) -> int | None:
    """Parse user input such as '10k', '1.5m', '100000' or '50_000'.

    Returns None when the input is not a valid positive number.
    """
    if not raw:
        return None
    text = raw.strip().lower().replace(" ", "").replace("_", "").replace(".", "").replace(",", "")
    text = text.replace("đ", "").replace("vnd", "").replace("xu", "").replace("coin", "")
    multiplier = 1
    if text.endswith("k"):
        multiplier = 1_000
        text = text[:-1]
    elif text.endswith("m"):
        multiplier = 1_000_000
        text = text[:-1]
    if not text.isdigit():
        return None
    value = int(text) * multiplier
    return value if value > 0 else None


def mask_name(name: str) -> str:
    """Partially mask a display name: 'Nguyen Van A' -> 'Nguy***n A'."""
    name = (name or "Ẩn danh").strip()
    if len(name) <= 3:
        return name[:1] + "***"
    return name[:3] + "***" + name[-1]


def signed(amount: int, currency: str = "vnd") -> str:
    prefix = "+" if amount >= 0 else ""
    return f"{prefix}{fmt_amount(amount, currency)}"
