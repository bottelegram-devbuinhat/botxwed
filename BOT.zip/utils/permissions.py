"""Admin permission helpers."""

from __future__ import annotations

from config import ADMIN_IDS, OWNER_IDS
from services.settings_service import all_settings


def _static_admins() -> set[int]:
    return {int(item) for item in (*OWNER_IDS, *ADMIN_IDS)}


async def is_admin(user_id: int) -> bool:
    if int(user_id) in _static_admins():
        return True
    settings = await all_settings()
    return int(user_id) in [int(x) for x in (settings.get("admin_ids") or [])]


async def is_owner(user_id: int) -> bool:
    return int(user_id) in OWNER_IDS


async def admin_ids() -> list[int]:
    settings = await all_settings()
    ids = _static_admins() | {int(x) for x in (settings.get("admin_ids") or [])}
    return sorted(ids)
