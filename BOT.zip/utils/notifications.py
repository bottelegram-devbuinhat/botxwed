"""Send notifications to every admin."""

from __future__ import annotations

from utils.logger import get_logger
from utils.permissions import admin_ids

log = get_logger(__name__)


async def notify_admins(bot, text: str, kb=None) -> None:
    for admin_id in await admin_ids():
        try:
            await bot.send_message(admin_id, text, reply_markup=kb, parse_mode="HTML")
        except Exception as exc:
            log.debug("Cannot notify admin %s: %s", admin_id, exc)
