"""Premium (animated) Telegram emoji support with a safe Unicode fallback.

Every UI token such as ``[[coin]]`` is expanded to either

* ``<tg-emoji emoji-id="...">🪙</tg-emoji>`` when premium emoji are available, or
* the plain ``🪙`` character when they are not.

Telegram only lets a bot send custom emoji when the bot bought a username on
Fragment or when the bot owner has Telegram Premium (Bot API 9.4). Because that
depends on the deployment, the layer always keeps the fallback character and can
be switched off at runtime the moment Telegram rejects a custom emoji.

The catalog lives in ``assets/emoji.json``; admins can override individual keys
with ``/setemoji <key>`` (as a reply to a message containing the emoji), which is
stored in ``data/emoji.json``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from config import BASE_DIR, DATA_DIR, PREMIUM_EMOJI, PREMIUM_EMOJI_FALLBACK
from utils.logger import get_logger

log = get_logger(__name__)

ASSET_FILE = BASE_DIR / "assets" / "emoji.json"
OVERRIDE_FILE = DATA_DIR / "emoji.json"

TOKEN_RE = re.compile(r"\[\[([a-z0-9_]+)\]\]")
TAG_RE = re.compile(r'<tg-emoji emoji-id="(\d+)">(.+?)</tg-emoji>', re.S)

_CATALOG: dict[str, dict[str, str]] = {}
_LOADED = False
_ENABLED = bool(PREMIUM_EMOJI)


def _read(path: Path) -> dict:
    try:
        with path.open(encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        log.warning("Cannot read %s: %s", path, exc)
        return {}
    return data if isinstance(data, dict) else {}


def load(force: bool = False) -> dict[str, dict[str, str]]:
    """Load the bundled catalog plus admin overrides (cached)."""
    global _CATALOG, _LOADED
    if _LOADED and not force:
        return _CATALOG

    catalog: dict[str, dict[str, str]] = {}
    base = _read(ASSET_FILE).get("emoji") or {}
    for key, meta in base.items():
        if isinstance(meta, dict):
            catalog[str(key)] = {
                "char": str(meta.get("char") or ""),
                "id": str(meta.get("id") or ""),
            }

    overrides = _read(OVERRIDE_FILE).get("emoji") or {}
    for key, meta in overrides.items():
        if isinstance(meta, dict):
            char = str(meta.get("char") or (catalog.get(str(key)) or {}).get("char") or "")
            catalog[str(key)] = {"char": char, "id": str(meta.get("id") or "")}

    _CATALOG = catalog
    _LOADED = True
    return _CATALOG


def catalog() -> dict[str, dict[str, str]]:
    return load()


def is_enabled() -> bool:
    return _ENABLED


def set_enabled(flag: bool, reason: str = "") -> None:
    global _ENABLED
    if _ENABLED == flag:
        return
    _ENABLED = flag
    if flag:
        log.info("Premium emoji enabled")
    else:
        log.warning("Premium emoji disabled%s", f": {reason}" if reason else "")


def char(key: str, default: str = "") -> str:
    meta = load().get(key)
    return (meta or {}).get("char") or default


def set_emoji(key: str, document_id: str, char_fallback: str | None = None) -> bool:
    """Persist a custom emoji id for ``key`` (admin tooling)."""
    key = (key or "").strip().lower()
    document_id = str(document_id or "").strip()
    if not key or not document_id.isdigit():
        return False

    data = _read(OVERRIDE_FILE)
    entries = data.get("emoji")
    if not isinstance(entries, dict):
        entries = {}
    current = entries.get(key) if isinstance(entries.get(key), dict) else {}
    fallback = char_fallback or current.get("char") or char(key)
    entries[key] = {"char": fallback, "id": document_id}
    data = {"version": 1, "emoji": entries}

    try:
        OVERRIDE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with OVERRIDE_FILE.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
    except OSError as exc:
        log.error("Cannot save emoji override: %s", exc)
        return False
    load(force=True)
    return True


def _pack_name(raw: str) -> str:
    """Accept ``NewsEmoji`` or ``https://t.me/addemoji/NewsEmoji`` and return the set name."""
    name = (raw or "").strip()
    if "/" in name:
        name = name.rstrip("/").rsplit("/", 1)[-1]
    return name.split("?")[0]


async def import_pack(bot, raw_name: str) -> dict:
    """Fetch a public emoji pack and bind its ids to the catalog keys we already use.

    Telegram exposes ``getStickerSet`` for custom-emoji packs; each sticker has the
    emoji character and its ``custom_emoji_id``. Matching by character lets us
    upgrade ``[[gem]]``/``[[fire]]``... to real animated emoji without inventing ids.
    """
    name = _pack_name(raw_name)
    if not name:
        return {"ok": False, "name": "", "error": "Tên pack trống."}
    try:
        sticker_set = await bot.get_sticker_set(name)
    except Exception as exc:
        return {"ok": False, "name": name, "error": str(exc)[:160]}

    entries = load()
    by_char: dict[str, list[str]] = {}
    for key, meta in entries.items():
        symbol = (meta or {}).get("char") or ""
        if symbol:
            by_char.setdefault(symbol, []).append(key)

    updates: dict[str, dict[str, str]] = {}
    for sticker in getattr(sticker_set, "stickers", []) or []:
        document_id = str(getattr(sticker, "custom_emoji_id", "") or "")
        symbol = getattr(sticker, "emoji", "") or ""
        if not document_id.isdigit() or not symbol:
            continue
        for key in by_char.get(symbol, []):
            updates[key] = {"char": symbol, "id": document_id}

    if not updates:
        return {
            "ok": True,
            "name": name,
            "stickers": len(getattr(sticker_set, "stickers", []) or []),
            "updated": 0,
            "keys": [],
        }

    data = _read(OVERRIDE_FILE)
    existing = data.get("emoji")
    if not isinstance(existing, dict):
        existing = {}
    existing.update(updates)
    try:
        OVERRIDE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with OVERRIDE_FILE.open("w", encoding="utf-8") as handle:
            json.dump({"version": 1, "emoji": existing}, handle, ensure_ascii=False, indent=2)
    except OSError as exc:
        return {"ok": False, "name": name, "error": f"Không ghi được file: {exc}"}
    load(force=True)
    return {
        "ok": True,
        "name": name,
        "title": getattr(sticker_set, "title", name),
        "stickers": len(getattr(sticker_set, "stickers", []) or []),
        "updated": len(updates),
        "keys": sorted(updates)[:20],
    }


def decorate(text: str) -> str:
    """Expand ``[[key]]`` tokens into custom or fallback emoji."""
    if not text or "[[" not in text:
        return text
    entries = load()

    def replace(match: re.Match) -> str:
        key = match.group(1)
        meta = entries.get(key)
        if meta is None:
            return PREMIUM_EMOJI_FALLBACK or match.group(0)
        fallback = meta.get("char") or ""
        document_id = meta.get("id") or ""
        if _ENABLED and document_id and fallback:
            return f'<tg-emoji emoji-id="{document_id}">{fallback}</tg-emoji>'
        return fallback or match.group(0)

    return TOKEN_RE.sub(replace, text)


def has_custom(text: str) -> bool:
    return "<tg-emoji" in (text or "")


def strip_custom(text: str) -> str:
    """Replace ``<tg-emoji>`` tags with their plain fallback characters."""
    return TAG_RE.sub(lambda match: match.group(2), text or "")


def custom_emoji_ids(message) -> list[tuple[str, str]]:
    """Return ``(document_id, fallback)`` pairs found in a Telegram message."""
    found: list[tuple[str, str]] = []
    text = getattr(message, "text", None) or getattr(message, "caption", None) or ""
    entities = getattr(message, "entities", None) or getattr(message, "caption_entities", None) or []
    for entity in entities:
        document_id = getattr(entity, "custom_emoji_id", None)
        if not document_id:
            continue
        start = int(getattr(entity, "offset", 0))
        length = int(getattr(entity, "length", 0))
        # Telegram offsets are UTF-16 code units; the emoji itself is usually
        # one or two Python characters, so slice the decoded remainder.
        try:
            raw = text.encode("utf-16-le")
            piece = raw[start * 2 : (start + length) * 2].decode("utf-16-le", "ignore")
        except (UnicodeDecodeError, AttributeError):
            piece = ""
        found.append((str(document_id), piece.strip()))
    return found
