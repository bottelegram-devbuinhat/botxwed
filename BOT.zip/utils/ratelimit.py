"""Very small in-memory rate limiter used to debounce button presses."""

from __future__ import annotations

import time


class RateLimiter:
    def __init__(self, interval: float = 0.7) -> None:
        self.interval = interval
        self._last: dict[str, float] = {}

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        last = self._last.get(key, 0.0)
        if now - last < self.interval:
            return False
        self._last[key] = now
        if len(self._last) > 5000:  # keep memory bounded
            cutoff = now - 60
            self._last = {k: v for k, v in self._last.items() if v >= cutoff}
        return True


callback_limiter = RateLimiter(0.6)
