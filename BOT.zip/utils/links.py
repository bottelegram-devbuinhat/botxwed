"""Link helpers: bot deep links, referral links and share links."""

from __future__ import annotations

from urllib.parse import quote

from config import BOT_USERNAME


def bot_link() -> str:
    return f"https://t.me/{BOT_USERNAME}"


def referral_link(user_id: int) -> str:
    """Deep link that stores ``user_id`` as the referrer on /start."""
    return f"https://t.me/{BOT_USERNAME}?start={int(user_id)}"


def share_link(user_id: int, text: str = "Tham gia bot ngay!") -> str:
    url = quote(referral_link(user_id), safe="")
    return f"https://t.me/share/url?url={url}&text={quote(text, safe='')}"
