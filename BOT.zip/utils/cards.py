"""Shared building blocks that keep every screen visually consistent.

Screens use a ``『 icon  TITLE 』`` header followed by a light divider, key/value
rows and optional progress bars. Emoji are written as ``[[key]]`` tokens so the
premium emoji layer (``utils.emoji``) can upgrade them to animated stickers and
fall back to plain Unicode automatically.
"""

from __future__ import annotations

LINE = "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"
THIN = "┄┄┄┄┄┄┄┄┄┄┄┄┄┄"


def title(icon: str, text: str, divider: str = LINE) -> str:
    """Big section header, e.g. ``『 🛒  SHOP ACC 』``, ending with a newline."""
    return f"『 [[{icon}]]  <b>{text}</b>  』\n{divider}\n"


def sub(text: str) -> str:
    return f"<b>{text}</b>"


def kv(label: str, value: str) -> str:
    return f"{label}  <b>{value}</b>"


def bullet(icon: str, text: str) -> str:
    return f"  [[{icon}]] {text}"


def quote(text: str) -> str:
    return f"<blockquote>{text}</blockquote>"


def note(text: str) -> str:
    return f"<i>{text}</i>"


def bar(current: int, total: int, width: int = 8, filled: str = "▰", empty: str = "▱") -> str:
    total = max(1, int(total))
    ratio = max(0.0, min(1.0, int(current) / total))
    filled_len = int(round(ratio * width))
    return filled * filled_len + empty * (width - filled_len)


def percent(current: int, total: int) -> str:
    total = max(1, int(total))
    return f"{min(100, round(int(current) / total * 100))}%"
