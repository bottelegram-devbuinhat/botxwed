"""Central configuration loaded from environment variables."""

from __future__ import annotations

import os
import re
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
BACKUP_DIR = DATA_DIR / "backups"
DATA_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int) -> int:
    """Read an integer env value.

    A plain ``int()`` first (so "0.5" is not silently turned into 15) and only
    when that fails are thousand separators (1.000.000) removed.
    """
    raw = os.getenv(name)
    if not raw:
        return default
    value = str(raw).strip().replace("_", "").replace(" ", "")
    try:
        return int(value)
    except ValueError:
        pass
    if re.fullmatch(r"-?\d{1,3}(\.\d{3})+", value):
        try:
            return int(value.replace(".", ""))
        except ValueError:
            return default
    try:
        return int(float(value))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _ids(name: str, default: str = "") -> tuple[int, ...]:
    raw = os.getenv(name, default)
    result = []
    for part in raw.split(","):
        part = part.strip()
        if part.lstrip("-").isdigit():
            result.append(int(part))
    return tuple(result)


BOT_TOKEN: str = os.getenv("BOT_TOKEN", "").strip()
OWNER_IDS: tuple[int, ...] = _ids("OWNER_IDS")

# Public bot username, used to build referral links (https://t.me/<username>?start=<id>).
BOT_USERNAME: str = os.getenv("BOT_USERNAME", "devbn_bot").strip().lstrip("@")

# GitHub configuration for Mini App stock auto-sync
# GITHUB_TOKEN: Personal Access Token (classic with 'repo' scope or fine-grained with 'contents:write')
GITHUB_TOKEN: str = os.getenv("GITHUB_TOKEN", "").strip()
GITHUB_STOCK_REPO: str = os.getenv("GITHUB_STOCK_REPO", "bottelegram-devbuinhat/anhdev-store").strip()
GITHUB_STOCK_BRANCH: str = os.getenv("GITHUB_STOCK_BRANCH", "main").strip()
GITHUB_STOCK_PATH: str = os.getenv("GITHUB_STOCK_PATH", "stock.json").strip()

# ===== Cloudflare sync (cầu nối số dư bot <-> web store) =====
# URL Worker đã deploy, ví dụ https://anhdev-balance.abc.workers.dev
# Token dùng chung bot <-> Worker (Worker secret SYNC_BOT_TOKEN). Để trống = tắt sync.
CLOUDFLARE_SYNC_URL: str = os.getenv("CLOUDFLARE_SYNC_URL", "").strip().rstrip("/")
CLOUDFLARE_SYNC_TOKEN: str = os.getenv("CLOUDFLARE_SYNC_TOKEN", "").strip()
# Full sync toàn bộ ví (giây). Mặc định 300 = 5 phút.
CLOUDFLARE_SYNC_INTERVAL: int = max(60, _int("CLOUDFLARE_SYNC_INTERVAL", 300))
# Bao lâu kéo lệnh nạp tạo từ web về bot một lần (giây).
CLOUDFLARE_DEPOSIT_PULL_INTERVAL: int = max(30, _int("CLOUDFLARE_DEPOSIT_PULL_INTERVAL", 60))

# Extra admins that always have access, even before any database setting exists.
ADMIN_IDS: tuple[int, ...] = _ids("ADMIN_IDS", "8792000582")

# The only account allowed to credit its own wallet/coins from the admin panel.
SELF_TOPUP_ADMIN_ID: int = _int("SELF_TOPUP_ADMIN_ID", 8792000582)

# Premium (animated) Telegram emoji. Requires the bot owner to have Telegram
# Premium or a Fragment username for the bot; the bot degrades to plain emoji.
# Plain Unicode emoji by default: Telegram only accepts custom (animated) emoji
# from bots that own a Fragment username or whose owner has Telegram Premium, so
# enabling this without that setup makes the API reject every decorated message.
# Set PREMIUM_EMOJI=1 once the bot really has custom emoji rights.
PREMIUM_EMOJI: bool = os.getenv("PREMIUM_EMOJI", "0").strip().lower() not in ("0", "false", "off", "no")
PREMIUM_EMOJI_FALLBACK: str = os.getenv("PREMIUM_EMOJI_FALLBACK", "")

DATABASE_URL: str = os.getenv("DATABASE_URL") or f"sqlite+aiosqlite:///{DATA_DIR / 'bot.db'}"
FERNET_KEY: str = os.getenv("FERNET_KEY", "").strip()

BANK_CODE: str = os.getenv("BANK_CODE", "MB").strip()
BANK_ACCOUNT: str = os.getenv("BANK_ACCOUNT", "0000000000").strip()
BANK_HOLDER: str = os.getenv("BANK_HOLDER", "NGUYEN VAN A").strip()

SEPAY_API_KEY: str = os.getenv("SEPAY_API_KEY", "").strip()
SEPAY_ENABLED: bool = os.getenv("SEPAY_ENABLED", "1").strip().lower() not in ("0", "false", "off", "no")
WEBHOOK_HOST: str = os.getenv("WEBHOOK_HOST", "0.0.0.0")
WEBHOOK_PORT: int = _int("WEBHOOK_PORT", 8080)

def _split_list(name: str) -> list[str]:
    """Read a comma/newline separated env value into a de-duplicated list."""
    raw = os.getenv(name, "")
    items: list[str] = []
    for part in raw.replace(";", ",").replace("\n", ",").split(","):
        part = part.strip()
        if part and part not in items:
            items.append(part)
    return items


def _ai_keys() -> tuple[str, ...]:
    """Collect AI_API_KEY (comma/newline list) plus AI_API_KEY_2..AI_API_KEY_10."""
    keys: list[str] = []
    for name in ("AI_API_KEY", *(f"AI_API_KEY_{index}" for index in range(2, 11))):
        for key in _split_list(name):
            if key not in keys:
                keys.append(key)
    return tuple(keys)


def _provider_fallback() -> tuple[tuple[str, ...], str, str]:
    """No explicit AI_API_KEY? Use the provider keys already in .env.

    The deployment has Gemini/Groq keys in .env but no OpenAI key, so the
    bot picks the first provider that has keys and uses that provider's
    endpoint and default model for it. An explicit AI_BASE_URL / AI_MODEL
    in .env still wins over these defaults. Returns (keys, base_url, model).
    """
    for prefix, base_url, model in (
        ("GEMINI_API_KEY", "https://generativelanguage.googleapis.com/v1beta/openai/", "gemini-2.0-flash"),
        ("GROQ_API_KEY", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
    ):
        keys: list[str] = []
        for suffix in ("", "_1", "_2", "_3"):
            for key in _split_list(f"{prefix}{suffix}"):
                # Keys copied from bot1 sometimes carry a "gg:" label prefix; strip it.
                if key.startswith("gg:"):
                    key = key[3:]
                if key and key not in keys:
                    keys.append(key)
        if keys:
            return tuple(keys), base_url, model
    return (), "", ""


# AI assistant (any OpenAI-compatible endpoint: OpenAI, Groq, OpenRouter, Ollama...).
# Leave AI_API_KEY empty to keep the assistant disabled.
# Several keys are rotated automatically when one hits its rate limit.
AI_API_KEYS: tuple[str, ...] = _ai_keys()
_FALLBACK_KEYS, _FALLBACK_BASE_URL, _FALLBACK_MODEL = (
    _provider_fallback() if not AI_API_KEYS else ((), "", "")
)
if _FALLBACK_KEYS:
    AI_API_KEYS = _FALLBACK_KEYS
AI_API_KEY: str = AI_API_KEYS[0] if AI_API_KEYS else ""
AI_BASE_URL: str = os.getenv("AI_BASE_URL", "").strip() or _FALLBACK_BASE_URL or "https://api.openai.com/v1"
AI_MODEL: str = os.getenv("AI_MODEL", "").strip() or _FALLBACK_MODEL or "gpt-4o-mini"

# Routing: the chat answers short questions (cheap model), file extraction needs
# a stronger model but few calls. Both fall back to AI_MODEL / AI_MODELS.
AI_MODEL_CHAT: str = os.getenv("AI_MODEL_CHAT", "").strip() or AI_MODEL
AI_MODEL_EXTRACT: str = os.getenv("AI_MODEL_EXTRACT", "").strip() or AI_MODEL
AI_MODELS: tuple[str, ...] = tuple(
    model for model in _split_list("AI_MODELS") if model not in (AI_MODEL_CHAT, AI_MODEL_EXTRACT)
)

AI_TIMEOUT: int = _int("AI_TIMEOUT", 45)
# Chat budget stays small on purpose: short answers cost fewer tokens.
AI_MAX_TOKENS: int = _int("AI_MAX_TOKENS", 450)
AI_MAX_TOKENS_EXTRACT: int = _int("AI_MAX_TOKENS_EXTRACT", 1800)
# Global guard rails so a busy bot cannot burn the whole quota in one minute.
AI_REQUESTS_PER_MINUTE: int = _int("AI_REQUESTS_PER_MINUTE", 20)
AI_MAX_CONCURRENCY: int = _int("AI_MAX_CONCURRENCY", 3)
AI_KEY_COOLDOWN: int = _int("AI_KEY_COOLDOWN", 60)
AI_MODEL_COOLDOWN: int = _int("AI_MODEL_COOLDOWN", 900)
AI_HISTORY_CHARS: int = _int("AI_HISTORY_CHARS", 600)
# Reasoning models (gpt-oss, o-series) spend output tokens thinking; "low" cuts
# that cost a lot. Empty = do not send the parameter (safe for any provider).
AI_REASONING_EFFORT: str = os.getenv("AI_REASONING_EFFORT", "").strip().lower()

# Largest account import file accepted from the admin panel (bytes).
IMPORT_MAX_BYTES: int = _int("IMPORT_MAX_BYTES", 1_000_000)
IMPORT_MAX_ROWS: int = _int("IMPORT_MAX_ROWS", 300)

CARD_API_URL: str = os.getenv("CARD_API_URL", "").strip()
CARD_API_KEY: str = os.getenv("CARD_API_KEY", "").strip()
CARD_FEE_PERCENT: int = _int("CARD_FEE_PERCENT", 20)

SUPPORT_USERNAME: str = os.getenv("SUPPORT_USERNAME", "@your_support").strip()
CHANNEL_USERNAME: str = os.getenv("CHANNEL_USERNAME", "@your_channel").strip()
GROUP_USERNAME: str = os.getenv("GROUP_USERNAME", "@your_group").strip()

TIMEZONE: str = os.getenv("TIMEZONE", "Asia/Ho_Chi_Minh")
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()
BACKUP_KEEP_DAYS: int = _int("BACKUP_KEEP_DAYS", 14)

# How long an account stays locked while a buyer is on the confirmation screen.
ACCOUNT_HOLD_MINUTES: int = _int("ACCOUNT_HOLD_MINUTES", 7)

# Default persisted settings. Admins can change almost all of them from the UI.
DEFAULT_SETTINGS: dict = {
    "maintenance": False,
    "maintenance_text": "🛠 Bot đang bảo trì, vui lòng quay lại sau ít phút.",
    "admin_ids": list(ADMIN_IDS),
    "support_rating_enabled": True,
    "ai_enabled": True,
    "ai_model": "",
    "ai_system_prompt": "",
    "feature_shop": True,
    "feature_sell": True,
    "feature_deposit": True,
    "feature_withdraw": True,
    "feature_casino": True,
    "feature_rewards": True,
    "feature_support": True,
    "min_deposit": 20000,
    "max_deposit": 5000000,
    "min_withdraw": 50000,
    "max_withdraw": 2000000,
    "withdraw_fee_percent": 0,
    "commission_percent": 10,
    "warranty_days_default": 3,
    "vip_discount": {"0": 0, "1": 2, "2": 4, "3": 6, "4": 8, "5": 10},
    "checkin_base_coins": 200,
    "checkin_vip_bonus": 100,
    "referral_bonus_coins": 1000,
    "casino_min_bet": 100,
    "casino_max_bet": 100000,
    "casino_rtp": 0.96,
    "casino_cooldown_seconds": 2,
    "jackpot": 0,
    "jackpot_contribution_percent": 2,
    "deposit_promotion": {"enabled": False, "threshold": 500000, "percent": 5},
    "game_enabled": {
        "taixiu": True,
        "chanle": True,
        "xocdia": True,
        "baucua": True,
        "rongho": True,
        "baccarat": True,
        "blackjack": True,
        "slots": True,
        "roulette": True,
        "highlow": True,
        "numberguess": True,
        "mysterybox": True,
    },
    "required_channels": [],
    "terms_text": (
        "• Xu casino là tiền ảo giải trí, không mua được bằng tiền thật và không quy đổi ra tiền.\n"
        "• Shop acc hoạt động theo hình thức ký gửi, bảo hành theo từng acc.\n"
        "• Mọi giao dịch nạp/rút cần admin duyệt hoặc cổng thanh toán xác nhận."
    ),
    "faq_text": (
        "❓ <b>Câu hỏi thường gặp</b>\n\n"
        "<b>1. Nạp tiền bao lâu thì được cộng?</b>\n"
        "Chuyển khoản đúng nội dung, hệ thống tự cộng hoặc admin duyệt trong 5-30 phút.\n\n"
        "<b>2. Mua acc nhận ở đâu?</b>\n"
        "Ngay trong tin nhắn xác nhận mua thành công, kèm hướng dẫn đổi mật khẩu.\n\n"
        "<b>3. Bảo hành thế nào?</b>\n"
        "Mỗi acc có số ngày bảo hành riêng. Trong thời gian đó, nếu lỗi hãy bấm ⚠️ Báo lỗi trong đơn.\n\n"
        "<b>4. Xu casino dùng làm gì?</b>\n"
        "Chơi game giải trí, leo bảng xếp hạng và nhận quà. Không quy đổi ra tiền hay acc."
    ),
}
