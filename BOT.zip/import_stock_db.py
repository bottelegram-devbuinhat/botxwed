import asyncio
import glob
import json
import os
import sys
from collections import OrderedDict

# Add BOT to sys.path
BOT_DIR = r"c:\Users\Admin\Videos\New folder (2)\BOT"
ACC_DIR = r"c:\Users\Admin\Videos\acc"
sys.path.insert(0, BOT_DIR)
sys.path.insert(0, ACC_DIR)

import xuat_file_bot_telegram as x
from database.models import Account
from database.session import init_db, session_scope
from services import crypto_service
from sqlalchemy import delete, func, select


async def import_all_stock():
    print("Khởi tạo database...")
    await init_db()

    print("Đọc và phân tích toàn bộ tài khoản từ các file nguồn...")
    files_to_process = sorted(glob.glob(os.path.join(x.TARGET_DIR, "Hits_*.txt"))) + [
        os.path.join(x.TARGET_DIR, "acc_p10k_10000.txt"),
        os.path.join(x.TARGET_DIR, "ket-qua-11651acc.txt"),
    ]

    merged_accounts = OrderedDict()
    for fp_path in files_to_process:
        fn = os.path.basename(fp_path)
        with open(fp_path, "r", encoding="utf-8", errors="ignore") as fp:
            for line in fp:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("⚠️") or line.startswith("❌") or line.startswith("⏱"):
                    continue

                res, err = x.parse_account_line(line, fn)
                if err:
                    continue

                tk_key = res["tk"].lower()
                if tk_key in merged_accounts:
                    prev = merged_accounts[tk_key]
                    if res["score"] > prev["score"]:
                        merged_accounts[tk_key] = res
                else:
                    merged_accounts[tk_key] = res

    total_acc = len(merged_accounts)
    print(f"Tổng số tài khoản duy nhất: {total_acc}")

    tinh_anh_plus = {"Tinh Anh", "Cao Thủ", "Chiến Tướng", "Thách Đấu"}

    # Chia nhóm theo đúng quy định Task 3
    # 1. Acc trắng: có khu vực riêng, giá 7.000đ
    # 2. Thứ nguyên vệ thần: nếu bán (for sale) -> vào RANDOM; chỉ vào READY-INFO nếu NOT for sale
    # 3. VIP (Tinh Anh+, >= 400 skin): vào READY-INFO
    # 4. Toàn bộ acc còn lại từ phân loại kho: vào RANDOM
    white_accs = []
    vip_info_accs = []
    random_accs = []

    for acc in merged_accounts.values():
        is_tnvt = x.has_thu_nguyen_ve_than(acc)
        is_white = acc["is_white"]
        is_vip = (acc["rank"] in tinh_anh_plus) or (acc["skin"] >= 400)

        if is_white:
            acc["target_kind"] = "white"
            acc["target_price"] = 7000
            white_accs.append(acc)
        elif is_tnvt:
            # TNVT đang bán -> vào RANDOM
            acc["target_kind"] = "random"
            line = x.build_account_line(acc, force_price=None)
            price = int(line.split(" | ")[0])
            acc["target_price"] = price  # giữ giá xứng đáng với TNVT (24k/32k)
            random_accs.append(acc)
        elif is_vip:
            if acc["is_ban"]:
                # Acc ban ở acc sẵn thông tin chuyển qua random
                acc["target_kind"] = "random"
                acc["target_price"] = 3000
                random_accs.append(acc)
            else:
                acc["target_kind"] = "info"
                line = x.build_account_line(acc, force_price=None)
                price = int(line.split(" | ")[0])
                acc["target_price"] = price
                vip_info_accs.append(acc)
        else:
            acc["target_kind"] = "random"
            acc["target_price"] = 3000
            random_accs.append(acc)

    print(f"  - Kho Random: {len(random_accs)} acc")
    print(f"  - Acc Sẵn Thông Tin (VIP): {len(vip_info_accs)} acc")
    print(f"  - Acc Trắng: {len(white_accs)} acc")

    # Sắp xếp các danh sách để đánh mã LQ0001 liên tục, không ngắt quãng
    # Xếp thứ tự: VIP (info) trước, rồi đến White, rồi đến Random
    all_ordered = vip_info_accs + white_accs + random_accs

    async with session_scope() as session:
        # Xóa các acc cũ chưa có đơn hàng
        print("Làm sạch bảng accounts cũ...")
        await session.execute(delete(Account))
        await session.flush()

        print("Bắt đầu nạp dữ liệu vào database theo lô 500 acc...")
        batch_size = 500
        for i in range(0, len(all_ordered), batch_size):
            batch = all_ordered[i : i + batch_size]
            for idx, acc in enumerate(batch, start=i + 1):
                code = f"LQ{idx:04d}"
                c = acc["counts"]
                sss_cnt = c["sss"]
                ss_cnt = c["ss"]
                ss_plus_cnt = c["ss+"]
                s_plus_cnt = c["s+"]
                ssm_cnt = c["ssm"]
                anime_cnt = c["anime"]

                skin_summary_str = f"(sss:{sss_cnt}, ss:{ss_cnt}, ss+:{ss_plus_cnt}, s+:{s_plus_cnt}, ssm:{ssm_cnt}, anime:{anime_cnt})"
                
                # Danh mục
                if sss_cnt > 0:
                    cat = "100% Skin SSS"
                    rare = ", ".join(acc["sss"])
                elif (ss_cnt + ss_plus_cnt) > 0:
                    cat = "100% Skin SS / SS+"
                    rare = ", ".join(acc["ss"][:5])
                elif anime_cnt > 0:
                    cat = "100% Skin Anime"
                    rare = ", ".join(acc["anime"][:5])
                else:
                    cat = "Skin thường (theo rank)"
                    rare = ""

                desc = f"[{cat}] {skin_summary_str} - {acc['status_label']}"
                
                skin_lists_json = json.dumps({
                    "sss": acc["sss"],
                    "ss": acc["ss"],
                    "ss_plus": acc["ss_plus"],
                    "s_plus": acc["s_plus"],
                    "ssm": acc["ssm"],
                    "anime": acc["anime"],
                }, ensure_ascii=False)

                # Raw info đầy đủ dùng cho tìm kiếm VIP và hiển thị đầy đủ
                raw_info = acc.get("raw") or ""
                if not raw_info or not acc["is_rich"]:
                    raw_info = f"{acc['tk']}:{acc['mk']} | Rank={acc['rank']} | Tướng={acc['tuong']} | Skin={acc['skin']} | {cat} | {acc['status_label']}"

                account_row = Account(
                    code=code,
                    price=acc["target_price"],
                    rank=acc["rank"][:64],
                    level=30,
                    heroes=acc["tuong"],
                    skins=acc["skin"],
                    rare_skins=rare[:255],
                    login_type=acc["login_type"][:32],
                    warranty_days=3,
                    description=desc[:4000],
                    photos="[]",
                    username_enc=crypto_service.encrypt(acc["tk"]),
                    password_enc=crypto_service.encrypt(acc["mk"]),
                    status="available",
                    is_hidden=False,
                    views=0,
                    kind=acc["target_kind"],
                    category=cat[:32],
                    is_banned=acc["is_ban"],
                    ban_note="BAN" if acc["is_ban"] else "",
                    ss_count=ss_cnt,
                    splus_count=s_plus_cnt,
                    s_count=0,
                    evo_count=ss_plus_cnt,
                    anime_count=anime_cnt,
                    dreamer_count=0,
                    other_count=len(acc["other"]),
                    skin_lists=skin_lists_json,
                    extra=raw_info,
                )
                session.add(account_row)
            await session.flush()
            print(f"  Đã nạp {min(i + batch_size, len(all_ordered))}/{len(all_ordered)} acc...")

    print("Hoàn tất nạp dữ liệu vào kho!")


if __name__ == "__main__":
    asyncio.run(import_all_stock())
