# 🤖 Bot Telegram — Shop Acc Liên Quân + Casino Xu Ảo (Full)

Bot Telegram viết bằng **Python 3.11+ / aiogram 3**, gồm 3 khối:

1. **Shop acc Liên Quân Mobile**: mua, bán, ký gửi, bảo hành, đánh giá, yêu thích.
2. **Casino giải trí bằng xu ảo**: 12 game, bảng xếp hạng, nhiệm vụ, vòng quay.
3. **Hệ thống quản trị**: người chơi, kho acc, đơn hàng, nạp/rút, giftcode, ticket, broadcast, backup.

Toàn bộ giao diện tiếng Việt (mặc định), có thể chuyển sang tiếng Anh trong 👤 Tài khoản → ⚙️ Cài đặt.

> ⚠️ **Xu casino là tiền ảo giải trí**: không mua bằng tiền thật, không quy đổi ra tiền hoặc acc.
> Khu casino dành cho người từ 18 tuổi. Hãy chơi có trách nhiệm.

---

## 1. Cài đặt nhanh

```bash
cd bot
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Sửa .env: BOT_TOKEN, OWNER_IDS, FERNET_KEY, thông tin ngân hàng...

python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# Dán key vừa in vào FERNET_KEY trong .env

python main.py
```

Yêu cầu tối thiểu: `BOT_TOKEN` và `OWNER_IDS`. Nếu thiếu `FERNET_KEY`, bot tự tạo file
`data/fernet.key` (chỉ dùng cho môi trường thử nghiệm — production nên đặt biến môi trường).

Bot chạy long polling. Database SQLite tự tạo tại `data/bot.db`, kèm dữ liệu mẫu
(4 acc demo, 3 giftcode: `WELCOME`, `TET2026`, `SHOP50K`).

### Biến môi trường chính

| Biến | Ý nghĩa |
|---|---|
| `BOT_TOKEN` | Token bot từ @BotFather |
| `OWNER_IDS` | ID Telegram của chủ bot, cách nhau bằng dấu phẩy |
| `BOT_USERNAME` | Username bot (không có `@`) để tạo link ref — mặc định `devbn_bot` |
| `ADMIN_IDS` | Admin luôn có quyền, mặc định `8792000582` |
| `PREMIUM_EMOJI` | `1`/`0` — bật emoji động Telegram, tự hạ cấp về emoji thường |
| `DATABASE_URL` | Mặc định SQLite; đổi sang PostgreSQL chỉ cần sửa URL |
| `FERNET_KEY` | Khoá mã hoá tài khoản/mật khẩu acc |
| `BANK_CODE`, `BANK_ACCOUNT`, `BANK_HOLDER` | Thông tin nhận chuyển khoản + VietQR |
| `SEPAY_API_KEY` | (Tuỳ chọn) bật webhook nạp tự động qua SePay |
| `CARD_API_URL`, `CARD_API_KEY`, `CARD_FEE_PERCENT` | (Tuỳ chọn) cổng đổi thẻ cào |
| `SUPPORT_USERNAME`, `CHANNEL_USERNAME`, `GROUP_USERNAME` | Liên hệ hiển thị trong bot |
| `AI_API_KEY` | Key của API OpenAI-compatible cho trợ lý AI (để trống = tắt trợ lý) |
| `AI_BASE_URL`, `AI_MODEL` | Endpoint và model, mặc định `https://api.openai.com/v1` + `gpt-4o-mini` |
| `AI_TIMEOUT`, `AI_MAX_TOKENS` | Thời gian chờ và độ dài trả lời của trợ lý |
| `IMPORT_MAX_BYTES`, `IMPORT_MAX_ROWS` | Giới hạn file và số acc mỗi lần admin nhập từ file |

Nạp tự động: đặt `SEPAY_API_KEY`, mở port `WEBHOOK_PORT` (mặc định 8080) và trỏ webhook SePay/Casso
tới `http://<ip>:8080/sepay/webhook`. Nội dung chuyển khoản phải chứa mã `NAP<id>T<xxxx>` mà bot cấp.
Không cấu hình webhook thì bot dùng luồng **admin duyệt tay** qua ảnh biên lai.

### Link giới thiệu

Mỗi người chơi có link riêng dạng `https://t.me/<BOT_USERNAME>?start=<user_id>` (mặc định
`https://t.me/devbn_bot?start=<id>`), xem và chia sẻ ở **🎁 Phần thưởng → 👥 Mời bạn**.
Khi người mới bấm `/start` qua link, người mời được cộng `referral_bonus_coins` (mặc định 1.000 xu),
chống cộng trùng bằng `Transaction.ref = referral:<id người mới>`.

### Emoji động (premium)

Giao diện dùng bộ emoji token `[[coin]]`, `[[gift]]`... trong `assets/emoji.json` — bộ sưu tập emoji động
miễn phí lấy từ các pack công khai (RestrictedEmoji, tgmacicons, vector_icons_by_fStikBot, NewsEmoji...).

- Bot gửi `<tg-emoji emoji-id="...">` khi được phép, ngược lại tự hiển thị emoji Unicode nên **không bao giờ lỗi**.
- Telegram chỉ cho bot dùng emoji động khi **chủ bot có Telegram Premium** hoặc bot đã mua username trên Fragment.
- Admin xem trạng thái bằng `/emoji`, thử bằng `/testemoji`, gán id mới bằng cách trả lời tin nhắn chứa emoji
  động rồi gõ `/setemoji <key>` (lưu vào `data/emoji.json`). Nút **✨ Emoji động** nằm trong `/admin`.

### Hai kho acc & thẻ thông tin đầy đủ

Shop tách làm 2 kho giống các shop acc AOV lớn:

| Kho | Nội dung |
|---|---|
| 💎 **Kho Random** | Acc giá rẻ, bán ngẫu nhiên theo mức giá, thông tin ẩn tới khi mua |
| 🌐 **Acc sẵn thông tin** | Bán kèm thẻ info đầy đủ: UID, region, sò, nạp sò, email/SĐT, PASS, 2FA, CCCD, FB, **trạng thái ban**, rank, level, skin + hero, skin SS/S+/S/EVO/Anime/Dreamer/Other (kèm tên skin), login cuối, ngày tạo acc |

Admin nhập acc bằng 2 luồng riêng trong **🛠 Admin → 🛍 Kho acc**:

- **🌐 Acc full info** — nhập `giá | loại` (ví dụ `500000 | 3S`), sau đó dán block kiểm tra acc
  (định dạng 🔑 `user:pass`, UID, RANK, SKIN, BAND…) hoặc gửi file `.txt`. Bot tự tách nhiều acc
  (cách nhau bằng dòng `━━━`), đọc ban/2FA/CCCD/skin theo từng tier, tự đoán loại `3S/2S/1S/Anime/SS`
  nếu admin để trống, và lưu tên skin để hiển thị trong thẻ acc.
- **🎲 Kho random** — nhập `giá | tên loại`, sau đó dán mỗi dòng `user:pass` (thêm ` | rank` nếu muốn).
- **📥 Nhập file** vẫn dùng cho `.csv`/`.json`/`.txt` cơ bản; nếu file là block full info, bot tự nhận ra và
  hỏi giá rồi nhập tiếp. Nếu file không khớp định dạng nào, bot tự chuyển sang **🤖 AI đọc file acc**.
- **🤖 AI đọc file acc** — gửi file lộn xộn (`.txt/.csv/.json`) hoặc dán nội dung; AI tách từng acc thành
  giá, rank, level, tướng, skin, user/pass, đăng nhập, ban/không ban, UID, email, SĐT, bảo hành, mô tả.
  Mỗi dòng vẫn được kiểm tra lại (giá > 0, có user/pass) trước khi ghi DB, AI không bịa acc hay giá.

DB cũ được tự động nâng cấp: `init_db()` thêm các cột mới vào bảng `accounts` khi khởi động (SQLite và PostgreSQL).

### Emoji động theo pack của bạn

Ngoài bộ emoji có sẵn, admin nạp thêm pack bằng lệnh:

```text
/addpack NewsEmoji
/addpack https://t.me/addemoji/BirthdayCollection
```

Bot gọi Bot API `getStickerSet`, ghép `custom_emoji_id` của pack vào đúng emoji đang dùng trong giao diện
(💎 ✨ 🔥 💰 …) và lưu vào `data/emoji.json`. Nếu bot chưa có quyền custom emoji thì tự hiển thị emoji thường.

### Trợ lý AI (hỗ trợ + quản lý)

Bot có trợ lý AI dùng **bất kỳ API OpenAI-compatible nào** (OpenAI, Groq, OpenRouter, Gemini compat,
Ollama nội bộ...) — chỉ cần đổi `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`. Không có key thì menu vẫn mở
và hướng dẫn admin cấu hình, bot hoạt động bình thường.

**Phân luồng & tiết kiệm token:** bot chia việc theo độ đắt — chat ngắn dùng `AI_MODEL_CHAT` (model rẻ,
`AI_MAX_TOKENS=450`, history và câu hỏi bị cắt ngắn), chỉ việc đọc file acc mới dùng `AI_MODEL_EXTRACT`
(`AI_MAX_TOKENS_EXTRACT`), chia file thành phần 6k ký tự, tối đa 4 phần và cache kết quả 5 phút nên gửi lại
cùng file không tốn thêm token. Nhiều key: `AI_API_KEY="key1,key2"` hoặc `AI_API_KEY_2..AI_API_KEY_10` —
key bị **429/401 tự tạm khoá và chuyển key kế tiếp**; model lỗi/không tồn tại tự nhảy sang `AI_MODELS` dự phòng.
Có thêm `AI_REQUESTS_PER_MINUTE` (mặc định 20), `AI_MAX_CONCURRENCY` (3) và cooldown `AI_KEY_COOLDOWN` /
`AI_MODEL_COOLDOWN`. Model reasoning (gpt-oss, o-series) tốn token để “suy nghĩ” — đặt `AI_REASONING_EFFORT=low`
(nếu provider không nhận tham số này bot tự bỏ và thử lại) giúp giảm mạnh token trả về. Trạng thái key/model, token đã dùng và số lần 429 xem ở **🛠 Admin → 🤖 Trợ lý AI**
(nút ♻️ Bỏ chờ key/model để dùng lại ngay).

Người chơi mở **🤖 Trợ lý AI** (hoặc `/ai`) và hỏi bằng tiếng Việt tự nhiên. Trợ lý **không bịa số liệu**:
mỗi câu trả lời về kho, giá, số lượng, đơn hàng hay số dư đều lấy từ công cụ đọc database thật:

| Công cụ | Việc trợ lý làm được |
|---|---|
| `kho_acc` | Liệt kê acc đang bán, lọc theo giá/rank, kèm giá và số lượng phù hợp |
| `chi_tiet_acc` | Thông tin một acc theo mã: giá, rank, tướng, skin, bảo hành, trạng thái |
| `thong_ke_kho` | Tồn kho theo trạng thái, giá thấp nhất/cao nhất, các rank đang có |
| `vi_cua_toi`, `don_hang_cua_toi` | Số dư shop/xu, VIP, đơn đã mua và hạn bảo hành |
| `dat_cuoc` | Đặt cược hộ một ván cụ thể (đúng game, xu, cửa) rồi báo kết quả thật |
| `hoan_tien_don` | Admin: hoàn tiền ngay. Người chơi: tạo ticket bảo hành gửi admin duyệt |

Admin quản lý trợ lý ở **🛠 Admin → 🤖 Trợ lý AI**: bật/tắt, đổi model, sửa system prompt, và **test**
câu trả lời ngay trong Telegram. Trợ lý chỉ đặt cược khi người dùng yêu cầu rõ ràng; xu vẫn là tiền ảo,
không quy đổi ra tiền.

---

## 2. Chức năng

### Người chơi
- `/start`: đăng ký tự động, menu inline + reply keyboard.
- 🛒 **Mua acc**: 2 kho (💎 Random mua ngẫu nhiên theo mức giá · 🌐 Acc sẵn thông tin với thẻ info đầy đủ gồm trạng thái ban, sò, email/SĐT, 2FA, CCCD, skin theo tier), lọc theo giá/rank/mới nhất/xem nhiều, tìm theo mã, yêu thích, chi tiết nhiều ảnh, mua khoá acc nguyên tử (không bán trùng), nhận tài khoản + hướng dẫn đổi mật khẩu, báo lỗi bảo hành, đánh giá sao.
- 💰 **Bán / Ký gửi**: form FSM 9 bước (rank, tướng, skin, giá, login, tài khoản, mật khẩu, mô tả, ảnh), chờ admin duyệt, sửa giá, xoá, xem thu nhập, rút tiền.
- 💳 **Nạp tiền**: VietQR tự tạo theo từng lệnh nạp, MoMo/ZaloPay (duyệt tay), thẻ cào qua API, lịch sử nạp, khuyến mãi nạp.
- 💸 **Rút tiền**: FSM 4 bước + màn hình xác nhận, tạm giữ tiền, admin duyệt/từ chối (hoàn tiền).
- 🎰 **Casino xu ảo**: Tài Xỉu, Chẵn Lẻ, Xóc Đĩa, Bầu Cua, Rồng Hổ, Baccarat, Blackjack (rút/dừng nhiều lượt), Slots (nổ hũ), Roulette, Cao Thấp, Đoán Số, Hộp Quà. Có luật chơi, lịch sử, cược lại, x2, seed công khai từng ván.
- 🎁 **Phần thưởng**: điểm danh chuỗi ngày, 4 nhiệm vụ/ngày (nhận thưởng bằng nút), vòng quay 24h, giftcode, mời bạn (link ref `t.me/devbn_bot?start=<id>`, thưởng xu cho người mời) + chia sẻ link.
- 🏆 **Bảng xếp hạng**: nạp, mua, xu, thắng, thắng lớn nhất, giới thiệu, chuỗi điểm danh × ngày/tuần/tháng/tất cả, ẩn tên, vị trí của tôi.
- 🆘 **Hỗ trợ**: ticket (5 loại), FAQ, liên hệ admin/kênh, trả lời trong ticket, đóng và đánh giá 1-5 sao.
- 🤖 **Trợ lý AI**: hỏi đáp tự nhiên về acc/giá/số lượng/đơn hàng/ví, đặt cược hộ, yêu cầu hoàn tiền — xem mục *Trợ lý AI* ở trên. Dùng `/ai` hoặc nút 🤖 trong menu chính.
- 📖 **Hướng dẫn**: 5 trang có nút ◀️ ▶️.

### Admin (`/admin` hoặc nút 🛠 Admin)
- 📊 Thống kê: user, acc, đơn, nạp, tổng số dư, tổng xu, hũ.
- 👥 Người chơi: phân trang, tìm theo ID, cộng/trừ tiền & xu (chọn nhanh số tiền → lý do → xác nhận), ban/unban, mute casino, set VIP, nhắn tin, xem lịch sử.
- 🛍 Kho acc: danh sách, thêm acc (một dòng), **nhập acc full info từ block kiểm tra**, **nhập kho random**, **nhập hàng loạt từ file .txt/.csv/.json**, **🤖 AI đọc file acc**, sửa giá, ẩn/hiện, xoá, duyệt/từ chối acc ký gửi.
- 👤 Menu người dùng: nút cuối bảng điều khiển chuyển sang giao diện người chơi; trong menu người dùng, admin bấm 🛠 Admin để quay lại.
- 🧾 Đơn hàng: chi tiết, hoàn tiền, hoàn tất, ghi chú.
- 💳 Nạp tiền / 💸 Rút tiền: xem biên lai, duyệt/từ chối, thông báo cho user.
- 🎟 Giftcode: tạo mã, bật/tắt.
- 🆘 Ticket: xem thread, trả lời (gửi thẳng cho user), đóng.
- 🎰 Casino: bật/tắt từng game, sửa min/max cược + RTP, reset hũ.
- ⚙️ Cài đặt: bật/tắt shop, ký gửi, nạp, rút, casino, phần thưởng, hỗ trợ, bảo trì.
- 🤖 Trợ lý AI: bật/tắt, đổi model, sửa system prompt, test trả lời.
- 📢 Broadcast, 💾 Backup SQLite, 📜 Log thao tác admin.

### Nhập acc từ file (admin)

**🛠 Admin → 🛍 Kho acc → 📥 Nhập file**, gửi file (hoặc dán nội dung) theo một trong các dạng:

```text
# .txt — mỗi dòng một acc (7 phần bắt buộc, phần 8 là mô tả)
500000 | Kim Cương | 80 | 40 | Facebook | user123 | pass123 | Acc tâm huyết
```

```csv
# .csv — có thể có dòng tiêu đề, thứ tự cột tuỳ ý, hỗ trợ tên cột tiếng Việt
price,rank,level,heroes,skins,login_type,warranty_days,username,password,description
500000,Kim Cương,120,80,40,Facebook,7,user123,pass123,Acc tâm huyết
```

```json
[
  {"price": 500000, "rank": "Kim Cương", "heroes": 80, "skins": 40,
   "login_type": "Facebook", "username": "user123", "password": "pass123",
   "warranty_days": 7, "description": "Acc tâm huyết"}
]
```

- Nhận cả giá dạng `500k`, `1.250.000`; dòng bắt đầu bằng `#` là ghi chú, bị bỏ qua.
- Acc hợp lệ được tạo ngay (mã `LQxxxx`, mật khẩu mã hoá bằng `FERNET_KEY`), báo lại số acc đã thêm và
  danh sách dòng lỗi kèm số dòng để admin sửa.
- Giới hạn mặc định 300 acc và 1 MB mỗi lần (`IMPORT_MAX_ROWS`, `IMPORT_MAX_BYTES`).

---

## 3. Cấu trúc

```
bot/
├── main.py                 # entry point
├── config.py               # env + settings mặc định
├── locales/                # vi.py (mặc định), en.py
├── database/               # models, session, seed
├── services/               # wallet, shop, casino, payment, crypto, ranking, rewards, settings
├── handlers/               # start, profile, wallet, shop, sell, casino/, admin/, ...
├── keyboards/              # inline/reply keyboards theo module
├── middlewares/            # context, ban/bảo trì, kênh bắt buộc, throttle
├── scheduler/              # nhả acc giữ, backup, thưởng BXH tuần
├── utils/                  # money, logger, ratelimit, permissions, notifications, logs
└── tests/                  # smoke test nghiệp vụ
```

Chuyển sang PostgreSQL: đổi `DATABASE_URL=postgresql+asyncpg://user:pass@host/db`
và cài thêm `asyncpg`.

---

## 4. Kiểm thử

```bash
cd bot
.venv/bin/python tests/smoke.py
```

Smoke test dùng SQLite tạm, kiểm tra: đăng ký user, nạp tiền, mua acc (trừ tiền + đơn hàng),
casino, điểm danh, giftcode (chống dùng trùng), nhiệm vụ, rút tiền + hoàn tiền, duyệt nạp, BXH, đánh giá.

---

## 5. Triển khai

### Docker
```bash
cp .env.example .env   # điền cấu hình
docker compose up -d --build
```

### VPS (systemd)
```ini
[Unit]
Description=Telegram shop casino bot
After=network.target

[Service]
WorkingDirectory=/opt/bot
ExecStart=/opt/bot/.venv/bin/python main.py
Restart=always
RestartSec=5
EnvironmentFile=/opt/bot/.env

[Install]
WantedBy=multi-user.target
```

### Termux (điện thoại)
```bash
pkg install python
pip install -r requirements.txt
python main.py
```

Lưu ý: `data/` chứa database, log, backup và (nếu chưa đặt `FERNET_KEY`) file khoá — sao lưu thư mục này.

---

## 6. Bảo mật & lưu ý

- Tài khoản/mật khẩu acc được mã hoá **Fernet** trước khi lưu; không lưu plaintext.
- Mọi thao tác tiền/xu dùng cập nhật có điều kiện (`balance >= amount`) trong transaction, chống âm ví và mua trùng acc.
- Giới hạn tần suất bấm nút, kiểm tra quyền admin ở cấp router, chống credit trùng bằng `Transaction.ref` unique.
- Không commit `.env` hay `data/`.
- Bot hỗ trợ vận hành shop/ký gửi acc; bạn tự chịu trách nhiệm về tính hợp pháp của việc kinh doanh acc và quy định của nhà phát hành game.
- Casino chỉ dùng xu ảo, không có cơ chế mua/đổi xu ra tiền — giữ nguyên nguyên tắc này khi tuỳ chỉnh.

---

# 🤖 Telegram Bot — Arena of Valor Account Shop + Virtual-Coin Casino

Python 3.11+ / aiogram 3 bot with three blocks: Liên Quân account shop (buy, consign, warranty, reviews), a virtual-coin casino with 12 games and leaderboards, and a full admin panel.

**Quick start:** `python -m venv .venv && pip install -r requirements.txt`, copy `.env.example` to `.env`, fill `BOT_TOKEN`, `OWNER_IDS`, `FERNET_KEY` and bank details, then `python main.py`. SQLite and sample data are created automatically.

**Payments:** VietQR per deposit with a unique `NAP<id>T<xxxx>` memo, manual admin approval via receipt photo, optional SePay webhook (`/sepay/webhook`, port 8080) and optional prepaid-card provider API.

**Coins:** virtual only — never purchasable with money and never cashable. Casino is 18+ and shows a responsible-play notice.

**Admin:** `/admin` opens statistics, players (balance/coins adjustments, ban, mute, VIP, DM), inventory, orders (refund/complete), deposits & withdrawals approval, giftcodes, tickets, per-game toggles and RTP, maintenance/feature switches, broadcast, SQLite backup, action logs and a premium-emoji panel.

**Referrals:** every player gets `https://t.me/<BOT_USERNAME>?start=<user_id>` (default `devbn_bot`); the inviter is credited `referral_bonus_coins` once per new player.

**Premium emoji:** UI tokens (`[[coin]]`, `[[gift]]`, ...) resolve to free animated emoji from public packs when the bot may send custom emoji (bot owner has Telegram Premium, or the bot owns a Fragment username) and fall back to plain Unicode otherwise. Admins can inspect with `/emoji`, test with `/testemoji` and bind their own ids with `/setemoji <key>` as a reply to a message containing the emoji.

**AI routing:** work is split by cost — short chat answers use `AI_MODEL_CHAT` with a small `AI_MAX_TOKENS` budget and trimmed history/question, while account-file extraction uses `AI_MODEL_EXTRACT` with 6k-character chunks, at most 4 chunks and a 5-minute result cache (re-sending the same file costs nothing). Several keys can be configured (`AI_API_KEY="key1,key2"` or `AI_API_KEY_2..10`); a key returning **429/401 is parked and the next key is used**, a missing model moves to the next model in `AI_MODELS`, and `AI_REQUESTS_PER_MINUTE` / `AI_MAX_CONCURRENCY` / `AI_KEY_COOLDOWN` / `AI_MODEL_COOLDOWN` cap the load. **🛠 Admin → 🤖 Trợ lý AI** shows key/model health, tokens used and 429 count, with a ♻️ reset button.

**AI assistant:** `/ai` or the 🤖 button opens an AI helper that works with any OpenAI-compatible API (`AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`) and answers only from live tools — account stock/prices/quantities (`kho_acc`, `chi_tiet_acc`, `thong_ke_kho`), wallet and orders, placing a specific casino bet (`dat_cuoc`) and refunds (`hoan_tien_don`: admins refund instantly, players get a warranty ticket). Admins manage it under `/admin` → 🤖 Trợ lý AI (toggle, model, system prompt, live test).

**Two storefronts:** 💎 Random pool (random draw by price, details hidden) and 🌐 full-info accounts whose card shows UID, region, shells, email/phone flags, 2FA, CCCD, Facebook, **ban status**, rank/level/skins with SS/S+/S/EVO/Anime/Dreamer tier lists. Admins add full-info stock by pasting their checker dumps (`/admin` → 🛍 Kho acc → 🌐 Acc full info: price, then blocks) and random stock as `user:pass` lines.

**Emoji packs:** `/addpack NewsEmoji` or `/addpack https://t.me/addemoji/BirthdayCollection` pulls `custom_emoji_id`s through the Bot API and binds them to the UI emoji.

**Bulk import:** `/admin` → 🛍 Kho acc → 📥 Nhập file accepts `.txt` (pipe-separated), `.csv` (optional header, any column order, Vietnamese or English column names) and `.json`, creating every valid row at once and reporting bad lines with their real line numbers.

**AI file import:** `/admin` → 🛍 Kho acc → 🤖 AI đọc file acc sends a messy dump to the model, which extracts per-account price, rank, level, heroes, skins, login, credentials, ban status, UID and notes as JSON; `shop_service.import_ai_accounts` re-validates every row (price > 0, credentials present) before inserting. A normal import that matches no known layout falls back to the same extractor automatically.

**Menus:** the admin panel always shows a 👤 Menu người dùng button that switches to the player interface, and the player menu keeps a 🛠 Admin button back to the panel. Unhandled errors are logged and answered by `handlers/errors.py`, and rejected HTML messages retry as plain text instead of disappearing.

**Tests:** `cd bot && .venv/bin/python tests/smoke.py` covers registration, deposit approval, account purchase, casino, check-in, giftcode, missions, withdrawal/refund and leaderboards. `tests/offline_ui.py` replays `/start` and menu callbacks through the real dispatcher with a fake Telegram session (reply presence, admin ↔ user menu switching, AI import validation); `tests/replay_pending.py` replays real pending updates without acknowledging them.

**Deploy:** Docker (`docker compose up -d --build`), systemd unit or Termux. Keep `data/` backed up; never commit `.env`.

---

## Ghi chú kỹ thuật / Technical notes

- `handlers/admin/__init__.py` gắn `AdminFilter` cho toàn bộ router admin.
- Mọi callback có tiền tố module (`shop:`, `cas:`, `admin:`, `dep:`, `sell:`, ...) và kiểm tra quyền sở hữu dữ liệu.
- Casino dùng `secrets` + seed băm SHA-256 công bố trong kết quả để người chơi đối chiếu.
- RTP/min/max cược đọc từ bảng `settings`, admin đổi không cần sửa code.
- Job định kỳ: nhả acc giữ hết hạn (60s), backup 03:00 hằng ngày, thưởng BXH tuần (thứ Hai 00:05).
