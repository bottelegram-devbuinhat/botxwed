DEPLOY BAN MERGE — lam tay trong cPanel (khi Chrome cua Muse cu ngat)
================================================================
1. Trong File Manager, vao /home/np3051uw4n/BOTLQ, Upload file zip nay, roi Extract (giai nen) ngay tai BOTLQ. Chon Overwrite khi hoi. 11 file code se nam dung cho.
2. Mo Terminal trong cPanel, chay (de sua main.py + nut shop.py tu dong):
     cd /home/np3051uw4n/BOTLQ && /home/np3051uw4n/virtualenv/BOTLQ/3.11/bin/python patch_main.py
   (neu duong dan venv khac, thay cho dung). No se bao OK cho tung muc. Chay lai lan 2 cung khong sao.
3. Kiem tra code bien dich duoc:
     /home/np3051uw4n/virtualenv/BOTLQ/3.11/bin/python -m py_compile main.py database/models.py database/session.py services/catalog_service.py services/cart_service.py services/discount_service.py services/order_service.py services/sepay_poller.py services/payment_service.py handlers/shop_merge.py keyboards/catalog.py keyboards/shop.py scheduler/jobs.py
   Khong co loi gi in ra la duoc.
4. Mo file BOTLQ/.env trong File Manager, dien:
     BOT_TOKEN=<token cu cua bot>
     SEPAY_ENABLED=true
   (SEPAY_API_KEY va cac AI key neu chua co thi dien them — khong gui qua chat.)
   Cac dong khac (BANK MB/05817666778899/BUI NGUYEN XUAN NHAT, BOT_USERNAME=devbn_bot, ADMIN_IDS=8792000582) giu nguyen.
5. Vao Setup Python App, Restart app BOTLQ. Doi ~3 phut, mo https://shoplq.duckdns.org/ — phai hien "Bot is running".
6. Kiem tra BOTLQ/stderr.log: khong con dong "BOT_TOKEN chua duoc cau hinh", khong co traceback. Neu thay "409 Conflict" nghia la bot HostVN cu van dang chay cung token — phai tat no truoc.
7. /catalog trong bot se hien danh muc (dang trong neu chua co san pham — la binh thuong, xem MERGE_SETUP.md muc 8 de them san pham).
Chu y: KHONG dong den app anhdev-admin. Chi restart BOTLQ.
