#!/usr/bin/env python3
"""Export the public stock of the Telegram shop bot to stock.json.

Reads a bot.db (SQLite) READ-ONLY and writes a public stock file with the
same shape as GET /api/stock, so the static GitHub Pages shop can show the
real stock even when the admin API is unreachable.

Works with BOTH schemas:
  * old bot.db (pre-merge): only the `accounts` table, no `category_id`,
    no `products`/`categories`/`credentials` tables -> products = [].
  * merged bot.db: accounts.category_id + categories/products/credentials
    tables -> exports accounts AND products.

Safety: this script NEVER selects username_enc / password_enc (the encrypted
account logins), NEVER selects credentials.data_enc or products.cost_price,
and never touches data/fernet.key. Only public shop fields are exported.

Usage:
    python3 export_stock.py /path/to/bot.db [-o stock.json]

    # on the trial host (cPanel Terminal), from BOTLQ:
    /home/np3051uw4n/virtualenv/BOTLQ/3.11/bin/python export_stock.py \\
        /home/np3051uw4n/BOTLQ/data/bot.db -o stock.json
    # then upload the new stock.json to the anhdev-store GitHub repo.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

# Public account columns only — keep username_enc / password_enc out, always.
# (category_id is handled separately; it is only used to look up the
# category NAME from the categories table.)
ACCOUNT_COLUMNS = (
    "code",
    "price",
    "rank",
    "level",
    "heroes",
    "skins",
    "rare_skins",
    "category",
    "kind",
    "description",
    "photos",
    "warranty_days",
    "status",
)

# Skin-tier counts: aggregate selling info, not identifiers.
SKIN_TIER_COLUMNS = (
    "ss_count",
    "splus_count",
    "s_count",
    "evo_count",
    "anime_count",
    "dreamer_count",
    "other_count",
)

# Public product columns only — NEVER cost_price, NEVER credential data.
PRODUCT_COLUMNS = (
    "id",
    "category_id",
    "name",
    "price",
    "description",
    "note",
    "product_type",
    "delivery_hours",
    "subscription_days",
    "warranty_days",
    "is_featured",
    "sort_order",
)


def _table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return {row["name"] for row in rows}


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone()
    return row is not None


def _parse_photos(raw) -> list:
    try:
        photos = json.loads(raw or "[]")
    except (ValueError, TypeError):
        return []
    if not isinstance(photos, list):
        return []
    return [str(p) for p in photos if isinstance(p, str)][:8]


def _load_categories(conn: sqlite3.Connection) -> dict[int, dict]:
    """id -> {name, emoji}. Empty when the categories table is absent."""
    if not _table_exists(conn, "categories"):
        return {}
    cols = _table_columns(conn, "categories")
    select = ["id", "name"]
    if "emoji" in cols:
        select.append("emoji")
    rows = conn.execute(
        "SELECT " + ", ".join(select) + " FROM categories WHERE is_active = 1 "
        "ORDER BY sort_order, id"
    ).fetchall()
    out: dict[int, dict] = {}
    for row in rows:
        out[int(row["id"])] = {
            "name": row["name"] or "",
            "emoji": row["emoji"] if "emoji" in row.keys() else "",
        }
    return out


def _load_products(conn: sqlite3.Connection, categories: dict[int, dict]) -> list[dict]:
    """Active, visible products with computed stock. Empty when the table
    is absent (old schema) or no product is sellable."""
    if not _table_exists(conn, "products"):
        return []
    cols = _table_columns(conn, "products")
    select = [c for c in PRODUCT_COLUMNS if c in cols]
    for extra in ("invite_slots", "preorder_stock"):
        if extra in cols:
            select.append(extra)
    if "id" not in select or "name" not in select:
        return []
    where = []
    if "is_active" in cols:
        where.append("is_active = 1")
    if "is_hidden" in cols:
        where.append("is_hidden = 0")
    sql = "SELECT " + ", ".join(select) + " FROM products"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY sort_order, id"
    rows = conn.execute(sql).fetchall()
    has_credentials = _table_exists(conn, "credentials")

    products: list[dict] = []
    for row in rows:
        pid = int(row["id"])
        ptype = row["product_type"] if "product_type" in row.keys() else "credential"
        if ptype == "invite":
            stock = int(row["invite_slots"] or 0) if "invite_slots" in row.keys() else 0
        elif ptype == "preorder":
            stock = int(row["preorder_stock"] or 0) if "preorder_stock" in row.keys() else 0
        elif has_credentials:
            stock = int(
                conn.execute(
                    "SELECT COUNT(*) FROM credentials "
                    "WHERE product_id = ? AND is_sold = 0",
                    (pid,),
                ).fetchone()[0]
            )
        else:
            stock = 0
        cat_id = row["category_id"] if "category_id" in row.keys() else None
        cat = categories.get(int(cat_id)) if cat_id is not None else None
        products.append(
            {
                "id": pid,
                "name": row["name"] or "",
                "price": int(row["price"] or 0),
                "description": row["description"] if "description" in row.keys() else "",
                "note": row["note"] if "note" in row.keys() else "",
                "product_type": ptype,
                "category": (cat or {}).get("name", ""),
                "category_emoji": (cat or {}).get("emoji", ""),
                "delivery_hours": int(row["delivery_hours"] or 0)
                if "delivery_hours" in row.keys()
                else 0,
                "subscription_days": row["subscription_days"]
                if "subscription_days" in row.keys()
                else None,
                "warranty_days": row["warranty_days"]
                if "warranty_days" in row.keys()
                else None,
                "is_featured": bool(row["is_featured"])
                if "is_featured" in row.keys()
                else False,
                "stock": stock,
            }
        )
    return products


def _load_accounts(conn: sqlite3.Connection, categories: dict[int, dict]) -> list[dict]:
    if not _table_exists(conn, "accounts"):
        return []
    cols = _table_columns(conn, "accounts")
    select = [c for c in ACCOUNT_COLUMNS if c in cols]
    for extra in ("category_id", *SKIN_TIER_COLUMNS):
        if extra in cols:
            select.append(extra)
    if "code" not in select or "price" not in select:
        return []
    where = []
    if "status" in cols:
        where.append("status = 'available'")
    if "is_hidden" in cols:
        where.append("is_hidden = 0")
    sql = "SELECT " + ", ".join(select) + " FROM accounts"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at DESC" if "created_at" in cols else " ORDER BY id DESC"
    rows = conn.execute(sql).fetchall()

    accounts: list[dict] = []
    for row in rows:
        cat_id = row["category_id"] if "category_id" in row.keys() else None
        cat = categories.get(int(cat_id)) if cat_id is not None else None
        category = row["category"] if "category" in row.keys() else ""
        if not category and cat:
            category = cat["name"]
        skin_tiers = {}
        for tier in SKIN_TIER_COLUMNS:
            if tier in row.keys():
                skin_tiers[tier.replace("_count", "")] = int(row[tier] or 0)
        accounts.append(
            {
                "code": row["code"],
                "price": int(row["price"] or 0),
                "rank": row["rank"] if "rank" in row.keys() else "",
                "level": int(row["level"] or 0) if "level" in row.keys() else 0,
                "heroes": int(row["heroes"] or 0) if "heroes" in row.keys() else 0,
                "skins": int(row["skins"] or 0) if "skins" in row.keys() else 0,
                "rare_skins": row["rare_skins"] if "rare_skins" in row.keys() else "",
                "category": category or "",
                "kind": row["kind"] if "kind" in row.keys() else "info",
                "description": row["description"] if "description" in row.keys() else "",
                "photos": _parse_photos(row["photos"]) if "photos" in row.keys() else [],
                "warranty_days": int(row["warranty_days"] or 0)
                if "warranty_days" in row.keys()
                else 0,
                "status": row["status"] if "status" in row.keys() else "available",
                "skin_tiers": skin_tiers,
            }
        )
    return accounts


def export_stock(db_path: Path) -> dict:
    if not db_path.exists():
        raise SystemExit(f"Không tìm thấy file database: {db_path}")
    uri = f"file:{db_path}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    try:
        categories = _load_categories(conn)
        accounts = _load_accounts(conn, categories)
        products = _load_products(conn, categories)
    except sqlite3.Error as exc:
        raise SystemExit(f"Không đọc được kho trong {db_path}: {exc}")
    finally:
        conn.close()

    by_category: dict[str, list] = {}
    for item in accounts:
        key = item["category"] or ("Random" if item["kind"] == "random" else "Chưa phân loại")
        by_category.setdefault(key, []).append(item)

    return {
        "ok": True,
        "total": len(accounts),
        "total_products": len(products),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "accounts": accounts,
        "products": products,
        "categories": [
            {"id": cid, "name": c["name"], "emoji": c["emoji"]}
            for cid, c in categories.items()
        ],
        "by_category": by_category,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Export public shop stock to stock.json (no credentials).")
    parser.add_argument("db", type=Path, help="Đường dẫn tới data/bot.db (chỉ đọc).")
    parser.add_argument("-o", "--output", type=Path, default=Path("stock.json"),
                        help="File JSON đầu ra (mặc định: stock.json).")
    args = parser.parse_args(argv)

    payload = export_stock(args.db)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Đã xuất {payload['total']} acc + {payload['total_products']} sản phẩm đang bán -> {args.output}")
    if payload["total"] == 0 and payload["total_products"] == 0:
        print("Kho đang trống (0 acc, 0 sản phẩm). Shop sẽ hiển thị 'Kho thật hiện đang hết hàng' "
              "cho tới khi thêm acc/sản phẩm qua web admin hoặc /addpack trong bot.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
