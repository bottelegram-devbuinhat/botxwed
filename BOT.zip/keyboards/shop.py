"""Shop keyboards."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from keyboards.common import pagination_row, with_nav
from locales import t
from utils.money import fmt_coin, fmt_vnd


def shop_menu(language: str = "vi", admin: bool = False, counts: dict | None = None) -> InlineKeyboardMarkup:
    counts = counts or {}
    rows = [
        [InlineKeyboardButton(
            text=f"💎 Kho Random · {counts.get('random', 0)} acc", callback_data="shop:random:0"
        )],
        [InlineKeyboardButton(
            text=f"🌐 Acc sẵn thông tin (VIP) · {counts.get('info', 0)} acc", callback_data="shop:info:0"
        )],
        [InlineKeyboardButton(
            text=f"⚪ Acc trắng (7.000đ) · {counts.get('white', 0)} acc", callback_data="shop:white:0"
        )],
        [
            InlineKeyboardButton(text="🔍 Tìm kiếm acc", callback_data="shop:search"),
            InlineKeyboardButton(text="🔢 Tìm theo mã", callback_data="shop:findcode"),
        ],
        [
            InlineKeyboardButton(text="🆕 Mới nhất", callback_data="shop:ilist:newest:0"),
            InlineKeyboardButton(text="💲 Giá thấp", callback_data="shop:ilist:cheap:0"),
        ],
        [
            InlineKeyboardButton(text="💎 Giá cao", callback_data="shop:ilist:expensive:0"),
            InlineKeyboardButton(text="🔥 Xem nhiều", callback_data="shop:ilist:popular:0"),
        ],
        [
            InlineKeyboardButton(text="🏅 Theo rank", callback_data="shop:ranks:0"),
            InlineKeyboardButton(text="⭐ Yêu thích", callback_data="shop:favs:0"),
        ],
    ]
    return with_nav(rows, language, back="menu:home", admin=admin)


def random_list(accounts, page: int, pages: int, language: str = "vi") -> InlineKeyboardMarkup:
    """Random accounts list showing ~5 accounts per page with pagination."""
    rows = [
        [InlineKeyboardButton(text="🔢 Tìm / Mua theo mã acc (LQ...)", callback_data="shop:findcode")]
    ]
    for a in accounts:
        coin_price = a.price * 5
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"🎲 {a.code} · {fmt_vnd(a.price)} ({fmt_coin(coin_price)})",
                    callback_data=f"shop:view:{a.code}",
                )
            ]
        )
    pager = pagination_row("shop:random", page, pages)
    if pager:
        rows.append(pager)
    rows.append([InlineKeyboardButton(text="⬅️ Menu Shop", callback_data="menu:buy")])
    return with_nav(rows, language, back="menu:buy")


def white_list(accounts, page: int, pages: int, language: str = "vi") -> InlineKeyboardMarkup:
    """White accounts list (7,000đ)."""
    rows = []
    for a in accounts:
        coin_price = a.price * 5
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"⚪ {a.code} · {fmt_vnd(a.price)} ({fmt_coin(coin_price)})",
                    callback_data=f"shop:view:{a.code}",
                )
            ]
        )
    pager = pagination_row("shop:white", page, pages)
    if pager:
        rows.append(pager)
    rows.append([InlineKeyboardButton(text="⬅️ Menu Shop", callback_data="menu:buy")])
    return with_nav(rows, language, back="menu:buy")


def random_pools_kb(pools: list[dict], language: str = "vi") -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"🎲 {pool['category']} · {fmt_vnd(pool['price'])} · {pool['count']} acc",
                callback_data=f"shop:rbuy:{pool['price']}",
            )
        ]
        for pool in pools[:12]
    ]
    if not rows:
        rows.append([InlineKeyboardButton(text="Kho random đang trống", callback_data="noop")])
    return with_nav(rows, language, back="menu:buy")


def random_confirm_kb(price: int, language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=f"🎲 Mua ngẫu nhiên {fmt_vnd(price)}", callback_data=f"shop:rconfirm:{price}")],
            [InlineKeyboardButton(text="⬅️ Kho random", callback_data="shop:random:0")],
        ]
    )


def info_list(
    accounts, page: int, pages: int, sort: str = "newest", language: str = "vi", search: str | None = None
) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="🔍 Tìm kiếm (skin, rank, giá)", callback_data="shop:search_info")]
    ]
    for account in accounts:
        coin_price = account.price * 4
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"◇ Acc #{account.code} · {fmt_vnd(account.price)} ({fmt_coin(coin_price)})",
                    callback_data=f"shop:view:{account.code}",
                )
            ]
        )
    prefix = f"shop:isearch:{search}" if search else f"shop:ilist:{sort}"
    pager = pagination_row(prefix, page, pages)
    if pager:
        rows.append(pager)
    rows.append([InlineKeyboardButton(text=t("filter", language), callback_data="menu:buy")])
    return with_nav(rows, language, back="menu:buy")


def search_list_kb(
    accounts, page: int, pages: int, qid: str, language: str = "vi"
) -> InlineKeyboardMarkup:
    rows = []
    for account in accounts:
        multiplier = 4 if account.kind == "info" else 5
        coin_price = account.price * multiplier
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"◇ Acc #{account.code} · {fmt_vnd(account.price)} ({fmt_coin(coin_price)})",
                    callback_data=f"shop:view:{account.code}",
                )
            ]
        )
    pager = pagination_row(f"shop:sp:{qid}", page, pages)
    if pager:
        rows.append(pager)
    rows.append([
        InlineKeyboardButton(text="🔍 Tìm kiếm khác", callback_data="shop:search"),
        InlineKeyboardButton(text="⬅️ Menu Shop", callback_data="menu:buy"),
    ])
    return with_nav(rows, language, back="menu:buy")


def ranks_kb(ranks: list[str], language: str = "vi") -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=f"🏅 {rank}", callback_data=f"shop:list:newest:{rank}:0")] for rank in ranks[:12]]
    rows.append([InlineKeyboardButton(text="♾ Tất cả rank", callback_data="shop:list:newest:-:0")])
    return with_nav(rows, language, back="menu:buy")


def account_list(
    accounts, page: int, pages: int, sort: str, language: str = "vi", rank: str | None = None
) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"{a.code} · {a.rank or 'Acc'} · {fmt_vnd(a.price)}", callback_data=f"shop:view:{a.code}")]
        for a in accounts
    ]
    pager = pagination_row(f"shop:list:{sort}:{rank or '-'}", page, pages)
    if pager:
        rows.append(pager)
    rows.append([InlineKeyboardButton(text=t("filter", language), callback_data="menu:buy")])
    return with_nav(rows, language, back="menu:buy")


def account_detail(account, price: int, is_fav: bool, language: str = "vi") -> InlineKeyboardMarkup:
    code = account.code if hasattr(account, "code") else str(account)
    kind = getattr(account, "kind", "info")
    multiplier = 4 if kind == "info" else 5
    coin_price = price * multiplier
    back_target = f"shop:{kind}:0" if kind in ("info", "random", "white") else "menu:buy"

    rows = [
        [InlineKeyboardButton(text=f"🛒 Mua bằng VND ({fmt_vnd(price)})", callback_data=f"shop:buy:{code}:vnd")],
        [InlineKeyboardButton(text=f"🪙 Mua bằng Xu ({fmt_coin(coin_price)})", callback_data=f"shop:buy:{code}:coin")],
        [InlineKeyboardButton(text="💳 Mua bằng chuyển khoản", callback_data=f"order:acc:{code}")],
    ]
    # Acc random chỉ có mã số thôi, không có ảnh, không đánh giá/yêu thích
    if kind != "random":
        rows.append([
            InlineKeyboardButton(
                text="💔 Bỏ yêu thích" if is_fav else "❤️ Yêu thích",
                callback_data=f"shop:fav:{code}",
            ),
        ])
        rows.append([
            InlineKeyboardButton(text="🖼 Xem ảnh", callback_data=f"shop:photos:{code}"),
            InlineKeyboardButton(text="⭐ Đánh giá", callback_data=f"shop:review:{code}"),
        ])
    rows.append([InlineKeyboardButton(text="⬅️ Quay lại danh sách", callback_data=back_target)])
    return with_nav(rows, language, back="menu:buy")


def buy_confirm(code: str, price_text: str, currency: str = "vnd", language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=f"✅ Xác nhận mua ({price_text})", callback_data=f"shop:confirm:{code}:{currency}")],
            [InlineKeyboardButton(text="⬅️ Chi tiết acc", callback_data=f"shop:view:{code}")],
        ]
    )


def buy_success(code: str, language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⚠️ Báo lỗi acc", callback_data="sup:new")],
            [InlineKeyboardButton(text="📄 Xem lại thông tin", callback_data=f"shop:creds:{code}")],
            [InlineKeyboardButton(text="🏠 Menu chính", callback_data="menu:home")],
        ]
    )


def sell_menu(language: str = "vi", admin: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="➕ Đăng acc mới", callback_data="sell:new")],
        [InlineKeyboardButton(text="📋 Acc của tôi", callback_data="sell:list:0")],
        [
            InlineKeyboardButton(text="💸 Rút tiền", callback_data="wd:new"),
            InlineKeyboardButton(text="📊 Thu nhập", callback_data="sell:earnings"),
        ],
    ]
    return with_nav(rows, language, back="menu:home", admin=admin)


def seller_accounts(accounts, page: int, pages: int, language: str = "vi") -> InlineKeyboardMarkup:
    rows = []
    for account in accounts:
        status = {
            "available": "🟢 Đang bán",
            "pending_approval": "⏳ Chờ duyệt",
            "sold": "✅ Đã bán",
            "rejected": "❌ Bị từ chối",
        }.get(account.status, account.status)
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{account.code} · {fmt_vnd(account.price)} · {status}",
                    callback_data=f"sell:view:{account.id}",
                )
            ]
        )
    pager = pagination_row("sell:list", page, pages)
    if pager:
        rows.append(pager)
    return with_nav(rows, language, back="menu:sell")


def seller_account_detail(account_id: int, can_edit: bool, language: str = "vi") -> InlineKeyboardMarkup:
    rows = []
    if can_edit:
        rows.append(
            [
                InlineKeyboardButton(text="✏️ Đổi giá", callback_data=f"sell:price:{account_id}"),
                InlineKeyboardButton(text="🗑 Xoá", callback_data=f"sell:del:{account_id}"),
            ]
        )
    return with_nav(rows, language, back="sell:list:0")


def deposit_methods(language: str = "vi") -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="🏦 Chuyển khoản (VietQR)", callback_data="dep:method:bank")],
        [InlineKeyboardButton(text="📱 MoMo / ZaloPay", callback_data="dep:method:momo")],
        [InlineKeyboardButton(text="💳 Thẻ cào", callback_data="dep:method:card")],
        [InlineKeyboardButton(text="📜 Lịch sử nạp", callback_data="dep:history")],
    ]
    return with_nav(rows, language, back="menu:deposit")


def deposit_amounts(method: str, language: str = "vi") -> InlineKeyboardMarkup:
    values = [20000, 50000, 100000, 200000, 500000, 1000000]
    rows = []
    for index in range(0, len(values), 2):
        rows.append(
            [
                InlineKeyboardButton(
                    text=fmt_vnd(value), callback_data=f"dep:amount:{method}:{value}"
                )
                for value in values[index : index + 2]
            ]
        )
    rows.append([InlineKeyboardButton(text="✏️ Nhập số khác", callback_data=f"dep:custom:{method}")])
    return with_nav(rows, language, back="menu:deposit")
