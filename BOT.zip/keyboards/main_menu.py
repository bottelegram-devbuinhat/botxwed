"""Main menu keyboard."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from locales import t


def main_menu(language: str = "vi", admin: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=t("menu_buy", language), callback_data="menu:buy"),
            InlineKeyboardButton(text=t("menu_sell", language), callback_data="menu:sell"),
        ],
        [
            InlineKeyboardButton(text=t("menu_casino", language), callback_data="menu:casino"),
            InlineKeyboardButton(text=t("menu_deposit", language), callback_data="menu:deposit"),
        ],
        [
            InlineKeyboardButton(text=t("menu_account", language), callback_data="menu:account"),
            InlineKeyboardButton(text=t("menu_leaderboard", language), callback_data="menu:lb"),
        ],
        [
            InlineKeyboardButton(text=t("menu_rewards", language), callback_data="menu:rewards"),
            InlineKeyboardButton(text=t("menu_support", language), callback_data="menu:support"),
        ],
        [
            InlineKeyboardButton(text="👥 Mời bạn", callback_data="rw:invite"),
            InlineKeyboardButton(text=t("menu_guide", language), callback_data="menu:guide"),
        ],
        [InlineKeyboardButton(text=t("menu_ai", language), callback_data="menu:ai")],
    ]
    if admin:
        rows.append(
            [InlineKeyboardButton(text=f"{t('btn_admin', language)} · Bảng điều khiển", callback_data="admin:panel")]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)
