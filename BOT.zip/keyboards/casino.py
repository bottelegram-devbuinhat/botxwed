"""Casino keyboards."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from keyboards.common import with_nav
from locales import t
from services.casino_service import GAMES
from utils.money import fmt_coin

PRESET_BETS = [100, 500, 1000, 5000, 10000]


def casino_menu(language: str = "vi", admin: bool = False) -> InlineKeyboardMarkup:
    keys = list(GAMES.keys())
    rows = []
    for index in range(0, len(keys), 2):
        rows.append(
            [
                InlineKeyboardButton(text=GAMES[key]["name"], callback_data=f"cas:game:{key}")
                for key in keys[index : index + 2]
            ]
        )
    rows.append([InlineKeyboardButton(text="📜 Lịch sử chơi", callback_data="cas:history")])
    return with_nav(rows, language, back="menu:home", admin=admin)


def game_screen(game: str, language: str = "vi") -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=fmt_coin(value), callback_data=f"cas:bet:{game}:{value}")
            for value in PRESET_BETS[:3]
        ],
        [
            InlineKeyboardButton(text=fmt_coin(value), callback_data=f"cas:bet:{game}:{value}")
            for value in PRESET_BETS[3:]
        ],
        [InlineKeyboardButton(text="✏️ Nhập số xu khác", callback_data=f"cas:custom:{game}")],
        [InlineKeyboardButton(text=t("casino_rules", language), callback_data=f"cas:rules:{game}")],
    ]
    return with_nav(rows, language, back="cas:menu")


def choice_screen(game: str, bet: int, language: str = "vi") -> InlineKeyboardMarkup:
    meta = GAMES[game]
    choices = meta.get("choices") or {}
    items = list(choices.items())
    rows = []
    for index in range(0, len(items), 3):
        rows.append(
            [
                InlineKeyboardButton(
                    text=label, callback_data=f"cas:play:{game}:{bet}:{key}"
                )
                for key, label in items[index : index + 3]
            ]
        )
    if not choices:
        rows.append([InlineKeyboardButton(text=t("casino_play", language), callback_data=f"cas:play:{game}:{bet}:None")])
    return with_nav(rows, language, back=f"cas:game:{game}")


def result_screen(game: str, bet: int, language: str = "vi") -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=f"🔁 Cược lại {fmt_coin(bet)}", callback_data=f"cas:bet:{game}:{bet}"),
            InlineKeyboardButton(text="✖️2", callback_data=f"cas:bet:{game}:{bet * 2}"),
        ],
        [InlineKeyboardButton(text=t("casino_other", language), callback_data="cas:menu")],
    ]
    return with_nav(rows, language, back="cas:menu")


def blackjack_kb(language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🃏 Rút bài", callback_data="cas:bj:hit"),
                InlineKeyboardButton(text="✋ Dừng", callback_data="cas:bj:stand"),
            ]
        ]
    )
