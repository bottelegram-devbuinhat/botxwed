"""Admin control panel keyboards."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from keyboards.common import pagination_row, with_nav


def admin_panel(self_topup: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="📊 Thống kê", callback_data="admin:stats"),
            InlineKeyboardButton(text="👥 Người chơi", callback_data="admin:players:0"),
        ],
        [
            InlineKeyboardButton(text="🛍 Kho acc", callback_data="admin:accounts:0"),
            InlineKeyboardButton(text="🧾 Đơn hàng", callback_data="admin:orders:0"),
        ],
        [
            InlineKeyboardButton(text="💳 Nạp tiền", callback_data="admin:deps:0"),
            InlineKeyboardButton(text="💸 Rút tiền", callback_data="admin:wds:0"),
        ],
        [
            InlineKeyboardButton(text="🎟 Giftcode", callback_data="admin:gcs"),
            InlineKeyboardButton(text="🆘 Ticket", callback_data="admin:tickets:0"),
        ],
        [
            InlineKeyboardButton(text="🎰 Casino", callback_data="admin:casino"),
            InlineKeyboardButton(text="⚙️ Cài đặt", callback_data="admin:settings"),
        ],
        [
            InlineKeyboardButton(text="📢 Broadcast", callback_data="admin:broadcast"),
            InlineKeyboardButton(text="💾 Backup", callback_data="admin:backup"),
        ],
        [
            InlineKeyboardButton(text="📜 Logs", callback_data="admin:logs"),
            InlineKeyboardButton(text="⏳ Chờ duyệt acc", callback_data="admin:pending"),
        ],
        [
            InlineKeyboardButton(text="🤖 Trợ lý AI", callback_data="admin:ai"),
            InlineKeyboardButton(text="✨ Emoji động", callback_data="admin:emoji"),
        ],
        [
            InlineKeyboardButton(text="⏹ Tắt bot", callback_data="admin:stop"),
        ],
        # Self top-up is limited to the configured owner account.
        *(
            [
                [
                    InlineKeyboardButton(text="💰 Tự nạp ví", callback_data="admin:selftop:vnd"),
                    InlineKeyboardButton(text="🪙 Tự nạp xu", callback_data="admin:selftop:coin"),
                ]
            ]
            if self_topup
            else []
        ),
        # Keep both worlds reachable: the admin panel always offers the user menu
        # and the user menu keeps the 🛠 Admin button back to this panel.
        [
            InlineKeyboardButton(text="👤 Menu người dùng", callback_data="menu:home"),
            InlineKeyboardButton(text="🔄 Làm mới", callback_data="admin:panel"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def user_admin(user_id: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="➕ Cộng tiền", callback_data=f"admin:adj:{user_id}:vnd:1"),
            InlineKeyboardButton(text="➖ Trừ tiền", callback_data=f"admin:adj:{user_id}:vnd:-1"),
        ],
        [
            InlineKeyboardButton(text="➕ Cộng xu", callback_data=f"admin:adj:{user_id}:coin:1"),
            InlineKeyboardButton(text="➖ Trừ xu", callback_data=f"admin:adj:{user_id}:coin:-1"),
        ],
        [
            InlineKeyboardButton(text="🔨 Ban/Unban", callback_data=f"admin:ban:{user_id}"),
            InlineKeyboardButton(text="🔇 Mute casino", callback_data=f"admin:mute:{user_id}"),
        ],
        [
            InlineKeyboardButton(text="👑 Set VIP", callback_data=f"admin:vip:{user_id}"),
            InlineKeyboardButton(text="✉️ Nhắn tin", callback_data=f"admin:msg:{user_id}"),
        ],
        [InlineKeyboardButton(text="📜 Lịch sử", callback_data=f"admin:history:{user_id}")],
    ]
    return with_nav(rows, "vi", back="admin:players:0")


def users_list(users, page: int, pages: int) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"{u.full_name or u.username or u.id} · {u.id}", callback_data=f"admin:user:{u.id}")]
        for u in users
    ]
    pager = pagination_row("admin:players", page, pages)
    if pager:
        rows.append(pager)
    rows.append([InlineKeyboardButton(text="🔎 Tìm theo ID", callback_data="admin:finduser")])
    return with_nav(rows, "vi", back="admin:panel")


def accounts_admin(accounts, page: int, pages: int) -> InlineKeyboardMarkup:
    rows = []
    for account in accounts:
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{account.code} · {account.price:,}đ · {account.status}".replace(",", "."),
                    callback_data=f"admin:acct:{account.id}",
                )
            ]
        )
    pager = pagination_row("admin:accounts", page, pages)
    if pager:
        rows.append(pager)
    rows.append(
        [
            InlineKeyboardButton(text="➕ Thêm acc", callback_data="admin:accadd"),
            InlineKeyboardButton(text="📥 Nhập file", callback_data="admin:accimport"),
        ]
    )
    rows.append(
        [
            InlineKeyboardButton(text="🌐 Acc full info", callback_data="admin:acchit"),
            InlineKeyboardButton(text="🎲 Kho random", callback_data="admin:accrand"),
        ]
    )
    rows.append([InlineKeyboardButton(text="🤖 AI đọc file acc", callback_data="admin:accai")])
    return with_nav(rows, "vi", back="admin:panel")


def account_admin(account_id: int, hidden: bool) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="✏️ Sửa giá", callback_data=f"admin:acctprice:{account_id}"),
            InlineKeyboardButton(text="👁 Ẩn/Hiện", callback_data=f"admin:accttoggle:{account_id}"),
        ],
        [InlineKeyboardButton(text="🗑 Xoá acc", callback_data=f"admin:acctdel:{account_id}")],
    ]
    return with_nav(rows, "vi", back="admin:accounts:0")


def orders_admin(orders, page: int, pages: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"#{o.id} · {o.account_code} · {o.status}",
                callback_data=f"admin:order:{o.id}",
            )
        ]
        for o in orders
    ]
    pager = pagination_row("admin:orders", page, pages)
    if pager:
        rows.append(pager)
    return with_nav(rows, "vi", back="admin:panel")


def order_admin(order_id: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="💰 Hoàn tiền", callback_data=f"admin:refund:{order_id}"),
            InlineKeyboardButton(text="✅ Hoàn tất", callback_data=f"admin:complete:{order_id}"),
        ],
        [InlineKeyboardButton(text="📝 Ghi chú", callback_data=f"admin:ordernote:{order_id}")],
    ]
    return with_nav(rows, "vi", back="admin:orders:0")


def pending_consignments(accounts) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=f"✅ {a.code}", callback_data=f"admin:conok:{a.id}"),
            InlineKeyboardButton(text="❌ Từ chối", callback_data=f"admin:conno:{a.id}"),
        ]
        for a in accounts
    ][:10]
    return with_nav(rows, "vi", back="admin:panel")


def deposits_admin(deposits) -> InlineKeyboardMarkup:
    rows = []
    for deposit in deposits:
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"#{deposit.id} · {deposit.user_id} · {deposit.amount:,}đ".replace(",", "."),
                    callback_data=f"admin:dep:{deposit.id}",
                )
            ]
        )
    if not rows:
        rows.append([InlineKeyboardButton(text="Không có yêu cầu nào", callback_data="noop")])
    return with_nav(rows, "vi", back="admin:panel")


def deposit_admin(deposit_id: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="✅ Duyệt", callback_data=f"admin:depok:{deposit_id}"),
            InlineKeyboardButton(text="❌ Từ chối", callback_data=f"admin:depno:{deposit_id}"),
        ]
    ]
    return with_nav(rows, "vi", back="admin:deps:0")


def withdrawals_admin(withdrawals) -> InlineKeyboardMarkup:
    rows = []
    for withdrawal in withdrawals:
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"#{withdrawal.id} · {withdrawal.user_id} · {withdrawal.amount:,}đ".replace(",", "."),
                    callback_data=f"admin:wd:{withdrawal.id}",
                )
            ]
        )
    if not rows:
        rows.append([InlineKeyboardButton(text="Không có yêu cầu nào", callback_data="noop")])
    return with_nav(rows, "vi", back="admin:panel")


def withdrawal_admin(withdrawal_id: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="✅ Duyệt", callback_data=f"admin:wdok:{withdrawal_id}"),
            InlineKeyboardButton(text="❌ Từ chối", callback_data=f"admin:wdno:{withdrawal_id}"),
        ]
    ]
    return with_nav(rows, "vi", back="admin:wds:0")


def settings_panel(settings: dict) -> InlineKeyboardMarkup:
    keys = [
        ("maintenance", "🛠 Bảo trì"),
        ("feature_shop", "🛒 Shop"),
        ("feature_sell", "💰 Ký gửi"),
        ("feature_deposit", "💳 Nạp tiền"),
        ("feature_withdraw", "💸 Rút tiền"),
        ("feature_casino", "🎰 Casino"),
        ("feature_rewards", "🎁 Phần thưởng"),
        ("feature_support", "🆘 Hỗ trợ"),
    ]
    rows = []
    for key, label in keys:
        state = "🟢" if settings.get(key) else "🔴"
        rows.append([InlineKeyboardButton(text=f"{label}: {state}", callback_data=f"admin:toggle:{key}")])
    rows.append([InlineKeyboardButton(text="🎰 Cấu hình casino", callback_data="admin:casino")])
    return with_nav(rows, "vi", back="admin:panel")


def casino_panel(settings: dict) -> InlineKeyboardMarkup:
    from services.casino_service import GAMES

    rows = []
    game_states = settings.get("game_enabled") or {}
    for key, meta in GAMES.items():
        state = "🟢" if game_states.get(key) else "🔴"
        rows.append([InlineKeyboardButton(text=f"{meta['name']}: {state}", callback_data=f"admin:game:{key}")])
    rows.append([InlineKeyboardButton(text="✏️ Sửa min/max cược & RTP", callback_data="admin:casinolimits")])
    rows.append([InlineKeyboardButton(text="💎 Reset hũ", callback_data="admin:resetjackpot")])
    return with_nav(rows, "vi", back="admin:settings")


def giftcodes_admin(codes) -> InlineKeyboardMarkup:
    rows = []
    for code in codes:
        state = "🟢" if code.is_active else "🔴"
        curr = getattr(code, "currency", "coin")
        icon = "💵" if curr == "vnd" else "🪙"
        amt = fmt_vnd(code.amount) if curr == "vnd" else fmt_coin(code.amount)
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{state} {icon} {code.code} · {amt} ({code.used}/{code.max_uses})",
                    callback_data=f"admin:gc:{code.code}",
                )
            ]
        )
    rows.append([
        InlineKeyboardButton(text="🪙 Tạo Giftcode Xu", callback_data="admin:gcnew:coin"),
        InlineKeyboardButton(text="💵 Tạo Giftcode Tiền", callback_data="admin:gcnew:vnd"),
    ])
    return with_nav(rows, "vi", back="admin:panel")


def tickets_admin(tickets) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"#{t.id} · {t.status} · {t.subject[:24]}", callback_data=f"admin:ticket:{t.id}"
            )
        ]
        for t in tickets
    ]
    if not rows:
        rows.append([InlineKeyboardButton(text="Không có ticket", callback_data="noop")])
    return with_nav(rows, "vi", back="admin:panel")


def ticket_admin(ticket_id: int, status: str) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="💬 Trả lời", callback_data=f"admin:treply:{ticket_id}")],
    ]
    if status != "closed":
        rows.append([InlineKeyboardButton(text="✅ Đóng ticket", callback_data=f"admin:tclose:{ticket_id}")])
    return with_nav(rows, "vi", back="admin:tickets:0")
