"""Shared inline keyboards: navigation, pagination, confirmations."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

from locales import t


def nav_row(language: str = "vi", back: str = "menu:home", admin: bool = False) -> list[InlineKeyboardButton]:
    row = [
        InlineKeyboardButton(text=t("btn_back", language), callback_data=back),
        InlineKeyboardButton(text=t("btn_home", language), callback_data="menu:home"),
    ]
    if admin:
        row.append(InlineKeyboardButton(text=t("btn_admin", language), callback_data="admin:panel"))
    return row


def with_nav(
    rows: list[list[InlineKeyboardButton]],
    language: str = "vi",
    back: str = "menu:home",
    admin: bool = False,
) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=list(rows) + [nav_row(language, back, admin)])


def pagination_row(prefix: str, page: int, pages: int) -> list[InlineKeyboardButton] | None:
    if pages <= 1:
        return None
    return [
        InlineKeyboardButton(text="⏮", callback_data=f"{prefix}:0"),
        InlineKeyboardButton(text="◀️", callback_data=f"{prefix}:{max(0, page - 1)}"),
        InlineKeyboardButton(text=f"{page + 1}/{pages}", callback_data="noop"),
        InlineKeyboardButton(text="▶️", callback_data=f"{prefix}:{min(pages - 1, page + 1)}"),
        InlineKeyboardButton(text="⏭", callback_data=f"{prefix}:{pages - 1}"),
    ]


def confirm_kb(yes_cb: str, no_cb: str = "menu:home", language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t("btn_confirm", language), callback_data=yes_cb),
                InlineKeyboardButton(text=t("btn_cancel", language), callback_data=no_cb),
            ]
        ]
    )


def main_reply_keyboard(language: str = "vi", admin: bool = False) -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=t("menu_buy", language)), KeyboardButton(text=t("menu_sell", language))],
        [KeyboardButton(text=t("menu_casino", language)), KeyboardButton(text=t("menu_deposit", language))],
        [KeyboardButton(text=t("menu_account", language)), KeyboardButton(text=t("menu_leaderboard", language))],
        [KeyboardButton(text=t("menu_rewards", language)), KeyboardButton(text=t("menu_support", language))],
        [KeyboardButton(text=t("menu_guide", language))],
    ]
    if admin:
        rows.append([KeyboardButton(text=t("btn_admin", language))])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def back_only(callback: str, language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=t("btn_back", language), callback_data=callback)]]
    )
