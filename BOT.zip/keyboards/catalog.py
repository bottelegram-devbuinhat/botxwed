"""Catalog + cart + direct-order keyboards (ported from telegram-sales-bot
inline keyboards: productHandler / cartHandler / orderHandler / quantityHandler).
"""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from keyboards.common import pagination_row, with_nav
from utils.money import fmt_vnd


def category_kb(categories: list[dict], language: str = "vi") -> InlineKeyboardMarkup:
    rows = []
    for cat in categories:
        emoji = cat.get("emoji") or "📦"
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{emoji} {cat['name']} · {cat.get('stock', 0)}",
                    callback_data=f"catalog:cat:{cat['id']}:0",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🛒 Giỏ hàng", callback_data="cart:view")])
    rows.append([InlineKeyboardButton(text="💎 Acc Liên Quân", callback_data="menu:buy")])
    return with_nav(rows, language, back="menu:home")


def product_list_kb(products: list[dict], category_id: int, page: int, pages: int, language: str = "vi") -> InlineKeyboardMarkup:
    rows = []
    for product in products:
        stock = product.get("stock", 0)
        badge = "✅" if stock > 0 else "🚫"
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{badge} {product['name']} · {fmt_vnd(product['price'])} · còn {stock}",
                    callback_data=f"catalog:prod:{product['id']}",
                )
            ]
        )
    pager = pagination_row(f"catalog:cat:{category_id}", page, pages)
    if pager:
        rows.append(pager)
    rows.append([InlineKeyboardButton(text="🛒 Giỏ hàng", callback_data="cart:view")])
    return with_nav(rows, language, back="catalog:list")


def product_detail_kb(product: dict, qty: int = 1, language: str = "vi") -> InlineKeyboardMarkup:
    pid = product["id"]
    stock = product.get("stock", 0)
    rows = []
    if stock > 0:
        rows.append(
            [
                InlineKeyboardButton(text="−", callback_data=f"catalog:qty:{pid}:{max(1, qty - 1)}"),
                InlineKeyboardButton(text=f"{qty}", callback_data="noop"),
                InlineKeyboardButton(text="+", callback_data=f"catalog:qty:{pid}:{min(stock, qty + 1)}"),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"💳 Mua ngay {fmt_vnd(int(product['price']) * qty)}",
                    callback_data=f"order:buy:{pid}:{qty}",
                )
            ]
        )
        rows.append([InlineKeyboardButton(text="🛒 Thêm vào giỏ", callback_data=f"cart:add:{pid}:{qty}")])
    rows.append([InlineKeyboardButton(text="🛒 Xem giỏ hàng", callback_data="cart:view")])
    return with_nav(rows, language, back=f"catalog:cat:{product.get('category_id') or 0}:0")


def cart_kb(lines: list[dict], language: str = "vi") -> InlineKeyboardMarkup:
    rows = []
    for line in lines:
        pid = line["product_id"]
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"❌ {line['name']} × {line['quantity']}",
                    callback_data=f"cart:del:{pid}",
                )
            ]
        )
    if lines:
        rows.append([InlineKeyboardButton(text="💳 Thanh toán giỏ hàng", callback_data="order:cart")])
    rows.append([InlineKeyboardButton(text="🛍 Tiếp tục mua", callback_data="catalog:list")])
    return with_nav(rows, language, back="menu:home")


def discount_prompt_kb(language: str = "vi") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎟 Nhập mã giảm giá", callback_data="discount:ask")],
            [InlineKeyboardButton(text="⏭ Không dùng mã", callback_data="discount:skip")],
        ]
    )


def order_kb(order_code: str, language: str = "vi") -> InlineKeyboardMarkup:
    return with_nav(
        [
            [InlineKeyboardButton(text="🔄 Đã chuyển khoản — kiểm tra", callback_data=f"order:check:{order_code}")],
            [InlineKeyboardButton(text="❌ Hủy đơn", callback_data=f"order:cancel:{order_code}")],
        ],
        language,
        back="menu:home",
    )
