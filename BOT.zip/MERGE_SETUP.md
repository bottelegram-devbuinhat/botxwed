# MERGE_SETUP — Hướng dẫn cài đặt bản merge (bot Python + telegram-sales-bot)

## 1. Đã thay đổi những gì

Bot Python cũ được giữ nguyên, thêm luồng **mua trực tiếp không cần nạp ví** theo thiết kế của
repo Node.js (đã viết lại bằng Python):

- Khách xem danh mục → chọn sản phẩm → chọn số lượng → (nhập mã giảm giá) → bot tạo đơn
  `ORD…` + ảnh QR VietQR đúng số tiền, nội dung chuyển khoản là mã đơn.
- Khách chuyển khoản → SePay webhook (hoặc poller 2 phút/lần) khớp mã + số tiền → đơn thành
  `paid` → bot **tự giao hàng**: acc Liên Quân (gửi tk/mk đã giải mã) hoặc credential sản phẩm.
- Đơn chưa thanh toán sau **5 phút** tự huỷ, acc đang giữ được thả ra.
- Thêm: giỏ hàng nhiều món, mã giảm giá, nhiều tài khoản ngân hàng, nhắc hết hạn gói subscription.

Luồng mua bằng ví cũ (nạp NAP → trừ số dư) **vẫn chạy song song**, không bị xoá.

## 2. File cần ghi đè lên host (thư mục bot, vd `/home/np3051uw4n/BOTLQ`)

| File trong gói này | Ghi đè lên | Ghi chú |
|---|---|---|
| `database/models.py` | `database/models.py` | **Thay toàn bộ.** Thêm Category, Product, Credential, CartItem, OrderItem, DiscountCode, DiscountUsage, BankAccount; Order mở rộng (order_code, total_amount, qr_url, expires_at…). Model cũ (Account, User, Deposit…) giữ nguyên. |
| `database/session.py` | `database/session.py` | **Thay toàn bộ.** Tự thêm cột mới khi khởi động (kể cả DB cũ). |
| `services/catalog_service.py` | `services/catalog_service.py` | **Mới.** Danh mục/sản phẩm/credential/ngân hàng. |
| `services/cart_service.py` | `services/cart_service.py` | **Mới.** Giỏ hàng. |
| `services/discount_service.py` | `services/discount_service.py` | **Mới.** Mã giảm giá. |
| `services/order_service.py` | `services/order_service.py` | **Mới.** Đơn trực tiếp ORD, hết hạn, giao hàng. |
| `services/sepay_poller.py` | `services/sepay_poller.py` | **Mới.** Poller SePay 2 phút/lần. |
| `services/payment_service.py` | `services/payment_service.py` | **Thay toàn bộ.** Thêm nhánh ORD vào webhook SePay + `vietqr_url_bank`. Nhánh NAP (nạp ví) giữ nguyên. |
| `handlers/shop_merge.py` | `handlers/shop_merge.py` | **Mới.** Router `/catalog`, giỏ hàng, mua trực tiếp, mã giảm giá. |
| `keyboards/catalog.py` | `keyboards/catalog.py` | **Mới.** Bàn phím danh mục/sản phẩm/giỏ/đơn. |
| `scheduler/jobs.py` | `scheduler/jobs.py` | **Thay toàn bộ.** Thêm job hết hạn đơn (30 giây) + nhắc hết hạn gói (1 giờ). Job cũ (giữ acc, backup, thưởng tuần) giữ nguyên. |

**Không ghi đè:** `main.py` (chỉ sửa 5 chỗ nhỏ dưới đây), `keyboards/shop.py` (thêm 1 nút),
`handlers/shop.py`, `handlers/wallet.py`, `handlers/casino.py`, `handlers/ai.py`, `services/shop_service.py`,
`services/wallet_service.py`, `config.py`, `data/bot.db`.

## 3. Sửa `main.py` (5 chỗ, làm bằng tay trên host)

1. Dòng import handlers (dòng ~18), thêm `shop_merge`:
   ```python
   from handlers import ai, guide, leaderboard, profile, rewards, sell, shop, shop_merge, start, support, wallet
   ```
2. Thêm import poller (sau dòng `from services.payment_service import start_webhook_server`):
   ```python
   from services.sepay_poller import start_sepay_poller
   ```
3. Thêm lệnh `/catalog` vào `BOT_COMMANDS`:
   ```python
   BotCommand(command="catalog", description="Danh mục sản phẩm"),
   ```
4. Trong `build_dispatcher()`, sau dòng `dp.include_router(shop.router)`:
   ```python
   dp.include_router(shop_merge.router)
   ```
5. Trong `main()`, sau khối `webhook_runner = await start_webhook_server(bot)`:
   ```python
   poller_task = start_sepay_poller(bot)
   ```
   Và trong khối `finally`, trước `await bot.session.close()`:
   ```python
   if poller_task is not None:
       poller_task.cancel()
   ```

## 4. Thêm nút "Mua bằng chuyển khoản" vào chi tiết acc (không bắt buộc nhưng nên có)

Trong `keyboards/shop.py`, hàm `account_detail` (dòng ~101), thêm 1 hàng sau nút `🛒 Mua ngay`:
```python
[InlineKeyboardButton(text="💳 Mua bằng chuyển khoản", callback_data=f"order:acc:{code}")],
```
Nút này mở luồng mua trực tiếp (không trừ ví) cho acc đó. Không thêm thì khách vẫn mua trực
tiếp được qua `/catalog` (sản phẩm) — còn acc LQ chỉ mua được bằng ví như cũ.

## 5. `.env` — những gì cần điền

```env
BOT_TOKEN=<token cũ của bot — giữ nguyên, KHÔNG gửi qua chat>
SEPAY_ENABLED=true          # bật lại SePay (trước đây là false)
SEPAY_API_KEY=<key SePay — lấy trong dashboard SePay, KHÔNG gửi qua chat>
ORDER_EXPIRY_MINUTES=5      # không bắt buộc, mặc định là 5
BANK_CODE=MB
BANK_ACCOUNT=05817666778899
BANK_HOLDER=BUI NGUYEN XUAN NHAT
```

AI key giữ nguyên như cũ (config.py tự chọn GEMINI/GROQ). Không cần key mới.

## 6. SePay — cấu hình webhook

- Webhook URL đặt trong dashboard SePay: `https://shoplq.duckdns.org/sepay/webhook`
  (bot lắng nghe `POST /sepay/webhook` trên cổng `WEBHOOK_PORT`, mặc định 8080).
- Sự kiện: **"Có tiền vào"** (incoming transaction).
- **Lưu ý trên host cPanel dùng chung:** cổng 8080 thường không mở ra ngoài, webhook có thể không
  tới được bot. Trường hợp đó **poller là đường chính**: cứ 2 phút nó tự gọi API SePay
  (`my.sepay.vn/userapi/transactions/list`) để đối soát, không cần mở cổng. Webhook chỉ là
  đường nhanh hơn khi cổng mở được.

## 7. Chạy thử

1. Sao lưu `data/bot.db` trước khi chạy (scheduler cũng backup lúc 3h sáng).
2. Khởi động lại bot. Log phải có: `SePay poller started` (nếu đã điền `SEPAY_API_KEY`),
   `SePay webhook listening on 0.0.0.0:8080`, `Scheduler started with 5 jobs`.
3. `/catalog` → phải hiện danh mục (trống nếu chưa có sản phẩm — xem mục 8).
4. Tạo 1 sản phẩm test + 1 credential test (mục 8), mua thử bằng chuyển khoản thật với số tiền
   nhỏ, kiểm tra: đơn thành `paid` → bot tự gửi credential → đơn thành `delivered`.
5. Kiểm tra đơn quá 5 phút không thanh toán tự huỷ và acc được thả.

## 8. Thêm sản phẩm / credential / mã giảm giá — CHƯA CÓ LỆNH ADMIN

**Chưa xong trong đợt này:** lệnh admin Telegram `/addproduct`, `/addcred`, `/bulkcred`,
`/stock`, `/adddiscount` của repo chưa được port thành lệnh cho bot Python. Hàm xử lý đã có
sẵn trong `services/catalog_service.py` (`create_category`, `create_product`,
`add_credentials`, `create_bank_account`, `list_products`) và
`services/discount_service.py` (`create_discount_code`) — chỉ thiếu lớp lệnh admin gọi chúng.
Tạm thời có 2 cách:

- **Cách nhanh (khuyên dùng):** chạy 1 đoạn Python ngắn trên host (trong venv của bot) gọi các
  hàm trên để thêm danh mục/sản phẩm/credential. Cần `FERNET_KEY` đúng để credential mã hoá
  được (hàm dùng `crypto_service` của bot).
- **Cách sau:** port thêm 1 router admin (`handlers/admin_catalog.py`) với các lệnh trên, hoặc
  mở rộng admin web Flask để quản lý Product/Credential/Discount.

Cho tới khi có sản phẩm, `/catalog` sẽ báo trống — đó là bình thường, không phải lỗi.

## 9. Tính năng đã xoá / không port

- Dashboard web Node.js (`public/admin.html`): không port — admin web Flask đã có.
- Đa tiền tệ, USDT, PayPal: không port — shop chỉ bán VND.
- Link checker, thu email khách: không port.
- Dữ liệu mẫu của repo (Capcut/ChatGPT/Netflix): **không copy** — là hàng mẫu giả.

## 10. Web shop (AnhDev Store) — TẠM DỪNG

Tích hợp web đọc `stock.json` từ git **đang tạm dừng** chờ merge này xong. Sau khi bot chạy ổn
với model mới, bước tiếp theo là: xuất `stock.json` từ DB Python mới (Product + Account) và
cho AnhDev Store đọc — lúc đó mới nối lại.

## 11. Những gì chưa kiểm chứng được

- **Chưa chạy thử bot thật:** không có môi trường chạy (không có aiogram/SQLAlchemy trên máy
  làm việc, không có token/DB thật). Tất cả file Python đã qua `py_compile`; model mới đã
  smoke-test tạo bảng + insert trên SQLite tạm (23 bảng, unique constraint OK).
- **Chưa test SePay thật:** cần key + giao dịch thật.
- **Chưa test trên host cPanel:** admin app trên trial host đang lỗi LiteSpeed (xem tiến độ
  triển khai) — cần HostVN hỗ trợ trước khi deploy bản merge.
- **Chưa có lệnh admin cho sản phẩm** (mục 8).
