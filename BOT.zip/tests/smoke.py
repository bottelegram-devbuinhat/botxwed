"""End-to-end smoke test for the business logic (no Telegram network involved).

Run with:  cd bot && .venv/bin/python tests/smoke.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="bot-smoke-"))
os.environ["BOT_TOKEN"] = "123456:TEST-TOKEN"
os.environ["OWNER_IDS"] = "1"
os.environ["DATABASE_URL"] = f"sqlite+aiosqlite:///{TMP / 'smoke.db'}"

from cryptography.fernet import Fernet  # noqa: E402

os.environ["FERNET_KEY"] = Fernet.generate_key().decode()

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from database.seed import seed_if_empty  # noqa: E402
from database.session import init_db  # noqa: E402
from services import casino_service, ranking_service, rewards_service, shop_service  # noqa: E402
from services import wallet_service as wallet  # noqa: E402
from settings_check import check_settings  # noqa: E402


async def main() -> None:
    await init_db()
    await seed_if_empty()
    await check_settings()

    # The sample seed is disabled in production, so the test creates its own
    # stock and giftcode instead of depending on it.
    created = await shop_service.create_account(
        price=100_000, rank="Kim Cương", heroes=50, skins=20,
        username="smoke_user", password="smoke_pass",
    )
    assert created.code, "cannot create a test account"
    assert await rewards_service.create_giftcode("WELCOME", 50_000, "vnd", 5, 30) is not None

    user_id = 900001
    user = await wallet.ensure_user(user_id, "smoke_tester", "Smoke Tester")
    assert user.id == user_id
    assert await wallet.add_balance(user_id, 500_000, "test", note="smoke top-up")
    assert not await wallet.add_balance(user_id, 0, "test")

    coins_ok = await wallet.add_balance(user_id, 10_000, "test_coin", currency="coin", note="smoke coins")
    assert coins_ok

    accounts, total = await shop_service.list_accounts(page=0, per_page=5)
    assert total >= 1 and accounts, "test account missing"
    target = next((item for item in accounts if item.code == created.code), accounts[0])
    result = await shop_service.buy_account(user_id, target.code)
    assert result["ok"], result
    assert result["username"] == "smoke_user", result["username"]
    after_purchase = await wallet.get_user(user_id)
    assert after_purchase.shop_balance < 500_000

    bet = await casino_service.place_bet(user_id, "taixiu", 1000, "TAI")
    assert bet["ok"], bet
    assert "Seed" in bet["text"]

    checkin = await rewards_service.checkin(user_id)
    assert checkin["ok"], checkin
    again = await rewards_service.checkin(user_id)
    assert not again["ok"]

    redeem = await rewards_service.redeem_giftcode(user_id, "WELCOME")
    assert redeem["ok"], redeem
    duplicate = await rewards_service.redeem_giftcode(user_id, "WELCOME")
    assert not duplicate["ok"]

    missions = await rewards_service.mission_progress(user_id)
    assert len(missions) == 4

    withdrawal = await wallet.request_withdraw(user_id, 100_000, "MB Bank", "0123456789", "SMOKE TESTER")
    assert withdrawal is not None
    pending = await wallet.pending_withdrawals()
    assert any(w.id == withdrawal.id for w in pending)
    rejected = await wallet.reject_withdraw(withdrawal.id, 1, "smoke")
    assert rejected is not None

    deposit = await wallet.create_deposit(user_id, 50_000, "bank")
    assert deposit is not None
    approved = await wallet.approve_deposit(deposit.id, 1)
    assert approved is not None
    assert (await wallet.get_user(user_id)).total_deposited == 50_000

    top = await ranking_service.top("deposits", "all", limit=5)
    assert top and top[0][0] == user_id
    rank, value = await ranking_service.my_rank("deposits", user_id)
    assert rank == 1, (rank, value)

    orders = await shop_service.orders_of(user_id)
    assert orders and orders[0].account_code == target.code

    review = await shop_service.add_review(user_id, target.id, 5, "Acc tốt")
    assert review.rating == 5

    print("SMOKE OK — users, shop, casino, rewards, deposits, withdrawals and rankings work")


if __name__ == "__main__":
    asyncio.run(main())
