"""Replay real pending Telegram updates through the dispatcher without acknowledging them.

The updates are only *peeked* at (offset=0 keeps them pending on the server), then
fed into the real dispatcher with a fake session, so a crash or a silent handler is
visible without touching the live chat.

Run with:  python tests/replay_pending.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import traceback
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ.setdefault("DATABASE_URL", f"sqlite+aiosqlite:///{Path(tempfile.mkdtemp()) / 'replay.db'}")

from aiogram import Bot  # noqa: E402
from aiogram.client.session.base import BaseSession  # noqa: E402
from aiogram.methods import AnswerCallbackQuery, EditMessageText, SendChatAction, SendMessage  # noqa: E402
from aiogram.types import Chat, Message  # noqa: E402

CALLS: list[str] = []


class FakeSession(BaseSession):
    async def close(self) -> None:
        return None

    async def stream_content(self, *args, **kwargs):
        yield b""

    async def make_request(self, bot, method, timeout=None):
        if isinstance(method, (SendMessage, EditMessageText)):
            CALLS.append(method.text or "")
            return Message(
                message_id=len(CALLS),
                date=datetime.now(),
                chat=Chat(id=getattr(method, "chat_id", 1), type="private"),
            )
        CALLS.append(f"<{type(method).__name__}>")
        return True


async def main() -> int:
    from config import BOT_TOKEN
    from database.seed import seed_if_empty
    from database.session import init_db
    from main import build_dispatcher

    await init_db()
    await seed_if_empty()

    real = Bot(BOT_TOKEN)
    updates = await real.get_updates(offset=0, limit=20, timeout=0, allowed_updates=["message", "callback_query"])
    await real.session.close()
    print(f"pending updates: {len(updates)}")

    bot = Bot("123456789:AAFakeTokenForReplayTests_abcdefghijkl", session=FakeSession())
    dp = build_dispatcher()

    failures = 0
    for update in updates:
        before = len(CALLS)
        try:
            await dp.feed_update(bot, update)
        except Exception:
            failures += 1
            print(f"✗ update {update.update_id}: CRASH")
            traceback.print_exc()
            continue
        produced = CALLS[before:]
        if not [c for c in produced if not c.startswith("<")]:
            print(f"✗ update {update.update_id}: NO REPLY (calls={produced})")
            failures += 1
        else:
            first = next(c for c in produced if not c.startswith("<")).splitlines()[0]
            print(f"✓ update {update.update_id}: {first[:80]}")

    await bot.session.close()
    print("RESULT:", "OK" if failures == 0 else f"{failures} FAILURE(S)")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
