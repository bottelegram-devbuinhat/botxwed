"""Small assertions about default settings used by the smoke test."""

from __future__ import annotations


async def check_settings() -> None:
    from services.settings_service import all_settings

    settings = await all_settings(force=True)
    assert settings["min_deposit"] > 0
    assert settings["casino_min_bet"] > 0
    assert settings["max_withdraw"] >= settings["min_withdraw"]
    assert set(settings["game_enabled"]) == {
        "taixiu",
        "chanle",
        "xocdia",
        "baucua",
        "rongho",
        "baccarat",
        "blackjack",
        "slots",
        "roulette",
        "highlow",
        "numberguess",
        "mysterybox",
    }
    assert settings["commission_percent"] >= 0
