"""AI router tests: model choice, key rotation on 429/401, cooldowns, token budget.

Run with:  python tests/ai_router.py

No network and no database: ``ai_service._http`` is replaced by a scripted fake.
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ["AI_API_KEY"] = "key-one,key-two"
os.environ["AI_MODEL_CHAT"] = "chat-small"
os.environ["AI_MODEL_EXTRACT"] = "extract-strong"
os.environ["AI_MODEL"] = "fallback-model"
os.environ["AI_MODELS"] = "extra-model"
os.environ["AI_REQUESTS_PER_MINUTE"] = "50"

from services import ai_service  # noqa: E402

FAILURES: list[str] = []


def check(condition: bool, message: str) -> None:
    print(("✓ " if condition else "✗ ") + message)
    if not condition:
        FAILURES.append(message)


def reset() -> None:
    ai_service.reset_cooldowns()
    ai_service._rate_window.clear()
    ai_service._EXTRACT_CACHE.clear()
    for key in ai_service._stats:
        ai_service._stats[key] = 0 if isinstance(ai_service._stats[key], int) else ""


class FakeHttp:
    def __init__(self, behaviour) -> None:
        self.behaviour = behaviour
        self.calls: list[tuple[str, str]] = []

    async def __call__(self, body: dict, key: str):
        self.calls.append((key, body["model"]))
        return self.behaviour(body, key)


def ok_payload(message: dict | None = None) -> dict:
    return {
        "choices": [{"message": message or {"content": "xin chào"}}],
        "usage": {"prompt_tokens": 120, "completion_tokens": 30},
    }


async def test_key_rotation_on_429() -> None:
    reset()

    def behaviour(body, key):
        if key == "key-one":
            return None, 429, '{"error": "rate limit"}'
        return ok_payload(), 200, ""

    fake = FakeHttp(behaviour)
    ai_service._http = fake
    data = await ai_service._call("chat", {"messages": [{"role": "user", "content": "hi"}]})

    check(data is not None, "429: vẫn lấy được câu trả lời từ key dự phòng")
    check([key for key, _ in fake.calls] == ["key-one", "key-two"], "429: key#1 -> key#2")
    check(ai_service._stats["rate_limited"] == 1, "429: có ghi nhận rate limit")
    check(ai_service.status()["keys"][0]["ready"] is False, "429: key#1 bị tạm khoá")
    check(ai_service.status()["keys"][1]["ready"] is True, "429: key#2 vẫn sẵn sàng")

    # A cooling key must be skipped without another HTTP call.
    before = len(fake.calls)
    await ai_service._call("chat", {"messages": [{"role": "user", "content": "again"}]})
    check(len(fake.calls) == before + 1, "429: lần sau bỏ qua key đang chờ, chỉ gọi key#2")


async def test_model_failover() -> None:
    reset()

    def behaviour(body, key):
        if body["model"] == "chat-small":
            return None, 404, '{"error": "model_not_found"}'
        return ok_payload(), 200, ""

    fake = FakeHttp(behaviour)
    ai_service._http = fake
    data = await ai_service._call("chat", {"messages": []}, preferred="chat-small")

    check(data is not None, "model lỗi: chuyển được model dự phòng")
    check([model for _, model in fake.calls] == ["chat-small", "fallback-model"], "model: chat-small -> fallback-model")
    check(ai_service._stats["switched"] == 1, "model: có ghi nhận đổi model")


async def test_dead_key_and_all_down() -> None:
    reset()

    fake = FakeHttp(lambda body, key: (None, 401, '{"error": "unauthorized"}'))
    ai_service._http = fake
    data = await ai_service._call("chat", {"messages": []})

    check(data is None, "401: không có phản hồi khi mọi key chết")
    check(all(not item["ready"] for item in ai_service.status()["keys"]), "401: mọi key bị khoá 1 giờ")

    before = len(fake.calls)
    await ai_service._call("chat", {"messages": []})
    check(len(fake.calls) == before, "401: lần sau không tốn thêm request nào")


async def test_request_budget() -> None:
    reset()
    fake = FakeHttp(lambda body, key: (ok_payload(), 200, ""))
    ai_service._http = fake
    original = ai_service.AI_REQUESTS_PER_MINUTE
    ai_service.AI_REQUESTS_PER_MINUTE = 1
    try:
        first = await ai_service._call("chat", {"messages": []})
        second = await ai_service._call("chat", {"messages": []})
    finally:
        ai_service.AI_REQUESTS_PER_MINUTE = original

    check(first is not None and second is None, "hạn mức: request thứ 2 bị chặn")
    check(len(fake.calls) == 1, "hạn mức: không gọi API khi đã vượt budget")


async def test_reasoning_effort_fallback() -> None:
    reset()
    seen: list[dict] = []

    def behaviour(body, key):
        seen.append(dict(body))
        if "reasoning_effort" in body:
            return None, 400, '{"error": "Unsupported parameter: reasoning_effort"}'
        return ok_payload(), 200, ""

    original = ai_service.AI_REASONING_EFFORT
    ai_service.AI_REASONING_EFFORT = "low"
    ai_service._http = FakeHttp(behaviour)
    try:
        data = await ai_service._call(
            "chat", {"messages": [], "max_tokens": 10, **ai_service._effort_params()}
        )
    finally:
        ai_service.AI_REASONING_EFFORT = original

    check(data is not None, "reasoning_effort: provider từ chối thì vẫn có câu trả lời")
    check(len(seen) == 2 and "reasoning_effort" not in seen[-1], "reasoning_effort: tự bỏ tham số và thử lại")


async def test_extract_route_and_cache() -> None:
    reset()
    payload = {
        "choices": [
            {
                "message": {
                    "content": '{"accounts": [{"price": 100000, "username": "u", "password": "p"}]}'
                }
            }
        ],
        "usage": {"prompt_tokens": 500, "completion_tokens": 80},
    }
    fake = FakeHttp(lambda body, key: (payload, 200, ""))
    ai_service._http = fake

    first = await ai_service.extract_accounts("acc 1: gia 100k user u pass p")
    calls_after_first = len(fake.calls)
    second = await ai_service.extract_accounts("acc 1: gia 100k user u pass p")

    check(first["ok"] and len(first["records"]) == 1, "extract: đọc được acc")
    check(fake.calls[0][1] == "extract-strong", "extract: dùng model đọc file riêng")
    check(len(fake.calls) == calls_after_first, "extract: gửi lại cùng file không tốn token")
    check(first == second, "extract: kết quả cache giống nhau")


async def test_reply_wiring() -> None:
    reset()
    captured: dict = {}

    async def fake_model_name() -> str:
        return "chat-small"

    async def fake_prompt() -> str:
        return "system"

    async def fake_context(ctx) -> str:
        return "context"

    async def fake_call(route, payload, preferred=None):
        captured.update({"route": route, "preferred": preferred, "payload": payload})
        return {"choices": [{"message": {"content": "ok"}}]}

    originals = (ai_service.model_name, ai_service.system_prompt, ai_service._context_block, ai_service._call)
    ai_service.model_name, ai_service.system_prompt, ai_service._context_block, ai_service._call = (
        fake_model_name,
        fake_prompt,
        fake_context,
        fake_call,
    )
    try:
        history = [{"role": "user", "content": "x" * 5000}, {"role": "assistant", "content": "y" * 5000}]
        answer = await ai_service.reply(1, "z" * 5000, history=history, is_admin=False, name="T")
    finally:
        (
            ai_service.model_name,
            ai_service.system_prompt,
            ai_service._context_block,
            ai_service._call,
        ) = originals

    payload = captured.get("payload") or {}
    messages = payload.get("messages") or []
    check(answer == "ok", "chat: trả lời đi qua router")
    check(captured.get("route") == "chat", "chat: đúng luồng chat")
    check(captured.get("preferred") == "chat-small", "chat: ưu tiên model chat")
    check(payload.get("max_tokens") == ai_service.AI_MAX_TOKENS, "chat: dùng hạn mức token nhỏ")
    check(
        all(len(message.get("content", "")) <= ai_service.AI_HISTORY_CHARS for message in messages[2:-1])
        and len(messages[-1]["content"]) <= ai_service.MAX_QUESTION_CHARS,
        "chat: cắt ngắn history/câu hỏi để tiết kiệm token",
    )


async def main() -> int:
    await test_key_rotation_on_429()
    await test_model_failover()
    await test_dead_key_and_all_down()
    await test_request_budget()
    await test_reasoning_effort_fallback()
    await test_extract_route_and_cache()
    await test_reply_wiring()
    print("RESULT:", "OK" if not FAILURES else f"{len(FAILURES)} FAILURE(S)")
    for item in FAILURES:
        print(" -", item)
    return 1 if FAILURES else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
