"""Offline UI harness: feeds updates through the real dispatcher without Telegram.

Run with:  python tests/offline_ui.py

Every outgoing API call is captured so the test can assert that the bot answered
and which keyboard the user would get. It also covers the admin <-> user menu
switch and the AI account-file extractor (with a stubbed model response).
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

TMP = Path(tempfile.mkdtemp(prefix="bot-offline-"))
os.environ["DATABASE_URL"] = f"sqlite+aiosqlite:///{TMP / 'test.db'}"
os.environ.setdefault("ADMIN_IDS", "8792000582")
# The extractor test stubs the HTTP call, but the AI service still refuses to run
# without a configured key.
os.environ.setdefault("AI_API_KEY", "offline-ui-test-key")

from aiogram import Bot  # noqa: E402
from aiogram.client.session.base import BaseSession  # noqa: E402
from aiogram.methods import EditMessageText, SendMessage  # noqa: E402
from aiogram.types import CallbackQuery, Chat, Message, Update, User as TgUser  # noqa: E402

ADMIN = 8792000582
PLAYER = 111

CALLS: list[dict] = []


def _buttons(markup) -> list[str]:
    data: list[str] = []
    for row in getattr(markup, "inline_keyboard", []) or []:
        for button in row:
            data.append(button.callback_data or button.url or button.text)
    return data


class FakeSession(BaseSession):
    async def close(self) -> None:
        return None

    async def stream_content(self, *args, **kwargs):
        yield b""

    async def make_request(self, bot, method, timeout=None):
        if isinstance(method, (SendMessage, EditMessageText)):
            CALLS.append({"kind": type(method).__name__, "text": method.text or "", "buttons": _buttons(method.reply_markup)})
            return Message(
                message_id=len(CALLS),
                date=datetime.now(),
                chat=Chat(id=getattr(method, "chat_id", 1), type="private"),
            )
        CALLS.append({"kind": type(method).__name__, "text": "", "buttons": []})
        return True


def _bot() -> Bot:
    return Bot("123456789:AAFakeTokenForOfflineTests_abcdefghijkl", session=FakeSession())


def _update(update_id: int, message: Message) -> Update:
    return Update(update_id=update_id, message=message)


def _msg(text: str, user_id: int, bot: Bot) -> Message:
    user = TgUser(id=user_id, is_bot=False, first_name=f"User{user_id}")
    message = Message(
        message_id=1,
        date=datetime.now(),
        chat=Chat(id=user_id, type="private"),
        from_user=user,
        text=text,
    )
    return message.as_(bot)


def _cb(data: str, user_id: int, bot: Bot, message_id: int = 50) -> Update:
    user = TgUser(id=user_id, is_bot=False, first_name=f"User{user_id}")
    message = Message(
        message_id=message_id,
        date=datetime.now(),
        chat=Chat(id=user_id, type="private"),
        from_user=user,
        text="screen",
    ).as_(bot)
    return Update(
        update_id=message_id + 1000,
        callback_query=CallbackQuery(
            id=f"cb{message_id}",
            from_user=user,
            chat_instance="ci",
            data=data,
            message=message,
        ).as_(bot),
    )


def _screens(before: int) -> list[dict]:
    return [call for call in CALLS[before:] if call["text"]]


async def _ai_import_check() -> list[str]:
    """The AI extractor must validate real rows without inventing anything."""
    from services import ai_service, shop_service

    payload = {
        "choices": [
            {
                "message": {
                    "content": (
                        '{"accounts": ['
                        '{"price": "450k", "rank": "Kim Cuong", "level": 40, "heroes": 80, "skins": 30, '
                        '"username": "ai_user_1", "password": "ai_pass_1", "login_type": "Facebook", '
                        '"category": "3S", "is_banned": false},'
                        '{"price": 120000, "rank": "Bach Kim", "username": "ai_user_2", '
                        '"password": "ai_pass_2", "is_banned": "true", "email_info": "a@b.c"},'
                        '{"price": 0, "username": "", "password": ""}'
                        "]}"
                    )
                }
            }
        ]
    }

    async def fake_http(body, key):
        return payload, 200, ""

    original = ai_service._http
    ai_service._http = fake_http
    ai_service.reset_cooldowns()
    ai_service._rate_window.clear()
    ai_service._EXTRACT_CACHE.clear()
    try:
        extracted = await ai_service.extract_accounts("garbage dump of 3 accounts")
    finally:
        ai_service._http = original

    problems: list[str] = []
    if len(extracted["records"]) != 3:
        problems.append(f"extractor returned {len(extracted['records'])} records")
    result = await shop_service.import_ai_accounts(extracted["records"])
    if result["created"] != 2:
        problems.append(f"AI import created {result['created']} accounts (expected 2)")
    if not any("giá" in error for error in result["errors"]):
        problems.append("invalid row (price 0) was not rejected")
    print(f"{'✓' if not problems else '✗'} AI file import: created={result['created']} errors={len(result['errors'])}")
    return problems


async def main() -> int:
    from database.seed import seed_if_empty
    from database.session import engine, init_db
    from main import build_dispatcher

    await init_db()
    await seed_if_empty()

    bot = _bot()
    dp = build_dispatcher()
    failures: list[str] = []

    async def run(name: str, update: Update) -> list[dict]:
        before = len(CALLS)
        try:
            await dp.feed_update(bot, update)
        except Exception as exc:  # noqa: BLE001 - report every crash
            failures.append(f"{name}: EXCEPTION {type(exc).__name__}: {exc}")
            print(f"✗ {name}: EXCEPTION {type(exc).__name__}: {exc}")
            return []
        screens = _screens(before)
        if not screens:
            failures.append(f"{name}: no message")
            print(f"✗ {name}: NO MESSAGE")
        else:
            print(f"✓ {name}: {screens[-1]['text'].splitlines()[0][:70]}")
        return screens

    await run("player /start", _update(1, _msg("/start", PLAYER, bot)))
    await run("player menu:buy", _cb("menu:buy", PLAYER, bot))
    await run("player menu:home", _cb("menu:home", PLAYER, bot, 51))

    admin_start = await run("admin /start", _update(2, _msg("/start", ADMIN, bot)))
    user_menu = admin_start[-1]["buttons"] if admin_start else []
    if not any("admin:panel" in (button or "") for button in user_menu):
        failures.append("admin /start: user menu is missing the 🛠 Admin button")

    await run("admin text button", _update(3, _msg("💰 Bán / Ký gửi", ADMIN, bot)))
    panel = await run("admin panel", _cb("admin:panel", ADMIN, bot, 60))
    panel_buttons = panel[-1]["buttons"] if panel else []
    if not any(button == "menu:home" for button in panel_buttons):
        failures.append("admin panel: missing the 👤 Menu người dùng switch")

    await run("admin stats", _cb("admin:stats", ADMIN, bot, 61))
    await run("admin accounts", _cb("admin:accounts:0", ADMIN, bot, 62))
    await run("admin ai", _cb("admin:ai", ADMIN, bot, 63))

    back_to_user = await run("admin menu:home", _cb("menu:home", ADMIN, bot, 64))
    if back_to_user:
        text = back_to_user[-1]["text"]
        if "MENU CHÍNH" not in text:
            failures.append("admin menu:home did not show the user menu")
        if not any("admin:panel" in (button or "") for button in back_to_user[-1]["buttons"]):
            failures.append("admin user menu: missing the way back to the admin panel")

    await run("plain text", _update(4, _msg("hello", PLAYER, bot)))

    failures.extend(await _ai_import_check())

    await engine.dispose()
    await bot.session.close()
    print("RESULT:", "OK" if not failures else f"{len(failures)} FAILURE(S)")
    for item in failures:
        print(" -", item)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
