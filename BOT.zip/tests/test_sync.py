import asyncio
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from services.stock_sync_service import sync_stock_now


async def main():
    print("Testing sync_stock_now()...")
    ok = await sync_stock_now()
    print("Result:", ok)
    assert ok is True, "sync_stock_now should succeed"
    assert os.path.exists("stock.json"), "stock.json should be created"
    print("Local stock.json size:", os.path.getsize("stock.json"))
    print("PASS: sync_stock_now works properly!")


if __name__ == "__main__":
    asyncio.run(main())
