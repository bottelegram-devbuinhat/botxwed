# Changelog

## 1.4.0 — 20/11/2026

### Bot không trả lời / im lặng
- Thêm `handlers/errors.py` gắn vào `dp.errors`: mọi lỗi chưa xử lý được ghi log kèm traceback và nhắn lại
  cho người dùng, thay vì im lặng như trước.
- `handlers/ui.py`: tin nhắn bị Telegram từ chối (HTML/entity lỗi) giờ tự gửi lại dạng văn bản thuần,
  không còn nuốt mất tin nhắn; bắt riêng `TelegramForbiddenError` (user chặn bot).
- `main.py`: xoá webhook còn sót trước khi long polling (nguyên nhân 409 Conflict làm bot "chết"),
  log rõ bot đang đăng nhập, token sai (401) hoặc trùng token (409); scheduler / webhook thanh toán
  lỗi không còn chặn polling.

### Menu admin và menu người dùng
- Bảng điều khiển admin luôn có nút **👤 Menu người dùng** (chuyển sang giao diện người chơi) và **🔄 Làm mới**;
  menu người dùng của admin giữ nút **🛠 Admin** để quay lại bảng điều khiển.
- Trang menu chính của admin có ghi chú đang ở menu người dùng và cách quay lại.

### Phân luồng AI, tiết kiệm token, đổi model/key khi bị limit
- Router trong `services/ai_service.py`: mỗi lượt gọi chia theo luồng — `chat` (câu trả lời ngắn, model rẻ,
  `AI_MAX_TOKENS=450`, history/câu hỏi bị cắt) và `extract` (đọc file acc, `AI_MAX_TOKENS_EXTRACT`).
- Nhiều API key: `AI_API_KEY="key1,key2"` hoặc `AI_API_KEY_2..AI_API_KEY_10`. Gặp **429** → tạm khoá key
  `AI_KEY_COOLDOWN` giây rồi chuyển key kế tiếp; **401/403** → khoá key 1 giờ; **404/model không tồn tại**
  → chuyển model dự phòng trong `AI_MODELS`; lỗi 5xx/timeout → khoá ngắn rồi thử key/model khác.
- Chặn quá tải: `AI_REQUESTS_PER_MINUTE` (20), `AI_MAX_CONCURRENCY` (3), tối đa 6 lần thử mỗi lượt;
  key/model đang chờ bị bỏ qua nên không tốn request.
- Đọc file tốn ít hơn: chunk 6k ký tự, tối đa 4 chunk, cache kết quả 5 phút theo nội dung file,
  dừng sớm khi đủ 300 acc. Chat: history 8 lượt × 600 ký tự, câu hỏi ≤ 1200 ký tự, tối đa 2 vòng tool.
- `AI_REASONING_EFFORT=low` (tuỳ chọn) cho model reasoning: đo thật trên Groq giảm output token
  từ 185 → 72 cho cùng câu hỏi; provider nào từ chối tham số thì bot tự bỏ rồi thử lại.
- **🛠 Admin → 🤖 Trợ lý AI** hiển thị số key sẵn sàng, model chat/model đọc file, danh sách model dự phòng
  kèm cooldown, số lượt gọi/OK/lỗi, số lần đổi key-model, 429 và tổng token đã dùng; có nút
  **♻️ Bỏ chờ key/model**.
- `tests/ai_router.py`: test 429 → đổi key, model lỗi → đổi model, mọi key chết → không tốn request,
  vượt budget → chặn, extract dùng đúng model + cache, chat dùng đúng luồng và cắt token.

### AI đọc file acc
- `ai_service.extract_accounts()`: chia file thành từng phần, gọi model trích xuất JSON
  (`price`, `rank`, `level`, `heroes`, `skins`, `username`, `password`, `login_type`, `category`,
  `is_banned`, `uid`, `email_info`, `phone_info`, `last_login`, `warranty_days`, `description`).
- `shop_service.import_ai_accounts()` kiểm tra lại từng dòng trước khi ghi DB (giá > 0, có user/pass),
  không bịa dữ liệu; nhập hàng loạt vẫn sinh mã `LQxxxx` liên tục.
- Admin: **🛠 Kho acc → 🤖 AI đọc file acc** gửi file `.txt/.csv/.json` hoặc dán nội dung.
  **📥 Nhập file** cũng tự chuyển sang AI khi không đọc được định dạng nào.
- Kiểm thử: `tests/offline_ui.py` (giả lập Telegram, kiểm tra trả lời, chuyển menu admin ↔ user, AI import)
  và `tests/replay_pending.py` (phát lại update thật đang chờ mà không xác nhận).

## 1.3.0 — 20/11/2026

### Hai kho acc: Random + Acc sẵn thông tin
- `Account` thêm bộ cột thông tin đầy đủ: `kind`, `category`, `uid`, `region`, `shells`, `shells_note`,
  `email_info`, `phone_info`, `has_pass`, `fb_username/fb_uid/fb_link`, `is_banned`, `ban_note`, `last_login`,
  `account_created`, `has_cccd`, `twofa`, `ss/splus/s/evo/anime/dreamer/other_count`, `skin_lists`, `extra`.
- `init_db()` tự ALTER TABLE thêm cột còn thiếu (SQLite + PostgreSQL), DB cũ không mất dữ liệu.
- Menu shop có 2 nút đầu: **💎 Kho Random (N acc)** và **🌐 Acc sẵn thông tin (N acc)**; danh sách/lọc/sắp xếp
  chỉ áp dụng cho acc sẵn thông tin.
- Thẻ acc mới hiển thị đúng như ảnh mẫu: trạng thái **Full Info [BAN]**, UID, region, sò/nạp sò, EMAIL, SĐT,
  PASS/2FA/CCCD, FB uid+link, rank/level, skin/hero, các tier SS/S+/S/EVO/Anime/Dreamer kèm tên skin,
  login cuối, ngày tạo acc, giá và bảo hành.
- Kho random: gom nhóm theo mức giá, mua ngẫu nhiên 1 acc (`buy_random`), nhận user/pass ngay sau khi thanh toán.

### Nhập acc full info từ block kiểm tra
- `services/hit_parser.py` đọc dump của checker (🔑 user:pass, UID, Region, Sò, Nạp sò, EMAIL, SĐT, PASS,
  FB, BAND, Login cuối, RANK, LEVEL, SKIN, HERO, CCCD, Authen, SS/S+/S/EVO/Anime/S-Dreamer/Other, Tình Trạng).
- Admin: **🌐 Acc full info** → nhập `giá | loại` → dán block hoặc gửi file; tự tách nhiều acc, tự đoán
  `3S/2S/1S/Anime/SS`, báo lại số acc đã thêm và từng acc lỗi.
- **🎲 Kho random**: nhập `giá | tên loại` rồi dán `user:pass` từng dòng.
- Nhập file thường gặp block full info sẽ tự nhận diện và hỏi giá thay vì báo lỗi định dạng.

### Emoji động theo pack
- `/addpack <tên hoặc link addemoji>`: gọi Bot API `getStickerSet`, ghép `custom_emoji_id` vào đúng key
  emoji đang dùng và lưu `data/emoji.json` (hỗ trợ nhiều pack một lần).
- Hỗ trợ sẵn `NewsEmoji`, `BirthdayCollection` — chạy lệnh sau khi bot có token hợp lệ.

### Trợ lý AI
- Công cụ `kho_acc`/`chi_tiet_acc` trả thêm loại acc, trạng thái ban, region, sò, 2FA/CCCD và skin tier;
  `thong_ke_kho` báo riêng số acc random / acc sẵn thông tin.

## 1.2.0 — 20/11/2026

### Trợ lý AI (hỗ trợ + quản lý)
- Thêm `services/ai_service.py`: chat với mọi API OpenAI-compatible (`AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`),
  tự tắt khi thiếu key, không bao giờ làm lỗi bot.
- 7 công cụ thật: `kho_acc`, `chi_tiet_acc`, `thong_ke_kho`, `vi_cua_toi`, `don_hang_cua_toi`, `dat_cuoc`,
  `hoan_tien_don` — mọi con số (giá, số lượng, đơn, số dư, kết quả cược) lấy từ database, không bịa.
- Hoàn tiền: admin được hoàn ngay; người chơi thường được tạo ticket bảo hành + thông báo admin.
- Giao diện **🤖 Trợ lý AI** trong menu chính, `/ai`, 4 câu hỏi nhanh, xoá hội thoại, giới hạn 12 lượt ngữ cảnh
  và rate-limit 2 giây/câu.
- Admin **🤖 Trợ lý AI**: bật/tắt, đổi model, sửa system prompt, test trả lời ngay trong Telegram.
- Thêm emoji `robot` và settings `ai_enabled`, `ai_model`, `ai_system_prompt`.

### Nhập acc hàng loạt từ file
- **🛠 Admin → 🛍 Kho acc → 📥 Nhập file**: nhận `.txt` (`giá | rank | tướng | skin | đăng nhập | user | pass | mô tả`),
  `.csv` (có/không tiêu đề, thứ tự cột tuỳ ý, tên cột Việt/Anh) và `.json` (danh sách object).
- Hỗ trợ giá `500k`/`1.250.000`, level và số ngày bảo hành tuỳ chọn, bỏ qua dòng `#` ghi chú.
- Tạo acc trong một transaction, mã `LQxxxx` liên tục, mật khẩu mã hoá Fernet; báo số acc đã thêm và
  từng dòng lỗi kèm số dòng thật trong file.
- Giới hạn `IMPORT_MAX_ROWS` (300) và `IMPORT_MAX_BYTES` (1 MB) mỗi lần nhập.
- Thêm `shop_service.stock_overview()` dùng chung cho panel admin và trợ lý AI.

## 1.1.0 — 20/11/2026

### Sửa lỗi "nút quay mãi"
- `rw:friends` thiếu `callback.answer()` → nút kẹt loading, đã bổ sung.
- Kiểm tra toàn bộ handler: 126 callback đều trả lời Telegram, không còn nút treo.
- Blackjack nhập cược tay từ tin nhắn gọi `callback.answer` trên `Message` → lỗi im lặng; thêm helper `_notice()` xử lý cả hai loại event.
- Rà soát tự động bằng AST: không còn hàm async gọi thiếu `await`, không còn thao tác blocking trong handler.

### Admin & link ref
- Thêm admin mặc định `8792000582` qua `ADMIN_IDS` (luôn có quyền, không phụ thuộc DB).
- `BOT_USERNAME` (mặc định `devbn_bot`) để tạo link giới thiệu `https://t.me/devbn_bot?start=<id>`.
- Thưởng giới thiệu `referral_bonus_coins` (1.000 xu) cộng một lần cho người mời, chống trùng bằng `Transaction.ref`.
- Nút **👥 Mời bạn** thêm vào menu chính.

### Emoji động & giao diện
- Hệ thống emoji token `[[key]]` (`utils/emoji.py`) + bộ 39 emoji (33 emoji động có id) miễn phí trong `assets/emoji.json`.
- Tự hạ cấp về emoji Unicode khi Telegram từ chối custom emoji (bot chưa có Premium/Fragment).
- Admin: `/emoji`, `/emoji on|off`, `/testemoji`, `/setemoji <key>`, nút **✨ Emoji động** trong panel.
- Làm lại giao diện: header `『 … 』`, thanh phân cách thống nhất, thanh tiến trình VIP, emoji theo ngữ cảnh ở trang chào, shop, casino, ví, hồ sơ, phần thưởng.

### Thư viện
- Thêm `asyncpg` (PostgreSQL) và `tzdata` (timezone cho APScheduler trên Windows/container slim).

## 1.0.0 — 20/11/2026

Bản đầu tiên theo prompt "Telegram bot — Casino (xu ảo) + Shop acc Liên Quân".

### Shop acc
- Danh mục acc với lọc giá/rank/mới nhất/xem nhiều, tìm theo mã, yêu thích, chi tiết nhiều ảnh, đánh giá sao.
- Mua acc nguyên tử: khoá acc + trừ ví + tạo đơn trong một transaction, chống mua trùng.
- Giữ acc tạm thời 7 phút khi đang xác nhận, tự nhả khi hết hạn.
- Giảm giá theo VIP, hoa hồng khi bán acc ký gửi, bảo hành theo từng acc.
- Quy trình ký gửi 9 bước qua FSM, admin duyệt/từ chối, người bán sửa giá, xoá, xem thu nhập.

### Ví & thanh toán
- Ví shop (VND) và ví xu tách biệt.
- Nạp: VietQR tự sinh theo lệnh nạp, MoMo/ZaloPay duyệt tay, thẻ cào qua provider API, lịch sử nạp.
- Nạp tự động qua SePay webhook với mã nội dung duy nhất và chống cộng trùng (`Transaction.ref`).
- Rút: FSM 4 bước + xác nhận, tạm giữ tiền, duyệt/từ chối và hoàn tiền.
- Khuyến mãi nạp, giới hạn min/max, phí rút, phí thẻ cấu hình trong settings.

### Casino (xu ảo)
- 12 game: Tài Xỉu, Chẵn Lẻ, Xóc Đĩa, Bầu Cua, Rồng Hổ, Baccarat, Blackjack nhiều lượt, Slots + nổ hũ, Roulette, Cao Thấp, Đoán Số, Hộp Quà.
- Cược min/max, cooldown, chống spam, không cho xu âm, log từng ván.
- Seed công khai mỗi ván (SHA-256) để đối chiếu; RTP và bật/tắt từng game do admin chỉnh.
- Cảnh báo 18+ và thông điệp chơi có trách nhiệm.

### Phần thưởng & cộng đồng
- Điểm danh chuỗi ngày, thưởng theo VIP.
- 4 nhiệm vụ ngày, nhận thưởng từng nhiệm vụ hoặc nhận tất cả (chống nhận trùng bằng ref theo ngày).
- Vòng quay may mắn 24h.
- Giftcode (xu hoặc VND), giới hạn lượt, hạn dùng, bật/tắt.
- Giới thiệu bạn bè, chia sẻ link, danh sách bạn bè, thưởng giới thiệu.
- Bảng xếp hạng 7 loại × 4 kỳ, ẩn tên, vị trí của tôi, thưởng tuần tự động.

### Hỗ trợ
- Ticket 5 loại, thread hội thoại, admin trả lời trực tiếp, đóng ticket, đánh giá 1-5 sao, FAQ.

### Admin
- Bảng điều khiển, thống kê, quản lý người chơi (cộng/trừ tiền & xu, ban, mute, VIP, DM, lịch sử).
- Kho acc (thêm/sửa giá/ẩn/xoá/duyệt ký gửi), đơn hàng (hoàn tiền/hoàn tất/ghi chú).
- Duyệt nạp/rút kèm ảnh biên lai, thông báo cho người chơi.
- Giftcode, ticket, cấu hình casino, bật/tắt tính năng, bảo trì, broadcast, backup SQLite, log thao tác.

### Kỹ thuật
- aiogram 3 (async), SQLAlchemy 2 + aiosqlite (đổi PostgreSQL chỉ cần `DATABASE_URL`).
- Mã hoá Fernet cho tài khoản/mật khẩu acc.
- Middleware: context người dùng, ban/bảo trì, kênh bắt buộc, throttle callback.
- APScheduler: nhả acc giữ mỗi 60s, backup hằng ngày, thưởng BXH tuần.
- Locale vi (mặc định) + en, reply keyboard + inline keyboard đầy đủ, phân trang, màn hình xác nhận.
- Dockerfile + docker-compose + systemd/Termux hướng dẫn, smoke test nghiệp vụ.

### Tính năng thêm ngoài danh sách prompt
- Nhật ký thao tác admin trong DB (📜 Logs).
- Job thưởng bảng xếp hạng tuần tự động.
- Ghi chú đơn hàng cho admin.
- Danh sách bạn bè đã mời và thưởng giới thiệu.
- Cảnh báo "phiên hết hạn" khi bấm nút cũ (message không còn tồn tại).
