"""Account shop handlers: browse, detail, purchase, favorites, reviews."""

from __future__ import annotations

import json
import re
import secrets

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from keyboards.common import back_only, with_nav
from keyboards.shop import (
    account_detail,
    account_list,
    buy_confirm,
    buy_success,
    info_list,
    random_confirm_kb,
    random_list,
    random_pools_kb,
    ranks_kb,
    search_list_kb,
    shop_menu,
    white_list,
)
from services import shop_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils import cards
from utils.money import fmt_coin, fmt_vnd
from utils.permissions import is_admin

from handlers.states import ReviewForm, SearchForm
from handlers.ui import answer, esc, render

router = Router(name="shop")

PER_PAGE = 5
_SEARCH_SESSIONS: dict[str, dict] = {}


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_shop"):
        await render(event, "🚧 Shop đang tạm đóng, vui lòng quay lại sau.")
        return
    counts = await shop_service.count_by_kind()
    discount = int((settings.get("vip_discount") or {}).get(str(db_user.vip_level), 0))
    text = (
        f"{cards.title('cart', 'SHOP TÀI KHOẢN LIÊN QUÂN')}"
        f"  [[gem]] Kho Random: <b>{counts['random']:,}</b> acc (3.000đ / 15.000 xu)\n"
        f"  [[scroll]] Acc sẵn thông tin (VIP): <b>{counts['info']:,}</b> acc (xem full info)\n"
        f"  [[shield]] Acc trắng thông tin: <b>{counts['white']:,}</b> acc (7.000đ / 35.000 xu)\n"
        f"{cards.LINE}"
        f"  [[money]] Số dư ví shop: <b>{fmt_vnd(db_user.shop_balance)}</b>\n"
        f"  [[coin]] Số dư ví xu: <b>{fmt_coin(db_user.coins)}</b>\n"
        f"  [[crown]] VIP {db_user.vip_level}: giảm <b>{discount}%</b> khi thanh toán bằng VND\n\n"
        f"{cards.note('• Acc sẵn thông tin: Tỉ lệ xu x4\n• Acc Random & Acc trắng: Tỉ lệ xu x5')}"
    )
    await render(event, text, shop_menu(db_user.language, await is_admin(db_user.id), counts))


def _parse_binding_info(account) -> tuple[str, str, str, str]:
    extra = account.extra or ""
    # SĐT
    phone = "Chưa bổ sung"
    m_p = re.search(r"SĐT\s*[:=]\s*(Yes[^\s|]*(\s*\[[^\]]+\])?)", extra, re.IGNORECASE)
    if m_p:
        phone = m_p.group(1).strip()
    elif account.phone_info and account.phone_info.lower() != "no":
        phone = account.phone_info.strip()

    # Email
    email = "Chưa bổ sung"
    m_e = re.search(r"Email\s*[:=]\s*([^|]+)", extra, re.IGNORECASE)
    if m_e:
        v = m_e.group(1).strip()
        if v.lower() in ("no", "chưa có", "không"):
            email = "Chưa bổ sung"
        else:
            email = v
    elif account.email_info and account.email_info.lower() != "no":
        email = account.email_info.strip()

    # CCCD
    cccd = "Chưa bổ sung"
    m_c = re.search(r"CCCD\s*[:=]\s*(Yes[^\s|]*(\s*\[[^\]]+\])?)", extra, re.IGNORECASE)
    if m_c:
        cccd = m_c.group(1).strip()
    elif account.has_cccd:
        cccd = "Đã gắn CCCD"

    has_bad_info = (phone != "Chưa bổ sung") or (cccd != "Chưa bổ sung") or ("yes" in email.lower())
    status_label = "Acc Thông Tin Xấu · Còn hàng" if has_bad_info else "Acc Sẵn Thông Tin · Còn hàng"
    return status_label, phone, email, cccd


def _mask_raw_extra(raw: str) -> str:
    """Mask credentials in raw checker line before purchase to avoid credential leak."""
    if not raw:
        return ""
    parts = raw.split(" | ", 1)
    if len(parts) == 2 and ":" in parts[0]:
        user_part = parts[0]
        rest = parts[1]
        u, _ = user_part.split(":", 1)
        return f"{u}:****** | {rest}"
    return raw


def _card_text(account) -> str:
    badge = "🚫" if account.is_banned else "✅"
    label = account.category or account.rank or "Acc Liên Quân"
    return (
        f"{badge} <b>{account.code}</b> · {esc(label)}\n"
        f"💵 <b>{fmt_vnd(account.price)}</b> · 🦸 {account.heroes} tướng · 👕 {account.skins} skin\n"
        f"🛡 {account.warranty_days} ngày bảo hành"
    )


async def _detail_text(account, db_user, price: int, rating: float) -> str:
    kind = account.kind or "info"
    multiplier = 4 if kind == "info" else 5
    coin_price = price * multiplier

    if kind == "random":
        lines = [
            f"{cards.title('dice', f'ACC RANDOM {account.code}')}",
            cards.LINE,
            f"🎲 Mã số: <b>{account.code}</b>",
            f"🛡 Bảo hành: <b>{account.warranty_days} ngày</b>",
            cards.LINE,
            f"💵 Giá tiền: <b>{fmt_vnd(price)}</b>",
            f"🪙 Giá xu: <b>{fmt_coin(coin_price)}</b> (tỉ lệ x5)",
            cards.LINE,
            "<i>Acc random ẩn hoàn toàn thông tin, không có ảnh. Nhận tài khoản & mật khẩu tự động ngay sau khi xác nhận mua.</i>",
        ]
        return "\n".join(lines)

    if kind == "white":
        lines = [
            f"{cards.title('gem', f'ACC TRẮNG THÔNG TIN {account.code}')}",
            "⚪ Tình trạng: <b>Chưa liên kết SĐT / Gmail / CCCD (Trắng 100%)</b>",
            f"👑 Rank: <b>{esc(account.rank) or 'Chưa rank'}</b>",
            f"🛡 Bảo hành: <b>{account.warranty_days} ngày</b>",
            cards.LINE,
            f"💵 Giá tiền: <b>{fmt_vnd(price)}</b>",
            f"🪙 Giá xu: <b>{fmt_coin(coin_price)}</b> (tỉ lệ x5)",
            cards.LINE,
            "<i>Acc trắng chưa liên kết, nhận tài khoản/mật khẩu ngay sau khi mua.</i>",
        ]
        return "\n".join(lines)

    # kind == "info" (Acc sẵn thông tin - VIP, định dạng chuẩn theo HÌNH 1)
    status_label, phone, email, cccd = _parse_binding_info(account)
    lines = [
        f"<b>ACC #{account.code}</b>",
        f"<i>{status_label}</i>",
        "",
        f"<b>Số điện thoại:</b> {phone}",
        f"<b>Email:</b> {email}",
        f"<b>CCCD:</b> {cccd}",
        "<b>Loại acc:</b> Tài khoản Liên Quân",
        cards.LINE,
        f"👑 <b>Rank:</b> {esc(account.rank) or '—'} · Level: {account.level}",
        f"🦸 <b>Tướng:</b> {account.heroes} · 👕 <b>Skin:</b> {account.skins}",
        f"★ <b>Skin nổi bật:</b> {esc(account.rare_skins) or 'Nhiều skin VIP'}",
        cards.LINE,
        f"💵 <b>Giá tiền:</b> {fmt_vnd(price)}",
        f"🪙 <b>Giá xu:</b> {fmt_coin(coin_price)} (tỉ lệ x4)",
        f"🛡 <b>Bảo hành:</b> {account.warranty_days} ngày",
        cards.LINE,
        "📋 <b>THÔNG TIN CHI TIẾT ĐẦY ĐỦ:</b>",
        f"<code>{esc(_mask_raw_extra(account.extra))}</code>",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------- RANDOM ACCOUNTS
@router.callback_query(F.data.startswith("shop:random:"))
async def on_random(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    try:
        page = int(parts[2]) if len(parts) > 2 else 0
    except ValueError:
        page = 0
    accounts, total = await shop_service.list_accounts(
        page=page, per_page=PER_PAGE, kind="random"
    )
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page = max(0, min(page, pages - 1))
    title = (
        f"{cards.title('dice', 'KHO ACC RANDOM LIÊN QUÂN')}"
        f"  [[gem]] Tổng có sẵn: <b>{total:,}</b> acc\n"
        f"  [[money]] Đồng giá: <b>3.000đ</b> hoặc <b>15.000 xu</b> (x5)\n"
        f"  [[shield]] Bảo hành theo từng acc, hỗ trợ đổi nếu sai thông tin\n\n"
        f"{cards.note('Mỗi trang hiển thị 5 acc. Bấm vào acc để xem và mua hoặc tìm theo mã:')}"
    )
    await render(callback, title, random_list(accounts, page, pages, db_user.language))


# ---------------------------------------------------------------- WHITE ACCOUNTS
@router.callback_query(F.data.startswith("shop:white:"))
async def on_white(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    try:
        page = int(parts[2]) if len(parts) > 2 else 0
    except ValueError:
        page = 0
    accounts, total = await shop_service.list_accounts(
        page=page, per_page=PER_PAGE, kind="white"
    )
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page = max(0, min(page, pages - 1))
    title = (
        f"{cards.title('gem', 'KHO ACC TRẮNG THÔNG TIN')}"
        f"  [[gem]] Tổng có sẵn: <b>{total:,}</b> acc\n"
        f"  [[money]] Đồng giá: <b>7.000đ</b> hoặc <b>35.000 xu</b> (x5)\n"
        f"  [[shield]] Acc trắng 100% chưa liên kết SĐT, Email - Đổi pass & gắn liên kết\n\n"
        f"{cards.note('Bấm vào tài khoản bên dưới để xem chi tiết và mua:')}"
    )
    await render(callback, title, white_list(accounts, page, pages, db_user.language))


# ---------------------------------------------------------------- READY-INFO ACCOUNTS
@router.callback_query(
    F.data.startswith("shop:info:")
    | F.data.startswith("shop:ilist:")
    | F.data.startswith("shop:isearch:")
)
async def on_info_list(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    prefix = parts[1]
    sort = "newest"
    search = None
    page = 0

    if prefix == "isearch":
        search = parts[2] if len(parts) > 2 and parts[2] != "-" else None
        try:
            page = int(parts[3]) if len(parts) > 3 else 0
        except ValueError:
            page = 0
    elif prefix == "ilist":
        sort = parts[2] if len(parts) > 2 else "newest"
        try:
            page = int(parts[3]) if len(parts) > 3 else 0
        except ValueError:
            page = 0
    else:  # shop:info:<page>
        try:
            page = int(parts[2]) if len(parts) > 2 else 0
        except ValueError:
            page = 0

    accounts, total = await shop_service.list_accounts(
        page=page, per_page=PER_PAGE, sort=sort, kind="info", search=search
    )
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page = max(0, min(page, pages - 1))

    header = f"{cards.title('scroll', 'ACC SẴN THÔNG TIN (VIP)')}"
    header += f"  [[gem]] Tổng có sẵn: <b>{total:,}</b> acc · Trang <b>{page + 1}/{pages}</b>\n"
    if search:
        header += f"  [[search]] Tìm kiếm: <i>{esc(search)}</i> ({total} kết quả)\n"
    header += f"  [[coin]] Mua bằng xu: tỉ lệ x4 giá tiền\n\n"
    if not accounts:
        text = f"{header}<i>Không có tài khoản nào phù hợp với yêu cầu.</i>"
    else:
        text = (
            header
            + "<i>Bấm vào nút mã acc bên dưới để xem chi tiết đầy đủ & mua:</i>"
        )

    await render(
        callback,
        text,
        info_list(accounts, page, pages, sort=sort, language=db_user.language, search=search),
    )


# ---------------------------------------------------------------- FILTER BY RANK
@router.callback_query(F.data.startswith("shop:list:"))
async def on_list(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    sort = parts[2] if len(parts) > 2 else "newest"
    rank = parts[3] if len(parts) > 3 and parts[3] != "-" else None
    try:
        page = int(parts[4]) if len(parts) > 4 else 0
    except ValueError:
        page = 0
    accounts, total = await shop_service.list_accounts(
        page=page, per_page=PER_PAGE, sort=sort, rank=rank, kind="info"
    )
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page = max(0, min(page, pages - 1))
    title = f"[[cart]] <b>DANH SÁCH ACC THEO RANK</b> ({total})"
    if rank:
        title += f" · rank {esc(rank)}"
    if not accounts:
        text = f"{title}\n\n<i>Chưa có acc phù hợp, thử bộ lọc khác nhé.</i>"
    else:
        text = title + f"\n{cards.LINE}\n" + "\n\n".join(_card_text(a) for a in accounts)
    await render(callback, text, account_list(accounts, page, pages, sort, db_user.language, rank))


@router.callback_query(F.data == "shop:ranks:0")
async def on_ranks(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    ranks = await shop_service.available_ranks()
    if not ranks:
        await render(callback, "🎖 Chưa có rank nào trong kho.", back_only("menu:buy", db_user.language))
        return
    await render(callback, "🎖 <b>CHỌN RANK</b>", ranks_kb(ranks, db_user.language))


@router.callback_query(F.data == "shop:favs:0")
async def on_favorites(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    accounts, total = await shop_service.list_accounts(page=0, per_page=PER_PAGE, favorites_of=db_user.id)
    if not accounts:
        await render(callback, "⭐ Bạn chưa lưu acc nào.", back_only("menu:buy", db_user.language))
        return
    text = f"⭐ <b>ACC YÊU THÍCH</b> ({total})\n━━━━━━━━━━━━━━\n" + "\n\n".join(_card_text(a) for a in accounts)
    await render(callback, text, account_list(accounts, 0, 1, "newest", db_user.language))


# ---------------------------------------------------------------- SEARCH & FIND CODE
@router.callback_query(F.data == "shop:findcode")
async def on_findcode(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(SearchForm.code)
    await render(
        callback,
        "🔢 <b>TÌM / MUA THEO MÃ ACC</b>\n\n"
        "Nhập mã tài khoản Liên Quân bạn muốn xem hoặc mua (ví dụ: <code>LQ0001</code>, <code>LQ0123</code>):",
        back_only("menu:buy", db_user.language),
    )


@router.callback_query(F.data.in_({"shop:search", "shop:search_info"}))
async def on_search(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(SearchForm.code)
    await render(
        callback,
        "🔍 <b>TÌM KIẾM ACC THEO YÊU CẦU</b>\n\n"
        "Nhập từ khóa cần tìm (hệ thống tìm kiếm trên mọi thông tin):\n"
        "• Tên skin: <i>Bijan, Kình thiên, Tuyệt sắc, Thứ nguyên, Kim ngư...</i>\n"
        "• Rank: <i>Tinh Anh, T.Anh, Cao Thủ, Kim Cương...</i>\n"
        "• Mức giá hoặc mã acc: <i>3000, 24000, LQ0001...</i>",
        back_only("menu:buy", db_user.language),
    )


@router.message(SearchForm.code, F.text)
async def on_search_text(message: Message, state: FSMContext, db_user) -> None:
    query = (message.text or "").strip()
    await state.clear()
    if not query:
        await message.answer("❌ Vui lòng nhập từ khóa tìm kiếm.", reply_markup=back_only("menu:buy"))
        return

    # Check if user entered an exact account code
    if query.upper().startswith("LQ"):
        account = await shop_service.get_account_by_code(query.upper())
        if account and not account.is_hidden:
            price = await shop_service.price_for(db_user.id, account)
            rating = await shop_service.average_rating(account.id)
            favorite = await shop_service.is_favorite(db_user.id, account.id)
            await message.answer(
                await _detail_text(account, db_user, price, rating),
                reply_markup=account_detail(account, price, favorite, db_user.language),
                parse_mode="HTML",
            )
            return

    # Search keyword in info accounts first
    accounts, total = await shop_service.list_accounts(page=0, per_page=PER_PAGE, kind="info", search=query)
    search_kind = "info"
    if not accounts:
        # If not found in info, search across all kinds
        accounts, total = await shop_service.list_accounts(page=0, per_page=PER_PAGE, search=query)
        search_kind = None

    if not accounts:
        await message.answer(
            f"❌ Không tìm thấy tài khoản nào khớp với từ khóa <code>{esc(query)}</code>.",
            reply_markup=back_only("menu:buy"),
            parse_mode="HTML",
        )
        return

    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    qid = secrets.token_hex(4)
    if len(_SEARCH_SESSIONS) > 500:
        for old_k in list(_SEARCH_SESSIONS.keys())[:100]:
            _SEARCH_SESSIONS.pop(old_k, None)
    _SEARCH_SESSIONS[qid] = {"query": query, "kind": search_kind}

    text = (
        f"🔍 <b>KẾT QUẢ TÌM KIẾM: '{esc(query)}'</b>\n"
        f"  [[gem]] Tìm thấy: <b>{total:,}</b> acc · Trang <b>1/{pages}</b>\n"
        f"  [[coin]] Mua bằng xu: x4 (acc sẵn TT) / x5 (acc random)\n\n"
        f"<i>Bấm vào nút mã acc bên dưới để xem chi tiết đầy đủ & mua:</i>"
    )
    await message.answer(
        text,
        reply_markup=search_list_kb(accounts, 0, pages, qid, db_user.language),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("shop:sp:"))
async def on_search_page(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    if len(parts) < 4:
        return
    qid = parts[2]
    try:
        page = int(parts[3])
    except ValueError:
        page = 0

    session = _SEARCH_SESSIONS.get(qid)
    if not session:
        await render(
            callback,
            "⚠️ Phiên tìm kiếm đã hết hạn, vui lòng thực hiện tìm kiếm lại.",
            back_only("menu:buy", db_user.language),
        )
        return

    query = session.get("query", "")
    search_kind = session.get("kind")
    accounts, total = await shop_service.list_accounts(
        page=page, per_page=PER_PAGE, kind=search_kind, search=query
    )
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page = max(0, min(page, pages - 1))

    text = (
        f"🔍 <b>KẾT QUẢ TÌM KIẾM: '{esc(query)}'</b>\n"
        f"  [[gem]] Tìm thấy: <b>{total:,}</b> acc · Trang <b>{page + 1}/{pages}</b>\n"
        f"  [[coin]] Mua bằng xu: x4 (acc sẵn TT) / x5 (acc random)\n\n"
        f"<i>Bấm vào nút mã acc bên dưới để xem chi tiết đầy đủ & mua:</i>"
    )
    await render(
        callback,
        text,
        search_list_kb(accounts, page, pages, qid, db_user.language),
    )



# ---------------------------------------------------------------- DETAIL & ACTIONS
@router.callback_query(F.data.startswith("shop:view:"))
async def on_view(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    code = callback.data.split(":")[2]
    account = await shop_service.get_account_by_code(code)
    if account is None or account.is_hidden:
        await render(callback, "❌ Không tìm thấy acc này.", back_only("menu:buy", db_user.language))
        return
    price = await shop_service.price_for(db_user.id, account)
    rating = await shop_service.average_rating(account.id)
    favorite = await shop_service.is_favorite(db_user.id, account.id)
    reviews = await shop_service.reviews_of(account.id, 3)
    text = await _detail_text(account, db_user, price, rating)
    if reviews:
        text += "\n\n⭐ <b>Đánh giá gần đây</b>\n" + "\n".join(
            f"• {r.rating}⭐ {esc(r.text)[:120]}" for r in reviews
        )
    await render(callback, text, account_detail(account, price, favorite, db_user.language))


@router.callback_query(F.data.startswith("shop:photos:"))
async def on_photos(callback: CallbackQuery, db_user) -> None:
    code = callback.data.split(":")[2]
    account = await shop_service.get_account_by_code(code)
    if account is None:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    if account.kind == "random":
        await answer(callback, "Acc random không có ảnh.", alert=True)
        return
    try:
        photos = json.loads(account.photos or "[]")
    except ValueError:
        photos = []
    if not photos:
        await answer(callback, "Acc này chưa có ảnh.", alert=True)
        return
    await answer(callback)
    for photo in photos[:10]:
        try:
            await callback.message.answer_photo(photo=photo, caption=f"🖼 {account.code}")
        except Exception:
            continue


@router.callback_query(F.data.startswith("shop:fav:"))
async def on_favorite(callback: CallbackQuery, db_user) -> None:
    code = callback.data.split(":")[2]
    account = await shop_service.get_account_by_code(code)
    if account is None:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    added = await shop_service.toggle_favorite(db_user.id, account.id)
    await answer(callback, "❤️ Đã thêm vào yêu thích" if added else "💔 Đã bỏ yêu thích")
    price = await shop_service.price_for(db_user.id, account)
    rating = await shop_service.average_rating(account.id)
    await render(
        callback,
        await _detail_text(account, db_user, price, rating),
        account_detail(account, price, added, db_user.language),
    )


async def _render_insufficient(callback: CallbackQuery, db_user, price: int, back: str) -> None:
    fresh = await wallet.get_user(db_user.id)
    balance = int(fresh.shop_balance) if fresh is not None else int(db_user.shop_balance)
    text = (
        f"❌ <b>Số dư không đủ</b>\n"
        f"• Giá acc: <b>{fmt_vnd(price)}</b>\n"
        f"• Số dư ví: <b>{fmt_vnd(balance)}</b>\n"
        f"• Cần thêm: <b>{fmt_vnd(max(0, price - balance))}</b>"
    )
    kb = with_nav(
        [[InlineKeyboardButton(text="💳 Nạp tiền ngay", callback_data="menu:deposit")]],
        db_user.language,
        back=back,
    )
    await render(callback, text, kb)


# ---------------------------------------------------------------- PURCHASE FLOW
@router.callback_query(F.data.startswith("shop:buy:"))
async def on_buy(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    code = parts[2]
    currency = parts[3] if len(parts) > 3 else "vnd"

    account = await shop_service.get_account_by_code(code)
    if account is None or account.status != "available" or account.is_hidden:
        await render(callback, "❌ Acc đã được bán hoặc đang ẩn.", back_only("menu:buy", db_user.language))
        return

    price_vnd = await shop_service.price_for(db_user.id, account)
    multiplier = 4 if account.kind == "info" else 5
    coin_price = price_vnd * multiplier

    if currency == "coin":
        if db_user.coins < coin_price:
            shortfall = coin_price - db_user.coins
            text = (
                f"❌ <b>Số xu không đủ</b>\n"
                f"• Giá acc: <b>{fmt_coin(coin_price)}</b> (tỉ lệ x{multiplier})\n"
                f"• Xu hiện có: <b>{fmt_coin(db_user.coins)}</b>\n"
                f"• Cần thêm: <b>{fmt_coin(shortfall)}</b>\n\n"
                f"💡 Điểm danh hàng ngày, làm nhiệm vụ hoặc nạp ví để đổi thêm xu!"
            )
            kb = with_nav(
                [[InlineKeyboardButton(text="🎁 Điểm danh / Nhiệm vụ", callback_data="menu:rewards")]],
                db_user.language,
                back=f"shop:view:{code}",
            )
            await render(callback, text, kb)
            return

        text = (
            f"🪙 <b>XÁC NHẬN MUA ACC BẰNG XU — {account.code}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"• Loại: <b>{esc(account.category or account.kind)}</b>\n"
            f"• Thanh toán: <b>{fmt_coin(coin_price)}</b>\n"
            f"• Xu hiện có: {fmt_coin(db_user.coins)}\n"
            f"• Xu còn lại sau mua: <b>{fmt_coin(db_user.coins - coin_price)}</b>\n"
            f"• Bảo hành: {account.warranty_days} ngày\n\n"
            "Bấm xác nhận để nhận tài khoản và mật khẩu ngay lập tức."
        )
        await render(
            callback,
            text,
            buy_confirm(code, f"{fmt_coin(coin_price)}", currency="coin", language=db_user.language),
        )
        return

    else:  # VND
        if db_user.shop_balance < price_vnd:
            await _render_insufficient(callback, db_user, price_vnd, back=f"shop:view:{code}")
            return

        text = (
            f"🛒 <b>XÁC NHẬN MUA ACC {account.code}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"• Loại: <b>{esc(account.category or account.kind)}</b>\n"
            f"• Giá gốc: {fmt_vnd(account.price)}\n"
            f"• Giảm VIP {db_user.vip_level}: -{fmt_vnd(account.price - price_vnd)}\n"
            f"• <b>Thanh toán: {fmt_vnd(price_vnd)}</b>\n"
            f"• Số dư sau khi mua: {fmt_vnd(db_user.shop_balance - price_vnd)}\n"
            f"• Bảo hành: {account.warranty_days} ngày\n\n"
            "Bấm xác nhận để nhận tài khoản và mật khẩu ngay lập tức."
        )
        await render(
            callback,
            text,
            buy_confirm(code, fmt_vnd(price_vnd), currency="vnd", language=db_user.language),
        )


@router.callback_query(F.data.startswith("shop:confirm:"))
async def on_confirm(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    code = parts[2]
    currency = parts[3] if len(parts) > 3 else "vnd"

    try:
        result = await shop_service.buy_account(db_user.id, code, currency=currency)
    except RuntimeError:
        await render(
            callback,
            "⚠️ Số dư thay đổi trong lúc xử lý, vui lòng thử lại.",
            back_only("menu:buy", db_user.language),
        )
        return

    if not result.get("ok"):
        if result.get("code") == "insufficient_balance" and int(result.get("price") or 0) > 0:
            await _render_insufficient(callback, db_user, int(result["price"]), back=f"shop:view:{code}")
            return
        await render(
            callback,
            f"❌ {result.get('error', 'Không mua được acc.')}",
            back_only("menu:buy", db_user.language),
        )
        return

    account = result["account"]
    paid_text = fmt_coin(result["price"]) if currency == "coin" else fmt_vnd(result["price"])
    text = (
        f"🎉 <b>MUA ACC THÀNH CÔNG — {account.code}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 Tài khoản: <code>{esc(result['username'])}</code>\n"
        f"🔑 Mật khẩu: <code>{esc(result['password'])}</code>\n"
        f"💳 Đã thanh toán: <b>{paid_text}</b>\n"
        f"🛡 Bảo hành đến: <b>{result['warranty_until']:%d/%m/%Y}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "<b>Việc cần làm ngay:</b>\n"
        "1. Đăng nhập và đổi mật khẩu.\n"
        "2. Kiểm tra thông tin bảo mật và liên kết.\n"
        "3. Bật xác thực 2 lớp (2FA).\n\n"
        "⚠️ Không chia sẻ thông tin acc cho người khác."
    )
    await render(callback, text, buy_success(account.code, db_user.language))

    orders = await shop_service.orders_of(db_user.id, limit=1)
    order_id = orders[0].id if orders else 0
    from utils.notifications import notify_admins

    await notify_admins(
        callback.bot,
        f"🛒 <b>Đơn mới #{order_id}</b>\n• User: <code>{db_user.id}</code>\n"
        f"• Acc: {account.code}\n• Thanh toán: {paid_text}",
    )


@router.callback_query(F.data.startswith("shop:creds:"))
async def on_creds(callback: CallbackQuery, db_user) -> None:
    code = callback.data.split(":")[2]
    orders = await shop_service.orders_of(db_user.id, limit=50)
    order = next((o for o in orders if o.account_code == code and o.status != "refunded"), None)
    if order is None:
        await answer(callback, "Bạn chưa mua acc này.", alert=True)
        return
    account = await shop_service.get_account_by_code(code)
    if account is None:
        await answer(callback, "Không tìm thấy acc.", alert=True)
        return
    from services import crypto_service

    lines = [
        f"📄 <b>THÔNG TIN ACC {account.code}</b>",
        f"• Tài khoản: <code>{esc(crypto_service.decrypt(account.username_enc))}</code>",
        f"• Mật khẩu: <code>{esc(crypto_service.decrypt(account.password_enc))}</code>",
    ]
    if order.warranty_until:
        lines.append(f"• Bảo hành đến: {order.warranty_until:%d/%m/%Y}")
    text = "\n".join(lines)
    await answer(callback)
    await render(callback, text, buy_success(code, db_user.language))


# ---------------------------------------------------------------- REVIEWS
@router.callback_query(F.data.startswith("shop:review:"))
async def on_review(callback: CallbackQuery, db_user) -> None:
    code = callback.data.split(":")[2]
    orders = await shop_service.orders_of(db_user.id, limit=50)
    if not any(o.account_code == code and o.status != "refunded" for o in orders):
        await answer(callback, "Bạn cần mua acc này để đánh giá.", alert=True)
        return
    await answer(callback)
    rows = [
        [
            InlineKeyboardButton(text=f"{n}⭐", callback_data=f"shop:rate:{code}:{n}")
            for n in range(1, 6)
        ]
    ]
    await render(callback, f"⭐ Bạn cho acc <b>{code}</b> mấy sao?", InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("shop:rate:"))
async def on_rate(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    code, rating = parts[2], int(parts[3])
    await state.set_state(ReviewForm.text)
    await state.update_data(review_code=code, review_rating=rating)
    await render(
        callback,
        f"⭐ {rating} sao! Hãy viết vài dòng cảm nhận (hoặc gửi <code>-</code> để bỏ qua):",
        back_only(f"shop:view:{code}", db_user.language),
    )


@router.message(ReviewForm.text, F.text)
async def on_review_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    await state.clear()
    code = data.get("review_code")
    rating = int(data.get("review_rating", 5))
    text = (message.text or "").strip()
    if text == "-":
        text = ""
    account = await shop_service.get_account_by_code(code or "")
    if account is None:
        await message.answer("❌ Không tìm thấy acc.")
        return
    await shop_service.add_review(db_user.id, account.id, rating, text)
    from utils.notifications import notify_admins

    await message.answer("🎉 Cảm ơn bạn đã đánh giá!")
    await notify_admins(
        message.bot,
        f"⭐ <b>Đánh giá mới</b>\n• Acc: {account.code}\n• User: <code>{db_user.id}</code>\n"
        f"• Sao: {rating}\n• Nội dung: {esc(text)[:300] or '(không có)'}",
    )
