"""Consignment flow: players post accounts for sale and manage their listings."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from keyboards.common import back_only, confirm_kb, with_nav
from keyboards.shop import sell_menu, seller_account_detail, seller_accounts
from services import shop_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils.money import fmt_vnd, parse_amount
from utils.notifications import notify_admins

from handlers.states import SellEditForm, SellForm
from handlers.ui import answer, esc, render, window

router = Router(name="sell")

RANKS = ["Kim Cương", "Bạch Kim", "Vàng", "Bạc", "Đồng", "Cao Thủ"]
LOGIN_TYPES = ["Facebook", "Google", "Garena", "Apple"]
PER_PAGE = 6


def _rank_kb() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=f"🏅 {rank}", callback_data=f"sell:rank:{rank}") for rank in RANKS[i : i + 2]] for i in range(0, len(RANKS), 2)]
    rows.append([InlineKeyboardButton(text="❌ Huỷ", callback_data="menu:sell")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _login_kb() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=value, callback_data=f"sell:login:{value}") for value in LOGIN_TYPES[i : i + 2]] for i in range(0, len(LOGIN_TYPES), 2)]
    rows.append([InlineKeyboardButton(text="❌ Huỷ", callback_data="menu:sell")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_sell"):
        await render(event, "🚧 Chức năng ký gửi đang tạm đóng.")
        return
    accounts = await shop_service.accounts_of_seller(db_user.id)
    pending = sum(1 for a in accounts if a.status == "pending_approval")
    selling = sum(1 for a in accounts if a.status == "available")
    text = (
        "💰 <b>BÁN / KÝ GỬI ACC</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Acc đang chờ duyệt: <b>{pending}</b>\n"
        f"• Acc đang bán: <b>{selling}</b>\n"
        f"• Hoa hồng shop: <b>{settings.get('commission_percent', 0)}%</b>\n"
        f"• Số dư ví: <b>{fmt_vnd(db_user.shop_balance)}</b>\n\n"
        "Gửi acc cho shop, khi bán được tiền sẽ vào ví sau khi trừ hoa hồng."
    )
    from utils.permissions import is_admin

    await render(event, text, sell_menu(db_user.language, await is_admin(db_user.id)))


@router.callback_query(F.data == "sell:new")
async def on_new(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(SellForm.rank)
    await render(
        callback,
        "➕ <b>ĐĂNG ACC MỚI — BƯỚC 1/9</b>\nChọn rank của acc (hoặc nhập rank khác):",
        _rank_kb(),
    )


@router.callback_query(F.data.startswith("sell:rank:"))
async def on_rank(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    rank = callback.data.split(":", 2)[2]
    await state.update_data(rank=rank)
    await state.set_state(SellForm.heroes)
    await render(callback, f"🏅 Rank: <b>{esc(rank)}</b>\n\nBước 2/9 — nhập <b>số tướng</b>:", back_only("menu:sell"))


@router.callback_query(F.data.startswith("sell:login:"))
async def on_login(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    login_type = callback.data.split(":", 2)[2]
    await state.update_data(login_type=login_type)
    await state.set_state(SellForm.photos)
    await render(
        callback,
        f"🔐 Đăng nhập: <b>{esc(login_type)}</b>\n\nBước 9/9 — gửi <b>ảnh acc</b> "
        "(có thể gửi nhiều ảnh), hoặc bấm Hoàn tất để bỏ qua:",
        InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="✅ Hoàn tất", callback_data="sell:finish")]]
        ),
    )


@router.message(
    StateFilter(
        SellForm.rank,
        SellForm.heroes,
        SellForm.skins,
        SellForm.price,
        SellForm.username,
        SellForm.password,
        SellForm.description,
    ),
    F.text,
)
async def on_text(message: Message, state: FSMContext, db_user) -> None:
    current = (await state.get_state() or "").split(":")[-1]
    value = (message.text or "").strip()

    if current == "rank":
        if len(value) < 2:
            await message.answer("❌ Rank quá ngắn, nhập lại:")
            return
        await state.update_data(rank=value[:64])
        await state.set_state(SellForm.heroes)
        await message.answer("Bước 2/9 — nhập <b>số tướng</b>:", parse_mode="HTML")
        return

    if current in ("heroes", "skins"):
        if not value.isdigit() or int(value) > 1000:
            await message.answer("❌ Vui lòng nhập một con số hợp lệ:")
            return
        await state.update_data(**{current: int(value)})
        if current == "heroes":
            await state.set_state(SellForm.skins)
            await message.answer("Bước 3/9 — nhập <b>số skin</b>:", parse_mode="HTML")
        else:
            await state.set_state(SellForm.price)
            await message.answer(
                "Bước 4/9 — nhập <b>giá mong muốn</b> (VNĐ, tối thiểu 20.000đ):",
                parse_mode="HTML",
            )
        return

    if current == "price":
        amount = parse_amount(value)
        if not amount or amount < 20000:
            await message.answer("❌ Giá phải từ 20.000đ, nhập lại:")
            return
        await state.update_data(price=amount)
        await state.set_state(SellForm.username)
        await message.answer("Bước 5/9 — nhập <b>tên đăng nhập</b> của acc (sẽ được mã hoá):", parse_mode="HTML")
        return

    if current == "username":
        if len(value) < 2:
            await message.answer("❌ Tên đăng nhập quá ngắn, nhập lại:")
            return
        await state.update_data(username=value)
        await state.set_state(SellForm.password)
        await message.answer("Bước 6/9 — nhập <b>mật khẩu</b> của acc (sẽ được mã hoá):", parse_mode="HTML")
        return

    if current == "password":
        if len(value) < 2:
            await message.answer("❌ Mật khẩu quá ngắn, nhập lại:")
            return
        await state.update_data(password=value)
        await state.set_state(SellForm.description)
        await message.answer(
            "Bước 7/9 — nhập <b>mô tả</b> (skin hiếm, tướng nổi bật...). Gửi <code>-</code> để bỏ qua:",
            parse_mode="HTML",
        )
        return

    if current == "description":
        await state.update_data(description="" if value == "-" else value[:2000])
        await state.set_state(SellForm.login_type)
        await message.answer(
            "Bước 8/9 — chọn <b>hình thức đăng nhập</b>:",
            parse_mode="HTML",
            reply_markup=_login_kb(),
        )
        return


@router.message(SellForm.photos, F.photo)
async def on_photo(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    photos = list(data.get("photos") or [])
    photos.append(message.photo[-1].file_id)
    await state.update_data(photos=photos[:10])
    await message.answer(
        f"🖼 Đã nhận <b>{len(photos)}</b> ảnh. Gửi thêm hoặc bấm Hoàn tất:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="✅ Hoàn tất", callback_data="sell:finish")]]
        ),
    )


@router.message(SellForm.photos, F.text)
async def on_photos_text(message: Message, state: FSMContext) -> None:
    value = (message.text or "").strip()
    if value in ("-", "xong", "done", "skip"):
        await finish_listing(message, state, message.from_user)
        return
    if value.startswith("http"):
        data = await state.get_data()
        photos = list(data.get("photos") or [])
        photos.append(value)
        await state.update_data(photos=photos[:10])
        await message.answer(
            "🖼 Đã thêm ảnh. Gửi thêm hoặc bấm Hoàn tất:",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="✅ Hoàn tất", callback_data="sell:finish")]]
            ),
        )
        return
    await message.answer("Gửi ảnh, link ảnh, hoặc bấm Hoàn tất.")


@router.callback_query(F.data == "sell:finish")
async def on_finish(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await finish_listing(callback, state, db_user)


async def finish_listing(event, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    required = ["rank", "price", "username", "password"]
    missing = [key for key in required if not data.get(key)]
    if missing:
        await state.clear()
        await render(event, "❌ Phiên đăng acc bị thiếu thông tin, vui lòng làm lại.", back_only("menu:sell"))
        return
    settings = await all_settings()
    account = await shop_service.create_account(
        price=int(data["price"]),
        rank=data.get("rank", ""),
        level=int(data.get("level", 0) or 0),
        heroes=int(data.get("heroes", 0) or 0),
        skins=int(data.get("skins", 0) or 0),
        rare_skins=data.get("rare_skins", ""),
        login_type=data.get("login_type", "Facebook"),
        warranty_days=int(settings.get("warranty_days_default", 3)),
        description=data.get("description", ""),
        photos=data.get("photos", []),
        username=data.get("username", ""),
        password=data.get("password", ""),
        seller_id=db_user.id,
        status="pending_approval",
    )
    await state.clear()
    await render(
        event,
        f"✅ <b>ĐÃ GỬI ACC {account.code}</b>\n"
        f"• Giá niêm yết: <b>{fmt_vnd(account.price)}</b>\n"
        f"• Trạng thái: ⏳ Chờ admin duyệt\n\n"
        "Admin có thể chỉnh giá trước khi đăng bán. Bạn sẽ được thông báo khi acc được duyệt.",
        back_only("menu:sell"),
    )
    await notify_admins(
        event.bot,
        f"🛍 <b>Acc ký gửi mới {account.code}</b>\n"
        f"• Người gửi: <code>{db_user.id}</code>\n"
        f"• Rank: {esc(account.rank)} · Giá: {fmt_vnd(account.price)}\n"
        f"• Duyệt trong 🛠 Admin → Kho acc → Chờ duyệt",
    )


@router.callback_query(F.data.startswith("sell:list:"))
async def on_list(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    try:
        page = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        page = 0
    accounts = await shop_service.accounts_of_seller(db_user.id)
    if not accounts:
        await render(callback, "📋 Bạn chưa đăng acc nào.", back_only("menu:sell", db_user.language))
        return
    chunk, page, pages = window(list(accounts), page, PER_PAGE)
    await render(
        callback,
        f"📋 <b>ACC CỦA TÔI</b> ({len(accounts)})",
        seller_accounts(chunk, page, pages, db_user.language),
    )


@router.callback_query(F.data.startswith("sell:view:"))
async def on_view(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None or account.seller_id != db_user.id:
        await render(callback, "❌ Không tìm thấy acc của bạn.", back_only("menu:sell"))
        return
    status_map = {
        "available": "🟢 Đang bán",
        "pending_approval": "⏳ Chờ duyệt",
        "sold": "✅ Đã bán",
        "rejected": "❌ Bị từ chối",
        "deleted": "🗑 Đã xoá",
    }
    text = (
        f"🛍 <b>ACC {account.code}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Trạng thái: {status_map.get(account.status, account.status)}\n"
        f"• Rank: {esc(account.rank)}\n"
        f"• Giá: <b>{fmt_vnd(account.price)}</b>\n"
        f"• Tướng: {account.heroes} · Skin: {account.skins}\n"
        f"• Đăng nhập: {esc(account.login_type)}\n"
        f"• Bảo hành: {account.warranty_days} ngày\n"
        f"• Ngày gửi: {account.created_at:%d/%m/%Y}"
    )
    if account.description:
        text += f"\n▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n{esc(account.description)}"
    await render(
        callback,
        text,
        seller_account_detail(account.id, account.status == "available", db_user.language),
    )


@router.callback_query(F.data.startswith("sell:price:"))
async def on_price(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None or account.seller_id != db_user.id:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    await state.set_state(SellEditForm.price)
    await state.update_data(edit_account_id=account_id)
    await render(
        callback,
        f"✏️ Nhập giá mới cho <b>{account.code}</b> (hiện tại {fmt_vnd(account.price)}):",
        back_only(f"sell:view:{account_id}", db_user.language),
    )


@router.message(SellEditForm.price, F.text)
async def on_price_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    amount = parse_amount(message.text or "")
    if not amount or amount < 20000:
        await message.answer("❌ Giá phải từ 20.000đ, nhập lại:")
        return
    await shop_service.update_price(int(data.get("edit_account_id", 0)), amount)
    await state.clear()
    await message.answer(f"✅ Đã đổi giá thành <b>{fmt_vnd(amount)}</b>.", parse_mode="HTML")


@router.callback_query(F.data.startswith("sell:del:"))
async def on_delete(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None or account.seller_id != db_user.id:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    await render(
        callback,
        f"🗑 Bạn chắc chắn muốn xoá acc <b>{account.code}</b>?",
        confirm_kb(f"sell:delok:{account_id}", f"sell:view:{account_id}"),
    )


@router.callback_query(F.data.startswith("sell:delok:"))
async def on_delete_confirm(callback: CallbackQuery, db_user) -> None:
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None or account.seller_id != db_user.id:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    if account.status == "sold":
        await answer(callback, "Acc đã bán, không thể xoá.", alert=True)
        return
    await shop_service.remove_account(account_id)
    await answer(callback, "Đã xoá acc")
    await callback.message.answer("✅ Đã xoá acc khỏi danh sách của bạn.")


@router.callback_query(F.data == "sell:earnings")
async def on_earnings(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    transactions = await wallet.transactions_of(db_user.id, limit=100)
    earnings = sum(t.amount for t in transactions if t.kind == "sale_credit")
    accounts = await shop_service.accounts_of_seller(db_user.id)
    sold = [a for a in accounts if a.status == "sold"]
    text = (
        "📊 <b>THU NHẬP KÝ GỬI</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Acc đã bán: <b>{len(sold)}</b>\n"
        f"• Tổng nhận: <b>{fmt_vnd(earnings)}</b>\n"
        f"• Số dư ví: <b>{fmt_vnd(db_user.shop_balance)}</b>\n\n"
        "Tiền bán acc được cộng vào ví shop, có thể rút qua 💸 Rút tiền."
    )
    rows = [[InlineKeyboardButton(text="💸 Rút tiền", callback_data="wd:new")]]
    await render(callback, text, with_nav(rows, db_user.language, back="menu:sell"))
