"""Support: tickets, FAQ, contact and ratings."""

from __future__ import annotations

from datetime import datetime

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select

from config import CHANNEL_USERNAME, GROUP_USERNAME, SUPPORT_USERNAME
from database.models import Ticket, TicketMessage
from database.session import session_scope
from keyboards.common import back_only, with_nav
from services.settings_service import all_settings
from utils.notifications import notify_admins

from handlers.states import TicketForm, TicketReplyForm
from handlers.ui import answer, esc, render, window

router = Router(name="support")

TYPES = {
    "deposit": "💳 Nạp tiền",
    "account": "🛒 Mua acc",
    "warranty": "🛡 Bảo hành",
    "bug": "🐞 Lỗi bot",
    "other": "📝 Khác",
}
STATUS_LABELS = {"new": "🆕 Mới", "in_progress": "🔄 Đang xử lý", "closed": "✅ Đã đóng"}
PER_PAGE = 6


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_support"):
        await render(event, "🚧 Hỗ trợ đang tạm đóng.")
        return
    text = (
        "🆘 <b>TRUNG TÂM HỖ TRỢ</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        "• Tạo ticket mô tả vấn đề, đính kèm ảnh nếu cần.\n"
        "• Theo dõi phản hồi trong mục Ticket của tôi.\n"
        "• Admin trả lời trực tiếp trong ticket.\n\n"
        f"📞 Hỗ trợ nhanh: {esc(SUPPORT_USERNAME)}"
    )
    rows = [
        [InlineKeyboardButton(text="📝 Tạo ticket", callback_data="sup:new")],
        [InlineKeyboardButton(text="📂 Ticket của tôi", callback_data="sup:list:0")],
        [InlineKeyboardButton(text="❓ FAQ", callback_data="sup:faq")],
        [
            InlineKeyboardButton(text="📞 Liên hệ admin", url=f"https://t.me/{SUPPORT_USERNAME.lstrip('@')}"),
            InlineKeyboardButton(text="📢 Kênh", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}"),
        ],
    ]
    await render(event, text, with_nav(rows, db_user.language, back="menu:home"))


@router.callback_query(F.data == "sup:faq")
async def on_faq(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    settings = await all_settings()
    text = settings.get("faq_text") or "❓ Chưa có FAQ."
    text += f"\n\n👥 Nhóm cộng đồng: {esc(GROUP_USERNAME)}"
    await render(callback, text, back_only("menu:support", db_user.language))


@router.callback_query(F.data == "sup:new")
async def on_new(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(TicketForm.type)
    rows = [[InlineKeyboardButton(text=label, callback_data=f"sup:type:{key}")] for key, label in TYPES.items()]
    rows.append([InlineKeyboardButton(text="❌ Huỷ", callback_data="menu:support")])
    await render(callback, "📝 <b>TẠO TICKET — CHỌN LOẠI VẤN ĐỀ</b>", InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("sup:type:"))
async def on_type(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    kind = callback.data.split(":")[2]
    await state.update_data(ticket_type=kind)
    await state.set_state(TicketForm.subject)
    await render(
        callback,
        f"📝 Loại: <b>{TYPES.get(kind, kind)}</b>\n\nNhập <b>tiêu đề ngắn</b> cho vấn đề:",
        back_only("menu:support", db_user.language),
    )


@router.message(TicketForm.subject, F.text)
async def on_subject(message: Message, state: FSMContext) -> None:
    subject = (message.text or "").strip()
    if len(subject) < 4:
        await message.answer("❌ Tiêu đề quá ngắn, nhập lại:")
        return
    await state.update_data(ticket_subject=subject[:255])
    await state.set_state(TicketForm.message)
    await message.answer("📄 Mô tả chi tiết vấn đề (kèm mã đơn/mã nạp nếu có):")


@router.message(TicketForm.message, F.text)
async def on_message(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    text = (message.text or "").strip()
    if len(text) < 5:
        await message.answer("❌ Nội dung quá ngắn, nhập lại:")
        return
    async with session_scope() as session:
        ticket = Ticket(
            user_id=db_user.id,
            type=data.get("ticket_type", "other"),
            subject=data.get("ticket_subject", "Không tiêu đề"),
        )
        session.add(ticket)
        await session.flush()
        session.add(TicketMessage(ticket_id=ticket.id, sender_id=db_user.id, is_admin=False, text=text))
        ticket_id = ticket.id
    await state.clear()
    await message.answer(
        f"✅ <b>Đã tạo ticket #{ticket_id}</b>\nAdmin sẽ phản hồi sớm nhất có thể.",
        parse_mode="HTML",
        reply_markup=back_only("menu:support", db_user.language),
    )
    await notify_admins(
        message.bot,
        f"🆘 <b>Ticket mới #{ticket_id}</b>\n• User: <code>{db_user.id}</code>\n"
        f"• Loại: {TYPES.get(data.get('ticket_type'), 'Khác')}\n"
        f"• Tiêu đề: {esc(data.get('ticket_subject'))}",
    )


@router.callback_query(F.data.startswith("sup:list:"))
async def on_list(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    try:
        page = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        page = 0
    async with session_scope() as session:
        tickets = (
            await session.execute(
                select(Ticket).where(Ticket.user_id == db_user.id).order_by(Ticket.created_at.desc())
            )
        ).scalars().all()
    if not tickets:
        await render(callback, "📂 Bạn chưa có ticket nào.", back_only("menu:support", db_user.language))
        return
    chunk, page, pages = window(list(tickets), page, PER_PAGE)
    rows = [
        [
            InlineKeyboardButton(
                text=f"#{t.id} · {STATUS_LABELS.get(t.status, t.status)} · {t.subject[:28]}",
                callback_data=f"sup:view:{t.id}",
            )
        ]
        for t in chunk
    ]
    if pages > 1:
        rows.append(
            [
                InlineKeyboardButton(text="◀️", callback_data=f"sup:list:{page - 1}"),
                InlineKeyboardButton(text=f"{page + 1}/{pages}", callback_data="noop"),
                InlineKeyboardButton(text="▶️", callback_data=f"sup:list:{page + 1}"),
            ]
        )
    await render(callback, f"📂 <b>TICKET CỦA TÔI</b> ({len(tickets)})", with_nav(rows, db_user.language, back="menu:support"))


@router.callback_query(F.data.startswith("sup:view:"))
async def on_view(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    ticket_id = int(callback.data.split(":")[2])
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None or ticket.user_id != db_user.id:
            await render(callback, "❌ Không tìm thấy ticket.", back_only("sup:list:0", db_user.language))
            return
        messages = (
            await session.execute(
                select(TicketMessage)
                .where(TicketMessage.ticket_id == ticket_id)
                .order_by(TicketMessage.created_at.asc())
                .limit(20)
            )
        ).scalars().all()
        status, subject, created = ticket.status, ticket.subject, ticket.created_at
        rating = ticket.rating

    lines = [
        f"🆘 <b>TICKET #{ticket_id}</b>",
        f"• Trạng thái: {STATUS_LABELS.get(status, status)}",
        f"• Tiêu đề: {esc(subject)}",
        f"• Ngày tạo: {created:%d/%m/%Y %H:%M}",
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰",
    ]
    for msg in messages:
        who = "🛠 Admin" if msg.is_admin else "👤 Bạn"
        lines.append(f"{who} · {msg.created_at:%d/%m %H:%M}\n{esc(msg.text)}")
        if len("\n".join(lines)) > 3200:
            lines.append("…")
            break

    rows = []
    if status != "closed":
        rows.append([InlineKeyboardButton(text="💬 Trả lời", callback_data=f"sup:reply:{ticket_id}")])
        rows.append([InlineKeyboardButton(text="✅ Đóng ticket", callback_data=f"sup:close:{ticket_id}")])
    else:
        if rating:
            lines.append(f"\n⭐ Bạn đã đánh giá: {rating}/5")
        else:
            rows.append(
                [
                    InlineKeyboardButton(text=f"{n}⭐", callback_data=f"sup:rate:{ticket_id}:{n}")
                    for n in range(1, 6)
                ]
            )
    await render(callback, "\n".join(lines), with_nav(rows, db_user.language, back="sup:list:0"))


@router.callback_query(F.data.startswith("sup:reply:"))
async def on_reply(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    ticket_id = int(callback.data.split(":")[2])
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None or ticket.user_id != db_user.id or ticket.status == "closed":
            await answer(callback, "Ticket không hợp lệ hoặc đã đóng.", alert=True)
            return
    await state.set_state(TicketReplyForm.text)
    await state.update_data(reply_ticket=ticket_id)
    await render(callback, "💬 Nhập nội dung trả lời:", back_only(f"sup:view:{ticket_id}", db_user.language))


@router.message(TicketReplyForm.text, F.text)
async def on_reply_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    ticket_id = int(data.get("reply_ticket", 0))
    text = (message.text or "").strip()
    await state.clear()
    if len(text) < 2:
        await message.answer("❌ Nội dung quá ngắn.")
        return
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None or ticket.user_id != db_user.id or ticket.status == "closed":
            await message.answer("Ticket không hợp lệ hoặc đã đóng.")
            return
        ticket.status = "in_progress"
        session.add(TicketMessage(ticket_id=ticket_id, sender_id=db_user.id, is_admin=False, text=text))
    await message.answer(f"✅ Đã gửi phản hồi cho ticket #{ticket_id}.", reply_markup=back_only(f"sup:view:{ticket_id}"))
    await notify_admins(
        message.bot,
        f"💬 <b>Phản hồi mới ticket #{ticket_id}</b>\n• User: <code>{db_user.id}</code>\n{esc(text)[:400]}",
    )


@router.callback_query(F.data.startswith("sup:close:"))
async def on_close(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    ticket_id = int(callback.data.split(":")[2])
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None or ticket.user_id != db_user.id:
            await answer(callback, "Không tìm thấy ticket", alert=True)
            return
        ticket.status = "closed"
        ticket.updated_at = datetime.utcnow()
    rows = [[InlineKeyboardButton(text=f"{n}⭐", callback_data=f"sup:rate:{ticket_id}:{n}") for n in range(1, 6)]]
    await render(callback, f"✅ Ticket #{ticket_id} đã đóng. Bạn đánh giá hỗ trợ thế nào?", InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("sup:rate:"))
async def on_rate(callback: CallbackQuery, db_user) -> None:
    await answer(callback, "Cảm ơn đánh giá của bạn!")
    parts = callback.data.split(":")
    ticket_id, rating = int(parts[2]), int(parts[3])
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is not None and ticket.user_id == db_user.id:
            ticket.rating = rating
    await render(callback, "⭐ Cảm ơn bạn đã đánh giá chất lượng hỗ trợ!", back_only("sup:list:0", db_user.language))
