"""UI helpers shared by handlers (edit vs send, emoji, escaping, chunking)."""

from __future__ import annotations

import html
import re

from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import CallbackQuery, Message

from utils import emoji
from utils.logger import get_logger

log = get_logger(__name__)

MAX_MESSAGE = 4000
MAX_TELEGRAM = 4096


TAG_RE = re.compile(r"<[^>]+>")


def esc(value) -> str:
    return html.escape(str(value or ""), quote=False)


def plain(text: str) -> str:
    """Strip formatting so a rejected message can still be delivered as plain text."""
    return html.unescape(TAG_RE.sub("", text or ""))


def insufficient_coins(bet: int, coins: int) -> str:
    """Shared warning shown when a player cannot cover a casino bet."""
    from utils.money import fmt_coin

    return (
        "❌ <b>KHÔNG ĐỦ XU</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Muốn cược: <b>{fmt_coin(bet)}</b>\n"
        f"• Xu hiện có: <b>{fmt_coin(coins)}</b>\n"
        f"• Còn thiếu: <b>{fmt_coin(max(0, bet - coins))}</b>\n\n"
        "Kiếm thêm xu ở 🎁 Điểm danh, 🎡 Vòng quay may mắn hoặc nhập giftcode."
    )


def fit(text: str) -> str:
    """Trim long texts and expand ``[[key]]`` emoji tokens."""
    if len(text) > MAX_MESSAGE:
        text = text[: MAX_MESSAGE - 40] + "\n…<i>(rút gọn)</i>"
    decorated = emoji.decorate(text)
    if len(decorated) > MAX_TELEGRAM:
        plain = emoji.strip_custom(decorated)
        decorated = plain[: MAX_TELEGRAM - 12] + "…"
    return decorated


def _emoji_error(error: str) -> bool:
    return any(word in error for word in ("emoji", "entity", "sticker", "custom"))


async def _safe_send(send, text: str, kwargs: dict) -> None:
    """Call a Telegram send method, degrading formatting instead of going silent.

    A rejected HTML entity or premium emoji used to swallow the whole message, so
    the bot looked dead. Every failure now ends with a plain-text attempt.
    """
    try:
        await send(text, **kwargs)
        return
    except TelegramForbiddenError as exc:
        log.info("User blocked the bot or chat is unavailable: %s", exc)
        return
    except TelegramBadRequest as exc:
        error = str(exc).lower()
        if "message is not modified" in error:
            return
        if emoji.has_custom(text) and _emoji_error(error):
            emoji.set_enabled(False, error[:160])
            text = emoji.strip_custom(text)
            try:
                await send(text, **kwargs)
                return
            except TelegramBadRequest as retry_exc:
                log.warning("Telegram rejected a message: %s", retry_exc)
        else:
            log.error("Telegram rejected a message: %s", exc)

    fallback = dict(kwargs)
    fallback["parse_mode"] = None
    try:
        await send(plain(text)[:MAX_TELEGRAM], **fallback)
    except TelegramForbiddenError as exc:
        log.info("Cannot deliver plain fallback: %s", exc)
    except Exception as exc:  # noqa: BLE001 - never raise from the UI layer
        log.error("Cannot deliver plain fallback: %s", exc)


_REPLY_MODE: dict[int, bool] = {}


def remember_reply_mode(user_id: int, admin: bool) -> None:
    _REPLY_MODE[int(user_id)] = bool(admin)


async def sync_reply_keyboard(
    event: Message | CallbackQuery, user_id: int, language: str = "vi", admin: bool = True
) -> None:
    """Switch the bottom reply keyboard between the admin and player menus.

    Editing an inline message cannot change a reply keyboard, so a small notice
    is sent only when the mode actually changes (not on every refresh).
    """
    from keyboards.common import main_reply_keyboard

    if _REPLY_MODE.get(int(user_id)) == bool(admin):
        return
    _REPLY_MODE[int(user_id)] = bool(admin)
    keyboard = main_reply_keyboard(language, admin)
    text = "🛠 Đã chuyển sang bảng điều khiển admin." if admin else "👤 Đã chuyển sang menu người dùng."
    try:
        if isinstance(event, CallbackQuery):
            if event.message is not None:
                await event.message.answer(text, reply_markup=keyboard)
        else:
            await event.answer(text, reply_markup=keyboard)
    except Exception as exc:  # noqa: BLE001 - keyboard sync must never break a screen
        log.debug("Cannot update reply keyboard: %s", exc)


async def render(event: Message | CallbackQuery, text: str, kb=None) -> None:
    """Edit the current message for callbacks, otherwise send a new message."""
    text = fit(text)
    kwargs = dict(reply_markup=kb, parse_mode=ParseMode.HTML, disable_web_page_preview=True)

    if isinstance(event, CallbackQuery):
        message = event.message
        if message is None:
            await _safe_send(lambda t, **kw: event.bot.send_message(event.from_user.id, t, **kw), text, kwargs)
            return
        try:
            await message.edit_text(text, **kwargs)
            return
        except TelegramForbiddenError as exc:
            log.info("Cannot edit message: %s", exc)
            return
        except TelegramBadRequest as exc:
            error = str(exc).lower()
            if "message is not modified" in error:
                return
            log.warning("edit_text failed (%s); sending a new message", exc)
            if emoji.has_custom(text) and _emoji_error(error):
                emoji.set_enabled(False, error[:160])
                text = emoji.strip_custom(text)
                try:
                    await message.edit_text(text, **kwargs)
                    return
                except TelegramBadRequest:
                    pass
            log.debug("edit_text failed (%s); sending a new message", exc)
        await _safe_send(message.answer, text, kwargs)
    else:
        await _safe_send(event.answer, text, kwargs)


async def answer(callback: CallbackQuery, text: str | None = None, alert: bool = False) -> None:
    try:
        await callback.answer(text=text, show_alert=alert)
    except TelegramBadRequest:
        pass


def window(items: list, page: int, per_page: int) -> tuple[list, int, int]:
    pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(0, min(page, pages - 1))
    return items[page * per_page : (page + 1) * per_page], page, pages
