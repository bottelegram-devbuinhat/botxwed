"""Leaderboards with type/period filters and personal rank."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from keyboards.common import with_nav
from services import ranking_service
from services.settings_service import all_settings
from utils.money import fmt_amount, fmt_coin, fmt_vnd

from handlers.ui import answer, render

router = Router(name="leaderboard")

PERIOD_LABELS = {"day": "Hôm nay", "week": "Tuần", "month": "Tháng", "all": "Tất cả"}


def _format_value(kind: str, value: int) -> str:
    if kind in ("coins", "wins", "referrals", "streak"):
        return fmt_coin(value) if kind == "coins" else f"{value:,}".replace(",", ".")
    if kind == "biggest_win":
        return fmt_coin(value)
    return fmt_vnd(value)


def _kb(kind: str = "deposits", period: str = "all", language: str = "vi") -> InlineKeyboardMarkup:
    types = list(ranking_service.RANKING_TYPES.items())
    rows = []
    for index in range(0, len(types), 2):
        rows.append(
            [
                InlineKeyboardButton(
                    text=("• " if key == kind else "") + label,
                    callback_data=f"lb:{key}:{period}",
                )
                for key, label in types[index : index + 2]
            ]
        )
    rows.append(
        [
            InlineKeyboardButton(
                text=("• " if key == period else "") + label,
                callback_data=f"lb:{kind}:{key}",
            )
            for key, label in PERIOD_LABELS.items()
        ]
    )
    rows.append([InlineKeyboardButton(text="📍 Vị trí của tôi", callback_data=f"lb:me:{kind}:{period}")])
    return with_nav(rows, language, back="menu:home")


async def _screen(kind: str, period: str, db_user) -> tuple[str, InlineKeyboardMarkup]:
    rows = await ranking_service.top(kind, period, limit=10)
    title = ranking_service.RANKING_TYPES.get(kind, kind)
    lines = [f"🏆 <b>{title}</b> · {PERIOD_LABELS.get(period, period)}", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    if not rows:
        lines.append("<i>Chưa có dữ liệu cho kỳ này.</i>")
    for index, (_uid, name, value) in enumerate(rows, start=1):
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(index, f"{index}.")
        lines.append(f"{medal} {name} — <b>{_format_value(kind, value)}</b>")
    return "\n".join(lines), _kb(kind, period, db_user.language)


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    text, kb = await _screen("deposits", "all", db_user)
    await render(event, text, kb)


@router.callback_query(F.data == "menu:lb")
async def on_menu(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await open_menu(callback, db_user)


@router.callback_query(F.data.startswith("lb:me:"))
async def on_me(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    kind, period = parts[2], parts[3]
    rank, value = await ranking_service.my_rank(kind, db_user.id, period)
    title = ranking_service.RANKING_TYPES.get(kind, kind)
    text = (
        f"📍 <b>VỊ TRÍ CỦA BẠN</b>\n"
        f"• Bảng: {title} · {PERIOD_LABELS.get(period, period)}\n"
        f"• Hạng: <b>{rank if rank else 'Chưa xếp hạng'}</b>\n"
        f"• Thành tích: <b>{_format_value(kind, value)}</b>"
    )
    await render(callback, text, _kb(kind, period, db_user.language))


@router.callback_query(F.data.startswith("lb:"))
async def on_type(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    if len(parts) < 3:
        return
    kind = parts[1] if parts[1] in ranking_service.RANKING_TYPES else "deposits"
    period = parts[2] if parts[2] in PERIOD_LABELS else "all"
    text, kb = await _screen(kind, period, db_user)
    await render(callback, text, kb)
