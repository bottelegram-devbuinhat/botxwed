"""Betting flow, all games and multi-turn blackjack."""

from __future__ import annotations

import time

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from keyboards.casino import blackjack_kb, choice_screen, result_screen
from keyboards.common import with_nav
from services import casino_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils.money import fmt_coin, parse_amount

from handlers.states import CasinoForm
from handlers.ui import answer, insufficient_coins, render

router = Router(name="casino_games")

_LAST_PLAY: dict[int, float] = {}


def _cooldown_left(user_id: int, seconds: int) -> int:
    last = _LAST_PLAY.get(int(user_id), 0.0)
    remaining = int(seconds - (time.monotonic() - last))
    return max(0, remaining)


def _rewards_kb(language: str = "vi"):
    from aiogram.types import InlineKeyboardButton

    return with_nav(
        [[InlineKeyboardButton(text="🎁 Nhận thêm xu", callback_data="menu:rewards")]],
        language,
        back="menu:casino",
    )


async def _show_insufficient(event, db_user, bet: int, coins: int | None = None) -> None:
    if coins is None:
        fresh = await wallet.get_user(db_user.id)
        coins = int(fresh.coins) if fresh is not None else int(db_user.coins)
    await render(event, insufficient_coins(bet, coins), _rewards_kb(db_user.language))


async def do_play(event, db_user, game: str, bet: int, choice: str | None) -> None:
    settings = await all_settings()
    cooldown = int(settings.get("casino_cooldown_seconds", 2))
    left = _cooldown_left(db_user.id, cooldown)
    if left > 0:
        if isinstance(event, CallbackQuery):
            await answer(event, f"⏳ Chờ {left}s nữa nhé.", alert=True)
        else:
            await event.answer(f"⏳ Chờ {left}s nữa nhé.")
        return
    result = await casino_service.place_bet(db_user.id, game, bet, choice)
    if not result.get("ok"):
        if result.get("code") == "insufficient_coins":
            await _show_insufficient(event, db_user, bet, int(result.get("coins") or 0))
            return
        message = result.get("error", "Không chơi được.")
        if isinstance(event, CallbackQuery):
            await answer(event, message, alert=True)
        else:
            await event.answer(message)
        return
    _LAST_PLAY[db_user.id] = time.monotonic()
    await render(event, result["text"], result_screen(game, bet, db_user.language))


@router.callback_query(F.data.startswith("cas:bet:"))
async def on_bet(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    parts = callback.data.split(":")
    if len(parts) < 4:
        await answer(callback)
        return
    game, bet_raw = parts[2], parts[3]
    try:
        bet = int(bet_raw)
    except ValueError:
        await answer(callback, "Mức cược không hợp lệ", alert=True)
        return
    meta = casino_service.GAMES.get(game)
    if meta is None:
        await answer(callback, "Game không tồn tại", alert=True)
        return

    if bet > int(db_user.coins):
        await answer(callback)
        await _show_insufficient(callback, db_user, bet)
        return

    if game == "blackjack":
        await answer(callback)
        await start_blackjack(callback, state, db_user, bet)
        return

    await answer(callback)
    if meta.get("choices"):
        text = (
            f"{meta['name']} — cược <b>{fmt_coin(bet)}</b>\n"
            f"🪙 Xu hiện có: <b>{fmt_coin(db_user.coins)}</b>\n\n"
            f"{meta['rules']}\n\nChọn cửa cược:"
        )
        await render(callback, text, choice_screen(game, bet, db_user.language))
    else:
        await do_play(callback, db_user, game, bet, None)


@router.callback_query(F.data.startswith("cas:play:"))
async def on_play(callback: CallbackQuery, db_user) -> None:
    parts = callback.data.split(":")
    if len(parts) < 5:
        await answer(callback)
        return
    game = parts[2]
    try:
        bet = int(parts[3])
    except ValueError:
        await answer(callback, "Mức cược không hợp lệ", alert=True)
        return
    choice = parts[4]
    if choice == "None":
        choice = None
    await answer(callback)
    await do_play(callback, db_user, game, bet, choice)


@router.callback_query(F.data.startswith("cas:custom:"))
async def on_custom(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    game = callback.data.split(":")[2]
    if game not in casino_service.GAMES:
        await answer(callback, "Game không tồn tại", alert=True)
        return
    await state.set_state(CasinoForm.bet)
    await state.update_data(bet_game=game)
    await render(
        callback,
        f"✏️ Nhập số xu muốn cược cho <b>{casino_service.GAMES[game]['name']}</b>\n"
        f"Ví dụ: <code>1000</code>",
    )


@router.message(CasinoForm.bet, F.text)
async def on_custom_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    game = data.get("bet_game", "taixiu")
    bet = parse_amount(message.text or "")
    await state.clear()
    if not bet:
        await message.answer("❌ Số xu không hợp lệ, thử lại từ menu game.")
        return
    if bet > int(db_user.coins):
        await _show_insufficient(message, db_user, bet)
        return
    if game == "blackjack":
        await start_blackjack(message, state, db_user, bet)
        return
    meta = casino_service.GAMES.get(game, {"name": game})
    if meta.get("choices"):
        await message.answer(
            f"{meta['name']} — cược <b>{fmt_coin(bet)}</b>\nChọn cửa cược:",
            parse_mode="HTML",
            reply_markup=choice_screen(game, bet, db_user.language),
        )
    else:
        await do_play(message, db_user, game, bet, None)


# --------------------------------------------------------------------------- blackjack
def _cards_text(cards) -> str:
    return " ".join(casino_service.card_str(card) for card in cards)


async def _notice(event, text: str) -> None:
    """Show a short warning for both callback buttons and plain messages."""
    if isinstance(event, CallbackQuery):
        await answer(event, text, alert=True)
    else:
        await event.answer(f"⚠️ {text}")


async def start_blackjack(event, state: FSMContext, db_user, bet: int) -> None:
    settings = await all_settings()
    min_bet = int(settings.get("casino_min_bet", 100))
    max_bet = int(settings.get("casino_max_bet", 100000))
    if bet < min_bet or bet > max_bet:
        await _notice(event, f"Cược từ {fmt_coin(min_bet)} đến {fmt_coin(max_bet)}")
        return
    if bet > int(db_user.coins):
        await _show_insufficient(event, db_user, bet)
        return
    if not await wallet.spend(db_user.id, bet, "casino_blackjack", "coin", "Cược Blackjack"):
        await _notice(event, "Bạn không đủ xu.")
        return

    deck = casino_service.new_deck()
    player, dealer = [deck[0], deck[1]], [deck[2], deck[3]]
    await state.set_state(CasinoForm.blackjack)
    await state.update_data(
        bj={
            "bet": bet,
            "deck": deck[4:],
            "player": player,
            "dealer": dealer,
        }
    )
    text = (
        "♠️ <b>BLACKJACK</b>\n"
        f"• Cược: <b>{fmt_coin(bet)}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"🃏 Bạn: <b>{_cards_text(player)}</b> = <b>{casino_service.hand_value(player)}</b>\n"
        f"🎩 Nhà cái: <b>{casino_service.card_str(dealer[0])}</b> + 1 lá úp\n\n"
        "Rút thêm hay dừng?"
    )
    if casino_service.hand_value(player) == 21:
        await _finish_blackjack(event, state, db_user, natural=True)
        return
    if isinstance(event, CallbackQuery):
        await render(event, text, blackjack_kb(db_user.language))
    else:
        await event.answer(text, parse_mode="HTML", reply_markup=blackjack_kb(db_user.language))


@router.callback_query(F.data == "cas:bj:hit")
async def on_hit(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    bj = data.get("bj")
    if not bj:
        await answer(callback, "Ván đã kết thúc.", alert=True)
        return
    await answer(callback)
    deck = bj["deck"]
    player = bj["player"] + [deck.pop(0)]
    bj["player"] = player
    await state.update_data(bj=bj)
    total = casino_service.hand_value(player)
    if total > 21:
        await casino_service.log_game(db_user.id, "blackjack", bj["bet"], 0, "lose", "Bust")
        await state.clear()
        text = (
            "♠️ <b>BLACKJACK — BỊ QUÁ 21</b>\n"
            f"🃏 Bạn: <b>{_cards_text(player)}</b> = <b>{total}</b>\n"
            f"❌ Thua <b>{fmt_coin(bj['bet'])}</b>."
        )
        await render(callback, text, result_screen("blackjack", bj["bet"], db_user.language))
        return
    text = (
        "♠️ <b>BLACKJACK</b>\n"
        f"• Cược: <b>{fmt_coin(bj['bet'])}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"🃏 Bạn: <b>{_cards_text(player)}</b> = <b>{total}</b>\n"
        f"🎩 Nhà cái: <b>{casino_service.card_str(bj['dealer'][0])}</b> + 1 lá úp\n\n"
        "Rút thêm hay dừng?"
    )
    if total == 21:
        await _finish_blackjack(callback, state, db_user)
        return
    await render(callback, text, blackjack_kb(db_user.language))


@router.callback_query(F.data == "cas:bj:stand")
async def on_stand(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await _finish_blackjack(callback, state, db_user)


async def _finish_blackjack(event, state: FSMContext, db_user, natural: bool = False) -> None:
    data = await state.get_data()
    bj = data.get("bj")
    if not bj:
        return
    bet = int(bj["bet"])
    player = list(bj["player"])
    dealer = list(bj["dealer"])
    deck = list(bj["deck"])

    player_total = casino_service.hand_value(player)
    dealer_total = casino_service.hand_value(dealer)

    if not natural:
        while dealer_total < 17 and deck:
            dealer.append(deck.pop(0))
            dealer_total = casino_service.hand_value(dealer)

    natural_blackjack = len(player) == 2 and player_total == 21
    if player_total > 21:
        payout = 0
    elif dealer_total > 21 or player_total > dealer_total:
        payout = int(bet * (2.5 if natural_blackjack else 2.0))
    elif player_total == dealer_total:
        payout = bet
    else:
        payout = 0

    if payout > 0:
        await wallet.add_balance(db_user.id, payout, "casino_blackjack_win", "coin", "Blackjack")
    await casino_service.log_game(
        db_user.id,
        "blackjack",
        bet,
        payout,
        "win" if payout > bet else "push" if payout == bet else "lose",
        f"Bạn {player_total} - Nhà cái {dealer_total}",
    )
    await state.clear()

    net = payout - bet
    label = "🎉 THẮNG" if net > 0 else "➖ HOÀ" if net == 0 else "❌ THUA"
    text = (
        f"♠️ <b>BLACKJACK — {label}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"🃏 Bạn: {_cards_text(player)} = <b>{player_total}</b>\n"
        f"🎩 Nhà cái: {_cards_text(dealer)} = <b>{dealer_total}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"{'+' if net > 0 else ''}{fmt_coin(net)}"
    )
    if isinstance(event, CallbackQuery):
        await render(event, text, result_screen("blackjack", bet, db_user.language))
    else:
        await event.answer(text, parse_mode="HTML", reply_markup=result_screen("blackjack", bet, db_user.language))
