"""Casino lobby, game screens, rules and history."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message

from keyboards.common import back_only, with_nav
from keyboards.casino import casino_menu, game_screen
from locales import t
from services import casino_service
from services.settings_service import all_settings
from utils import cards
from utils.money import fmt_coin
from utils.permissions import is_admin

from handlers.ui import answer, render

router = Router(name="casino_menu")


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_casino"):
        await render(event, "🚧 Sảnh casino đang tạm đóng.")
        return
    enabled = sum(1 for key in casino_service.GAMES if (settings.get("game_enabled") or {}).get(key))
    text = (
        f"{cards.title('slot', 'SẢNH CASINO XU ẢO')}"
        f"  [[coin]] Xu của bạn: <b>{fmt_coin(db_user.coins)}</b>\n"
        f"  [[gem]] Hũ hiện tại: <b>{fmt_coin(int(settings.get('jackpot', 0)))}</b>\n"
        f"  [[gamepad]] Game đang mở: <b>{enabled}/{len(casino_service.GAMES)}</b>\n"
        f"  [[dice]] Cược: {fmt_coin(int(settings.get('casino_min_bet', 100)))} - "
        f"{fmt_coin(int(settings.get('casino_max_bet', 100000)))}\n\n"
        f"{cards.quote(t('casino_warning', db_user.language))}\n\n"
        f"{cards.note('Chọn game bên dưới 👇')}"
    )
    await render(event, text, casino_menu(db_user.language, await is_admin(db_user.id)))


@router.callback_query(F.data == "cas:menu")
async def on_menu(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await open_menu(callback, db_user)


@router.callback_query(F.data.startswith("cas:game:"))
async def on_game(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    game = callback.data.split(":")[2]
    meta = casino_service.GAMES.get(game)
    if meta is None:
        await render(callback, "❌ Game không tồn tại.", back_only("cas:menu"))
        return
    settings = await all_settings()
    if not (settings.get("game_enabled") or {}).get(game):
        await render(callback, "🔴 Game này đang tạm đóng.", back_only("cas:menu"))
        return
    text = (
        f"{meta['name']}\n"
        f"{cards.LINE}\n"
        f"{meta['rules']}\n"
        f"{cards.LINE}\n"
        f"  [[coin]] Xu: <b>{fmt_coin(db_user.coins)}</b>\n"
        f"  [[target]] Cược tối thiểu: {fmt_coin(int(settings.get('casino_min_bet', 100)))}\n"
        f"  [[fire]] Cược tối đa: {fmt_coin(int(settings.get('casino_max_bet', 100000)))}\n\n"
        f"{cards.note('Chọn mức cược bên dưới 👇')}"
    )
    await render(callback, text, game_screen(game, db_user.language))


@router.callback_query(F.data.startswith("cas:rules:"))
async def on_rules(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    game = callback.data.split(":")[2]
    meta = casino_service.GAMES.get(game)
    if meta is None:
        await render(callback, "❌ Game không tồn tại.", back_only("cas:menu"))
        return
    text = (
        f"{meta['name']} — <b>LUẬT CHƠI</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"{meta['rules']}\n\n"
        "🔐 Mỗi ván dùng seed ngẫu nhiên, hash công bố cùng kết quả để bạn kiểm tra.\n"
        "🪙 Xu là tiền ảo giải trí, không mua bằng tiền thật và không quy đổi ra tiền/acc.\n"
        "⚠️ Chỉ dành cho người từ 18 tuổi, chơi có trách nhiệm."
    )
    rows = [[InlineKeyboardButton(text="🎲 Đặt cược", callback_data=f"cas:game:{game}")]]
    await render(callback, text, with_nav(rows, db_user.language, back=f"cas:game:{game}"))


@router.callback_query(F.data == "cas:history")
async def on_history(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    rows = await casino_service.game_history(db_user.id, limit=12)
    if not rows:
        await render(callback, "📜 Bạn chưa chơi ván nào.", back_only("cas:menu", db_user.language))
        return
    lines = ["📜 <b>LỊCH SỬ CASINO</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for row in rows:
        meta = casino_service.GAMES.get(row.game, {"name": row.game})
        net = row.payout - row.bet
        icon = "🎉" if net > 0 else "➖" if net == 0 else "❌"
        lines.append(
            f"{icon} {meta['name']} · cược {fmt_coin(row.bet)} · "
            f"<b>{'+' if net > 0 else ''}{fmt_coin(net)}</b> · {row.created_at:%d/%m %H:%M}"
        )
    await render(callback, "\n".join(lines), back_only("cas:menu", db_user.language))
