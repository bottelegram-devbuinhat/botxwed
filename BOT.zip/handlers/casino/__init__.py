"""Casino handlers package."""

from aiogram import Router

from handlers.casino import games, menu
from handlers.casino.menu import open_menu

router = Router(name="casino")
router.include_router(menu.router)
router.include_router(games.router)

__all__ = ["router", "open_menu"]
