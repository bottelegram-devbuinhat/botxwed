"""Wallet handlers: deposits (bank / momo / card), withdrawals and history."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, InlineKeyboardButton, Message
from sqlalchemy import select

from config import BANK_ACCOUNT, BANK_CODE, BANK_HOLDER, CARD_FEE_PERCENT, SUPPORT_USERNAME
from database.models import Deposit
from database.session import session_scope
from keyboards.admin import deposit_admin
from keyboards.common import back_only, confirm_kb, with_nav
from keyboards.shop import deposit_amounts, deposit_methods
from services import payment_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils import cards
from utils.money import fmt_vnd, parse_amount
from utils.notifications import notify_admins
from utils.permissions import admin_ids

from handlers.states import DepositForm, WithdrawForm
from handlers.ui import answer, esc, render

router = Router(name="wallet")

STATUS_LABELS = {
    "pending": "⏳ Chờ duyệt",
    "approved": "✅ Thành công",
    "rejected": "❌ Bị từ chối",
    "completed": "✅ Hoàn tất",
}


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_deposit"):
        await render(event, "🚧 Chức năng nạp tiền đang tạm đóng.")
        return
    promo = settings.get("deposit_promotion") or {}
    promo_text = ""
    if promo.get("enabled"):
        promo_text = (
            f"\n🎁 Khuyến mãi: nạp từ <b>{fmt_vnd(int(promo.get('threshold', 0)))}</b> "
            f"tặng thêm <b>{promo.get('percent', 0)}%</b>."
        )
    text = (
        f"{cards.title('card', 'VÍ TIỀN')}"
        f"  [[money]] Số dư shop: <b>{fmt_vnd(db_user.shop_balance)}</b>\n"
        f"  [[gift]] Nạp tối thiểu: {fmt_vnd(int(settings['min_deposit']))}\n"
        f"  [[gem]] Nạp tối đa: {fmt_vnd(int(settings['max_deposit']))}\n"
        f"  [[cash]] Rút: {fmt_vnd(int(settings['min_withdraw']))} - {fmt_vnd(int(settings['max_withdraw']))}"
        f"{promo_text}\n\n"
        f"{cards.note('Chọn thao tác bên dưới 👇')}"
    )
    row = [InlineKeyboardButton(text="💳 Nạp tiền", callback_data="dep:menu")]
    if settings.get("feature_withdraw"):
        row.append(InlineKeyboardButton(text="💸 Rút tiền", callback_data="wd:new"))
    rows = [row, [InlineKeyboardButton(text="📜 Lịch sử nạp", callback_data="dep:history")]]
    await render(event, text, with_nav(rows, db_user.language, back="menu:home"))


@router.callback_query(F.data == "dep:menu")
async def on_deposit_menu(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await render(callback, "💳 <b>CHỌN PHƯƠNG THỨC NẠP</b>", deposit_methods(db_user.language))


def _instructions(deposit: Deposit, method: str) -> str:
    if method == "bank":
        return (
            f"🏦 <b>HÓA ĐƠN NẠP {fmt_vnd(deposit.amount)}</b>\n"
            "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
            f"• Ngân hàng: <b>{esc(BANK_CODE)}</b>\n"
            f"• Số tài khoản: <code>{esc(BANK_ACCOUNT)}</code>\n"
            f"• Chủ tài khoản: <b>{esc(BANK_HOLDER)}</b>\n"
            f"• Số tiền: <b>{fmt_vnd(deposit.amount)}</b>\n"
            f"• Nội dung: <code>{deposit.code}</code>\n"
            "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
            "⚠️ Chuyển đúng <b>số tiền</b> và <b>nội dung</b> để được cộng tự động.\n"
            f"📷 Sau khi chuyển, gửi ảnh biên lai vào chat."
        )
    if method == "card":
        return "💳 <b>ĐỔI THẺ CÀO</b>\nLàm theo hướng dẫn trong chat."
    return (
        f"📱 <b>NẠP QUA MOMO / ZALOPAY — {fmt_vnd(deposit.amount)}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Chủ ví: <b>{esc(BANK_HOLDER)}</b>\n"
        f"• Số ví: <code>{esc(BANK_ACCOUNT)}</code>\n"
        f"• Nội dung: <code>{deposit.code}</code>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"⚠️ Sau khi chuyển, gửi ảnh biên lai để admin duyệt.\n"
        f"🆘 Cần hỗ trợ: {esc(SUPPORT_USERNAME)}"
    )


async def _create_and_show(event, db_user, method: str, amount: int, state: FSMContext) -> None:
    deposit = await wallet.create_deposit(db_user.id, amount, method)
    if deposit is None:
        settings = await all_settings()
        await render(
            event,
            f"❌ Số tiền nạp phải từ <b>{fmt_vnd(int(settings['min_deposit']))}</b> đến "
            f"<b>{fmt_vnd(int(settings['max_deposit']))}</b>.",
            back_only("dep:menu", db_user.language),
        )
        return

    await state.set_state(DepositForm.receipt)
    await state.update_data(deposit_id=deposit.id, dep_method=method)

    target = event.message if isinstance(event, CallbackQuery) else event
    if method == "bank":
        qr_bytes = None
        try:
            qr_bytes = await payment_service.get_qr_bytes(deposit.amount, deposit.code)
        except Exception as exc:
            log.warning("Lỗi tạo mã VietQR: %s", exc)

        try:
            if qr_bytes:
                await target.answer_photo(
                    photo=BufferedInputFile(qr_bytes, filename=f"vietqr-{deposit.code}.png"),
                    caption=_instructions(deposit, method),
                    parse_mode="HTML",
                )
            else:
                await target.answer(_instructions(deposit, method), parse_mode="HTML")
        except Exception:
            await target.answer(_instructions(deposit, method), parse_mode="HTML")
    else:
        await target.answer(_instructions(deposit, method), parse_mode="HTML")
    await target.answer(
        "📷 Gửi <b>ảnh biên lai</b> vào đây để admin duyệt nhanh.\n"
        f"Mã nạp của bạn: <code>{deposit.code}</code>",
        parse_mode="HTML",
        reply_markup=back_only("menu:deposit", db_user.language),
    )
    await notify_admins(
        target.bot,
        f"💳 <b>Yêu cầu nạp mới #{deposit.id}</b>\n"
        f"• User: <code>{db_user.id}</code> ({esc(db_user.full_name)})\n"
        f"• Số tiền: <b>{fmt_vnd(deposit.amount)}</b>\n"
        f"• Phương thức: {method}\n"
        f"• Mã: <code>{deposit.code}</code>",
    )


@router.callback_query(F.data == "dep:method:bank")
async def on_bank(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await render(
        callback,
        "🏦 <b>CHUYỂN KHOẢN — CHỌN MỆNH GIÁ</b>\n"
        "Hệ thống tạo mã VietQR riêng cho bạn.",
        deposit_amounts("bank", db_user.language),
    )


@router.callback_query(F.data == "dep:method:momo")
async def on_momo(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await render(
        callback,
        "📱 <b>MOMO / ZALOPAY — CHỌN MỆNH GIÁ</b>\n"
        "Sau khi chọn, bot hiện thông tin ví và nội dung chuyển.",
        deposit_amounts("momo", db_user.language),
    )


@router.callback_query(F.data.startswith("dep:amount:"))
async def on_amount(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    parts = callback.data.split(":")
    if len(parts) < 4:
        await answer(callback)
        return
    method = parts[2]
    try:
        amount = int(parts[3])
    except ValueError:
        await answer(callback, "Số tiền không hợp lệ", alert=True)
        return
    await answer(callback)
    await _create_and_show(callback, db_user, method, amount, state)


@router.callback_query(F.data.startswith("dep:custom:"))
async def on_custom(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    method = callback.data.split(":")[2]
    await state.set_state(DepositForm.amount)
    await state.update_data(dep_method=method)
    await render(
        callback,
        "✏️ Nhập số tiền muốn nạp (ví dụ <code>50000</code>, <code>100k</code>):",
        back_only("dep:menu", db_user.language),
    )


@router.message(DepositForm.amount, F.text)
async def on_amount_text(message: Message, state: FSMContext, db_user) -> None:
    amount = parse_amount(message.text or "")
    data = await state.get_data()
    method = data.get("dep_method", "bank")
    if not amount:
        await message.answer("❌ Số tiền không hợp lệ, hãy nhập lại.")
        return
    await _create_and_show(message, db_user, method, amount, state)


@router.message(DepositForm.receipt, F.photo)
async def on_receipt(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    deposit_id = data.get("deposit_id")
    file_id = message.photo[-1].file_id
    async with session_scope() as session:
        deposit = await session.get(Deposit, int(deposit_id)) if deposit_id else None
        if deposit is None:
            deposit = (
                await session.execute(
                    select(Deposit)
                    .where(Deposit.user_id == db_user.id, Deposit.status == "pending")
                    .order_by(Deposit.created_at.desc())
                    .limit(1)
                )
            ).scalar_one_or_none()
        if deposit is None:
            await message.answer("Không tìm thấy yêu cầu nạp đang chờ. Hãy tạo lại từ 💳 Nạp tiền.")
            await state.clear()
            return
        deposit.receipt_file_id = file_id
        dep_id, dep_amount = deposit.id, deposit.amount

    await state.clear()
    await message.answer(
        f"✅ Đã nhận biên lai cho yêu cầu nạp <b>{fmt_vnd(dep_amount)}</b>.\n"
        "Admin sẽ kiểm tra và duyệt trong ít phút.",
        parse_mode="HTML",
        reply_markup=back_only("menu:deposit", db_user.language),
    )
    caption = (
        f"🧾 <b>Biên lai nạp #{dep_id}</b>\n"
        f"• User: <code>{db_user.id}</code> ({esc(db_user.full_name)})\n"
        f"• Số tiền: <b>{fmt_vnd(dep_amount)}</b>"
    )
    for admin_id in await admin_ids():
        try:
            await message.bot.send_photo(
                admin_id,
                photo=file_id,
                caption=caption,
                reply_markup=deposit_admin(dep_id),
                parse_mode="HTML",
            )
        except Exception:
            continue


@router.message(DepositForm.receipt, F.text)
async def on_receipt_text(message: Message, db_user) -> None:
    await message.answer(
        "📷 Vui lòng gửi <b>ảnh biên lai</b>, hoặc bấm Menu để huỷ yêu cầu.",
        parse_mode="HTML",
        reply_markup=back_only("menu:deposit", db_user.language),
    )


# --------------------------------------------------------------------------- prepaid cards
@router.callback_query(F.data == "dep:method:card")
async def on_card(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(DepositForm.card_serial)
    await render(
        callback,
        f"💳 <b>ĐỔI THẺ CÀO</b>\nPhí đổi: <b>{CARD_FEE_PERCENT}%</b>\n\n"
        "Nhập <b>serial</b> thẻ (dãy số in trên thẻ):",
        back_only("dep:menu", db_user.language),
    )


@router.message(DepositForm.card_serial, F.text)
async def on_card_serial(message: Message, state: FSMContext) -> None:
    serial = (message.text or "").strip()
    if len(serial) < 6:
        await message.answer("❌ Serial không hợp lệ, nhập lại.")
        return
    await state.update_data(card_serial=serial)
    await state.set_state(DepositForm.card_code)
    await message.answer("🔑 Nhập <b>mã thẻ</b> (mã PIN):", parse_mode="HTML")


@router.message(DepositForm.card_code, F.text)
async def on_card_code(message: Message, state: FSMContext) -> None:
    code = (message.text or "").strip()
    if len(code) < 6:
        await message.answer("❌ Mã thẻ không hợp lệ, nhập lại.")
        return
    await state.update_data(card_code=code)
    await state.set_state(DepositForm.card_amount)
    await message.answer("💰 Nhập <b>mệnh giá</b> thẻ (ví dụ 100000):", parse_mode="HTML")


@router.message(DepositForm.card_amount, F.text)
async def on_card_amount(message: Message, state: FSMContext, db_user) -> None:
    declared = parse_amount(message.text or "")
    if not declared:
        await message.answer("❌ Mệnh giá không hợp lệ, nhập lại.")
        return
    data = await state.get_data()
    await state.clear()
    ok, text, value = await payment_service.redeem_card(
        data.get("card_serial", ""), data.get("card_code", ""), declared
    )
    if not ok:
        await message.answer(f"❌ {esc(text)}")
        return
    fee = value * CARD_FEE_PERCENT // 100
    credit = value - fee
    if credit <= 0:
        await message.answer("❌ Giá trị thẻ sau phí không hợp lệ.")
        return
    await wallet.credit_deposit_direct(
        db_user.id, credit, f"Đổi thẻ {data.get('card_serial')}", ref=f"card:{data.get('card_serial')}:{db_user.id}"
    )
    await message.answer(
        f"✅ <b>Đổi thẻ thành công</b>\n• Mệnh giá: {fmt_vnd(value)}\n"
        f"• Phí: {fmt_vnd(fee)} ({CARD_FEE_PERCENT}%)\n• Thực nhận: <b>{fmt_vnd(credit)}</b>",
        parse_mode="HTML",
    )
    await notify_admins(
        message.bot,
        f"💳 <b>Đổi thẻ</b> · user <code>{db_user.id}</code> · {fmt_vnd(value)} → {fmt_vnd(credit)}",
    )


# --------------------------------------------------------------------------- history
@router.callback_query(F.data == "dep:history")
async def on_history(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    deposits = await wallet.deposits_of(db_user.id, limit=12)
    if not deposits:
        await render(callback, "📜 Bạn chưa có lệnh nạp nào.", back_only("menu:deposit", db_user.language))
        return
    lines = ["📜 <b>LỊCH SỬ NẠP</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for deposit in deposits:
        lines.append(
            f"• #{deposit.id} · {fmt_vnd(deposit.amount)} · {deposit.method} · "
            f"{STATUS_LABELS.get(deposit.status, deposit.status)} · {deposit.created_at:%d/%m %H:%M}"
        )
    if any(d.status == "pending" for d in deposits):
        lines.append("\n⏳ Có yêu cầu đang chờ duyệt, vui lòng đợi admin.")
    await render(callback, "\n".join(lines), back_only("menu:deposit", db_user.language))


# --------------------------------------------------------------------------- withdrawals
@router.callback_query(F.data == "wd:new")
async def on_withdraw(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_withdraw"):
        await answer(callback, "Chức năng rút tiền đang tạm đóng.", alert=True)
        return
    await answer(callback)
    await state.set_state(WithdrawForm.bank)
    await render(
        callback,
        "🏦 <b>RÚT TIỀN — BƯỚC 1/4</b>\nNhập tên ngân hàng (ví dụ <b>MB Bank</b>):",
        back_only("menu:deposit", db_user.language),
    )


@router.message(WithdrawForm.bank, F.text)
async def on_wd_bank(message: Message, state: FSMContext) -> None:
    bank = (message.text or "").strip()
    if len(bank) < 2:
        await message.answer("❌ Tên ngân hàng quá ngắn, nhập lại.")
        return
    await state.update_data(bank=bank)
    await state.set_state(WithdrawForm.number)
    await message.answer("💳 <b>BƯỚC 2/4</b>\nNhập số tài khoản:", parse_mode="HTML")


@router.message(WithdrawForm.number, F.text)
async def on_wd_number(message: Message, state: FSMContext) -> None:
    number = (message.text or "").strip().replace(" ", "")
    if not number.isdigit() or len(number) < 6:
        await message.answer("❌ Số tài khoản không hợp lệ, nhập lại.")
        return
    await state.update_data(number=number)
    await state.set_state(WithdrawForm.name)
    await message.answer("👤 <b>BƯỚC 3/4</b>\nNhập tên chủ tài khoản:", parse_mode="HTML")


@router.message(WithdrawForm.name, F.text)
async def on_wd_name(message: Message, state: FSMContext) -> None:
    name = (message.text or "").strip()
    if len(name) < 3:
        await message.answer("❌ Tên chủ tài khoản quá ngắn, nhập lại.")
        return
    await state.update_data(name=name)
    await state.set_state(WithdrawForm.amount)
    settings = await all_settings()
    await message.answer(
        f"💰 <b>BƯỚC 4/4</b>\nNhập số tiền muốn rút ({fmt_vnd(int(settings['min_withdraw']))} - "
        f"{fmt_vnd(int(settings['max_withdraw']))}):",
        parse_mode="HTML",
    )


@router.message(WithdrawForm.amount, F.text)
async def on_wd_amount(message: Message, state: FSMContext, db_user) -> None:
    amount = parse_amount(message.text or "")
    settings = await all_settings()
    if not amount:
        await message.answer("❌ Số tiền không hợp lệ, nhập lại.")
        return
    if amount < int(settings["min_withdraw"]) or amount > int(settings["max_withdraw"]):
        await message.answer(
            f"❌ Số tiền rút phải từ {fmt_vnd(int(settings['min_withdraw']))} đến "
            f"{fmt_vnd(int(settings['max_withdraw']))}."
        )
        return
    fee = amount * int(settings.get("withdraw_fee_percent", 0)) // 100
    if db_user.shop_balance < amount + fee:
        await message.answer(
            f"❌ Số dư không đủ. Cần {fmt_vnd(amount + fee)}, bạn có {fmt_vnd(db_user.shop_balance)}."
        )
        return
    data = await state.get_data()
    await state.update_data(amount=amount)
    await state.set_state(WithdrawForm.confirm)
    text = (
        "🧾 <b>XÁC NHẬN RÚT TIỀN</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Ngân hàng: <b>{esc(data.get('bank'))}</b>\n"
        f"• STK: <code>{esc(data.get('number'))}</code>\n"
        f"• Chủ TK: <b>{esc(data.get('name'))}</b>\n"
        f"• Số tiền: <b>{fmt_vnd(amount)}</b>\n"
        f"• Phí: {fmt_vnd(fee)}\n"
        f"• Thực nhận: <b>{fmt_vnd(amount - fee)}</b>\n\n"
        "Tiền sẽ bị tạm giữ cho đến khi admin duyệt."
    )
    await message.answer(text, parse_mode="HTML", reply_markup=confirm_kb("wd:confirm", "menu:deposit"))


@router.callback_query(StateFilter(WithdrawForm.confirm), F.data == "wd:confirm")
async def on_wd_confirm(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    amount = int(data.get("amount", 0))
    withdrawal = await wallet.request_withdraw(
        db_user.id, amount, data.get("bank", ""), data.get("number", ""), data.get("name", "")
    )
    if withdrawal is None:
        await answer(callback, "Không tạo được yêu cầu rút. Kiểm tra số dư.", alert=True)
        return
    await state.clear()
    await answer(callback)
    await render(
        callback,
        f"⏳ <b>Đã gửi yêu cầu rút {fmt_vnd(amount)}</b>\n"
        "Admin sẽ duyệt và chuyển khoản trong 1-24 giờ.",
        back_only("menu:deposit", db_user.language),
    )
    await notify_admins(
        callback.bot,
        f"💸 <b>Yêu cầu rút mới #{withdrawal.id}</b>\n"
        f"• User: <code>{db_user.id}</code>\n• Số tiền: <b>{fmt_vnd(amount)}</b>\n"
        f"• Bank: {esc(data.get('bank'))} · {esc(data.get('number'))} · {esc(data.get('name'))}",
    )


@router.callback_query(F.data == "wd:cancel")
async def on_wd_cancel(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await state.clear()
    await answer(callback, "Đã huỷ")
    await open_menu(callback, db_user)
