"""Player profile: info, history, VIP and settings."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from keyboards.common import with_nav
from locales import language_name, t
from services import casino_service, shop_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils import cards
from utils.money import fmt_coin, fmt_vnd, signed
from utils.permissions import is_admin

from handlers.ui import answer, esc, render

router = Router(name="profile")


def _settings_kb(db_user) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"🌐 Ngôn ngữ: {language_name(db_user.language)}", callback_data="prof:lang"
            )
        ],
        [
            InlineKeyboardButton(
                text=f"🙈 Ẩn tên BXH: {'🟢' if db_user.hide_name else '🔴'}", callback_data="prof:hide"
            )
        ],
        [
            InlineKeyboardButton(
                text=f"🔔 Thông báo: {'🟢' if db_user.notifications else '🔴'}", callback_data="prof:notify"
            )
        ],
    ]
    return with_nav(rows, db_user.language, back="menu:account")


def _profile_kb(db_user) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="📜 Giao dịch", callback_data="prof:tx:0"),
            InlineKeyboardButton(text="🧾 Đơn hàng", callback_data="prof:orders"),
        ],
        [
            InlineKeyboardButton(text="🎮 Lịch sử game", callback_data="prof:games"),
            InlineKeyboardButton(text="👑 VIP", callback_data="prof:vip"),
        ],
        [InlineKeyboardButton(text="⚙️ Cài đặt", callback_data="prof:settings")],
        [InlineKeyboardButton(text="💳 Nạp tiền", callback_data="menu:deposit")],
    ]
    return with_nav(rows, db_user.language, back="menu:home")


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    progress = cards.bar(db_user.vip_level, 5) + f"  {cards.percent(db_user.vip_level, 5)}"
    text = (
        f"{cards.title('user', 'THÔNG TIN TÀI KHOẢN')}"
        f"  [[user]] Tên: <b>{esc(db_user.full_name)}</b>\n"
        f"  [[pin]] ID: <code>{db_user.id}</code>\n"
        f"  [[money]] Số dư shop: <b>{fmt_vnd(db_user.shop_balance)}</b>\n"
        f"  [[coin]] Xu casino: <b>{fmt_coin(db_user.coins)}</b>\n"
        f"  [[crown]] VIP <b>{db_user.vip_level}</b> · {progress}\n"
        f"  [[card]] Tổng nạp: {fmt_vnd(db_user.total_deposited)}\n"
        f"  [[cart]] Tổng mua acc: {fmt_vnd(db_user.total_purchased)}\n"
        f"  [[fire]] Chuỗi điểm danh: <b>{db_user.checkin_streak}</b> ngày\n"
        f"  [[sparkle]] Tham gia: {db_user.created_at:%d/%m/%Y}\n"
        f"{cards.LINE}\n"
        f"{cards.note('Xu casino là tiền ảo giải trí, không quy đổi ra tiền mặt.')}"
    )
    await render(event, text, _profile_kb(db_user))


@router.callback_query(F.data.startswith("prof:tx"))
async def show_transactions(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    page = int(callback.data.split(":")[2]) if len(callback.data.split(":")) > 2 else 0
    rows = await wallet.transactions_of(db_user.id, limit=50)
    per_page = 8
    pages = max(1, (len(rows) + per_page - 1) // per_page)
    page = max(0, min(page, pages - 1))
    chunk = rows[page * per_page : (page + 1) * per_page]
    if not chunk:
        await render(callback, "📜 <b>Giao dịch</b>\nChưa có giao dịch nào.", with_nav([], db_user.language, back="menu:account"))
        return
    lines = ["📜 <b>GIAO DỊCH GẦN ĐÂY</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for item in chunk:
        lines.append(
            f"• {item.created_at:%d/%m %H:%M} · <b>{signed(item.amount, item.currency)}</b> · {esc(item.note) or item.kind}"
        )
    rows_kb = []
    if pages > 1:
        rows_kb.append(
            [
                InlineKeyboardButton(text="◀️", callback_data=f"prof:tx:{page - 1}"),
                InlineKeyboardButton(text=f"{page + 1}/{pages}", callback_data="noop"),
                InlineKeyboardButton(text="▶️", callback_data=f"prof:tx:{page + 1}"),
            ]
        )
    await render(callback, "\n".join(lines), with_nav(rows_kb, db_user.language, back="menu:account"))


@router.callback_query(F.data == "prof:orders")
async def show_orders(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    orders = await shop_service.orders_of(db_user.id, limit=10)
    if not orders:
        await render(callback, "🧾 Bạn chưa mua acc nào.", with_nav([], db_user.language, back="menu:account"))
        return
    status_map = {
        "completed": "✅ Hoàn tất",
        "refunded": "💰 Đã hoàn tiền",
        "warranty": "🛡 Bảo hành",
    }
    lines = ["🧾 <b>ĐƠN HÀNG CỦA BẠN</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for order in orders:
        lines.append(
            f"• Đơn #{order.id} · <b>{order.account_code}</b> · {fmt_vnd(order.price)} · "
            f"{status_map.get(order.status, order.status)}"
        )
        if order.warranty_until:
            lines.append(f"  🛡 Bảo hành đến {order.warranty_until:%d/%m/%Y}")
    rows = [[InlineKeyboardButton(text="📄 Xem acc đã mua", callback_data=f"shop:creds:{order.account_code}")] for order in orders[:5]]
    await render(callback, "\n".join(lines), with_nav(rows, db_user.language, back="menu:account"))


@router.callback_query(F.data == "prof:games")
async def show_games(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    history = await casino_service.game_history(db_user.id, limit=10)
    if not history:
        await render(callback, "🎮 Bạn chưa chơi ván nào.", with_nav([], db_user.language, back="menu:account"))
        return
    lines = ["🎮 <b>LỊCH SỬ CASINO</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for row in history:
        meta = casino_service.GAMES.get(row.game, {"name": row.game})
        icon = "🎉" if row.payout > row.bet else "➖" if row.payout == row.bet else "❌"
        net = row.payout - row.bet
        lines.append(f"{icon} {meta['name']} · cược {fmt_coin(row.bet)} · <b>{signed(net, 'coin')}</b> · {row.created_at:%d/%m %H:%M}")
    await render(callback, "\n".join(lines), with_nav([], db_user.language, back="menu:account"))


@router.callback_query(F.data == "prof:vip")
async def show_vip(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    settings = await all_settings()
    discounts = settings.get("vip_discount") or {}
    lines = [
        "👑 <b>CẤP VIP</b>",
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰",
        f"• Cấp hiện tại: <b>{db_user.vip_level}</b>",
        f"• Tổng nạp: <b>{fmt_vnd(db_user.total_deposited)}</b>",
        "",
        "Mốc thăng cấp:",
        "• VIP 1: 200.000đ",
        "• VIP 2: 1.000.000đ",
        "• VIP 3: 3.000.000đ",
        "• VIP 4: 10.000.000đ",
        "• VIP 5: 30.000.000đ",
        "",
        "Ưu đãi giảm giá mua acc:",
    ]
    for level in range(6):
        lines.append(f"• VIP {level}: giảm <b>{discounts.get(str(level), 0)}%</b>")
    lines.append("\n🎁 Điểm danh VIP cao nhận nhiều xu hơn.")
    await render(callback, "\n".join(lines), with_nav([], db_user.language, back="menu:account"))


@router.callback_query(F.data == "prof:settings")
async def show_settings(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await render(
        callback,
        "⚙️ <b>CÀI ĐẶT</b>\nChọn thông tin bạn muốn thay đổi:",
        _settings_kb(db_user),
    )


@router.callback_query(F.data == "prof:lang")
async def toggle_language(callback: CallbackQuery, db_user) -> None:
    new_language = "en" if db_user.language == "vi" else "vi"
    await wallet.update_user(db_user.id, language=new_language)
    db_user.language = new_language
    await answer(callback, "Đã đổi ngôn ngữ" if new_language == "vi" else "Language updated")
    await render(callback, "⚙️ <b>CÀI ĐẶT</b>\nChọn thông tin bạn muốn thay đổi:", _settings_kb(db_user))


@router.callback_query(F.data == "prof:hide")
async def toggle_hide(callback: CallbackQuery, db_user) -> None:
    await wallet.update_user(db_user.id, hide_name=not db_user.hide_name)
    db_user.hide_name = not db_user.hide_name
    await answer(callback, "Đã cập nhật")
    await render(callback, "⚙️ <b>CÀI ĐẶT</b>\nChọn thông tin bạn muốn thay đổi:", _settings_kb(db_user))


@router.callback_query(F.data == "prof:notify")
async def toggle_notify(callback: CallbackQuery, db_user) -> None:
    await wallet.update_user(db_user.id, notifications=not db_user.notifications)
    db_user.notifications = not db_user.notifications
    await answer(callback, "Đã cập nhật")
    await render(callback, "⚙️ <b>CÀI ĐẶT</b>\nChọn thông tin bạn muốn thay đổi:", _settings_kb(db_user))
