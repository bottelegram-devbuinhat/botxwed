"""AI assistant: natural-language support for the shop, wallet, orders and casino."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message

from keyboards.casino import result_screen
from keyboards.common import back_only, with_nav
from services import ai_service, casino_service
from services.settings_service import all_settings
from utils import cards
from utils.logger import get_logger
from utils.permissions import is_admin
from utils.ratelimit import RateLimiter

from handlers.states import AIForm
from handlers.ui import answer, esc, insufficient_coins, render

router = Router(name="ai")
log = get_logger(__name__)

HISTORY: dict[int, list[dict]] = {}
_limiter = RateLimiter(2.0)
MAX_TURNS = 12

QUICK_ASKS = [
    ("💰 Acc giá rẻ", "Shop đang có acc nào giá rẻ nhất? Cho tôi xem 5 acc kèm giá và rank."),
    ("📦 Tồn kho", "Kho acc hiện có bao nhiêu acc đang bán, giá thấp nhất và cao nhất là bao nhiêu?"),
    ("🧾 Đơn của tôi", "Cho tôi xem các đơn mua acc gần đây của tôi kèm hạn bảo hành."),
    ("🎰 Cách chơi", "Hướng dẫn tôi cách đặt cược Tài Xỉu và mức cược tối thiểu, tối đa."),
]


def _kb(language: str = "vi"):
    rows = [
        [InlineKeyboardButton(text="💬 Hỏi tiếp", callback_data="ai:chat")],
        [InlineKeyboardButton(text="🧹 Xoá hội thoại", callback_data="ai:clear")],
    ]
    return with_nav(rows, language, back="menu:ai")


def _intro_text(db_user) -> str:
    return (
        f"{cards.title('robot', 'TRỢ LÝ AI')}"
        f"  [[sparkle]] Hỏi đáp tự nhiên: acc, giá, số lượng, đơn hàng, ví, casino.\n"
        f"  [[coin]] Đặt cược hộ bằng xu ảo · kiểm tra kết quả.\n"
        f"  [[shield]] Yêu cầu hoàn tiền / bảo hành, chuyển thẳng admin.\n"
        f"{cards.LINE}"
        f"  [[user]] {esc(db_user.full_name or 'bạn')} · VIP <b>{db_user.vip_level}</b>\n\n"
        f"{cards.note('Bấm 💬 Bắt đầu trò chuyện rồi nhắn câu hỏi, ví dụ: “còn acc Kim Cương nào dưới 500k?”')}"
    )


def _quick_kb(language: str = "vi"):
    rows = [[InlineKeyboardButton(text="💬 Bắt đầu trò chuyện", callback_data="ai:chat")]]
    rows += [
        [
            InlineKeyboardButton(text=QUICK_ASKS[i][0], callback_data=f"ai:ask:{i}"),
            InlineKeyboardButton(text=QUICK_ASKS[i + 1][0], callback_data=f"ai:ask:{i + 1}"),
        ]
        for i in range(0, len(QUICK_ASKS), 2)
    ]
    return with_nav(rows, language, back="menu:home")


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_support") or not settings.get("ai_enabled"):
        await render(event, "🚧 Trợ lý AI đang tạm đóng.", back_only("menu:home", db_user.language))
        return
    if not ai_service.configured():
        await render(
            event,
            f"{cards.title('robot', 'TRỢ LÝ AI')}"
            "Trợ lý chưa được cấu hình. Admin cần thêm <code>AI_API_KEY</code> vào file <code>.env</code> "
            "(và có thể đổi <code>AI_MODEL</code>, <code>AI_BASE_URL</code>) rồi khởi động lại bot.\n\n"
            f"{cards.note('Trong lúc chờ, bạn vẫn dùng được 🆘 Hỗ trợ để gửi ticket cho admin.')}",
            with_nav([[InlineKeyboardButton(text="🆘 Hỗ trợ", callback_data="menu:support")]], db_user.language),
        )
        return
    await render(event, _intro_text(db_user), _quick_kb(db_user.language))


async def _run(event: Message | CallbackQuery, db_user, question: str, state: FSMContext | None = None) -> None:
    question = (question or "").strip()
    if len(question) < 2:
        await render(event, "❌ Câu hỏi quá ngắn, nhắn lại nhé.", _kb(db_user.language))
        return
    if not _limiter.allow(f"ai:{db_user.id}"):
        await render(event, "⏳ Chậm thôi nào, mình đang trả lời câu trước…", _kb(db_user.language))
        return
    if state is not None:
        await state.set_state(AIForm.text)

    chat_id = event.from_user.id
    bot = event.bot
    try:
        await bot.send_chat_action(chat_id, "typing")
    except Exception:
        pass
    if isinstance(event, Message):
        placeholder = await event.answer("🤖 <i>Đang xử lý…</i>", parse_mode="HTML")

    history = HISTORY.setdefault(int(db_user.id), [])
    answer_text = await ai_service.reply(
        user_id=db_user.id,
        message=question,
        history=history,
        is_admin=await is_admin(db_user.id),
        name=db_user.full_name or db_user.username or "",
        bot=bot,
    )

    if not answer_text:
        answer_text = await ai_service._smart_fallback(
            db_user.id, question, {"user_id": db_user.id, "name": db_user.full_name or "", "is_admin": await is_admin(db_user.id)}
        )

    history.append({"role": "user", "content": question[:2000]})
    if answer_text:
        history.append({"role": "assistant", "content": answer_text[:2000]})
        del history[:-MAX_TURNS]
        body = ai_service.to_html(answer_text)
        text = f"{cards.title('robot', 'TRỢ LÝ AI')}{body}"
    else:
        text = (
            f"{cards.title('robot', 'TRỢ LÝ AI')}"
            "⚠️ Trợ lý đang bận hoặc chưa phản hồi được. Thử lại sau ít giây, "
            "hoặc mở 🆘 Hỗ trợ để admin xử lý trực tiếp."
        )

    if isinstance(event, Message):
        try:
            await placeholder.edit_text(text, reply_markup=_kb(db_user.language), parse_mode="HTML")
            return
        except Exception:
            pass
    await render(event, text, _kb(db_user.language))


@router.callback_query(F.data == "ai:chat")
async def on_chat(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AIForm.text)
    await render(
        callback,
        f"{cards.title('robot', 'TRỢ LÝ AI')}"
        "Nhắn câu hỏi của bạn, ví dụ:\n"
        "• “Còn acc nào dưới 500k không?”\n"
        "• “Đơn gần nhất của tôi bảo hành đến khi nào?”\n"
        "• “Cược 1.000 xu vào Tài Xỉu cửa Tài”\n\n"
        f"{cards.note('Gõ /menu để thoát khỏi chế độ trò chuyện.')}",
        back_only("menu:ai", db_user.language),
    )


@router.callback_query(F.data.startswith("ai:ask:"))
async def on_quick_ask(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    try:
        index = int(callback.data.split(":")[2])
        question = QUICK_ASKS[index][1]
    except (IndexError, ValueError):
        question = QUICK_ASKS[0][1]
    await _run(callback, db_user, question, state)


@router.callback_query(F.data.startswith("ai:betok:"))
async def on_ai_bet_confirm(callback: CallbackQuery, db_user) -> None:
    """Player pressed the confirmation button for a bet proposed by the AI."""
    token = callback.data.split(":", 2)[2]
    staged = ai_service.take_staged_bet(db_user.id, token)
    if staged is None:
        await answer(callback, "Lệnh cược đã hết hạn, hãy yêu cầu lại.", alert=True)
        return
    await answer(callback)
    result = await casino_service.place_bet(
        db_user.id, staged["game"], int(staged["bet"]), staged.get("choice")
    )
    if not result.get("ok"):
        if result.get("code") == "insufficient_coins":
            text = insufficient_coins(int(staged["bet"]), int(result.get("coins") or 0))
        else:
            text = f"❌ {esc(result.get('error', 'Không đặt cược được.'))}"
        await render(
            callback,
            text,
            with_nav(
                [[InlineKeyboardButton(text="🎁 Nhận thêm xu", callback_data="menu:rewards")]],
                db_user.language,
                back="menu:casino",
            ),
        )
        return
    await render(
        callback,
        result["text"],
        result_screen(staged["game"], int(staged["bet"]), db_user.language),
    )


@router.callback_query(F.data.startswith("ai:betno:"))
async def on_ai_bet_cancel(callback: CallbackQuery, db_user) -> None:
    ai_service.take_staged_bet(db_user.id, callback.data.split(":", 2)[2])
    await answer(callback, "Đã huỷ")
    await render(
        callback,
        "❌ Đã huỷ lệnh cược. Không có xu nào bị trừ.",
        back_only("menu:casino", db_user.language),
    )


@router.callback_query(F.data == "ai:clear")
async def on_clear(callback: CallbackQuery, db_user) -> None:
    HISTORY.pop(int(db_user.id), None)
    await answer(callback, "Đã xoá hội thoại")
    await open_menu(callback, db_user)


@router.message(AIForm.text, F.text)
async def on_question(message: Message, state: FSMContext, db_user) -> None:
    await _run(message, db_user, message.text or "", state)


@router.message(AIForm.text)
async def on_unsupported(message: Message, db_user) -> None:
    await message.answer(
        "🤖 Mình chỉ đọc được tin nhắn văn bản. Gõ câu hỏi hoặc /menu để thoát.",
        reply_markup=back_only("menu:ai", db_user.language),
    )


@router.message(Command("ai"))
async def cmd_ai(message: Message, state: FSMContext, db_user) -> None:
    await state.set_state(AIForm.text)
    await open_menu(message, db_user)
