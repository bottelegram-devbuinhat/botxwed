"""Rewards: check-in, missions, lucky wheel, giftcodes and referrals."""

from __future__ import annotations

from datetime import datetime, timedelta

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from keyboards.common import back_only, with_nav
from services import casino_service, rewards_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils import cards
from utils.links import referral_link, share_link
from utils.money import fmt_coin, fmt_vnd, parse_amount

from handlers.states import GiftcodeForm
from handlers.ui import answer, esc, render

router = Router(name="rewards")


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    settings = await all_settings()
    if not settings.get("feature_rewards"):
        await render(event, "🚧 Khu phần thưởng đang tạm đóng.")
        return
    missions = await rewards_service.mission_progress(db_user.id)
    ready = sum(1 for m in missions if m["progress"] >= m["target"])
    wheel_ready = not db_user.last_wheel or datetime.utcnow() - db_user.last_wheel >= timedelta(hours=24)
    # checkin() uses the local calendar day, so the screen must use it too.
    checked = db_user.last_checkin is not None and db_user.last_checkin == datetime.now().date()
    text = (
        f"{cards.title('gift', 'PHẦN THƯỞNG & ĐIỂM DANH')}"
        f"  [[coin]] Xu hiện có: <b>{fmt_coin(db_user.coins)}</b>\n"
        f"  [[fire]] Chuỗi điểm danh: <b>{db_user.checkin_streak}</b> ngày\n"
        f"  [[check]] Hôm nay: {'đã điểm danh' if checked else 'chưa điểm danh'}\n"
        f"  [[wheel]] Vòng quay: {'sẵn sàng' if wheel_ready else 'đã dùng hôm nay'}\n"
        f"  [[target]] Nhiệm vụ nhận được: <b>{ready}/{len(missions)}</b>\n\n"
        f"{cards.note('Chọn phần thưởng bên dưới 👇')}"
    )
    rows = [
        [
            InlineKeyboardButton(text="📅 Điểm danh", callback_data="rw:checkin"),
            InlineKeyboardButton(text="🎡 Vòng quay", callback_data="rw:wheel"),
        ],
        [
            InlineKeyboardButton(text="🎯 Nhiệm vụ", callback_data="rw:missions"),
            InlineKeyboardButton(text="🎟 Nhập giftcode", callback_data="rw:gift"),
        ],
        [
            InlineKeyboardButton(text="👥 Mời bạn", callback_data="rw:invite"),
            InlineKeyboardButton(text="🏆 Bảng xếp hạng", callback_data="menu:lb"),
        ],
    ]
    await render(event, text, with_nav(rows, db_user.language, back="menu:home"))


@router.callback_query(F.data == "rw:checkin")
async def on_checkin(callback: CallbackQuery, db_user) -> None:
    result = await rewards_service.checkin(db_user.id)
    await answer(callback)
    if not result.get("ok"):
        await answer(callback, result.get("error", "Không điểm danh được."), alert=True)
        await render(callback, f"📅 {result.get('error')}", back_only("menu:rewards", db_user.language))
        return
    updated = await wallet.get_user(db_user.id)
    text = (
        "📅 <b>ĐIỂM DANH THÀNH CÔNG</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Nhận: <b>{fmt_coin(result['reward'])}</b>\n"
        f"• Chuỗi: <b>{result['streak']}</b> ngày\n"
        f"• Ví xu: <b>{fmt_coin(updated.coins if updated else db_user.coins)}</b>\n\n"
        "Quay lại mỗi ngày để nhận thưởng lớn hơn nhé!"
    )
    await render(callback, text, back_only("menu:rewards", db_user.language))


@router.callback_query(F.data == "rw:missions")
async def on_missions(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    missions = await rewards_service.mission_progress(db_user.id)
    lines = ["🎯 <b>NHIỆM VỤ HÔM NAY</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    rows = []
    for mission in missions:
        done = mission["progress"] >= mission["target"]
        status = "✅" if done else "⏳"
        lines.append(
            f"{status} {mission['title']}\n"
            f"   {mission['progress']}/{mission['target']} · thưởng {fmt_coin(mission['reward'])}"
        )
        if done:
            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"🎁 Nhận {fmt_coin(mission['reward'])}", callback_data=f"rw:claim:{mission['key']}"
                    )
                ]
            )
    rows.append([InlineKeyboardButton(text="🎁 Nhận tất cả", callback_data="rw:claimall")])
    lines.append("\n<i>Thưởng nhiệm vụ được cộng vào xu casino.</i>")
    await render(callback, "\n".join(lines), with_nav(rows, db_user.language, back="menu:rewards"))


@router.callback_query(F.data.startswith("rw:claim:"))
async def on_claim(callback: CallbackQuery, db_user) -> None:
    kind = callback.data.split(":")[2]
    result = await rewards_service.claim_mission(db_user.id, kind)
    await answer(callback, result.get("error") if not result.get("ok") else "🎉 Đã nhận thưởng", alert=not result.get("ok"))
    await on_missions(callback, db_user)


@router.callback_query(F.data == "rw:claimall")
async def on_claim_all(callback: CallbackQuery, db_user) -> None:
    result = await rewards_service.claim_all_missions(db_user.id)
    if not result.get("ok"):
        await answer(callback, result.get("error", "Không có thưởng."), alert=True)
    else:
        await answer(callback, f"🎉 Nhận {fmt_coin(result['total'])} từ {result['claimed']} nhiệm vụ")
    await on_missions(callback, db_user)


@router.callback_query(F.data == "rw:wheel")
async def on_wheel(callback: CallbackQuery, db_user) -> None:
    result = await casino_service.spin_wheel(db_user.id)
    await answer(callback)
    if not result.get("ok"):
        await answer(callback, result.get("error", "Chưa quay được."), alert=True)
        await render(callback, f"🎡 {result.get('error')}", back_only("menu:rewards", db_user.language))
        return
    updated = await wallet.get_user(db_user.id)
    text = (
        "🎡 <b>VÒNG QUAY MAY MẮN</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"🎉 Bạn nhận được: <b>{fmt_coin(result['prize'])}</b>\n"
        f"🪙 Ví xu: <b>{fmt_coin(updated.coins if updated else 0)}</b>\n\n"
        "Quay lại sau 24 giờ để tiếp tục nhé!"
    )
    await render(callback, text, back_only("menu:rewards", db_user.language))


@router.callback_query(F.data == "rw:gift")
async def on_gift(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(GiftcodeForm.code)
    await render(
        callback,
        "🎟 Nhập <b>mã giftcode</b> của bạn:\nVí dụ: <code>WELCOME2026</code>",
        back_only("menu:rewards", db_user.language),
    )


@router.message(GiftcodeForm.code, F.text)
async def on_gift_text(message: Message, state: FSMContext, db_user) -> None:
    code = (message.text or "").strip().upper()
    await state.clear()
    result = await rewards_service.redeem_giftcode(db_user.id, code)
    if not result.get("ok"):
        await message.answer(f"❌ {esc(result.get('error'))}", reply_markup=back_only("menu:rewards"))
        return
    updated = await wallet.get_user(db_user.id)
    await message.answer(
        f"🎉 <b>NHẬP MÃ THÀNH CÔNG</b>\n• Mã: <code>{esc(code)}</code>\n"
        f"• Nhận: <b>{result['text']}</b>\n"
        f"• Ví xu: {fmt_coin(updated.coins if updated else 0)} · Ví shop: "
        f"{fmt_vnd(updated.shop_balance if updated else 0)}",
        parse_mode="HTML",
        reply_markup=back_only("menu:rewards"),
    )


@router.callback_query(F.data == "rw:invite")
async def on_invite(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    settings = await all_settings()
    bonus = int(settings.get("referral_bonus_coins", 0))
    link = referral_link(db_user.id)
    count = await rewards_service.referral_count(db_user.id)
    earnings = await rewards_service.referral_earnings(db_user.id)
    text = (
        f"{cards.title('user', 'MỜI BẠN')}"
        f"  [[user]] Người đã mời: <b>{count}</b>\n"
        f"  [[coin]] Thưởng giới thiệu: <b>{fmt_coin(earnings)}</b>\n"
        f"  [[gift]] Mỗi người bạn mời: <b>{fmt_coin(bonus)}</b>\n\n"
        f"  [[pin]] Link của bạn:\n<code>{esc(link)}</code>\n\n"
        f"{cards.quote('Chia sẻ link để bạn bè tham gia, xu thưởng cộng ngay khi họ bấm /start.')}"
    )
    rows = [
        [InlineKeyboardButton(text="📤 Chia sẻ link", url=share_link(db_user.id))],
        [InlineKeyboardButton(text="📋 Danh sách bạn bè", callback_data="rw:friends")],
    ]
    await render(callback, text, with_nav(rows, db_user.language, back="menu:rewards"))


@router.callback_query(F.data == "rw:friends")
async def on_friends(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    from sqlalchemy import select

    from database.models import User
    from database.session import session_scope

    async with session_scope() as session:
        rows = (
            await session.execute(
                select(User).where(User.referrer_id == db_user.id).order_by(User.created_at.desc()).limit(15)
            )
        ).scalars().all()
    if not rows:
        await render(
            callback,
            f"{cards.title('user', 'BẠN BÈ ĐÃ MỜI')}Chưa có ai. Hãy chia sẻ link mời của bạn!",
            back_only("rw:invite", db_user.language),
        )
        return
    lines = [cards.title("user", f"BẠN BÈ ĐÃ MỜI ({len(rows)})")]
    for user in rows:
        lines.append(f"  [[user]] {esc(user.full_name)} · {user.created_at:%d/%m/%Y}")
    await render(callback, "\n".join(lines), back_only("rw:invite", db_user.language))
