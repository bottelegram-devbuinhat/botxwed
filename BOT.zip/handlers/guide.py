"""Guide pages with prev/next navigation."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from locales import t
from utils.permissions import is_admin

from handlers.ui import answer, esc, render

router = Router(name="guide")

PAGES = [
    (
        "💳 Nạp tiền",
        "1. Mở 💳 Nạp tiền → chọn phương thức.\n"
        "2. Chọn mệnh giá hoặc nhập số tiền.\n"
        "3. Chuyển khoản đúng <b>nội dung</b> hiển thị (ví dụ NAP1234TAB12).\n"
        "4. Gửi ảnh biên lai nếu bot yêu cầu. Admin duyệt trong 5-30 phút.\n\n"
        "⚠️ Chuyển sai nội dung có thể chậm được cộng tiền.",
    ),
    (
        "🛒 Mua acc",
        "1. Mở 🛒 Mua Acc → chọn kiểu lọc (giá, rank, mới nhất).\n"
        "2. Bấm vào acc để xem chi tiết, ảnh, bảo hành.\n"
        "3. Bấm 🛒 Mua ngay → kiểm tra giá sau giảm VIP → xác nhận.\n"
        "4. Bot gửi tài khoản + hướng dẫn đổi mật khẩu ngay trong chat.\n\n"
        "🛡 Trong thời gian bảo hành, nếu acc lỗi hãy mở đơn và bấm ⚠️ Báo lỗi.",
    ),
    (
        "💰 Ký gửi acc",
        "1. Mở 💰 Bán / Ký gửi → ➕ Đăng acc mới.\n"
        "2. Nhập rank, số tướng, số skin, giá mong muốn, tài khoản/mật khẩu.\n"
        "3. Acc chờ admin duyệt rồi mới hiện trong shop.\n"
        "4. Khi bán được, tiền vào ví shop sau khi trừ hoa hồng.\n\n"
        "🔐 Tài khoản/mật khẩu được mã hoá trước khi lưu.",
    ),
    (
        "🎰 Casino xu ảo",
        "• Xu nhận từ điểm danh, nhiệm vụ, giftcode, vòng quay, sự kiện.\n"
        "• <b>Không</b> mua xu bằng tiền thật và <b>không</b> đổi xu ra tiền/acc.\n"
        "• Mỗi game có luật riêng, bấm 📖 Luật chơi để xem.\n"
        "• Kết quả dùng seed công khai, có thể kiểm tra sau mỗi ván.\n\n"
        "🔞 Chỉ dành cho người từ 18 tuổi. Chơi có trách nhiệm.",
    ),
    (
        "🆘 Hỗ trợ",
        "• Tạo ticket mô tả vấn đề, đính kèm ảnh nếu cần.\n"
        "• Theo dõi trạng thái trong 📂 Ticket của tôi.\n"
        "• Admin trả lời trực tiếp trong ticket.\n"
        "• Sau khi đóng ticket bạn có thể đánh giá 1-5 sao.",
    ),
]


def _guide_kb(page: int, language: str = "vi") -> InlineKeyboardMarkup:
    rows = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"guide:page:{page - 1}"))
    nav.append(InlineKeyboardButton(text=f"{page + 1}/{len(PAGES)}", callback_data="noop"))
    if page < len(PAGES) - 1:
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"guide:page:{page + 1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton(text="🏠 Menu chính", callback_data="menu:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _page_text(page: int) -> str:
    title, body = PAGES[page]
    return f"📖 <b>{esc(title)}</b>\n▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n{body}"


async def open_menu(event: Message | CallbackQuery, db_user) -> None:
    await render(event, _page_text(0), _guide_kb(0, db_user.language))


@router.callback_query(F.data == "menu:guide")
async def on_guide_menu(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await open_menu(callback, db_user)


@router.callback_query(F.data.startswith("guide:page:"))
async def on_page(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    try:
        page = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        page = 0
    page = max(0, min(page, len(PAGES) - 1))
    await render(callback, _page_text(page), _guide_kb(page, db_user.language))
