"""Global error handler: log every unhandled exception and answer the user.

Without it aiogram only writes to the log, so a crashing handler looks like a
dead bot: the player sends a message and never gets a reply.
"""

from __future__ import annotations

import time

from aiogram.types import CallbackQuery, ErrorEvent, Message

from utils.logger import get_logger

log = get_logger(__name__)

_WINDOW = 60.0
_LAST_NOTICE: dict[int, float] = {}

TEXT = "⚠️ Có lỗi xảy ra khi xử lý yêu cầu này. Bấm /start để thử lại, hoặc 🆘 Hỗ trợ để báo admin."


def _should_notice(user_id: int) -> bool:
    """Do not spam a user whose every click fails in the same minute."""
    now = time.monotonic()
    if now - _LAST_NOTICE.get(user_id, 0.0) < _WINDOW:
        return False
    _LAST_NOTICE[user_id] = now
    if len(_LAST_NOTICE) > 5000:
        _LAST_NOTICE.clear()
        _LAST_NOTICE[user_id] = now
    return True


async def on_error(event: ErrorEvent) -> bool:
    exception = event.exception
    update = event.update
    log.error(
        "Unhandled %s while processing update %s",
        type(exception).__name__,
        getattr(update, "update_id", "?"),
        exc_info=exception,
    )

    callback: CallbackQuery | None = getattr(update, "callback_query", None)
    message: Message | None = getattr(update, "message", None) or (
        callback.message if callback is not None else None
    )
    user = getattr(update, "event_from_user", None) or getattr(message, "from_user", None)

    if callback is not None:
        try:
            await callback.answer("⚠️ Có lỗi xảy ra, thử lại nhé.", show_alert=True)
        except Exception:  # noqa: BLE001 - the callback may already be answered
            pass

    if user is None or getattr(user, "is_bot", False) or not _should_notice(user.id):
        return True

    try:
        if message is not None:
            await message.answer(TEXT)
        else:
            await event.bot.send_message(user.id, TEXT)
    except Exception as exc:  # noqa: BLE001 - never fail inside the error handler
        log.warning("Cannot notify user about the error: %s", exc)
    return True
