"""Direct-order + catalog + cart handlers (ported from telegram-sales-bot
handlers: productHandler, quantityHandler, cartHandler, discountHandler,
orderHandler, deliveryHandler).

Flow (repo): browse categories -> product -> choose quantity -> Buy Now /
Add to Cart -> discount prompt -> VietQR payment (exact amount + order code
as the transfer content) -> SePay webhook/poller confirms -> auto-delivery.

The old bot's wallet flow (shop.py) is untouched; this router adds the
direct-buy path next to it. Register it in main.py next to the shop router.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from handlers.ui import answer, esc, render
from keyboards.catalog import (
    cart_kb,
    category_kb,
    discount_prompt_kb,
    order_kb,
    product_detail_kb,
    product_list_kb,
)
from services import cart_service, catalog_service, discount_service, order_service
from services.settings_service import all_settings
from utils.money import fmt_vnd

router = Router(name="shop_merge")

PER_PAGE = 6


class DirectOrderForm(StatesGroup):
    waiting_discount = State()


async def _ensure_shop_open(event: Message | CallbackQuery) -> bool:
    settings = await all_settings()
    if not settings.get("feature_shop"):
        await render(event, "🚧 Shop đang tạm đóng, vui lòng quay lại sau.")
        return False
    return True


# ---------------------------------------------------------------- catalog
@router.message(F.text == "/catalog")
async def cmd_catalog(message: Message) -> None:
    if not await _ensure_shop_open(message):
        return
    categories = await catalog_service.list_categories(with_stock=True)
    if not categories:
        await message.answer("📦 Chưa có danh mục sản phẩm nào.")
        return
    await message.answer(
        "🛍 <b>DANH MỤC SẢN PHẨM</b>\n\nChọn danh mục để xem sản phẩm.",
        reply_markup=category_kb(categories),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "catalog:list")
async def cb_catalog_list(callback: CallbackQuery) -> None:
    if not await _ensure_shop_open(callback):
        return
    categories = await catalog_service.list_categories(with_stock=True)
    if not categories:
        await render(callback, "📦 Chưa có danh mục sản phẩm nào.")
        return
    await render(
        callback,
        "🛍 <b>DANH MỤC SẢN PHẨM</b>\n\nChọn danh mục để xem sản phẩm.",
        category_kb(categories),
    )


@router.callback_query(F.data.startswith("catalog:cat:"))
async def cb_category(callback: CallbackQuery) -> None:
    if not await _ensure_shop_open(callback):
        return
    _, _, raw_id, raw_page = callback.data.split(":")
    category_id = int(raw_id)
    page = max(0, int(raw_page))
    category = await catalog_service.get_category(category_id)
    if category is None:
        await answer(callback, "Danh mục không tồn tại.", alert=True)
        return
    products, pages = await catalog_service.list_products(
        category_id=category_id, page=page, per_page=PER_PAGE, only_active=True
    )
    text = (
        f"{category.get('emoji') or '📦'} <b>{esc(category['name'])}</b>\n"
        f"Trang {page + 1}/{max(1, pages)} · {len(products)} sản phẩm\n\n"
        "Chọn sản phẩm để xem chi tiết."
    )
    await render(callback, text, product_list_kb(products, category_id, page, pages))


@router.callback_query(F.data.startswith("catalog:prod:"))
async def cb_product(callback: CallbackQuery) -> None:
    await _show_product(callback, int(callback.data.split(":")[2]), qty=1)


@router.callback_query(F.data.startswith("catalog:qty:"))
async def cb_product_qty(callback: CallbackQuery) -> None:
    _, _, raw_id, raw_qty = callback.data.split(":")
    await _show_product(callback, int(raw_id), qty=max(1, int(raw_qty)))


async def _show_product(callback: CallbackQuery, product_id: int, qty: int) -> None:
    if not await _ensure_shop_open(callback):
        return
    product = await catalog_service.get_product(product_id)
    if product is None or not product.get("is_active"):
        await answer(callback, "Sản phẩm không còn bán.", alert=True)
        return
    stock = int(product.get("stock", 0))
    qty = max(1, min(stock, qty)) if stock > 0 else 1
    lines = [
        f"📦 <b>{esc(product['name'])}</b>",
        f"💲 Giá: <b>{fmt_vnd(product['price'])}</b>",
        f"📊 Còn: <b>{stock}</b>",
    ]
    if product.get("description"):
        lines.append(f"\n{esc(product['description'])}")
    if product.get("note"):
        lines.append(f"\n📝 {esc(product['note'])}")
    if product.get("delivery_hours"):
        lines.append(f"⏰ Giao trong: <b>{product['delivery_hours']} giờ</b>")
    if product.get("warranty_days"):
        lines.append(f"🛡 Bảo hành: <b>{product['warranty_days']} ngày</b>")
    await render(callback, "\n".join(lines), product_detail_kb(product, qty))


# ---------------------------------------------------------------- cart
@router.callback_query(F.data.startswith("cart:add:"))
async def cb_cart_add(callback: CallbackQuery) -> None:
    _, _, raw_id, raw_qty = callback.data.split(":")
    ok = await cart_service.add_to_cart(callback.from_user.id, int(raw_id), int(raw_qty))
    await answer(callback, "✅ Đã thêm vào giỏ hàng." if ok else "❌ Sản phẩm không còn bán.", alert=not ok)


@router.callback_query(F.data == "cart:view")
async def cb_cart_view(callback: CallbackQuery) -> None:
    lines = await cart_service.get_cart(callback.from_user.id)
    if not lines:
        await render(callback, "🛒 Giỏ hàng của bạn đang trống.", cart_kb([]))
        return
    total = sum(line["subtotal"] for line in lines)
    text_lines = ["🛒 <b>GIỎ HÀNG</b>", ""]
    for line in lines:
        text_lines.append(
            f"• {esc(line['name'])} × {line['quantity']} — <b>{fmt_vnd(line['subtotal'])}</b> (còn {line['stock']})"
        )
    text_lines.append(f"\n💰 <b>Tổng: {fmt_vnd(total)}</b>")
    await render(callback, "\n".join(text_lines), cart_kb(lines))


@router.callback_query(F.data.startswith("cart:del:"))
async def cb_cart_del(callback: CallbackQuery) -> None:
    await cart_service.remove_from_cart(callback.from_user.id, int(callback.data.split(":")[2]))
    await cb_cart_view(callback)


# ------------------------------------------------- discount prompt + order
async def _ask_discount(event: Message | CallbackQuery, state: FSMContext, items: list[dict]) -> None:
    await state.set_state(DirectOrderForm.waiting_discount)
    await state.update_data(items=items)
    await render(
        event,
        "🎟 <b>MÃ GIẢM GIÁ</b>\n\n"
        "Bạn có mã giảm giá không? Nhập mã vào khung chat, hoặc bấm <b>Không dùng mã</b> để tạo đơn ngay.",
        discount_prompt_kb(),
    )


@router.callback_query(F.data.startswith("order:buy:"))
async def cb_order_buy(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _ensure_shop_open(callback):
        return
    _, _, raw_id, raw_qty = callback.data.split(":")
    await _ask_discount(callback, state, [{"product_id": int(raw_id), "quantity": int(raw_qty)}])


@router.callback_query(F.data == "order:cart")
async def cb_order_cart(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _ensure_shop_open(callback):
        return
    lines = await cart_service.get_cart(callback.from_user.id)
    if not lines:
        await answer(callback, "Giỏ hàng đang trống.", alert=True)
        return
    items = [{"product_id": line["product_id"], "quantity": line["quantity"]} for line in lines]
    await _ask_discount(callback, state, items)


@router.callback_query(F.data.startswith("order:acc:"))
async def cb_order_account(callback: CallbackQuery, state: FSMContext) -> None:
    """Direct-buy a unique Liên Quân account (button added to the account
    detail keyboard in keyboards/shop.py — see MERGE_SETUP.md)."""
    if not await _ensure_shop_open(callback):
        return
    code = callback.data.split(":")[2]
    await _ask_discount(callback, state, [{"account_code": code}])


@router.callback_query(F.data == "discount:ask")
async def cb_discount_ask(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(DirectOrderForm.waiting_discount)
    await answer(callback, "Nhập mã giảm giá vào khung chat (hoặc /boqua).")


@router.callback_query(F.data == "discount:skip")
async def cb_discount_skip(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    items = data.get("items") or []
    await state.clear()
    await _create_order(callback, items, discount_code=None)


@router.message(DirectOrderForm.waiting_discount, F.text)
async def msg_discount_code(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    items = data.get("items") or []
    code = (message.text or "").strip().upper()
    if code in ("/BOQUA", "BOQUA", "KHONG"):
        await state.clear()
        await _create_order(message, items, discount_code=None)
        return
    # Validate against the first line's total (repo validates before creating).
    from services import shop_service as _shop

    subtotal = 0
    first = items[0] if items else {}
    if first.get("account_code"):
        account = await _shop.get_account_by_code(first["account_code"])
        subtotal = int(account.price) if account else 0
    elif first.get("product_id"):
        product = await catalog_service.get_product(first["product_id"])
        subtotal = int(product["price"]) * int(first.get("quantity", 1)) if product else 0
    check = await discount_service.validate_discount(
        code, message.from_user.id, subtotal,
        product_id=first.get("product_id"), quantity=first.get("quantity", 1),
    )
    if not check.get("valid"):
        await message.answer(f"❌ {check.get('reason', 'Mã không hợp lệ.')}\n\nNhập mã khác hoặc gửi /boqua để tiếp tục.")
        return
    await state.clear()
    await _create_order(message, items, discount_code=code)


async def _create_order(event: Message | CallbackQuery, items: list[dict], discount_code: str | None) -> None:
    user_id = event.from_user.id
    result = await order_service.create_direct_order(
        user_id, items, discount_code=discount_code, payment_method="vietqr", bot=event.bot
    )
    if not result.get("ok"):
        await render(event, f"❌ {result.get('error', 'Không tạo được đơn hàng.')}")
        return
    if result.get("free"):
        await render(
            event,
            f"🎉 <b>ĐƠN {esc(result['order_code'])} ĐÃ HOÀN TẤT!</b>\n\n"
            "Mã giảm giá đã bao toàn bộ số tiền. Sản phẩm đã được gửi vào chat này.",
        )
        return
    code = result["order_code"]
    total = int(result["total"])
    expires = result["expires_at"]
    caption = (
        f"💳 <b>THANH TOÁN ĐƠN HÀNG</b>\n\n"
        f"🆔 Mã đơn: <code>{esc(code)}</code>\n"
        f"💰 Số tiền: <b>{fmt_vnd(total)}</b>\n"
        f"🏦 Ngân hàng: <b>{esc(result['bank_code'])} — {esc(result['bank_account'])}</b>\n"
        f"👤 Chủ TK: <b>{esc(result['bank_holder'])}</b>\n"
        f"📝 Nội dung chuyển khoản: <code>{esc(code)}</code>\n"
        f"⏰ Hạn thanh toán: <b>{expires:%H:%M %d/%m}</b> (5 phút)\n\n"
        "⚠️ Chuyển đúng số tiền và đúng nội dung để hệ thống tự xác nhận.\n"
        "Sau khi chuyển, bấm <b>Đã chuyển khoản — kiểm tra</b>."
    )
    kb = order_kb(code)
    if isinstance(event, Message):
        try:
            await event.answer_photo(result["qr_url"], caption=caption, reply_markup=kb, parse_mode="HTML")
        except Exception:
            await event.answer(caption, reply_markup=kb, parse_mode="HTML")
    else:
        # Callback: send a fresh message (the QR photo cannot edit the old one).
        try:
            await event.message.answer_photo(result["qr_url"], caption=caption, reply_markup=kb, parse_mode="HTML")
        except Exception:
            await event.message.answer(caption, reply_markup=kb, parse_mode="HTML")
        await answer(event)


@router.callback_query(F.data.startswith("order:check:"))
async def cb_order_check(callback: CallbackQuery) -> None:
    code = callback.data.split(":")[2]
    order = await order_service.get_order_by_code(code)
    if order is None:
        await answer(callback, "Không tìm thấy đơn hàng.", alert=True)
        return
    if order.status == "pending":
        await answer(
            callback,
            "Chưa nhận được tiền. Nếu bạn đã chuyển, vui lòng chờ vài giây rồi bấm lại.",
            alert=True,
        )
        return
    if order.status in ("paid", "delivering"):
        # Webhook may have paid it but delivery failed — retry delivery.
        if await order_service.deliver_order(callback.bot, order):
            await answer(callback, "✅ Đã thanh toán — sản phẩm đã được gửi.", alert=True)
        else:
            await answer(callback, "✅ Đã thanh toán. Admin sẽ xử lý phần giao hàng.", alert=True)
        return
    if order.status == "delivered":
        await answer(callback, "✅ Đơn hàng đã giao thành công.", alert=True)
        return
    await answer(callback, f"Đơn hàng đã {order.status}.", alert=True)


@router.callback_query(F.data.startswith("order:cancel:"))
async def cb_order_cancel(callback: CallbackQuery) -> None:
    code = callback.data.split(":")[2]
    ok = await order_service.cancel_direct_order(code, callback.from_user.id)
    if ok:
        await render(callback, f"❌ Đơn hàng <code>{esc(code)}</code> đã được hủy.")
    else:
        await answer(callback, "Đơn hàng này không thể hủy.", alert=True)
