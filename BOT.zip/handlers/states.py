"""FSM states for multi-step forms."""

from aiogram.fsm.state import State, StatesGroup


class DepositForm(StatesGroup):
    amount = State()
    receipt = State()
    card_serial = State()
    card_code = State()
    card_amount = State()


class WithdrawForm(StatesGroup):
    bank = State()
    number = State()
    name = State()
    amount = State()
    confirm = State()


class SellForm(StatesGroup):
    rank = State()
    heroes = State()
    skins = State()
    price = State()
    login_type = State()
    username = State()
    password = State()
    description = State()
    photos = State()


class SellEditForm(StatesGroup):
    price = State()


class TicketForm(StatesGroup):
    type = State()
    subject = State()
    message = State()


class TicketReplyForm(StatesGroup):
    text = State()


class ReviewForm(StatesGroup):
    rating = State()
    text = State()


class SearchForm(StatesGroup):
    code = State()


class CasinoForm(StatesGroup):
    bet = State()
    blackjack = State()


class AdminValueForm(StatesGroup):
    find_user = State()
    adjust = State()
    add_account = State()
    import_accounts = State()
    ai_import = State()
    hit_price = State()
    hit_body = State()
    random_price = State()
    random_body = State()
    price = State()
    note = State()
    limits = State()
    ai_model = State()
    ai_prompt = State()
    ai_test = State()
    self_topup = State()


class AdminForm(StatesGroup):
    value = State()
    broadcast = State()
    giftcode = State()
    add_account = State()
    reply_ticket = State()
    message_user = State()
    confirm = State()


class AIForm(StatesGroup):
    text = State()


class GiftcodeForm(StatesGroup):
    code = State()
