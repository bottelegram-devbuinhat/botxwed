"""Start command, main menu and top-level navigation."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from keyboards.common import main_reply_keyboard
from keyboards.main_menu import main_menu
from locales import t
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils import cards
from utils.money import fmt_coin, fmt_vnd
from utils.permissions import is_admin

from handlers.ui import answer, esc, remember_reply_mode, render, sync_reply_keyboard

router = Router(name="start")

SECTIONS = [
    ("menu_buy", "buy"),
    ("menu_sell", "sell"),
    ("menu_casino", "casino"),
    ("menu_deposit", "deposit"),
    ("menu_account", "account"),
    ("menu_leaderboard", "lb"),
    ("menu_rewards", "rewards"),
    ("menu_support", "support"),
    ("menu_guide", "guide"),
    ("menu_ai", "ai"),
]


def _label_actions() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for key, action in SECTIONS:
        for language in ("vi", "en"):
            mapping[t(key, language)] = action
    return mapping


async def dispatch(event: Message | CallbackQuery, action: str, db_user) -> None:
    from handlers import ai, casino, guide, leaderboard, profile, rewards, sell, shop, support, wallet

    handlers = {
        "buy": shop.open_menu,
        "sell": sell.open_menu,
        "casino": casino.open_menu,
        "deposit": wallet.open_menu,
        "account": profile.open_menu,
        "lb": leaderboard.open_menu,
        "rewards": rewards.open_menu,
        "support": support.open_menu,
        "guide": guide.open_menu,
        "ai": ai.open_menu,
    }
    handler = handlers.get(action)
    if handler is None:
        await render(event, "⚠️ Chức năng không tồn tại.")
        return
    await handler(event, db_user)


def welcome_text(db_user) -> str:
    return (
        f"{cards.title('sparkle', 'XIN CHÀO ' + esc((db_user.full_name or 'bạn').upper()))}"
        f"  [[cart]] Shop acc Liên Quân uy tín\n"
        f"  [[slot]] Sảnh casino xu ảo giải trí\n"
        f"  [[gift]] Điểm danh · nhiệm vụ · giftcode mỗi ngày\n"
        f"{cards.LINE}\n"
        f"  [[money]] Số dư shop: <b>{fmt_vnd(db_user.shop_balance)}</b>\n"
        f"  [[coin]] Xu casino: <b>{fmt_coin(db_user.coins)}</b>\n"
        f"  [[crown]] VIP: <b>{db_user.vip_level}</b>\n\n"
        f"{cards.note('Chọn chức năng bên dưới hoặc dùng menu ở góc trái.')}"
    )


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, db_user) -> None:
    await state.clear()
    payload = ""
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) > 1:
        payload = parts[1].strip()

    if payload.isdigit() and int(payload) != db_user.id and db_user.referrer_id is None:
        referrer = await wallet.get_user(int(payload))
        if referrer is not None:
            await wallet.update_user(db_user.id, referrer_id=int(payload))
            settings = await all_settings()
            bonus = int(settings.get("referral_bonus_coins", 0))
            credited = False
            if bonus > 0:
                credited = await wallet.add_balance(
                    int(payload),
                    bonus,
                    "referral",
                    "coin",
                    f"Mời {db_user.full_name or db_user.id} tham gia bot",
                    ref=f"referral:{db_user.id}",
                )  # unique ref prevents double credit
            try:
                tail = f"\n[[coin]] +{fmt_coin(bonus)} thưởng giới thiệu" if credited else ""
                await message.bot.send_message(
                    int(payload),
                    f"{cards.title('party', 'CÓ NGƯỜI MỚI')}"
                    f"  [[user]] <b>{esc(db_user.full_name)}</b> vừa tham gia qua link của bạn.{tail}",
                    parse_mode="HTML",
                )
            except Exception:
                pass
            db_user = await wallet.get_user(db_user.id)

    admin = await is_admin(db_user.id)
    remember_reply_mode(db_user.id, admin)
    await render(message, welcome_text(db_user), main_reply_keyboard(db_user.language, admin))
    await message.answer(
        t("menu_title", db_user.language),
        reply_markup=main_menu(db_user.language, admin),
        parse_mode="HTML",
    )


@router.message(Command("menu"))
async def cmd_menu(message: Message, state: FSMContext, db_user) -> None:
    await state.clear()
    admin = await is_admin(db_user.id)
    remember_reply_mode(db_user.id, admin)
    await message.answer(
        t("menu_title", db_user.language),
        reply_markup=main_menu(db_user.language, admin),
        parse_mode="HTML",
    )


@router.message(Command("admin"))
async def cmd_admin(message: Message, db_user) -> None:
    from handlers.admin.panel import show_panel

    if not await is_admin(db_user.id):
        await message.answer(t("no_permission", db_user.language))
        return
    await show_panel(message, db_user)


@router.callback_query(F.data == "noop")
async def on_noop(callback: CallbackQuery) -> None:
    await answer(callback)


@router.callback_query(F.data == "menu:home")
async def on_home(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await state.clear()
    await answer(callback)
    admin = await is_admin(db_user.id)
    text = f"{welcome_text(db_user)}\n\n{t('menu_title', db_user.language)}"
    if admin:
        text += f"\n{cards.note('Bạn đang ở menu người dùng · bấm 🛠 Admin để mở bảng điều khiển.')}"
    # Switch the bottom reply keyboard (a separate message) so the menu itself
    # stays the last message on screen.
    await sync_reply_keyboard(callback, db_user.id, db_user.language, admin=False)
    await render(callback, text, main_menu(db_user.language, admin))


@router.callback_query(F.data.startswith("menu:"))
async def on_menu(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await state.clear()
    await callback.answer()
    action = callback.data.split(":", 1)[1]
    await dispatch(callback, action, db_user)


@router.message(StateFilter(None), F.text)
async def on_text(message: Message, state: FSMContext, db_user) -> None:
    text = (message.text or "").strip()
    action = _label_actions().get(text)
    if action:
        await dispatch(message, action, db_user)
        return
    if text == t("btn_admin", db_user.language):
        from handlers.admin.panel import show_panel

        if await is_admin(db_user.id):
            await show_panel(message, db_user)
        return
    settings = await all_settings()
    await message.answer(
        "🤔 Mình chưa hiểu tin nhắn này.\n"
        f"Dùng /menu để mở menu, hoặc /start để bắt đầu.\n\n"
        f"<i>{esc(settings.get('terms_text') or '')[:400]}</i>",
        parse_mode="HTML",
    )
