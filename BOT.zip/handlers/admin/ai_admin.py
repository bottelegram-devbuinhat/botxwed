"""Admin screen for the AI assistant: status, model, prompt and a live test."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import AI_BASE_URL
from keyboards.common import back_only, with_nav
from services import ai_service
from services.settings_service import all_settings, set_value, toggle
from utils import cards
from utils.logs import log_action

from handlers.states import AdminValueForm
from handlers.ui import answer, esc, render

router = Router(name="admin_ai")


def _kb(settings: dict) -> InlineKeyboardMarkup:
    state = "🟢 Bật" if settings.get("ai_enabled") else "🔴 Tắt"
    rows = [
        [InlineKeyboardButton(text=f"Trợ lý AI: {state}", callback_data="admin:aitoggle")],
        [
            InlineKeyboardButton(text="🧠 Đổi model", callback_data="admin:aimodel"),
            InlineKeyboardButton(text="📝 Sửa prompt", callback_data="admin:aiprompt"),
        ],
        [InlineKeyboardButton(text="🧪 Test câu trả lời", callback_data="admin:aitest")],
        [
            InlineKeyboardButton(text="🔄 Làm mới", callback_data="admin:ai"),
            InlineKeyboardButton(text="♻️ Bỏ chờ key/model", callback_data="admin:aireset"),
        ],
    ]
    return with_nav(rows, "vi", back="admin:panel")


async def _screen(event: Message | CallbackQuery) -> None:
    settings = await all_settings(force=True)
    model = await ai_service.model_name()
    tools = ", ".join(tool["function"]["name"] for tool in ai_service.TOOLS)
    health = ai_service.status()
    stats = health["stats"]
    keys = health["keys"]
    ready = sum(1 for key in keys if key["ready"])

    def _state(item: dict) -> str:
        return "✅" if item["ready"] else "⏳" + str(item["retry_in"]) + "s"

    key_line = " · ".join(item["label"] + " " + _state(item) for item in keys) or "chưa có key"
    models = health["models"]
    model_lines = "\n".join(
        "   – <code>" + esc(item["name"]) + "</code> " + _state(item) for item in models
    ) or "   – chưa cấu hình"
    tokens_in = int(stats.get("tokens_in", 0))
    tokens_out = int(stats.get("tokens_out", 0))
    numbers = (
        f"  📊 Lượt gọi: <b>{stats.get('calls', 0)}</b> · OK {stats.get('ok', 0)} · "
        f"lỗi {stats.get('failed', 0)}\n"
        f"  🔁 Đổi key/model: {stats.get('switched', 0)} · 429: {stats.get('rate_limited', 0)}\n"
        f"  🪙 Token đã dùng: <b>{tokens_in + tokens_out}</b> "
        f"(vào {tokens_in} / ra {tokens_out})\n"
    )
    text = (
        f"{cards.title('robot', 'TRỢ LÝ AI')}"
        f"  [[check]] Trạng thái: <b>{'Bật' if settings.get('ai_enabled') else 'Tắt'}</b>\n"
        f"  [[bolt]] API key: <b>{len(keys)}</b> ({ready} sẵn sàng) · {esc(key_line)}\n"
        f"  [[stats]] Model chat: <code>{esc(model)}</code>\n"
        f"  [[pin]] Model đọc file: <code>{esc(ai_service.model_chain('extract')[0])}</code>\n"
        f"  [[book]] Prompt riêng: {'có' if settings.get('ai_system_prompt') else 'mặc định'}\n"
        f"{cards.LINE}"
        f"  [[gamepad]] Model dự phòng (thử lần lượt):\n{model_lines}\n"
        f"{cards.THIN}"
        f"{numbers}"
        f"  ⏱ Hạn mức: {health['budget']} request/phút · tối đa {health['concurrency']} cùng lúc\n"
        f"  [[pin]] Endpoint: <code>{esc(AI_BASE_URL)}</code>\n"
        f"{cards.LINE}"
        f"  [[gamepad]] Công cụ: {esc(tools)}\n\n"
        f"{cards.note('Key bị 429/401 tự tạm khoá và chuyển key khác; model lỗi tự chuyển model dự phòng. Thiếu key: thêm AI_API_KEY, AI_API_KEY_2... vào .env rồi khởi động lại bot.')}"
    )
    await render(event, text, _kb(settings))


@router.callback_query(F.data == "admin:ai")
async def on_ai(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await _screen(callback)


@router.callback_query(F.data == "admin:aireset")
async def on_ai_reset(callback: CallbackQuery, db_user) -> None:
    ai_service.reset_cooldowns()
    await log_action("ai", f"Admin {db_user.id} bỏ tạm khoá key/model AI")
    await answer(callback, "Đã bỏ chờ, dùng lại từ key/model đầu tiên")
    await _screen(callback)


@router.callback_query(F.data == "admin:aitoggle")
async def on_ai_toggle(callback: CallbackQuery, db_user) -> None:
    value = await toggle("ai_enabled")
    await log_action("ai", f"Admin {db_user.id} đổi trợ lý AI -> {value}")
    await answer(callback, f"Trợ lý AI: {'BẬT' if value else 'TẮT'}")
    await _screen(callback)


@router.callback_query(F.data == "admin:aimodel")
async def on_ai_model(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.ai_model)
    await render(
        callback,
        "🧠 Nhập tên model cho <b>luồng chat</b> (câu trả lời ngắn, tốn ít token).\n"
        "Ví dụ: <code>gpt-4o-mini</code>, <code>openai/gpt-oss-20b</code>, "
        "<code>gemini-2.0-flash</code>.\n\n"
        "Model đọc file acc lấy từ <code>AI_MODEL_EXTRACT</code>, model dự phòng từ <code>AI_MODELS</code> "
        "trong <code>.env</code>. Gửi dấu <code>-</code> để quay về model trong .env.",
        back_only("admin:ai"),
    )


@router.message(AdminValueForm.ai_model, F.text)
async def on_ai_model_text(message: Message, state: FSMContext, db_user) -> None:
    value = (message.text or "").strip()
    await state.clear()
    await set_value("ai_model", "" if value in ("-", "0") else value[:120])
    await log_action("ai", f"Admin {db_user.id} đổi model AI -> {value}")
    await message.answer(
        f"✅ Đã đặt model: <code>{esc(await ai_service.model_name())}</code>",
        parse_mode="HTML",
        reply_markup=back_only("admin:ai"),
    )


@router.callback_query(F.data == "admin:aiprompt")
async def on_ai_prompt(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.ai_prompt)
    await render(
        callback,
        "📝 Gửi <b>system prompt</b> mới cho trợ lý (tiếng Việt, mô tả vai trò và giới hạn).\n"
        "Gửi dấu <code>-</code> để khôi phục prompt mặc định.\n\n"
        f"{cards.note('Prompt mặc định đã yêu cầu không bịa số liệu và chỉ đặt cược khi người dùng yêu cầu rõ.')}",
        back_only("admin:ai"),
    )


@router.message(AdminValueForm.ai_prompt, F.text)
async def on_ai_prompt_text(message: Message, state: FSMContext, db_user) -> None:
    value = (message.text or "").strip()
    await state.clear()
    await set_value("ai_system_prompt", "" if value == "-" else value[:4000])
    await log_action("ai", f"Admin {db_user.id} cập nhật prompt AI")
    await message.answer(
        "✅ Đã lưu prompt mới." if value != "-" else "✅ Đã khôi phục prompt mặc định.",
        reply_markup=back_only("admin:ai"),
    )


@router.callback_query(F.data == "admin:aitest")
async def on_ai_test(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    if not ai_service.configured():
        await answer(callback, "Chưa có AI_API_KEY trong .env", alert=True)
        return
    await state.set_state(AdminValueForm.ai_test)
    await render(callback, "🧪 Nhập câu hỏi để test trợ lý AI:", back_only("admin:ai"))


@router.message(AdminValueForm.ai_test, F.text)
async def on_ai_test_text(message: Message, state: FSMContext, db_user) -> None:
    question = (message.text or "").strip()
    await state.clear()
    reply = await ai_service.reply(
        user_id=db_user.id,
        message=question,
        history=[],
        is_admin=True,
        name=db_user.full_name or "",
        bot=message.bot,
    )
    if not reply:
        await message.answer(
            "⚠️ Không nhận được phản hồi. Kiểm tra AI_API_KEY, AI_BASE_URL và tên model.",
            reply_markup=back_only("admin:ai"),
        )
        return
    text = f"{cards.title('robot', 'TEST TRỢ LÝ AI')}{ai_service.to_html(reply)[:3000]}"
    await message.answer(text, parse_mode="HTML", reply_markup=back_only("admin:ai"))
