"""Admin panel: statistics, settings, casino config, giftcodes, broadcast, backup, logs."""

from __future__ import annotations

import asyncio
import os
from datetime import datetime

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select

from config import BACKUP_DIR, SELF_TOPUP_ADMIN_ID
from database.models import Account, Deposit, Order, Ticket, User, Withdrawal
from database.session import backup_database, session_scope
from keyboards.admin import admin_panel, casino_panel, giftcodes_admin, pending_consignments, settings_panel
from keyboards.common import back_only
from locales import t
from services import rewards_service, shop_service
from services import wallet_service as wallet
from services.settings_service import all_settings, set_value, toggle, update_dict
from utils.logs import log_action, recent_logs
from utils.logger import get_logger
from utils.money import fmt_coin, fmt_vnd, parse_amount
from utils.notifications import notify_admins

from handlers.states import AdminForm, AdminValueForm
from handlers.ui import answer, esc, render, sync_reply_keyboard

router = Router(name="admin_panel")
log = get_logger(__name__)


async def _stats() -> dict:
    async with session_scope() as session:
        async def count(model, *conditions):
            query = select(func.count()).select_from(model)
            for condition in conditions:
                query = query.where(condition)
            return int((await session.execute(query)).scalar() or 0)

        stats = {
            "users": await count(User),
            "banned": await count(User, User.is_banned.is_(True)),
            "available_accounts": await count(Account, Account.status == "available"),
            "pending_accounts": await count(Account, Account.status == "pending_approval"),
            "orders": await count(Order),
            "pending_deposits": await count(Deposit, Deposit.status == "pending"),
            "pending_withdrawals": await count(Withdrawal, Withdrawal.status == "pending"),
            "tickets": await count(Ticket, Ticket.status != "closed"),
            "balance": int((await session.execute(select(func.coalesce(func.sum(User.shop_balance), 0)))).scalar() or 0),
            "coins": int((await session.execute(select(func.coalesce(func.sum(User.coins), 0)))).scalar() or 0),
            "deposited": int(
                (await session.execute(select(func.coalesce(func.sum(Deposit.amount), 0)).where(Deposit.status == "approved"))).scalar()
                or 0
            ),
        }
    return stats


async def _panel_text() -> str:
    stats = await _stats()
    settings = await all_settings()
    return (
        "🛠 <b>BẢNG ĐIỀU KHIỂN ADMIN</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"👥 Người chơi: <b>{stats['users']}</b> (khoá {stats['banned']})\n"
        f"🛍 Acc đang bán: <b>{stats['available_accounts']}</b> · chờ duyệt {stats['pending_accounts']}\n"
        f"🧾 Đơn hàng: <b>{stats['orders']}</b>\n"
        f"💳 Nạp chờ duyệt: <b>{stats['pending_deposits']}</b>\n"
        f"💸 Rút chờ duyệt: <b>{stats['pending_withdrawals']}</b>\n"
        f"🆘 Ticket mở: <b>{stats['tickets']}</b>\n"
        f"💰 Tổng số dư ví: <b>{fmt_vnd(stats['balance'])}</b>\n"
        f"🪙 Tổng xu: <b>{fmt_coin(stats['coins'])}</b>\n"
        f"💎 Hũ: <b>{fmt_coin(int(settings.get('jackpot', 0)))}</b>\n"
        f"🛠 Bảo trì: {'🟢 Bật' if settings.get('maintenance') else '🔴 Tắt'}\n\n"
        "<i>Bấm 👤 Menu người dùng để chuyển sang giao diện người chơi; "
        "trong menu người dùng bấm 🛠 Admin để quay lại đây.</i>"
    )


async def show_panel(event: Message | CallbackQuery, db_user) -> None:
    # Switch the bottom reply keyboard first (admin button visible only here) so
    # the panel stays the last message on screen.
    await sync_reply_keyboard(event, db_user.id, db_user.language, admin=True)
    await render(event, await _panel_text(), admin_panel(int(db_user.id) == int(SELF_TOPUP_ADMIN_ID)))


@router.callback_query(F.data == "admin:panel")
async def on_panel(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await state.clear()
    await answer(callback)
    await show_panel(callback, db_user)


@router.callback_query(F.data == "admin:stats")
async def on_stats(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    stats = await _stats()
    settings = await all_settings()
    text = (
        "📊 <b>THỐNG KÊ HỆ THỐNG</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"👥 Tổng người chơi: <b>{stats['users']}</b>\n"
        f"🚫 Bị khoá: <b>{stats['banned']}</b>\n"
        f"🛍 Acc đang bán: <b>{stats['available_accounts']}</b>\n"
        f"⏳ Acc chờ duyệt: <b>{stats['pending_accounts']}</b>\n"
        f"🧾 Tổng đơn hàng: <b>{stats['orders']}</b>\n"
        f"💳 Đã nạp (duyệt): <b>{fmt_vnd(stats['deposited'])}</b>\n"
        f"💰 Tổng số dư ví: <b>{fmt_vnd(stats['balance'])}</b>\n"
        f"🪙 Tổng xu lưu hành: <b>{fmt_coin(stats['coins'])}</b>\n"
        f"💎 Hũ jackpot: <b>{fmt_coin(int(settings.get('jackpot', 0)))}</b>\n"
        f"🎰 RTP cấu hình: <b>{settings.get('casino_rtp')}</b>"
    )
    await render(callback, text, back_only("admin:panel"))


@router.callback_query(F.data == "admin:settings")
async def on_settings(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    settings = await all_settings(force=True)
    await render(callback, "⚙️ <b>CÀI ĐẶT HỆ THỐNG</b>\nBấm để bật/tắt:", settings_panel(settings))


@router.callback_query(F.data.startswith("admin:toggle:"))
async def on_toggle(callback: CallbackQuery, db_user) -> None:
    key = callback.data.split(":", 2)[2]
    allowed = {
        "maintenance",
        "feature_shop",
        "feature_sell",
        "feature_deposit",
        "feature_withdraw",
        "feature_casino",
        "feature_rewards",
        "feature_support",
    }
    if key not in allowed:
        await answer(callback, "Không hợp lệ", alert=True)
        return
    value = await toggle(key)
    await log_action("setting", f"Admin {db_user.id} đổi {key} -> {value}")
    await answer(callback, f"{key}: {'BẬT' if value else 'TẮT'}")
    settings = await all_settings(force=True)
    await render(callback, "⚙️ <b>CÀI ĐẶT HỆ THỐNG</b>\nBấm để bật/tắt:", settings_panel(settings))


@router.callback_query(F.data == "admin:casino")
async def on_casino(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    settings = await all_settings(force=True)
    text = (
        "🎰 <b>CẤU HÌNH CASINO</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Cược min/max: {fmt_coin(int(settings.get('casino_min_bet', 100)))} - "
        f"{fmt_coin(int(settings.get('casino_max_bet', 100000)))}\n"
        f"• RTP: <b>{settings.get('casino_rtp')}</b>\n"
        f"• Hũ: <b>{fmt_coin(int(settings.get('jackpot', 0)))}</b>\n"
        f"• Góp hũ mỗi ván: {settings.get('jackpot_contribution_percent')}%\n\n"
        "Bấm vào game để bật/tắt:"
    )
    await render(callback, text, casino_panel(settings))


@router.callback_query(F.data.startswith("admin:game:"))
async def on_game_toggle(callback: CallbackQuery, db_user) -> None:
    game = callback.data.split(":", 2)[2]
    settings = await all_settings(force=True)
    states = dict(settings.get("game_enabled") or {})
    if game not in states:
        await answer(callback, "Game không tồn tại", alert=True)
        return
    states[game] = not states[game]
    await update_dict("game_enabled", states)
    await log_action("casino", f"Admin {db_user.id} đổi game {game} -> {states[game]}")
    await answer(callback, f"{game}: {'BẬT' if states[game] else 'TẮT'}")
    await on_casino(callback, db_user)


@router.callback_query(F.data == "admin:resetjackpot")
async def on_reset_jackpot(callback: CallbackQuery, db_user) -> None:
    await set_value("jackpot", 0)
    await log_action("casino", f"Admin {db_user.id} reset hũ")
    await answer(callback, "Đã reset hũ về 0")
    await on_casino(callback, db_user)


@router.callback_query(F.data == "admin:casinolimits")
async def on_limits(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.limits)
    await render(
        callback,
        "✏️ Nhập theo dạng: <code>min max rtp</code>\n"
        "Ví dụ: <code>100 50000 0.95</code>",
        back_only("admin:casino"),
    )


@router.message(AdminValueForm.limits, F.text)
async def on_limits_text(message: Message, state: FSMContext, db_user) -> None:
    parts = (message.text or "").split()
    await state.clear()
    if len(parts) != 3:
        await message.answer("❌ Sai định dạng. Ví dụ: 100 50000 0.95")
        return
    try:
        min_bet, max_bet, rtp = int(parts[0]), int(parts[1]), float(parts[2])
    except ValueError:
        await message.answer("❌ Giá trị không hợp lệ.")
        return
    if min_bet < 1 or max_bet <= min_bet or not 0.5 <= rtp <= 1.2:
        await message.answer("❌ Kiểm tra lại: min > 0, max > min, 0.5 <= rtp <= 1.2")
        return
    await set_value("casino_min_bet", min_bet)
    await set_value("casino_max_bet", max_bet)
    await set_value("casino_rtp", rtp)
    await log_action("casino", f"Admin {db_user.id} set min={min_bet} max={max_bet} rtp={rtp}")
    await message.answer(
        f"✅ Đã cập nhật: min {fmt_coin(min_bet)}, max {fmt_coin(max_bet)}, RTP {rtp}",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin:gcs")
async def on_giftcodes(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    codes = await rewards_service.list_giftcodes(15)
    text = "🎟 <b>GIFTCODE</b>\nBấm vào mã để bật/tắt:"
    if not codes:
        text += "\n<i>Chưa có mã nào.</i>"
    await render(callback, text, giftcodes_admin(codes))


@router.callback_query(F.data.startswith("admin:gc:"))
async def on_giftcode_toggle(callback: CallbackQuery, db_user) -> None:
    code = callback.data.split(":", 2)[2]
    codes = await rewards_service.list_giftcodes(50)
    target = next((c for c in codes if c.code == code), None)
    if target is None:
        await answer(callback, "Không tìm thấy mã", alert=True)
        return
    await rewards_service.set_giftcode_active(code, not target.is_active)
    await log_action("giftcode", f"Admin {db_user.id} đổi trạng thái {code}")
    await answer(callback, "Đã cập nhật")
    await on_giftcodes(callback, db_user)


@router.callback_query(F.data.startswith("admin:gcnew"))
async def on_giftcode_new(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    mode = parts[2] if len(parts) > 2 else "coin"
    await state.set_state(AdminForm.giftcode)
    await state.update_data(giftcode_default_currency=mode)
    if mode == "vnd":
        text = (
            "💵 <b>TẠO GIFTCODE TIỀN (VND)</b>\n\n"
            "Nhập theo định dạng:\n"
            "<code>MÃ | số_tiền | số_lần_dùng | số_ngày</code>\n\n"
            "Ví dụ: <code>TIENTET | 50000 | 20 | 7</code>\n"
            "(Hoặc kèm đơn vị: <code>TIENTET | 50000 | vnd | 20 | 7</code>)"
        )
    else:
        text = (
            "🪙 <b>TẠO GIFTCODE XU</b>\n\n"
            "Nhập theo định dạng:\n"
            "<code>MÃ | số_xu | số_lần_dùng | số_ngày</code>\n\n"
            "Ví dụ: <code>XUTET | 5000 | 50 | 7</code>\n"
            "(Hoặc kèm đơn vị: <code>XUTET | 5000 | coin | 50 | 7</code>)"
        )
    await render(
        callback,
        text,
        back_only("admin:gcs"),
    )


@router.message(AdminForm.giftcode, F.text)
async def on_giftcode_created(message: Message, state: FSMContext, db_user) -> None:
    raw = (message.text or "").strip()
    data = await state.get_data()
    default_curr = data.get("giftcode_default_currency", "coin")
    await state.clear()
    parts = [part.strip() for part in raw.split("|")]
    if len(parts) == 4:
        code, amount_raw, uses_raw, days_raw = parts
        currency = default_curr
    elif len(parts) >= 5:
        code, amount_raw, currency, uses_raw, days_raw = parts[:5]
    else:
        await message.answer("❌ Sai định dạng. Ví dụ: WELCOME | 1000 | coin | 100 | 7 (hoặc WELCOME | 1000 | 100 | 7)")
        return
    try:
        amount, uses, days = int(amount_raw), int(uses_raw), int(days_raw)
    except ValueError:
        await message.answer("❌ Số lượng / lượt dùng / số ngày phải là số nguyên.")
        return
    currency = currency.lower()
    if currency not in ("coin", "vnd"):
        await message.answer("❌ Đơn vị phải là coin hoặc vnd.")
        return
    giftcode = await rewards_service.create_giftcode(code, amount, currency, uses, days, db_user.id)
    if giftcode is None:
        await message.answer("❌ Mã đã tồn tại hoặc dữ liệu không hợp lệ.")
        return
    unit_str = "TIỀN (VND)" if currency == "vnd" else "XU"
    reward_text = fmt_vnd(amount) if currency == "vnd" else fmt_coin(amount)
    await log_action("giftcode", f"Admin {db_user.id} tạo mã {giftcode.code} ({currency})")
    await message.answer(
        f"✅ Đã tạo giftcode <b>{unit_str}</b>: <code>{giftcode.code}</code>\n"
        f"• Thưởng: <b>{reward_text}</b>\n"
        f"• Lượt sử dụng: <b>{uses}</b> · Hết hạn sau <b>{days}</b> ngày",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin:pending")
async def on_pending(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    accounts = await shop_service.pending_consignments(10)
    if not accounts:
        await render(callback, "⏳ Không có acc chờ duyệt.", back_only("admin:panel"))
        return
    lines = ["⏳ <b>ACC CHỜ DUYỆT</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for account in accounts:
        lines.append(
            f"• <b>{account.code}</b> · {esc(account.rank)} · {fmt_vnd(account.price)}\n"
            f"  Người gửi: <code>{account.seller_id}</code> · {account.heroes} tướng · {account.skins} skin"
        )
    await render(callback, "\n".join(lines), pending_consignments(accounts))


@router.callback_query(F.data.startswith("admin:conok:"))
async def on_consignment_ok(callback: CallbackQuery, db_user) -> None:
    account_id = int(callback.data.split(":")[2])
    from services import shop_service

    await shop_service.approve_consignment(account_id)
    account = await shop_service.get_account(account_id)
    await answer(callback, "Đã duyệt acc")
    await log_action("consignment", f"Admin {db_user.id} duyệt acc {account_id}")
    if account and account.seller_id:
        try:
            await callback.bot.send_message(
                account.seller_id,
                f"✅ Acc <b>{account.code}</b> của bạn đã được duyệt và đăng bán.",
                parse_mode="HTML",
            )
        except Exception:
            pass
    await on_pending(callback, db_user)


@router.callback_query(F.data.startswith("admin:conno:"))
async def on_consignment_no(callback: CallbackQuery, db_user) -> None:
    account_id = int(callback.data.split(":")[2])
    from services import shop_service

    await shop_service.reject_consignment(account_id, "Thông tin chưa hợp lệ")
    account = await shop_service.get_account(account_id)
    await answer(callback, "Đã từ chối")
    await log_action("consignment", f"Admin {db_user.id} từ chối acc {account_id}")
    if account and account.seller_id:
        try:
            await callback.bot.send_message(
                account.seller_id,
                f"❌ Acc <b>{account.code}</b> bị từ chối. Vui lòng kiểm tra lại thông tin và gửi lại.",
                parse_mode="HTML",
            )
        except Exception:
            pass
    await on_pending(callback, db_user)


@router.callback_query(F.data == "admin:broadcast")
async def on_broadcast(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminForm.broadcast)
    await render(
        callback,
        "📢 Nhập nội dung broadcast (hỗ trợ HTML cơ bản).\nNội dung sẽ gửi tới mọi người dùng đang bật thông báo.",
        back_only("admin:panel"),
    )


@router.message(AdminForm.broadcast, F.text)
async def on_broadcast_text(message: Message, state: FSMContext, db_user) -> None:
    text = (message.text or "").strip()
    await state.clear()
    if len(text) < 3:
        await message.answer("❌ Nội dung quá ngắn.")
        return
    async with session_scope() as session:
        users = (
            await session.execute(select(User.id).where(User.notifications.is_(True), User.is_banned.is_(False)))
        ).scalars().all()
    sent = failed = 0
    for user_id in users:
        try:
            await message.bot.send_message(int(user_id), text, parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1
    await log_action("broadcast", f"Admin {db_user.id} gửi broadcast tới {sent} user")
    await message.answer(f"📢 Đã gửi: <b>{sent}</b> thành công, <b>{failed}</b> thất bại.", parse_mode="HTML")


SELF_TOPUP_PRESETS = {
    "vnd": [50000, 100000, 500000, 1000000, 5000000],
    "coin": [1000, 5000, 10000, 50000, 100000],
}
SELF_TOPUP_LIMIT = {"vnd": 1_000_000_000, "coin": 100_000_000}


def _self_topup_allowed(db_user) -> bool:
    return int(db_user.id) == int(SELF_TOPUP_ADMIN_ID)


def _self_topup_kb(currency: str) -> InlineKeyboardMarkup:
    format_value = fmt_vnd if currency == "vnd" else fmt_coin
    values = SELF_TOPUP_PRESETS[currency]
    rows = [
        [
            InlineKeyboardButton(
                text=format_value(value),
                callback_data=f"admin:selftopdo:{currency}:{value}",
            )
            for value in values[index : index + 2]
        ]
        for index in range(0, len(values), 2)
    ]
    rows.append(
        [InlineKeyboardButton(text="✏️ Nhập số khác", callback_data=f"admin:selftopcustom:{currency}")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _credit_self(event: Message | CallbackQuery, db_user, currency: str, amount: int) -> None:
    if not _self_topup_allowed(db_user):
        if isinstance(event, CallbackQuery):
            await answer(event, "Chỉ admin được cấu hình mới dùng được chức năng này.", alert=True)
        else:
            await event.answer("⛔ Chỉ admin được cấu hình mới dùng được chức năng này.")
        return
    if currency not in SELF_TOPUP_LIMIT:
        currency = "vnd"
    if amount <= 0 or amount > SELF_TOPUP_LIMIT[currency]:
        message = f"❌ Số không hợp lệ (tối đa {fmt_vnd(SELF_TOPUP_LIMIT[currency]) if currency == 'vnd' else fmt_coin(SELF_TOPUP_LIMIT[currency])})."
        if isinstance(event, CallbackQuery):
            await answer(event, message, alert=True)
        else:
            await event.answer(message)
        return
    if not await wallet.add_balance(
        db_user.id, amount, "admin_self_topup", currency, "Admin tự nạp cho mình"
    ):
        if isinstance(event, CallbackQuery):
            await answer(event, "Không cộng được, thử lại.", alert=True)
        else:
            await event.answer("❌ Không cộng được, thử lại.")
        return
    await log_action("balance", f"Admin {db_user.id} tự nạp {amount} {currency}")
    fresh = await wallet.get_user(db_user.id)
    format_value = fmt_vnd if currency == "vnd" else fmt_coin
    balance = (
        fmt_vnd(fresh.shop_balance) if currency == "vnd" and fresh is not None
        else fmt_coin(fresh.coins) if fresh is not None else "—"
    )
    text = (
        "✅ <b>ĐÃ TỰ NẠP</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Số: <b>{format_value(amount)}</b>\n"
        f"• Số dư mới: <b>{balance}</b>"
    )
    if isinstance(event, CallbackQuery):
        await answer(event, "Đã cộng")
        await render(event, text, back_only("admin:panel"))
    else:
        await event.answer(text, parse_mode="HTML")


@router.callback_query(F.data.startswith("admin:selftop:"))
async def on_self_topup(callback: CallbackQuery, db_user) -> None:
    if not _self_topup_allowed(db_user):
        await answer(callback, "Chỉ admin được cấu hình mới dùng được chức năng này.", alert=True)
        return
    await answer(callback)
    currency = callback.data.split(":")[2]
    if currency not in SELF_TOPUP_PRESETS:
        currency = "vnd"
    unit = "tiền vào ví" if currency == "vnd" else "xu vào tài khoản"
    await render(
        callback,
        f"💰 <b>TỰ NẠP {unit.upper()}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        "Chọn số muốn cộng cho chính mình:",
        _self_topup_kb(currency),
    )


@router.callback_query(F.data.startswith("admin:selftopdo:"))
async def on_self_topup_do(callback: CallbackQuery, db_user) -> None:
    parts = callback.data.split(":")
    currency, amount_raw = parts[2], parts[3]
    try:
        amount = int(amount_raw)
    except (IndexError, ValueError):
        await answer(callback, "Số không hợp lệ", alert=True)
        return
    await _credit_self(callback, db_user, currency, amount)


@router.callback_query(F.data.startswith("admin:selftopcustom:"))
async def on_self_topup_custom(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    if not _self_topup_allowed(db_user):
        await answer(callback, "Chỉ admin được cấu hình mới dùng được chức năng này.", alert=True)
        return
    currency = callback.data.split(":")[2]
    if currency not in SELF_TOPUP_PRESETS:
        currency = "vnd"
    await answer(callback)
    await state.set_state(AdminValueForm.self_topup)
    await state.update_data(self_currency=currency)
    await render(
        callback,
        "✏️ Nhập số muốn nạp (ví dụ <code>500000</code>, <code>500k</code>):",
        back_only("admin:panel"),
    )


@router.message(AdminValueForm.self_topup, F.text)
async def on_self_topup_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    currency = data.get("self_currency", "vnd")
    amount = parse_amount(message.text or "")
    await state.clear()
    if not amount:
        await message.answer("❌ Số không hợp lệ.", reply_markup=back_only("admin:panel"))
        return
    await _credit_self(message, db_user, currency, amount)


@router.callback_query(F.data == "admin:backup")
async def on_backup(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    target = BACKUP_DIR / f"backup-{datetime.now():%Y%m%d-%H%M%S}.db"
    try:
        created = backup_database(target)
    except Exception as exc:  # noqa: BLE001 - a failed backup must not break the panel
        await render(callback, f"❌ Sao lưu thất bại: {esc(exc)}", back_only("admin:panel"))
        return
    if created is None:
        await render(callback, "⚠️ Không tìm thấy file SQLite (có thể đang dùng PostgreSQL).", back_only("admin:panel"))
        return
    target = created
    await log_action("backup", f"Admin {db_user.id} tạo backup {target.name}")
    await render(
        callback,
        f"💾 <b>ĐÃ SAO LƯU</b>\n• File: <code>{target.name}</code>\n"
        f"• Kích thước: {target.stat().st_size / 1024:.1f} KB",
        back_only("admin:panel"),
    )


@router.callback_query(F.data == "admin:logs")
async def on_logs(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    entries = await recent_logs(20)
    if not entries:
        await render(callback, "📜 Chưa có log.", back_only("admin:panel"))
        return
    lines = ["📜 <b>LOG GẦN ĐÂY</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for entry in entries:
        lines.append(f"• {entry.created_at:%d/%m %H:%M} · <b>{esc(entry.kind)}</b>: {esc(entry.message)[:120]}")
    await render(callback, "\n".join(lines), back_only("admin:panel"))


@router.callback_query(F.data == "admin:addadmin")
async def on_addadmin_hint(callback: CallbackQuery, db_user) -> None:
    await answer(callback, "Dùng file .env hoặc sửa settings admin_ids", alert=True)


async def _stop_bot() -> None:
    """Exit the whole process after a short delay so the reply goes out first.

    os._exit skips main()'s finally cleanup (scheduler/webhook/session close),
    but the process is ending anyway and nohup does not restart it, so the bot
    stays down until it is started again by hand in the cPanel Terminal.
    """
    await asyncio.sleep(1.5)
    log.info("Bot tắt theo lệnh admin")
    os._exit(0)


@router.callback_query(F.data == "admin:stop")
async def on_stop_confirm(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Tắt bot ngay", callback_data="admin:stop:yes")],
            [InlineKeyboardButton(text="❌ Hủy", callback_data="admin:panel")],
        ]
    )
    await render(
        callback,
        "⏹ <b>TẮT BOT?</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        "Bot sẽ dừng hẳn và <b>không tự chạy lại</b>.\n"
        "Muốn mở lại phải chạy lệnh nohup trong Terminal cPanel.",
        keyboard,
    )


@router.callback_query(F.data == "admin:stop:yes")
async def on_stop(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await log_action("system", f"Admin {db_user.id} tắt bot")
    await render(callback, "⏹ Bot đang tắt. Hẹn gặp lại 👋", back_only("admin:panel"))
    asyncio.create_task(_stop_bot())


@router.message(Command("tatbot"))
async def on_tatbot_command(message: Message, db_user) -> None:
    await log_action("system", f"Admin {db_user.id} tắt bot (lệnh /tatbot)")
    await message.answer("⏹ Bot đang tắt. Hẹn gặp lại 👋")
    asyncio.create_task(_stop_bot())


@router.message(Command("syncstock"))
async def on_syncstock_command(message: Message, db_user) -> None:
    from services.stock_sync_service import sync_stock_now
    msg = await message.answer("⏳ Đang xuất kho và đồng bộ stock.json...")
    ok = await sync_stock_now()
    if ok:
        await msg.edit_text("✅ Đã xuất và đồng bộ stock.json thành công cho Mini App!")
    else:
        await msg.edit_text("⚠️ Đã xuất stock.json cục bộ nhưng chưa đẩy được lên GitHub. Kiểm tra GITHUB_TOKEN trong .env.")
