"""Admin account inventory and order management."""

from __future__ import annotations

import io

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from sqlalchemy import func, select

from config import IMPORT_MAX_BYTES, IMPORT_MAX_ROWS
from database.models import Order
from database.session import session_scope
from keyboards.admin import account_admin, accounts_admin, order_admin, orders_admin
from keyboards.common import back_only, with_nav
from services import ai_service, shop_service
from utils import cards
from utils.logs import log_action
from utils.money import fmt_vnd, parse_amount

from handlers.states import AdminValueForm
from handlers.ui import answer, esc, render

router = Router(name="admin_shop_admin")

PER_PAGE = 8


@router.callback_query(F.data.startswith("admin:accounts:"))
async def on_accounts(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    try:
        page = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        page = 0
    accounts, total = await shop_service.list_accounts(
        page=page, per_page=PER_PAGE, status="all", include_hidden=True, sort="newest"
    )
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    await render(
        callback,
        f"🛍 <b>KHO ACC</b> ({total})\nBấm để quản lý acc:",
        accounts_admin(accounts, page, pages),
    )


@router.callback_query(F.data.startswith("admin:acct:"))
async def on_account(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None:
        await render(callback, "❌ Không tìm thấy acc.", back_only("admin:accounts:0"))
        return
    text = (
        f"🛍 <b>ACC {account.code}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Trạng thái: {account.status} · {'Ẩn' if account.is_hidden else 'Hiện'}\n"
        f"• Giá: <b>{fmt_vnd(account.price)}</b>\n"
        f"• Rank: {esc(account.rank)} · Level {account.level}\n"
        f"• Tướng: {account.heroes} · Skin: {account.skins}\n"
        f"• Đăng nhập: {esc(account.login_type)} · Bảo hành {account.warranty_days} ngày\n"
        f"• Người bán: <code>{account.seller_id or 'Admin'}</code>\n"
        f"• Lượt xem: {account.views}\n"
        f"• Tạo: {account.created_at:%d/%m/%Y}"
    )
    if account.description:
        text += f"\n▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n{esc(account.description)}"
    await render(callback, text, account_admin(account.id, account.is_hidden))


@router.callback_query(F.data.startswith("admin:accttoggle:"))
async def on_account_toggle(callback: CallbackQuery, db_user) -> None:
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    await shop_service.set_visibility(account_id, not account.is_hidden)
    await log_action("account", f"Admin {db_user.id} đổi hiển thị acc {account.code}")
    await answer(callback, "Đã cập nhật")
    await on_account(callback, db_user)


@router.callback_query(F.data.startswith("admin:acctprice:"))
async def on_account_price(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    account_id = int(callback.data.split(":")[2])
    await state.set_state(AdminValueForm.price)
    await state.update_data(price_account=account_id)
    await render(callback, "✏️ Nhập giá mới (VNĐ):", back_only(f"admin:acct:{account_id}"))


@router.message(AdminValueForm.price, F.text)
async def on_account_price_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    account_id = int(data.get("price_account", 0))
    amount = parse_amount(message.text or "")
    await state.clear()
    if not amount:
        await message.answer("❌ Giá không hợp lệ.")
        return
    await shop_service.update_price(account_id, amount)
    await log_action("account", f"Admin {db_user.id} đổi giá acc {account_id} -> {amount}")
    await message.answer(f"✅ Đã đổi giá thành <b>{fmt_vnd(amount)}</b>.", parse_mode="HTML")


@router.callback_query(F.data.startswith("admin:acctdel:"))
async def on_account_delete(callback: CallbackQuery, db_user) -> None:
    account_id = int(callback.data.split(":")[2])
    account = await shop_service.get_account(account_id)
    if account is None:
        await answer(callback, "Không tìm thấy acc", alert=True)
        return
    await shop_service.remove_account(account_id)
    await log_action("account", f"Admin {db_user.id} xoá acc {account.code}")
    await answer(callback, "Đã xoá acc")
    await on_accounts(callback, db_user)


@router.callback_query(F.data == "admin:accadd")
async def on_account_add(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.add_account)
    await render(
        callback,
        "➕ <b>THÊM ACC</b>\nNhập một dòng theo dạng:\n"
        "<code>giá | rank | tướng | skin | đăng nhập | user | pass | mô tả</code>\n\n"
        "Ví dụ:\n<code>500000 | Kim Cương | 80 | 40 | Facebook | user123 | pass123 | Acc tâm huyết</code>",
        back_only("admin:accounts:0"),
    )


@router.message(AdminValueForm.add_account, F.text)
async def on_account_add_text(message: Message, state: FSMContext, db_user) -> None:
    raw = (message.text or "").strip()
    await state.clear()
    parts = [part.strip() for part in raw.split("|")]
    if len(parts) < 7:
        await message.answer("❌ Cần ít nhất 7 phần: giá | rank | tướng | skin | đăng nhập | user | pass")
        return
    price_raw, rank, heroes_raw, skins_raw, login_type, username, password = parts[:7]
    description = parts[7] if len(parts) > 7 else ""
    try:
        price = parse_amount(price_raw) or 0
        heroes = int(heroes_raw or 0)
        skins = int(skins_raw or 0)
    except ValueError:
        await message.answer("❌ Giá/tướng/skin không hợp lệ.")
        return
    if price <= 0:
        await message.answer("❌ Giá phải lớn hơn 0.")
        return
    account = await shop_service.create_account(
        price=price,
        rank=rank,
        heroes=heroes,
        skins=skins,
        login_type=login_type or "Facebook",
        description=description,
        username=username,
        password=password,
        status="available",
    )
    await log_action("account", f"Admin {db_user.id} thêm acc {account.code}")
    await message.answer(
        f"✅ Đã thêm acc <b>{account.code}</b> · {fmt_vnd(account.price)}",
        parse_mode="HTML",
    )


IMPORT_HELP = (
    "📥 <b>NHẬP ACC TỪ FILE</b>\n"
    "Gửi file <b>.txt</b>, <b>.csv</b> hoặc <b>.json</b> (hoặc dán nội dung trực tiếp).\n"
    "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
    "• <b>.txt</b> mỗi dòng: <code>giá | rank | tướng | skin | đăng nhập | user | pass | mô tả</code>\n"
    "• <b>.csv</b> có thể có dòng tiêu đề:\n"
    "<code>price,rank,heroes,skins,login_type,username,password,description</code>\n"
    "• <b>.json</b> danh sách object với các khóa: price, rank, level, heroes, skins, "
    "login_type, warranty_days, username, password, description.\n\n"
    "Ví dụ TXT:"
    "\n<code>500000 | Kim Cương | 80 | 40 | Facebook | user123 | pass123 | Acc tâm huyết</code>"
    f"\n\nTối đa <b>{IMPORT_MAX_ROWS}</b> acc mỗi lần, file ≤ "
    f"<b>{IMPORT_MAX_BYTES // 1000} KB</b>.\n"
    "File không đúng các dạng trên thì bấm <b>🤖 AI đọc file acc</b>."
)


@router.callback_query(F.data == "admin:accimport")
async def on_account_import(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.import_accounts)
    await render(callback, IMPORT_HELP, back_only("admin:accounts:0"))


async def _finish_import(message: Message, state: FSMContext, db_user, text: str, filename: str) -> None:
    from services.hit_parser import looks_like_hit

    if looks_like_hit(text):
        await state.set_state(AdminValueForm.hit_price)
        await state.update_data(pending_hit=text[:200_000])
        await message.answer(
            f"{cards.title('scroll', 'NHẬN DIỆN ACC FULL INFO')}"
            "Nội dung bạn gửi là block kiểm tra acc. Nhập <b>giá | loại</b> để nhập cả lô "
            "(ví dụ <code>500000 | 3S</code>), hoặc bấm nút quay lại.",
            parse_mode="HTML",
            reply_markup=back_only("admin:accounts:0"),
        )
        return
    await state.clear()
    result = await shop_service.import_accounts(text, filename, seller_id=None)
    created = result["created"]
    errors = result["errors"]
    ai_note = ""
    if created == 0 and ai_service.configured():
        # The file did not match any known layout: let the assistant read it.
        extracted = await ai_service.extract_accounts(text)
        if extracted.get("records"):
            ai_result = await shop_service.import_ai_accounts(extracted["records"])
            if ai_result["created"]:
                result = ai_result
                created = ai_result["created"]
                errors = ai_result["errors"]
                ai_note = "\n  🤖 Đọc bằng AI: " + str(created) + " acc"
        else:
            errors = errors + [e for e in extracted.get("errors") or [] if e not in errors]
    if created:
        await log_action("account", f"Admin {db_user.id} nhập {created} acc từ {filename or 'tin nhắn'}")
    lines = ["📥 <b>KẾT QUẢ NHẬP FILE</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    lines.append(f"✅ Đã thêm: <b>{created}</b> acc")
    if result["codes"]:
        shown = ", ".join(result["codes"][:12])
        lines.append(f"• Mã: {shown}{' …' if created > 12 else ''}")
    if errors:
        lines.append(f"⚠️ Bỏ qua: <b>{len(errors)}</b> dòng")
        lines.extend(f"  – {esc(item)}" for item in errors[:6])
        if len(errors) > 6:
            lines.append(f"  – … và {len(errors) - 6} lỗi khác")
    if not created and not errors:
        lines.append("❌ Không đọc được dòng nào. Kiểm tra lại định dạng file.")
    if ai_note:
        lines.append(ai_note.strip())
    await message.answer(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=with_nav(
            [[InlineKeyboardButton(text="🛍 Xem kho acc", callback_data="admin:accounts:0")]],
            "vi",
            back="admin:accounts:0",
        ),
    )


@router.message(AdminValueForm.import_accounts, F.document)
async def on_import_file(message: Message, state: FSMContext, db_user) -> None:
    document = message.document
    if document is None:
        return
    if (document.file_size or 0) > IMPORT_MAX_BYTES:
        await message.answer(
            f"❌ File quá lớn (tối đa {IMPORT_MAX_BYTES // 1000} KB). Hãy chia nhỏ file."
        )
        return
    buffer = io.BytesIO()
    try:
        await message.bot.download(document, destination=buffer)
    except Exception:
        await message.answer("❌ Không tải được file, thử gửi lại.")
        return
    text = buffer.getvalue().decode("utf-8-sig", errors="replace")
    await _finish_import(message, state, db_user, text, document.file_name or "import")


@router.message(AdminValueForm.import_accounts, F.text)
async def on_import_text(message: Message, state: FSMContext, db_user) -> None:
    await _finish_import(message, state, db_user, message.text or "", "paste.txt")


@router.message(AdminValueForm.import_accounts)
async def on_import_other(message: Message, db_user) -> None:
    await message.answer(
        "📥 Hãy gửi file .txt/.csv/.json hoặc dán nội dung acc dạng văn bản.",
        reply_markup=back_only("admin:accounts:0"),
    )


HIT_PRICE_HELP = (
    "🌐 <b>NHẬP ACC FULL INFO</b>\n"
    "Bước 1: nhập <b>giá | loại</b> cho cả lô.\n"
    "Ví dụ: <code>500000 | 3S</code> · <code>120000 | Anime</code>\n\n"
    f"{cards.note('Bỏ trống loại thì bot tự đoán 3S / 2S / Anime / SS theo skin.')}"
)

HIT_BODY_HELP = (
    "📋 <b>DÁN NỘI DUNG ACC</b>\n"
    "Gửi file .txt hoặc dán trực tiếp các block kiểm tra acc (🔑 UID, RANK, SKIN, BAND...).\n"
    "Nhiều acc thì cách nhau bằng dòng ━━━.\n"
    f"Tối đa <b>{IMPORT_MAX_ROWS}</b> acc mỗi lần."
)

RANDOM_PRICE_HELP = (
    "🎲 <b>NHẬP KHO RANDOM</b>\n"
    "Bước 1: nhập <b>giá | tên loại</b>.\n"
    "Ví dụ: <code>30000 | Random</code> · <code>50000 | Random VIP</code>"
)

RANDOM_BODY_HELP = (
    "🔑 <b>DÁN DANH SÁCH ACC RANDOM</b>\n"
    "Mỗi dòng một acc dạng <code>user:pass</code> (có thể thêm <code> | rank</code>).\n"
    "Ví dụ:\n<code>nick01:pass01</code>\n<code>nick02:pass02 | Kim Cương</code>\n\n"
    "Hoặc gửi file .txt cùng định dạng."
)


def _summary(title: str, result: dict) -> str:
    lines = [f"{cards.title('check', title)}", f"  ✅ Đã thêm: <b>{result['created']}</b> acc"]
    if result["codes"]:
        shown = ", ".join(result["codes"][:12])
        lines.append(f"  [[scroll]] Mã: {shown}{' …' if len(result['codes']) > 12 else ''}")
    if result["errors"]:
        lines.append(f"  [[warn]] Bỏ qua <b>{len(result['errors'])}</b> mục:")
        lines.extend(f"   – {esc(item)}" for item in result["errors"][:6])
        if len(result["errors"]) > 6:
            lines.append(f"   – … và {len(result['errors']) - 6} lỗi khác")
    return "\n".join(lines)


@router.callback_query(F.data == "admin:acchit")
async def on_hit_start(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.hit_price)
    await render(callback, HIT_PRICE_HELP, back_only("admin:accounts:0"))


@router.message(AdminValueForm.hit_price, F.text)
async def on_hit_price(message: Message, state: FSMContext, db_user) -> None:
    parts = [part.strip() for part in (message.text or "").split("|")]
    price = parse_amount(parts[0]) if parts else None
    if not price:
        await message.answer("❌ Giá không hợp lệ. Ví dụ: <code>500000 | 3S</code>", parse_mode="HTML")
        return
    data = await state.get_data()
    await state.update_data(hit_price=price, hit_category=(parts[1] if len(parts) > 1 else "")[:32])
    pending = data.get("pending_hit")
    if pending:
        await _finish_hit(message, state, db_user, pending)
        return
    await state.set_state(AdminValueForm.hit_body)
    await message.answer(HIT_BODY_HELP, parse_mode="HTML", reply_markup=back_only("admin:accounts:0"))


async def _finish_hit(message: Message, state: FSMContext, db_user, text: str) -> None:
    data = await state.get_data()
    await state.clear()
    result = await shop_service.import_hit_accounts(
        text,
        price=int(data.get("hit_price") or 0),
        category=data.get("hit_category") or "",
        seller_id=None,
    )
    if result["created"]:
        await log_action("account", f"Admin {db_user.id} nhập {result['created']} acc full info")
    await message.answer(
        _summary("KẾT QUẢ NHẬP FULL INFO", result),
        parse_mode="HTML",
        reply_markup=with_nav(
            [[InlineKeyboardButton(text="🛍 Xem kho acc", callback_data="admin:accounts:0")]],
            "vi",
            back="admin:accounts:0",
        ),
    )


@router.message(AdminValueForm.hit_body, F.document)
async def on_hit_file(message: Message, state: FSMContext, db_user) -> None:
    if message.document is None:
        return
    if (message.document.file_size or 0) > IMPORT_MAX_BYTES:
        await message.answer(f"❌ File quá lớn (tối đa {IMPORT_MAX_BYTES // 1000} KB).")
        return
    buffer = io.BytesIO()
    try:
        await message.bot.download(message.document, destination=buffer)
    except Exception:
        await message.answer("❌ Không tải được file, thử lại.")
        return
    await _finish_hit(message, state, db_user, buffer.getvalue().decode("utf-8-sig", errors="replace"))


@router.message(AdminValueForm.hit_body, F.text)
async def on_hit_text(message: Message, state: FSMContext, db_user) -> None:
    await _finish_hit(message, state, db_user, message.text or "")


@router.callback_query(F.data == "admin:accrand")
async def on_random_start(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.random_price)
    await render(callback, RANDOM_PRICE_HELP, back_only("admin:accounts:0"))


@router.message(AdminValueForm.random_price, F.text)
async def on_random_price(message: Message, state: FSMContext, db_user) -> None:
    parts = [part.strip() for part in (message.text or "").split("|")]
    price = parse_amount(parts[0]) if parts else None
    if not price:
        await message.answer("❌ Giá không hợp lệ. Ví dụ: <code>30000 | Random</code>", parse_mode="HTML")
        return
    await state.update_data(random_price=price, random_category=(parts[1] if len(parts) > 1 else "Random")[:32])
    await state.set_state(AdminValueForm.random_body)
    await message.answer(RANDOM_BODY_HELP, parse_mode="HTML", reply_markup=back_only("admin:accounts:0"))


async def _finish_random(message: Message, state: FSMContext, db_user, text: str) -> None:
    data = await state.get_data()
    await state.clear()
    result = await shop_service.import_random_accounts(
        text,
        price=int(data.get("random_price") or 0),
        category=data.get("random_category") or "Random",
        seller_id=None,
    )
    if result["created"]:
        await log_action("account", f"Admin {db_user.id} nhập {result['created']} acc random")
    await message.answer(
        _summary("KẾT QUẢ NHẬP KHO RANDOM", result),
        parse_mode="HTML",
        reply_markup=with_nav(
            [[InlineKeyboardButton(text="🛍 Xem kho acc", callback_data="admin:accounts:0")]],
            "vi",
            back="admin:accounts:0",
        ),
    )


@router.message(AdminValueForm.random_body, F.document)
async def on_random_file(message: Message, state: FSMContext, db_user) -> None:
    if message.document is None:
        return
    if (message.document.file_size or 0) > IMPORT_MAX_BYTES:
        await message.answer(f"❌ File quá lớn (tối đa {IMPORT_MAX_BYTES // 1000} KB).")
        return
    buffer = io.BytesIO()
    try:
        await message.bot.download(message.document, destination=buffer)
    except Exception:
        await message.answer("❌ Không tải được file, thử lại.")
        return
    await _finish_random(message, state, db_user, buffer.getvalue().decode("utf-8-sig", errors="replace"))


@router.message(AdminValueForm.random_body, F.text)
async def on_random_text(message: Message, state: FSMContext, db_user) -> None:
    await _finish_random(message, state, db_user, message.text or "")


AI_IMPORT_HELP = (
    f"{cards.title('robot', 'AI ĐỌC FILE ACC')}"
    "Gửi file <b>.txt/.csv/.json</b> (hoặc dán nội dung) mà định dạng lộn xộn — "
    "AI sẽ tự tách từng acc thành: giá, rank, level, tướng, skin, user/pass, mô tả, ban hay không.\n"
    f"{cards.note('AI chỉ lấy dữ liệu có trong file, không bịa acc hay giá. Giá phải có sẵn trong file.')}"
)


@router.callback_query(F.data == "admin:accai")
async def on_ai_import(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    if not ai_service.configured():
        await render(
            callback,
            "⚠️ Chưa cấu hình <code>AI_API_KEY</code> trong <code>.env</code> nên chưa dùng được tính năng này.",
            back_only("admin:accounts:0"),
        )
        return
    await state.set_state(AdminValueForm.ai_import)
    await render(callback, AI_IMPORT_HELP, back_only("admin:accounts:0"))


async def _finish_ai_import(message: Message, state: FSMContext, db_user, text: str, filename: str) -> None:
    await state.clear()
    if not (text or "").strip():
        await message.answer("❌ Nội dung trống.", reply_markup=back_only("admin:accounts:0"))
        return
    await message.answer("🤖 <i>AI đang đọc file…</i>", parse_mode="HTML")
    extracted = await ai_service.extract_accounts(text)
    if not extracted.get("ok"):
        await message.answer(
            "❌ " + esc(" · ".join(extracted.get("errors") or ["Không đọc được file."])),
            parse_mode="HTML",
            reply_markup=back_only("admin:accounts:0"),
        )
        return
    result = await shop_service.import_ai_accounts(extracted["records"])
    errors = list(extracted.get("errors") or []) + list(result["errors"])
    result = dict(result)
    result["errors"] = errors
    if result["created"]:
        await log_action(
            "account", f"Admin {db_user.id} nhập {result['created']} acc bằng AI từ {filename or 'tin nhắn'}"
        )
    head = (
        f"  🤖 AI đọc: <b>{len(extracted['records'])}</b> mục "
        f"({extracted.get('chunks', 1)} phần)\n"
    )
    await message.answer(
        head + _summary("KẾT QUẢ AI ĐỌC FILE", result),
        parse_mode="HTML",
        reply_markup=with_nav(
            [[InlineKeyboardButton(text="🛍 Xem kho acc", callback_data="admin:accounts:0")]],
            "vi",
            back="admin:accounts:0",
        ),
    )


@router.message(AdminValueForm.ai_import, F.document)
async def on_ai_import_file(message: Message, state: FSMContext, db_user) -> None:
    document = message.document
    if document is None:
        return
    if (document.file_size or 0) > IMPORT_MAX_BYTES:
        await message.answer(f"❌ File quá lớn (tối đa {IMPORT_MAX_BYTES // 1000} KB). Hãy chia nhỏ file.")
        return
    buffer = io.BytesIO()
    try:
        await message.bot.download(document, destination=buffer)
    except Exception:
        await message.answer("❌ Không tải được file, thử gửi lại.")
        return
    text = buffer.getvalue().decode("utf-8-sig", errors="replace")
    await _finish_ai_import(message, state, db_user, text, document.file_name or "import")


@router.message(AdminValueForm.ai_import, F.text)
async def on_ai_import_text(message: Message, state: FSMContext, db_user) -> None:
    await _finish_ai_import(message, state, db_user, message.text or "", "paste.txt")


@router.message(AdminValueForm.ai_import)
async def on_ai_import_other(message: Message, db_user) -> None:
    await message.answer(
        "📥 Hãy gửi file .txt/.csv/.json hoặc dán nội dung acc dạng văn bản.",
        reply_markup=back_only("admin:accounts:0"),
    )


# --------------------------------------------------------------------------- orders
@router.callback_query(F.data.startswith("admin:orders:"))
async def on_orders(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    try:
        page = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        page = 0
    async with session_scope() as session:
        total = int((await session.execute(select(func.count()).select_from(Order))).scalar() or 0)
        orders = (
            await session.execute(
                select(Order).order_by(Order.created_at.desc()).offset(page * PER_PAGE).limit(PER_PAGE)
            )
        ).scalars().all()
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    await render(callback, f"🧾 <b>ĐƠN HÀNG</b> ({total})", orders_admin(list(orders), page, pages))


@router.callback_query(F.data.startswith("admin:order:"))
async def on_order(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    order_id = int(callback.data.split(":")[2])
    async with session_scope() as session:
        order = await session.get(Order, order_id)
        if order is None:
            await render(callback, "❌ Không tìm thấy đơn.", back_only("admin:orders:0"))
            return
        data = (
            order.id,
            order.user_id,
            order.account_code,
            order.price,
            order.status,
            order.warranty_until,
            order.created_at,
            order.note,
        )
    lines = [
        f"🧾 <b>ĐƠN #{data[0]}</b>",
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰",
        f"• Người mua: <code>{data[1]}</code>",
        f"• Acc: <b>{data[2]}</b>",
        f"• Giá: <b>{fmt_vnd(data[3])}</b>",
        f"• Trạng thái: {data[4]}",
        f"• Ngày mua: {data[6]:%d/%m/%Y %H:%M}",
    ]
    if data[5]:
        lines.append(f"• Bảo hành: {data[5]:%d/%m/%Y}")
    text = "\n".join(lines)
    if data[7]:
        text += f"\n• Ghi chú: {esc(data[7])}"
    await render(callback, text, order_admin(order_id))


@router.callback_query(F.data.startswith("admin:refund:"))
async def on_refund(callback: CallbackQuery, db_user) -> None:
    order_id = int(callback.data.split(":")[2])
    order = await shop_service.refund_order(order_id, db_user.id, "Admin hoàn tiền")
    if order is None:
        await answer(callback, "Không hoàn tiền được.", alert=True)
        return
    await log_action("order", f"Admin {db_user.id} hoàn tiền đơn {order_id}")
    await answer(callback, "Đã hoàn tiền")
    try:
        await callback.bot.send_message(
            order.user_id,
            f"💰 Đơn #{order.id} ({order.account_code}) đã được hoàn tiền <b>{fmt_vnd(order.price)}</b>.",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await on_order(callback, db_user)


@router.callback_query(F.data.startswith("admin:complete:"))
async def on_complete(callback: CallbackQuery, db_user) -> None:
    order_id = int(callback.data.split(":")[2])
    order = await shop_service.complete_order(order_id)
    if order is None:
        await answer(callback, "Không tìm thấy đơn", alert=True)
        return
    await log_action("order", f"Admin {db_user.id} hoàn tất đơn {order_id}")
    await answer(callback, "Đã hoàn tất")
    await on_order(callback, db_user)


@router.callback_query(F.data.startswith("admin:ordernote:"))
async def on_order_note(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    order_id = int(callback.data.split(":")[2])
    await state.set_state(AdminValueForm.note)
    await state.update_data(note_order=order_id)
    await render(callback, "📝 Nhập ghi chú cho đơn:", back_only(f"admin:order:{order_id}"))


@router.message(AdminValueForm.note, F.text)
async def on_order_note_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    order_id = int(data.get("note_order", 0))
    note = (message.text or "").strip()
    await state.clear()
    if not note:
        await message.answer("❌ Ghi chú trống.")
        return
    await shop_service.set_order_note(order_id, note)
    await log_action("order", f"Admin {db_user.id} ghi chú đơn {order_id}")
    await message.answer("✅ Đã lưu ghi chú.")
