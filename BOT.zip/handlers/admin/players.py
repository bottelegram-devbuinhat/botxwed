"""Admin player management: search, profile, balance adjustments, ban, VIP."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select

from database.models import User
from database.session import session_scope
from keyboards.admin import user_admin, users_list
from keyboards.common import back_only
from services import casino_service
from services import wallet_service as wallet
from utils.logs import log_action
from utils.money import fmt_coin, fmt_vnd, parse_amount, signed

from handlers.states import AdminForm, AdminValueForm
from handlers.ui import answer, esc, render, window

router = Router(name="admin_players")

PER_PAGE = 8
REASONS = {
    "event": "🎉 Thưởng sự kiện",
    "refund": "🔄 Hoàn tiền lỗi",
    "compensation": "🎁 Đền bù",
    "other": "📝 Khác",
}


async def _show_user(event, user_id: int) -> None:
    user = await wallet.get_user(user_id)
    if user is None:
        await render(event, "❌ Không tìm thấy người dùng.", back_only("admin:players:0"))
        return
    text = (
        f"👤 <b>NGƯỜI CHƠI {user.id}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• Tên: <b>{esc(user.full_name)}</b>\n"
        f"• Username: @{esc(user.username) if user.username else '—'}\n"
        f"• Số dư ví: <b>{fmt_vnd(user.shop_balance)}</b>\n"
        f"• Xu casino: <b>{fmt_coin(user.coins)}</b>\n"
        f"• VIP: <b>{user.vip_level}</b>\n"
        f"• Tổng nạp: {fmt_vnd(user.total_deposited)}\n"
        f"• Tổng mua: {fmt_vnd(user.total_purchased)}\n"
        f"• Chuỗi điểm danh: {user.checkin_streak}\n"
        f"• Trạng thái: {'🚫 Bị khoá' if user.is_banned else '✅ Hoạt động'}"
        f"{' · 🔇 Mute casino' if user.is_muted_casino else ''}\n"
        f"• Ngày tạo: {user.created_at:%d/%m/%Y %H:%M}\n"
        f"• Người giới thiệu: <code>{user.referrer_id or '—'}</code>"
    )
    await render(event, text, user_admin(user.id))


@router.callback_query(F.data.startswith("admin:players:"))
async def on_players(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    try:
        page = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        page = 0
    async with session_scope() as session:
        total = int((await session.execute(select(func.count()).select_from(User))).scalar() or 0)
        users = (
            await session.execute(
                select(User).order_by(User.created_at.desc()).offset(max(0, page) * PER_PAGE).limit(PER_PAGE)
            )
        ).scalars().all()
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    await render(
        callback,
        f"👥 <b>NGƯỜI CHƠI</b> ({total})\nBấm để xem và quản lý:",
        users_list(list(users), page, pages),
    )


@router.callback_query(F.data.startswith("admin:user:"))
async def on_user(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    await _show_user(callback, int(callback.data.split(":")[2]))


@router.callback_query(F.data == "admin:finduser")
async def on_find_user(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    await state.set_state(AdminValueForm.find_user)
    await render(callback, "🔎 Nhập ID Telegram của người chơi:", back_only("admin:players:0"))


@router.message(AdminValueForm.find_user, F.text)
async def on_find_user_text(message: Message, state: FSMContext, db_user) -> None:
    raw = (message.text or "").strip()
    await state.clear()
    if not raw.isdigit():
        await message.answer("❌ ID phải là dãy số.")
        return
    await _show_user(message, int(raw))


@router.callback_query(F.data.startswith("admin:adj:"))
async def on_adjust(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    user_id, currency, sign = parts[2], parts[3], parts[4]
    presets = [10000, 50000, 100000, 500000] if currency == "vnd" else [1000, 5000, 10000, 50000]
    rows = [
        [
            InlineKeyboardButton(
                text=fmt_vnd(value) if currency == "vnd" else fmt_coin(value),
                callback_data=f"admin:adjamt:{user_id}:{currency}:{sign}:{value}",
            )
            for value in presets[index : index + 2]
        ]
        for index in range(0, len(presets), 2)
    ]
    rows.append([InlineKeyboardButton(text="✏️ Nhập số khác", callback_data=f"admin:adjcustom:{user_id}:{currency}:{sign}")])
    label = "cộng" if sign == "1" else "trừ"
    unit = "tiền" if currency == "vnd" else "xu"
    await render(
        callback,
        f"💰 Chọn số {unit} cần {label} cho <code>{user_id}</code>:",
        InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data.startswith("admin:adjcustom:"))
async def on_adjust_custom(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    await state.set_state(AdminValueForm.adjust)
    await state.update_data(adj_user=parts[2], adj_currency=parts[3], adj_sign=parts[4])
    await render(callback, "✏️ Nhập số tiền/xu:", back_only(f"admin:user:{parts[2]}"))


@router.message(AdminValueForm.adjust, F.text)
async def on_adjust_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    amount = parse_amount(message.text or "")
    await state.clear()
    if not amount:
        await message.answer("❌ Số không hợp lệ.")
        return
    await _reason_kb(message, data["adj_user"], data["adj_currency"], data["adj_sign"], amount)


def _reason_kb_text(user_id: str, currency: str, sign: str, amount: int) -> tuple[str, InlineKeyboardMarkup]:
    unit = fmt_vnd(amount) if currency == "vnd" else fmt_coin(amount)
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"admin:adjdo:{user_id}:{currency}:{sign}:{amount}:{key}")]
        for key, label in REASONS.items()
    ]
    rows.append([InlineKeyboardButton(text="❌ Huỷ", callback_data=f"admin:user:{user_id}")])
    action = "cộng" if sign == "1" else "trừ"
    return f"📝 Chọn lý do {action} <b>{unit}</b>:", InlineKeyboardMarkup(inline_keyboard=rows)


async def _reason_kb(event, user_id, currency, sign, amount) -> None:
    text, kb = _reason_kb_text(user_id, currency, sign, amount)
    await render(event, text, kb)


@router.callback_query(F.data.startswith("admin:adjamt:"))
async def on_adjust_amount(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    parts = callback.data.split(":")
    await _reason_kb(callback, parts[2], parts[3], parts[4], int(parts[5]))


@router.callback_query(F.data.startswith("admin:adjdo:"))
async def on_adjust_do(callback: CallbackQuery, db_user) -> None:
    parts = callback.data.split(":")
    user_id, currency, sign, amount, reason = parts[2], parts[3], parts[4], int(parts[5]), parts[6]
    if int(user_id) == db_user.id:
        await answer(callback, "Không thể tự điều chỉnh số dư của mình", alert=True)
        return
    note = REASONS.get(reason, "Điều chỉnh")
    if sign == "1":
        ok = await wallet.add_balance(int(user_id), amount, "admin_add", currency, note)
    else:
        ok = await wallet.spend(int(user_id), amount, "admin_sub", currency, note)
    if not ok:
        await answer(callback, "Không thực hiện được (kiểm tra số dư).", alert=True)
        return
    await answer(callback, "Đã cập nhật số dư")
    await log_action(
        "balance",
        f"Admin {db_user.id} {'cộng' if sign == '1' else 'trừ'} {amount} {currency} cho {user_id} ({note})",
    )
    updated = await wallet.get_user(int(user_id))
    unit = fmt_vnd(amount) if currency == "vnd" else fmt_coin(amount)
    try:
        await callback.bot.send_message(
            int(user_id),
            f"💰 <b>Biến động số dư</b>\n• {'+' if sign == '1' else '-'}{unit}\n"
            f"• Lý do: {note}\n• Số dư mới: "
            f"{fmt_vnd(updated.shop_balance) if currency == 'vnd' else fmt_coin(updated.coins)}",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await _show_user(callback, int(user_id))


@router.callback_query(F.data.startswith("admin:ban:"))
async def on_ban(callback: CallbackQuery, db_user) -> None:
    user_id = int(callback.data.split(":")[2])
    user = await wallet.get_user(user_id)
    if user is None:
        await answer(callback, "Không tìm thấy user", alert=True)
        return
    await wallet.update_user(user_id, is_banned=not user.is_banned)
    await log_action("ban", f"Admin {db_user.id} đổi ban {user_id} -> {not user.is_banned}")
    await answer(callback, "Đã cập nhật")
    await _show_user(callback, user_id)


@router.callback_query(F.data.startswith("admin:mute:"))
async def on_mute(callback: CallbackQuery, db_user) -> None:
    user_id = int(callback.data.split(":")[2])
    user = await wallet.get_user(user_id)
    if user is None:
        await answer(callback, "Không tìm thấy user", alert=True)
        return
    await wallet.update_user(user_id, is_muted_casino=not user.is_muted_casino)
    await log_action("mute", f"Admin {db_user.id} mute casino {user_id}")
    await answer(callback, "Đã cập nhật")
    await _show_user(callback, user_id)


@router.callback_query(F.data.startswith("admin:vip:"))
async def on_vip(callback: CallbackQuery, db_user) -> None:
    user_id = int(callback.data.split(":")[2])
    user = await wallet.get_user(user_id)
    if user is None:
        await answer(callback, "Không tìm thấy user", alert=True)
        return
    new_level = (user.vip_level + 1) % 6
    await wallet.update_user(user_id, vip_level=new_level)
    await log_action("vip", f"Admin {db_user.id} set VIP {user_id} -> {new_level}")
    await answer(callback, f"VIP → {new_level}")
    await _show_user(callback, user_id)


@router.callback_query(F.data.startswith("admin:msg:"))
async def on_message_user(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    user_id = int(callback.data.split(":")[2])
    await state.set_state(AdminForm.message_user)
    await state.update_data(target_user=user_id)
    await render(callback, f"✉️ Nhập tin nhắn gửi tới <code>{user_id}</code>:", back_only(f"admin:user:{user_id}"))


@router.message(AdminForm.message_user, F.text)
async def on_message_user_send(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    user_id = int(data.get("target_user", 0))
    text = (message.text or "").strip()
    await state.clear()
    try:
        await message.bot.send_message(user_id, text, parse_mode="HTML")
    except Exception as exc:
        await message.answer(f"❌ Không gửi được: {esc(exc)}")
        return
    await log_action("message", f"Admin {db_user.id} nhắn {user_id}")
    await message.answer("✅ Đã gửi.")


@router.callback_query(F.data.startswith("admin:history:"))
async def on_history(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    user_id = int(callback.data.split(":")[2])
    transactions = await wallet.transactions_of(user_id, limit=10)
    games = await casino_service.game_history(user_id, limit=5)
    lines = [f"📜 <b>LỊCH SỬ {user_id}</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰", "<b>Giao dịch:</b>"]
    if not transactions:
        lines.append("<i>Chưa có giao dịch.</i>")
    for item in transactions:
        lines.append(f"• {item.created_at:%d/%m %H:%M} · {signed(item.amount, item.currency)} · {esc(item.note) or item.kind}")
    lines.append("\n<b>Casino:</b>")
    if not games:
        lines.append("<i>Chưa chơi.</i>")
    for game in games:
        lines.append(
            f"• {game.created_at:%d/%m %H:%M} · {game.game} · cược {fmt_coin(game.bet)} · "
            f"{'+' if game.payout > game.bet else ''}{fmt_coin(game.payout - game.bet)}"
        )
    await render(callback, "\n".join(lines), back_only(f"admin:user:{user_id}"))
