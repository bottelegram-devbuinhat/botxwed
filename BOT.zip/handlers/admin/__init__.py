"""Admin routers, protected by an admin-only filter."""

from aiogram import Router
from aiogram.filters import BaseFilter
from aiogram.types import TelegramObject

from utils.permissions import is_admin


class AdminFilter(BaseFilter):
    async def __call__(self, event: TelegramObject, **kwargs) -> bool:
        user = getattr(event, "from_user", None)
        if user is None:
            return False
        return await is_admin(user.id)


from handlers.admin import ai_admin, emoji_admin, finance, panel, players, shop_admin  # noqa: E402

router = Router(name="admin")
for sub_router in (
    panel.router,
    players.router,
    shop_admin.router,
    finance.router,
    emoji_admin.router,
    ai_admin.router,
):
    sub_router.message.filter(AdminFilter())
    sub_router.callback_query.filter(AdminFilter())
    router.include_router(sub_router)

__all__ = ["router"]
