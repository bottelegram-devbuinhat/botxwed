"""Admin tooling for premium (animated) Telegram emoji.

The bot ships a catalog of free animated emoji collected from public packs
(``assets/emoji.json``). Telegram only renders custom emoji when the bot owns a
Fragment username or when the bot owner has Telegram Premium, so this module
lets an admin check the catalog, bind new emoji ids from any pack, and test the
result before relying on it.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from keyboards.common import back_only
from utils import cards, emoji

from handlers.ui import answer, esc, render

router = Router(name="admin_emoji")

PREVIEW_KEYS = [
    "coin",
    "gift",
    "cart",
    "money",
    "card",
    "trophy",
    "gem",
    "crown",
    "fire",
    "star",
    "check",
    "cross",
    "slot",
    "dice",
    "user",
    "sparkle",
]

HELP = (
    f"{cards.title('sparkle', 'EMOJI ĐỘNG (PREMIUM)')}"
    "Trạng thái: <b>{state}</b>\n"
    f"{cards.LINE}\n"
    "Bot dùng bộ emoji động miễn phí thu thập từ các pack công khai "
    "(RestrictedEmoji, tgmacicons, vector_icons_by_fStikBot, NewsEmoji...).\n\n"
    "<b>Cách hoạt động</b>\n"
    "  • Có Telegram Premium hoặc username Fragment → hiển thị emoji động.\n"
    "  • Không có → tự động hiển thị emoji Unicode, bot vẫn chạy bình thường.\n\n"
    "<b>Lệnh</b>\n"
    "  • <code>/emoji</code> — xem danh sách &amp; trạng thái\n"
    "  • <code>/emoji on</code> / <code>/emoji off</code> — bật/tắt tạm thời\n"
    "  • <code>/setemoji coin</code> — trả lời tin nhắn chứa emoji động để gán id\n"
    "  • <code>/testemoji</code> — gửi bảng thử\n"
    "  • <code>/addpack NewsEmoji BirthdayCollection</code> — nạp emoji động từ pack\n"
)


def _panel_text() -> str:
    state = "🟢 đang bật" if emoji.is_enabled() else "🔴 đang tắt"
    return HELP.format(state=state)


def _catalog_lines(limit: int = 40) -> list[str]:
    entries = emoji.catalog()
    lines = [cards.title("sparkle", f"DANH SÁCH EMOJI ({len(entries)})")]
    for key, meta in list(entries.items())[:limit]:
        mark = "🟢" if meta.get("id") else "⚪"
        document_id = meta.get("id") or "chưa có id"
        lines.append(f"  {mark} [[{key}]] <code>{key}</code> · <code>{esc(document_id)}</code>")
    if len(entries) > limit:
        lines.append(f"  … và {len(entries) - limit} mục khác")
    return lines


@router.message(Command("emoji"))
async def cmd_emoji(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    argument = parts[1].strip().lower() if len(parts) > 1 else ""
    if argument in ("on", "off"):
        emoji.set_enabled(argument == "on")
        await message.answer(
            f"{cards.title('sparkle', 'EMOJI ĐỘNG')}"
            f"Đã {'bật' if argument == 'on' else 'tắt'} emoji động cho phiên này.",
            parse_mode="HTML",
        )
        return
    text = _panel_text() + "\n" + "\n".join(_catalog_lines())
    await message.answer(text, parse_mode="HTML", reply_markup=back_only("admin:panel"))


@router.message(Command("testemoji"))
async def cmd_test(message: Message) -> None:
    lines = [cards.title("sparkle", "THỬ EMOJI ĐỘNG")]
    for key in PREVIEW_KEYS:
        lines.append(f"  [[{key}]] <code>{key}</code>")
    lines.append("")
    lines.append(cards.quote("Nếu các emoji trên chỉ là hình tĩnh → bot chưa có quyền emoji động."))
    await message.answer("\n".join(lines), parse_mode="HTML")


@router.message(Command("setemoji"))
async def cmd_setemoji(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer(
            "Cách dùng: trả lời tin nhắn có emoji động rồi gõ <code>/setemoji coin</code>",
            parse_mode="HTML",
        )
        return
    key = parts[1].strip().lower()
    target = message.reply_to_message
    if target is None:
        await message.answer("Hãy <b>trả lời</b> tin nhắn chứa emoji động cần gán.", parse_mode="HTML")
        return
    found = emoji.custom_emoji_ids(target)
    if not found:
        await message.answer(
            "Không tìm thấy emoji động trong tin nhắn được trả lời. Hãy chuyển tiếp một emoji động "
            "từ pack bạn muốn dùng rồi thử lại.",
            parse_mode="HTML",
        )
        return
    document_id, fallback = found[0]
    if not emoji.set_emoji(key, document_id, fallback):
        await message.answer("❌ Không lưu được. Id phải là dãy số.", parse_mode="HTML")
        return
    await message.answer(
        f"{cards.title('check', 'ĐÃ GÁN EMOJI')}"
        f"  [[{key}]] <code>{key}</code> → <code>{esc(document_id)}</code>\n"
        f"{cards.note('Xem lại bằng /testemoji.')}",
        parse_mode="HTML",
    )


@router.message(Command("addpack"))
async def cmd_addpack(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer(
            f"{cards.title('sparkle', 'NẠP PACK EMOJI ĐỘNG')}"
            "Cách dùng:\n<code>/addpack NewsEmoji</code>\n"
            "<code>/addpack https://t.me/addemoji/BirthdayCollection</code>\n\n"
            "Bot đọc pack qua Bot API, ghép id động vào đúng emoji đang dùng trong giao diện "
            "(💎 ✨ 🔥 …) rồi lưu vào <code>data/emoji.json</code>.",
            parse_mode="HTML",
        )
        return
    names = [item for item in parts[1].replace(",", " ").split() if item]
    lines = [cards.title("sparkle", "NẠP PACK EMOJI ĐỘNG")]
    for raw in names[:5]:
        result = await emoji.import_pack(message.bot, raw)
        if not result["ok"]:
            lines.append(f"  ❌ <b>{esc(result['name'] or raw)}</b>: {esc(result['error'])}")
            continue
        lines.append(
            f"  ✅ <b>{esc(result['name'])}</b> · {result['stickers']} sticker · "
            f"ghép được <b>{result['updated']}</b> emoji"
        )
        if result["keys"]:
            lines.append(f"     <code>{esc(', '.join(result['keys']))}</code>")
    lines.append("")
    lines.append(cards.note("Emoji động chỉ hiển thị khi bot có quyền custom emoji; nếu không sẽ tự dùng emoji thường."))
    await message.answer("\n".join(lines), parse_mode="HTML", reply_markup=back_only("admin:panel"))


@router.callback_query(F.data == "admin:emoji")
async def on_panel(callback: CallbackQuery) -> None:
    await answer(callback)
    await render(callback, _panel_text() + "\n" + "\n".join(_catalog_lines(18)), back_only("admin:panel"))
