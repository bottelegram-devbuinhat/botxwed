"""Admin finance approvals (deposits, withdrawals) and support tickets."""

from __future__ import annotations

from datetime import datetime

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from database.models import Ticket, TicketMessage
from database.session import session_scope
from keyboards.admin import (
    deposit_admin,
    deposits_admin,
    ticket_admin,
    tickets_admin,
    withdrawal_admin,
    withdrawals_admin,
)
from keyboards.common import back_only
from services import wallet_service as wallet
from utils.logs import log_action
from utils.money import fmt_vnd

from handlers.states import AdminForm
from handlers.ui import answer, esc, render

router = Router(name="admin_finance")

TICKET_STATUS = {"new": "🆕 Mới", "in_progress": "🔄 Đang xử lý", "closed": "✅ Đã đóng"}
TICKET_TYPES = {"deposit": "💳 Nạp", "account": "🛒 Acc", "warranty": "🛡 Bảo hành", "bug": "🐞 Lỗi", "other": "📝 Khác"}


# --------------------------------------------------------------------------- deposits
@router.callback_query(F.data.startswith("admin:deps:"))
async def on_deposits(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    deposits = await wallet.pending_deposits(20)
    text = "💳 <b>NẠP TIỀN CHỜ DUYỆT</b>\nBấm vào yêu cầu để xem chi tiết:"
    if not deposits:
        text += "\n<i>Không có yêu cầu nào.</i>"
    await render(callback, text, deposits_admin(deposits))


@router.callback_query(F.data.startswith("admin:dep:"))
async def on_deposit(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    deposit_id = int(callback.data.split(":")[2])
    from database.models import Deposit

    async with session_scope() as session:
        deposit = await session.get(Deposit, deposit_id)
        if deposit is None:
            await render(callback, "❌ Không tìm thấy yêu cầu.", back_only("admin:deps:0"))
            return
        data = (
            deposit.id,
            deposit.user_id,
            deposit.amount,
            deposit.method,
            deposit.status,
            deposit.code,
            deposit.receipt_file_id,
            deposit.created_at,
        )
    user = await wallet.get_user(data[1])
    text = (
        f"💳 <b>YÊU CẦU NẠP #{data[0]}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• User: <code>{data[1]}</code> ({esc(user.full_name) if user else '—'})\n"
        f"• Số tiền: <b>{fmt_vnd(data[2])}</b>\n"
        f"• Phương thức: {data[3]}\n"
        f"• Mã: <code>{data[5]}</code>\n"
        f"• Trạng thái: {data[4]}\n"
        f"• Tạo lúc: {data[7]:%d/%m/%Y %H:%M}\n"
        f"• Biên lai: {'✅ có' if data[6] else '❌ chưa gửi'}"
    )
    kb = deposit_admin(data[0]) if data[4] == "pending" else back_only("admin:deps:0")
    await render(callback, text, kb)
    if data[6]:
        try:
            await callback.message.answer_photo(data[6], caption="🧾 Biên lai")
        except Exception:
            pass


@router.callback_query(F.data.startswith("admin:depok:"))
async def on_deposit_ok(callback: CallbackQuery, db_user) -> None:
    deposit_id = int(callback.data.split(":")[2])
    deposit = await wallet.approve_deposit(deposit_id, db_user.id)
    if deposit is None:
        await answer(callback, "Không duyệt được (đã xử lý?).", alert=True)
        return
    await answer(callback, "Đã duyệt nạp tiền")
    await log_action("deposit", f"Admin {db_user.id} duyệt nạp #{deposit_id} {deposit.amount}")
    user = await wallet.get_user(deposit.user_id)
    try:
        await callback.bot.send_message(
            deposit.user_id,
            f"✅ <b>Nạp tiền thành công</b>\n• Số tiền: <b>{fmt_vnd(deposit.amount)}</b>\n"
            f"• Số dư mới: <b>{fmt_vnd(user.shop_balance if user else 0)}</b>",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await on_deposits(callback, db_user)


@router.callback_query(F.data.startswith("admin:depno:"))
async def on_deposit_no(callback: CallbackQuery, db_user) -> None:
    deposit_id = int(callback.data.split(":")[2])
    deposit = await wallet.reject_deposit(deposit_id, db_user.id, "Admin từ chối")
    if deposit is None:
        await answer(callback, "Không từ chối được.", alert=True)
        return
    await answer(callback, "Đã từ chối")
    await log_action("deposit", f"Admin {db_user.id} từ chối nạp #{deposit_id}")
    try:
        await callback.bot.send_message(
            deposit.user_id,
            f"❌ Yêu cầu nạp <b>{fmt_vnd(deposit.amount)}</b> bị từ chối. Liên hệ hỗ trợ nếu cần.",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await on_deposits(callback, db_user)


# --------------------------------------------------------------------------- withdrawals
@router.callback_query(F.data.startswith("admin:wds:"))
async def on_withdrawals(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    withdrawals = await wallet.pending_withdrawals(20)
    text = "💸 <b>RÚT TIỀN CHỜ DUYỆT</b>\nBấm vào yêu cầu để xem chi tiết:"
    if not withdrawals:
        text += "\n<i>Không có yêu cầu nào.</i>"
    await render(callback, text, withdrawals_admin(withdrawals))


@router.callback_query(F.data.startswith("admin:wd:"))
async def on_withdrawal(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    withdrawal_id = int(callback.data.split(":")[2])
    from database.models import Withdrawal

    async with session_scope() as session:
        withdrawal = await session.get(Withdrawal, withdrawal_id)
        if withdrawal is None:
            await render(callback, "❌ Không tìm thấy yêu cầu.", back_only("admin:wds:0"))
            return
        data = (
            withdrawal.id,
            withdrawal.user_id,
            withdrawal.amount,
            withdrawal.bank,
            withdrawal.account_number,
            withdrawal.account_name,
            withdrawal.status,
            withdrawal.created_at,
        )
    text = (
        f"💸 <b>YÊU CẦU RÚT #{data[0]}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"• User: <code>{data[1]}</code>\n"
        f"• Số tiền: <b>{fmt_vnd(data[2])}</b>\n"
        f"• Ngân hàng: <b>{esc(data[3])}</b>\n"
        f"• STK: <code>{esc(data[4])}</code>\n"
        f"• Chủ TK: <b>{esc(data[5])}</b>\n"
        f"• Trạng thái: {data[6]}\n"
        f"• Tạo lúc: {data[7]:%d/%m/%Y %H:%M}"
    )
    kb = withdrawal_admin(data[0]) if data[6] == "pending" else back_only("admin:wds:0")
    await render(callback, text, kb)


@router.callback_query(F.data.startswith("admin:wdok:"))
async def on_withdrawal_ok(callback: CallbackQuery, db_user) -> None:
    withdrawal_id = int(callback.data.split(":")[2])
    withdrawal = await wallet.approve_withdraw(withdrawal_id, db_user.id)
    if withdrawal is None:
        await answer(callback, "Không duyệt được.", alert=True)
        return
    await answer(callback, "Đã duyệt rút tiền")
    await log_action("withdraw", f"Admin {db_user.id} duyệt rút #{withdrawal_id} {withdrawal.amount}")
    try:
        await callback.bot.send_message(
            withdrawal.user_id,
            f"🎉 <b>Rút tiền thành công</b>\n• Số tiền: <b>{fmt_vnd(withdrawal.amount)}</b>\n"
            f"• Về: {esc(withdrawal.bank)} · {esc(withdrawal.account_number)}",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await on_withdrawals(callback, db_user)


@router.callback_query(F.data.startswith("admin:wdno:"))
async def on_withdrawal_no(callback: CallbackQuery, db_user) -> None:
    withdrawal_id = int(callback.data.split(":")[2])
    withdrawal = await wallet.reject_withdraw(withdrawal_id, db_user.id, "Admin từ chối")
    if withdrawal is None:
        await answer(callback, "Không từ chối được.", alert=True)
        return
    await answer(callback, "Đã từ chối và hoàn tiền")
    await log_action("withdraw", f"Admin {db_user.id} từ chối rút #{withdrawal_id}")
    try:
        await callback.bot.send_message(
            withdrawal.user_id,
            f"❌ Yêu cầu rút <b>{fmt_vnd(withdrawal.amount)}</b> bị từ chối. Tiền đã được hoàn vào ví.",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await on_withdrawals(callback, db_user)


# --------------------------------------------------------------------------- tickets
async def _ticket_thread(ticket_id: int, limit: int = 20):
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None:
            return None, []
        messages = (
            await session.execute(
                select(TicketMessage)
                .where(TicketMessage.ticket_id == ticket_id)
                .order_by(TicketMessage.created_at.asc())
                .limit(limit)
            )
        ).scalars().all()
        return ticket, list(messages)


@router.callback_query(F.data.startswith("admin:tickets:"))
async def on_tickets(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    async with session_scope() as session:
        tickets = (
            await session.execute(select(Ticket).order_by(Ticket.updated_at.desc()).limit(20))
        ).scalars().all()
    text = "🆘 <b>TICKET HỖ TRỢ</b>\nBấm vào ticket để xem và trả lời:"
    if not tickets:
        text += "\n<i>Không có ticket nào.</i>"
    await render(callback, text, tickets_admin(list(tickets)))


@router.callback_query(F.data.startswith("admin:ticket:"))
async def on_ticket(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    ticket_id = int(callback.data.split(":")[2])
    ticket, messages = await _ticket_thread(ticket_id)
    if ticket is None:
        await render(callback, "❌ Không tìm thấy ticket.", back_only("admin:tickets:0"))
        return
    lines = [
        f"🆘 <b>TICKET #{ticket.id}</b>",
        f"• User: <code>{ticket.user_id}</code>",
        f"• Loại: {TICKET_TYPES.get(ticket.type, ticket.type)}",
        f"• Trạng thái: {TICKET_STATUS.get(ticket.status, ticket.status)}",
        f"• Tiêu đề: {esc(ticket.subject)}",
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰",
    ]
    for msg in messages:
        who = "🛠 Admin" if msg.is_admin else "👤 User"
        lines.append(f"{who} · {msg.created_at:%d/%m %H:%M}\n{esc(msg.text)}")
        if len("\n".join(lines)) > 3200:
            lines.append("…")
            break
    await render(callback, "\n".join(lines), ticket_admin(ticket.id, ticket.status))


@router.callback_query(F.data.startswith("admin:treply:"))
async def on_ticket_reply(callback: CallbackQuery, state: FSMContext, db_user) -> None:
    await answer(callback)
    ticket_id = int(callback.data.split(":")[2])
    await state.set_state(AdminForm.reply_ticket)
    await state.update_data(reply_ticket=ticket_id)
    await render(callback, "💬 Nhập nội dung trả lời cho user:", back_only(f"admin:ticket:{ticket_id}"))


@router.message(AdminForm.reply_ticket, F.text)
async def on_ticket_reply_text(message: Message, state: FSMContext, db_user) -> None:
    data = await state.get_data()
    ticket_id = int(data.get("reply_ticket", 0))
    text = (message.text or "").strip()
    await state.clear()
    if not text:
        await message.answer("❌ Nội dung trống.")
        return
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None:
            await message.answer("❌ Không tìm thấy ticket.")
            return
        ticket.status = "in_progress"
        ticket.assigned_to = db_user.id
        ticket.updated_at = datetime.utcnow()
        session.add(TicketMessage(ticket_id=ticket_id, sender_id=db_user.id, is_admin=True, text=text))
        user_id = ticket.user_id
    await log_action("ticket", f"Admin {db_user.id} trả lời ticket {ticket_id}")
    try:
        await message.bot.send_message(
            user_id,
            f"💬 <b>Phản hồi cho ticket #{ticket_id}</b>\n{esc(text)}\n\n"
            f"<i>Trả lời bằng cách mở ticket trong 🆘 Hỗ trợ.</i>",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await message.answer("✅ Đã gửi phản hồi.")


@router.callback_query(F.data.startswith("admin:tclose:"))
async def on_ticket_close(callback: CallbackQuery, db_user) -> None:
    await answer(callback)
    ticket_id = int(callback.data.split(":")[2])
    async with session_scope() as session:
        ticket = await session.get(Ticket, ticket_id)
        if ticket is None:
            await answer(callback, "Không tìm thấy ticket", alert=True)
            return
        ticket.status = "closed"
        ticket.updated_at = datetime.utcnow()
        user_id = ticket.user_id
    await log_action("ticket", f"Admin {db_user.id} đóng ticket {ticket_id}")
    try:
        await callback.bot.send_message(
            user_id,
            f"✅ Ticket #{ticket_id} đã được đóng. Cảm ơn bạn đã liên hệ hỗ trợ!",
        )
    except Exception:
        pass
    await on_ticket(callback, db_user)
