#!/usr/bin/env python3
"""Patch BOTLQ/main.py (5 cho) va keyboards/shop.py (1 nut) cho ban merge.

Chay trong thu muc bot (vd /home/np3051uw4n/BOTLQ):
    python3 patch_main.py
Hoac chi ro thu muc bot:
    python3 patch_main.py /home/np3051uw4n/BOTLQ

Idempotent: chay lai lan 2 se bao "da co" va khong sua gi them.
Khong can token/key. Chi sua main.py va keyboards/shop.py.
"""
import sys
from pathlib import Path

BOT_DIR = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
MAIN = BOT_DIR / "main.py"
SHOP_KB = BOT_DIR / "keyboards" / "shop.py"


def patch_file(path: Path, label: str, edits):
    """edits: list of (old, new, name). old xuat hien 1 lan thi thay, da co new thi bo qua."""
    if not path.exists():
        print(f"[LOI] Khong thay {path}")
        return False
    text = path.read_text(encoding="utf-8")
    ok = True
    for old, new, name in edits:
        if new in text:
            print(f"  [{label}] {name}: da co, bo qua")
            continue
        if text.count(old) != 1:
            print(f"  [{label}] {name}: LOI — khong tim thay dung 1 cho (tim thay {text.count(old)})")
            ok = False
            continue
        text = text.replace(old, new, 1)
        print(f"  [{label}] {name}: OK")
    if ok:
        path.write_text(text, encoding="utf-8")
    return ok


def main():
    print(f"Bot dir: {BOT_DIR}")
    all_ok = True

    print("== main.py ==")
    all_ok &= patch_file(MAIN, "main.py", [
        (
            "from handlers import ai, guide, leaderboard, profile, rewards, sell, shop, start, support, wallet",
            "from handlers import ai, guide, leaderboard, profile, rewards, sell, shop, shop_merge, start, support, wallet",
            "1. import shop_merge",
        ),
        (
            "from services.payment_service import start_webhook_server",
            "from services.payment_service import start_webhook_server\nfrom services.sepay_poller import start_sepay_poller",
            "2. import sepay_poller",
        ),
        (
            '    BotCommand(command="admin", description="Bảng điều khiển admin"),',
            '    BotCommand(command="admin", description="Bảng điều khiển admin"),\n    BotCommand(command="catalog", description="Danh mục sản phẩm"),',
            "3. lenh /catalog",
        ),
        (
            "    dp.include_router(shop.router)",
            "    dp.include_router(shop.router)\n    dp.include_router(shop_merge.router)",
            "4. router shop_merge",
        ),
        (
            '        log.error("Không mở được webhook server thanh toán: %s", exc)',
            '        log.error("Không mở được webhook server thanh toán: %s", exc)\n\n    poller_task = None\n    try:\n        poller_task = start_sepay_poller(bot)\n    except Exception as exc:  # noqa: BLE001 - SePay poller is optional\n        log.error("Không khởi động được SePay poller: %s", exc)',
            "5a. khoi dong poller",
        ),
        (
            "        await bot.session.close()",
            "        if poller_task is not None:\n            poller_task.cancel()\n        await bot.session.close()",
            "5b. dung poller trong finally",
        ),
    ])

    print("== keyboards/shop.py ==")
    all_ok &= patch_file(SHOP_KB, "shop.py", [
        (
            '        [InlineKeyboardButton(text="🛒 Mua ngay", callback_data=f"shop:buy:{code}")],',
            '        [InlineKeyboardButton(text="🛒 Mua ngay", callback_data=f"shop:buy:{code}")],\n        [InlineKeyboardButton(text="💳 Mua bằng chuyển khoản", callback_data=f"order:acc:{code}")],',
            "nut Mua bang chuyen khoan",
        ),
    ])

    print("XONG." if all_ok else "CO LOI — kiem tra lai cac muc LOI o tren.")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
