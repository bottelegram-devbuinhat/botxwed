"""Database models (SQLAlchemy 2.x, async-friendly)."""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    return datetime.utcnow()


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    full_name: Mapped[str] = mapped_column(String(255), default="")
    language: Mapped[str] = mapped_column(String(5), default="vi")

    shop_balance: Mapped[int] = mapped_column(Integer, default=0)
    # New users start with 100 casino coins (xu) as a welcome bonus.
    coins: Mapped[int] = mapped_column(Integer, default=100)
    vip_level: Mapped[int] = mapped_column(Integer, default=0)

    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    is_muted_casino: Mapped[bool] = mapped_column(Boolean, default=False)
    hide_name: Mapped[bool] = mapped_column(Boolean, default=False)
    notifications: Mapped[bool] = mapped_column(Boolean, default=True)

    referrer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    total_deposited: Mapped[int] = mapped_column(Integer, default=0)
    total_purchased: Mapped[int] = mapped_column(Integer, default=0)

    checkin_streak: Mapped[int] = mapped_column(Integer, default=0)
    last_checkin: Mapped[date | None] = mapped_column(Date, nullable=True)
    last_wheel: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Account(Base):
    __tablename__ = "accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    seller_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    price: Mapped[int] = mapped_column(Integer, default=0)
    rank: Mapped[str] = mapped_column(String(64), default="")
    level: Mapped[int] = mapped_column(Integer, default=0)
    heroes: Mapped[int] = mapped_column(Integer, default=0)
    skins: Mapped[int] = mapped_column(Integer, default=0)
    rare_skins: Mapped[str] = mapped_column(String(255), default="")
    login_type: Mapped[str] = mapped_column(String(32), default="Facebook")
    warranty_days: Mapped[int] = mapped_column(Integer, default=3)
    description: Mapped[str] = mapped_column(Text, default="")
    photos: Mapped[str] = mapped_column(Text, default="[]")  # JSON list of photo URLs/file_ids

    username_enc: Mapped[str] = mapped_column(Text, default="")
    password_enc: Mapped[str] = mapped_column(Text, default="")

    status: Mapped[str] = mapped_column(String(20), default="available", index=True)
    is_hidden: Mapped[bool] = mapped_column(Boolean, default=False)
    views: Mapped[int] = mapped_column(Integer, default=0)

    # Shop layout: "info" = acc bán kèm thông tin đầy đủ, "random" = kho random.
    kind: Mapped[str] = mapped_column(String(12), default="info", index=True)
    category: Mapped[str] = mapped_column(String(32), default="", index=True)
    # Category FK (ported from the repo). The free-text `category` above is kept
    # as a denormalised label for backward compatibility.
    category_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("categories.id"), nullable=True)

    # Full-info fields shown on the account card (mirrors the checker dump).
    uid: Mapped[str] = mapped_column(String(32), default="")
    region: Mapped[str] = mapped_column(String(12), default="VN")
    shells: Mapped[int] = mapped_column(Integer, default=0)
    shells_note: Mapped[str] = mapped_column(String(64), default="")
    email_info: Mapped[str] = mapped_column(String(160), default="")
    phone_info: Mapped[str] = mapped_column(String(80), default="")
    has_pass: Mapped[bool] = mapped_column(Boolean, default=True)
    fb_username: Mapped[str] = mapped_column(String(80), default="")
    fb_uid: Mapped[str] = mapped_column(String(80), default="")
    fb_link: Mapped[str] = mapped_column(String(80), default="")
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    ban_note: Mapped[str] = mapped_column(String(80), default="")
    last_login: Mapped[str] = mapped_column(String(80), default="")
    account_created: Mapped[str] = mapped_column(String(80), default="")
    has_cccd: Mapped[bool] = mapped_column(Boolean, default=False)
    twofa: Mapped[bool] = mapped_column(Boolean, default=False)

    ss_count: Mapped[int] = mapped_column(Integer, default=0)
    splus_count: Mapped[int] = mapped_column(Integer, default=0)
    s_count: Mapped[int] = mapped_column(Integer, default=0)
    evo_count: Mapped[int] = mapped_column(Integer, default=0)
    anime_count: Mapped[int] = mapped_column(Integer, default=0)
    dreamer_count: Mapped[int] = mapped_column(Integer, default=0)
    other_count: Mapped[int] = mapped_column(Integer, default=0)
    skin_lists: Mapped[str] = mapped_column(Text, default="{}")  # JSON {tier: [names]}
    extra: Mapped[str] = mapped_column(Text, default="")

    held_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    held_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    sold_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    account_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("accounts.id"), nullable=True)
    account_code: Mapped[str] = mapped_column(String(16), default="")
    price: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default="completed")
    note: Mapped[str] = mapped_column(Text, default="")
    warranty_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    # --- Direct-order fields (ported from telegram-sales-bot repo) ---
    # order_code: "ORD" + timestamp + random, used as the VietQR transfer content.
    order_code: Mapped[str | None] = mapped_column(String(32), unique=True, nullable=True, index=True)
    product_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("products.id"), nullable=True)
    product_name: Mapped[str] = mapped_column(String(255), default="")
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    unit_price: Mapped[int] = mapped_column(Integer, default=0)
    total_amount: Mapped[int] = mapped_column(Integer, default=0)
    payment_code: Mapped[str] = mapped_column(String(32), default="")
    qr_url: Mapped[str] = mapped_column(String(512), default="")
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    paid_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    discount_code: Mapped[str] = mapped_column(String(32), default="")
    discount_amount: Mapped[int] = mapped_column(Integer, default=0)
    payment_method: Mapped[str] = mapped_column(String(20), default="vietqr")
    customer_email: Mapped[str] = mapped_column(String(255), default="")
    source: Mapped[str] = mapped_column(String(20), default="bot")
    # Subscription tracking (repo: orders.subscription_expires_at).
    subscription_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    subscription_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expiry_reminded: Mapped[bool] = mapped_column(Boolean, default=False)


class Transaction(Base):
    __tablename__ = "transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    kind: Mapped[str] = mapped_column(String(32))
    currency: Mapped[str] = mapped_column(String(8), default="vnd")
    amount: Mapped[int] = mapped_column(Integer)  # signed
    balance_after: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(String(255), default="")
    ref: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Deposit(Base):
    __tablename__ = "deposits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    amount: Mapped[int] = mapped_column(Integer)
    method: Mapped[str] = mapped_column(String(20), default="bank")
    code: Mapped[str] = mapped_column(String(32), unique=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    receipt_file_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    admin_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    note: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class Withdrawal(Base):
    __tablename__ = "withdrawals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    amount: Mapped[int] = mapped_column(Integer)
    bank: Mapped[str] = mapped_column(String(64), default="")
    account_number: Mapped[str] = mapped_column(String(64), default="")
    account_name: Mapped[str] = mapped_column(String(128), default="")
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    admin_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    note: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class GameHistory(Base):
    __tablename__ = "game_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    game: Mapped[str] = mapped_column(String(32), index=True)
    bet: Mapped[int] = mapped_column(Integer)
    payout: Mapped[int] = mapped_column(Integer, default=0)
    result: Mapped[str] = mapped_column(String(16), default="lose")
    detail: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Giftcode(Base):
    __tablename__ = "giftcodes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    amount: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(8), default="coin")
    max_uses: Mapped[int] = mapped_column(Integer, default=1)
    used: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class GiftcodeUse(Base):
    __tablename__ = "giftcode_uses"
    __table_args__ = (UniqueConstraint("giftcode_id", "user_id", name="uq_giftcode_user"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    giftcode_id: Mapped[int] = mapped_column(Integer, ForeignKey("giftcodes.id"))
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Favorite(Base):
    __tablename__ = "favorites"
    __table_args__ = (UniqueConstraint("user_id", "account_id", name="uq_fav_user_account"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    account_id: Mapped[int] = mapped_column(Integer, ForeignKey("accounts.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Review(Base):
    __tablename__ = "reviews"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    account_id: Mapped[int] = mapped_column(Integer, ForeignKey("accounts.id"))
    rating: Mapped[int] = mapped_column(Integer, default=5)
    text: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Ticket(Base):
    __tablename__ = "tickets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    type: Mapped[str] = mapped_column(String(32), default="other")
    subject: Mapped[str] = mapped_column(String(255), default="")
    status: Mapped[str] = mapped_column(String(20), default="new", index=True)
    assigned_to: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class TicketMessage(Base):
    __tablename__ = "ticket_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ticket_id: Mapped[int] = mapped_column(Integer, ForeignKey("tickets.id"), index=True)
    sender_id: Mapped[int] = mapped_column(BigInteger)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    text: Mapped[str] = mapped_column(Text, default="")
    photo_file_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class LogEntry(Base):
    __tablename__ = "logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kind: Mapped[str] = mapped_column(String(32), index=True)
    message: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Setting(Base):
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="null")


Index("ix_accounts_status_hidden", Account.status, Account.is_hidden)
Index("ix_transactions_user_created", Transaction.user_id, Transaction.created_at)
Index("ix_game_history_user_created", GameHistory.user_id, GameHistory.created_at)


# ===========================================================================
# MERGE (telegram-sales-bot repo, ported to Python)
# Product / credential-pool sales, cart, discount codes, multi-bank accounts.
# The old Account model stays the unique-account (Liên Quân) stock; Product +
# Credential add the repo's fungible digital-goods model (Capcut, ChatGPT,
# Netflix...): one Product, many Credential rows, buy N units = take N rows.
# ===========================================================================


class Category(Base):
    """Product category (repo: categories). Accounts link via Account.category_id."""

    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(64), nullable=False)
    emoji: Mapped[str] = mapped_column(String(16), default="📦")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Product(Base):
    """A sellable fungible product (repo: products). Stock = unused Credentials,
    except product_type 'invite' (invite_slots) and 'preorder' (preorder_stock)."""

    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    category_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("categories.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    price: Mapped[int] = mapped_column(Integer, default=0)
    description: Mapped[str] = mapped_column(Text, default="")
    note: Mapped[str] = mapped_column(String(255), default="")
    # 'credential' | 'invite' | 'preorder'
    product_type: Mapped[str] = mapped_column(String(20), default="credential")
    # JSON list of {key, label, icon} — the fields each credential carries.
    credential_fields: Mapped[str] = mapped_column(
        Text,
        default='[{"key":"username","label":"Tài khoản","icon":"👤"},'
        '{"key":"password","label":"Mật khẩu","icon":"🔑"}]',
    )
    invite_slots: Mapped[int] = mapped_column(Integer, default=0)
    preorder_stock: Mapped[int] = mapped_column(Integer, default=0)
    delivery_hours: Mapped[int] = mapped_column(Integer, default=24)
    subscription_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    warranty_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # JSON list of {key, label, type} — extra info asked from the buyer.
    customer_fields: Mapped[str] = mapped_column(
        Text, default='[{"key":"email","label":"Email","type":"email"}]'
    )
    cost_price: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_hidden: Mapped[bool] = mapped_column(Boolean, default=False)
    is_featured: Mapped[bool] = mapped_column(Boolean, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Credential(Base):
    """One sellable credential for a Product (repo: credentials).
    `data_enc` is the Fernet-encrypted JSON of the credential fields
    (e.g. {"username": ..., "password": ...}) — never stored in plain text."""

    __tablename__ = "credentials"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    product_id: Mapped[int] = mapped_column(Integer, ForeignKey("products.id"), index=True)
    data_enc: Mapped[str] = mapped_column(Text, default="")
    is_sold: Mapped[bool] = mapped_column(Boolean, default=False)
    order_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("orders.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class CartItem(Base):
    """One line in a buyer's multi-item cart (repo: cart_items)."""

    __tablename__ = "cart_items"
    __table_args__ = (UniqueConstraint("user_id", "product_id", name="uq_cart_user_product"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    product_id: Mapped[int] = mapped_column(Integer, ForeignKey("products.id"))
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class OrderItem(Base):
    """One line of a multi-item order (repo: order_items)."""

    __tablename__ = "order_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_id: Mapped[int] = mapped_column(Integer, ForeignKey("orders.id"), index=True)
    product_id: Mapped[int] = mapped_column(Integer, ForeignKey("products.id"))
    product_name: Mapped[str] = mapped_column(String(255), default="")
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    unit_price: Mapped[int] = mapped_column(Integer, default=0)
    subtotal: Mapped[int] = mapped_column(Integer, default=0)
    delivery_status: Mapped[str] = mapped_column(String(20), default="pending")
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class DiscountCode(Base):
    """Discount code (repo: discount_codes)."""

    __tablename__ = "discount_codes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    # 'percent' | 'fixed'
    type: Mapped[str] = mapped_column(String(16), default="percent")
    value: Mapped[int] = mapped_column(Integer, default=0)
    product_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # JSON list of product ids (multi-product codes); empty = all products.
    product_ids: Mapped[str] = mapped_column(Text, default="")
    min_order_amount: Mapped[int] = mapped_column(Integer, default=0)
    max_discount_amount: Mapped[int | None] = mapped_column(Integer, nullable=True)
    max_uses: Mapped[int] = mapped_column(Integer, default=0)
    max_uses_per_user: Mapped[int] = mapped_column(Integer, default=0)
    used_count: Mapped[int] = mapped_column(Integer, default=0)
    starts_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_hidden: Mapped[bool] = mapped_column(Boolean, default=False)
    is_new_user_only: Mapped[bool] = mapped_column(Boolean, default=False)
    allowed_user_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class DiscountUsage(Base):
    """One recorded use of a discount code (repo: discount_usage)."""

    __tablename__ = "discount_usage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    discount_code_id: Mapped[int] = mapped_column(Integer, ForeignKey("discount_codes.id"))
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    order_code: Mapped[str] = mapped_column(String(32), default="")
    used_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class BankAccount(Base):
    """Saved bank accounts for VietQR (repo: bank_accounts). One is active;
    the env BANK_* values are the fallback when no row is active."""

    __tablename__ = "bank_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    bank_id: Mapped[str] = mapped_column(String(16), default="")
    bank_code: Mapped[str] = mapped_column(String(16), default="")
    bank_name: Mapped[str] = mapped_column(String(64), default="")
    account_no: Mapped[str] = mapped_column(String(32), default="")
    account_name: Mapped[str] = mapped_column(String(128), default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


Index("ix_orders_code_status", Order.order_code, Order.status)
Index("ix_credentials_product_sold", Credential.product_id, Credential.is_sold)
Index("ix_products_category_active", Product.category_id, Product.is_active)
