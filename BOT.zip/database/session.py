"""Async engine and session helpers."""

from __future__ import annotations

import shutil
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import AsyncIterator

from sqlalchemy import inspect, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from config import BACKUP_DIR, BACKUP_KEEP_DAYS, DATA_DIR, DATABASE_URL
from database.models import Account, Base, Order
from utils.logger import get_logger

log = get_logger(__name__)

engine = create_async_engine(DATABASE_URL, echo=False, pool_pre_ping=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


def _column_default(column) -> str:
    default = getattr(column.default, "arg", None) if column.default is not None else None
    if default is None:
        return ""
    if isinstance(default, bool):
        return f" DEFAULT {'TRUE' if default else 'FALSE'}"
    if isinstance(default, (int, float)):
        return f" DEFAULT {default}"
    if isinstance(default, str):
        return " DEFAULT '" + default.replace("'", "''") + "'"
    return ""


async def _add_missing_columns() -> list[str]:
    """Add new columns to an existing database (SQLite and PostgreSQL).

    MERGE: now covers both Account and Order, so the direct-order columns
    added by the merge are created on an existing bot.db at startup.
    New tables (categories, products, credentials, ...) are created by
    Base.metadata.create_all in init_db; only new COLUMNS need this helper.
    """
    added: list[str] = []
    async with engine.begin() as conn:
        dialect = conn.dialect
        for model in (Account, Order):
            table = model.__tablename__

            def _existing(sync_conn, _table=table) -> set[str] | None:
                inspector = inspect(sync_conn)
                if not inspector.has_table(_table):
                    return None
                return {column["name"] for column in inspector.get_columns(_table)}

            existing = await conn.run_sync(_existing)
            if existing is None:
                continue
            for column in model.__table__.columns:
                if column.name in existing:
                    continue
                try:
                    ddl = (
                        f"ALTER TABLE {table} ADD COLUMN {column.name} "
                        f"{column.type.compile(dialect=dialect)}{_column_default(column)}"
                    )
                    await conn.execute(text(ddl))
                    added.append(f"{table}.{column.name}")
                except Exception as exc:  # never block startup on a migration
                    log.warning("Cannot add column %s.%s: %s", table, column.name, exc)
    if added:
        log.info("Đã thêm cột mới: %s", ", ".join(added))
    return added


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await _add_missing_columns()


async def backup_database() -> Path | None:
    """Copy the SQLite file to BACKUP_DIR and prune old backups.

    Needed by handlers/admin/panel.py (admin backup button), which imports
    this name from database.session. Returns the backup file path, or None
    when there is no local SQLite file (e.g. PostgreSQL).
    """
    source = DATA_DIR / "bot.db"
    if not source.exists():
        return None
    target = BACKUP_DIR / f"backup-{datetime.now():%Y%m%d-%H%M%S}.db"
    shutil.copy2(source, target)
    cutoff = datetime.now() - timedelta(days=BACKUP_KEEP_DAYS)
    for old in BACKUP_DIR.glob("backup-*.db"):
        if datetime.fromtimestamp(old.stat().st_mtime) < cutoff:
            old.unlink(missing_ok=True)
    log.info("Database backup written to %s", target.name)
    return target


@asynccontextmanager
async def session_scope() -> AsyncIterator[AsyncSession]:
    session = SessionLocal()
    try:
        yield session
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    finally:
        await session.close()
