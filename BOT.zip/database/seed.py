# Disabled 2026-11-20 no sample seed
SAMPLE_ACCOUNTS = []
SAMPLE_GIFTCODES = []
async def seed_if_empty():
    return None
