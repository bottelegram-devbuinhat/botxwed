"""SePay polling backup (ported from telegram-sales-bot src/utils/sepayPoller.js).

Webhooks can fail (server restart, cold start, network). The poller runs
every 2 minutes, fetches recent incoming transactions from the SePay API and
matches them to pending direct orders (ORD code) and pending deposits (NAP
code). Matched payments go through the SAME confirm/credit paths as the
webhook, so a payment is never credited twice.

Guarded by SEPAY_ENABLED + SEPAY_API_KEY (same as the webhook server).
Started from main.py: ``start_sepay_poller(bot)`` returns an asyncio Task.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timedelta

import aiohttp

from config import SEPAY_API_KEY, SEPAY_ENABLED
from services import order_service
from utils.logger import get_logger

log = get_logger(__name__)

POLL_INTERVAL_SECONDS = 120
ALERT_AFTER_MINUTES = 10
SEPAY_TXN_URL = "https://my.sepay.vn/userapi/transactions/list"


async def _fetch_transactions() -> list[dict] | None:
    today = datetime.utcnow().date().isoformat()
    url = f"{SEPAY_TXN_URL}?transaction_date_min={today}&limit=50"
    timeout = aiohttp.ClientTimeout(total=15)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                url,
                headers={"Authorization": f"Bearer {SEPAY_API_KEY}", "Content-Type": "application/json"},
            ) as response:
                if response.status != 200:
                    log.warning("SePay poller: API responded %s", response.status)
                    return None
                data = await response.json(content_type=None)
                if not isinstance(data, dict):
                    return None
                return list(data.get("transactions") or [])
    except (aiohttp.ClientError, ValueError, TimeoutError) as exc:
        log.warning("SePay poller fetch failed: %s", exc)
        return None


def _txn_fields(txn: dict) -> tuple[str, str, int]:
    content = str(txn.get("transaction_content") or "").upper()
    code = str(txn.get("code") or "").upper()
    amount = 0
    try:
        amount = int(txn.get("amount_in") or 0)
    except (TypeError, ValueError):
        amount = 0
    return content, code, amount


async def poll_and_reconcile(bot=None) -> None:
    """One poll cycle: match pending orders/deposits against SePay transactions."""
    pending = await order_service.pending_orders()
    if not pending:
        return
    transactions = await _fetch_transactions()
    if not transactions:
        return
    log.info("SePay poller: %s pending orders, %s recent transactions", len(pending), len(transactions))
    now = datetime.utcnow()
    for order in pending:
        code = (order.order_code or "").upper()
        if not code:
            continue
        matched = None
        for txn in transactions:
            content, txn_code, amount = _txn_fields(txn)
            if txn.get("transaction_type") not in (None, "in") and int(txn.get("amount_in") or 0) <= 0:
                continue
            if (txn_code == code or code in content) and amount >= int(order.total_amount):
                matched = (txn, amount)
                break
        if matched is None:
            if order.created_at and (now - order.created_at) > timedelta(minutes=ALERT_AFTER_MINUTES):
                log.warning("SePay poller: order %s pending > %s min", code, ALERT_AFTER_MINUTES)
            continue
        txn, amount = matched
        ok, _ = await order_service.confirm_order_payment(code, amount, str(txn.get("id") or ""))
        if ok:
            fresh = await order_service.get_order_by_code(code)
            if fresh is not None and bot is not None:
                await order_service.deliver_order(bot, fresh)
            log.info("SePay poller: order %s paid via txn %s", code, txn.get("id"))

    # Pending wallet deposits (NAP codes) get the same reconciliation.
    await _reconcile_deposits(transactions)


async def _reconcile_deposits(transactions: list[dict]) -> None:
    from services.payment_service import credit_bank_transfer

    for txn in transactions:
        content, _code, amount = _txn_fields(txn)
        if amount <= 0:
            continue
        ok, _user_id = await credit_bank_transfer(content, amount, str(txn.get("id") or ""))
        if ok:
            log.info("SePay poller: deposit credited via txn %s", txn.get("id"))


async def _loop(bot) -> None:
    await asyncio.sleep(30)
    while True:
        try:
            await poll_and_reconcile(bot)
        except Exception as exc:  # noqa: BLE001 - the poller must never kill the bot
            log.error("SePay poller error: %s", exc)
        await asyncio.sleep(POLL_INTERVAL_SECONDS)


def start_sepay_poller(bot) -> asyncio.Task | None:
    """Start the background poller. Returns the Task, or None when disabled."""
    if not SEPAY_ENABLED or not SEPAY_API_KEY:
        log.info("SePay poller disabled (SEPAY_ENABLED/SEPAY_API_KEY not set)")
        return None
    log.info("SePay poller started (every %ss)", POLL_INTERVAL_SECONDS)
    return asyncio.create_task(_loop(bot))
