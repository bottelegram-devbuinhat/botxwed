"""Đồng bộ số dư ví bot lên Cloudflare Worker + D1 cho web store.

Kiến trúc:
    bot (SQLite, nguồn sự thật)  --push-->  Cloudflare Worker  --đọc-->  web store
    web store  --tạo lệnh nạp-->  Cloudflare Worker  --bot pull-->  bot (Deposit)

Mỗi người dùng có một bản ghi trên Cloudflare: telegram_id, shop_balance (VND),
coins (xu), updated_at.

Đẩy số dư:
* ``queue_push(user_id)`` được gọi ở mọi chỗ số dư thay đổi (nạp, mua, thưởng,
  hoàn tiền, admin cộng/trừ, điểm danh, casino...). Hàm này không chặn handler:
  nó gom id lại và một task nền đẩy sau vài giây (gộp nhiều thay đổi liên tiếp
  của cùng một người thành một lần ghi).
* ``flush_pending()`` đẩy các ví đang chờ (job 15 giây một lần để tự phục hồi
  nếu task nền bị mất khi tiến trình restart).
* ``full_sync()`` đẩy TOÀN BỘ ví mỗi 5 phút (CLOUDFLARE_SYNC_INTERVAL). Nó so
  với dấu vân tay đã đẩy thành công lần trước (data/balance_sync_state.json)
  nên chỉ ghi các ví thật sự thay đổi — vừa tự phục hồi lần đẩy bị lỡ, vừa
  không đốt hạn mức D1.

Lệnh nạp tạo từ web:
* Web gọi POST /api/deposit trên Worker, Worker sinh mã dạng NAP<id>T<4hex>
  (cùng định dạng bot dùng) và lưu ở bảng deposits.
* ``adopt_web_deposits()`` (job 60 giây) kéo các lệnh nạp đó về bot, tạo
  Deposit tương ứng để SePay tự đối soát hoặc admin duyệt trong bot như bình
  thường; đồng thời đẩy ngược trạng thái đã duyệt/từ chối lên Worker.
* Người nạp qua web mà chưa từng /start bot vẫn được tạo user (ví 0đ) ngay khi
  bot nhận lệnh nạp, nên lệnh nạp không bị bỏ mất — họ chỉ cần mở bot là thấy
  tiền trong ví.

Mọi secret đọc từ biến môi trường (CLOUDFLARE_SYNC_URL, CLOUDFLARE_SYNC_TOKEN).
Không có cấu hình thì mọi hàm ở đây im lặng bỏ qua — bot vẫn chạy y như cũ.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import aiohttp
from sqlalchemy import select

from config import CLOUDFLARE_SYNC_TOKEN, CLOUDFLARE_SYNC_URL, DATA_DIR
from database.models import Deposit, User
from database.session import session_scope
from utils.logger import get_logger

log = get_logger(__name__)

STATE_FILE: Path = DATA_DIR / "balance_sync_state.json"
PUSH_DEBOUNCE_SECONDS = 3
CHUNK_SIZE = 200
WEB_DEPOSIT_CODE_RE = re.compile(r"^NAP\d+T[0-9A-F]{4}$")

_pending: set[int] = set()
_flush_task: asyncio.Task | None = None
_flush_lock = asyncio.Lock()
_state_cache: dict[str, list[int]] | None = None


def enabled() -> bool:
    """True khi đã cấu hình Worker URL + sync token trong .env."""
    return bool(CLOUDFLARE_SYNC_URL and CLOUDFLARE_SYNC_TOKEN)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------- state file
def _load_state() -> dict[str, list[int]]:
    """Dấu vân tay (shop_balance, coins) của lần đẩy THÀNH CÔNG gần nhất."""
    global _state_cache
    if _state_cache is not None:
        return _state_cache
    state: dict[str, list[int]] = {}
    try:
        raw = STATE_FILE.read_text(encoding="utf-8")
        data = json.loads(raw)
        users = data.get("users") if isinstance(data, dict) else None
        if isinstance(users, dict):
            for key, value in users.items():
                if isinstance(value, list) and len(value) == 2:
                    state[str(key)] = [int(value[0]), int(value[1])]
    except FileNotFoundError:
        pass
    except Exception as exc:  # noqa: BLE001 - file hỏng thì coi như chưa có
        log.warning("Balance sync: không đọc được %s: %s", STATE_FILE.name, exc)
    _state_cache = state
    return state


def _save_state() -> None:
    if _state_cache is None:
        return
    payload = {
        "updated_at": _now_iso(),
        "users": _state_cache,
    }
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, STATE_FILE)
    except Exception as exc:  # noqa: BLE001 - chỉ là cache, không được làm hỏng bot
        log.warning("Balance sync: không ghi được %s: %s", STATE_FILE.name, exc)


def _remember(rows: Iterable[tuple[int, int, int]]) -> None:
    state = _load_state()
    changed = False
    for telegram_id, shop_balance, coins in rows:
        key = str(int(telegram_id))
        value = [int(shop_balance), int(coins)]
        if state.get(key) != value:
            state[key] = value
            changed = True
    if changed:
        _save_state()


# ------------------------------------------------------------------- HTTP client
async def _request(
    method: str,
    path: str,
    payload: dict | None = None,
    params: dict | None = None,
    attempts: int = 3,
) -> dict | None:
    """Gọi Worker kèm token bot. Retry lỗi mạng/5xx với backoff ngắn."""
    if not enabled():
        return None
    url = f"{CLOUDFLARE_SYNC_URL}{path}"
    headers = {
        "X-Sync-Token": CLOUDFLARE_SYNC_TOKEN,
        "Content-Type": "application/json",
        "User-Agent": "AnhDevBot-Sync/1.0",
    }
    for attempt in range(1, attempts + 1):
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.request(method, url, json=payload, params=params, headers=headers) as resp:
                    text = await resp.text()
                    if resp.status >= 500 and attempt < attempts:
                        await asyncio.sleep(attempt * 2)
                        continue
                    if resp.status != 200:
                        log.warning(
                            "Balance sync %s %s -> HTTP %s: %s",
                            method,
                            path,
                            resp.status,
                            (text or "")[:200],
                        )
                        return None
                    try:
                        data = json.loads(text)
                    except ValueError:
                        log.warning("Balance sync %s %s: phản hồi không phải JSON", method, path)
                        return None
                    return data if isinstance(data, dict) else None
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            if attempt < attempts:
                await asyncio.sleep(attempt * 2)
                continue
            log.warning("Balance sync %s %s lỗi mạng: %s", method, path, exc)
            return None
        except Exception as exc:  # noqa: BLE001 - sync không được kill bot
            log.warning("Balance sync %s %s lỗi: %s", method, path, exc)
            return None
    return None


# ----------------------------------------------------------------------- pushes
def queue_push(telegram_id: int) -> None:
    """Đánh dấu ví cần đẩy lên Cloudflare. An toàn khi gọi từ bất kỳ handler nào."""
    if not enabled():
        return
    try:
        uid = int(telegram_id)
    except (TypeError, ValueError):
        return
    if uid <= 0:
        return
    _pending.add(uid)
    _ensure_flush_task()


def _ensure_flush_task() -> None:
    global _flush_task
    if _flush_task is not None and not _flush_task.done():
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # gọi ngoài event loop (script đồng bộ) thì bỏ qua
        return
    _flush_task = loop.create_task(_delayed_flush())


async def _delayed_flush() -> None:
    try:
        await asyncio.sleep(PUSH_DEBOUNCE_SECONDS)
        await flush_pending()
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001
        log.warning("Balance sync: flush nền lỗi: %s", exc)


async def _balances_of(ids: Iterable[int]) -> list[tuple[int, int, int]]:
    wanted = [int(i) for i in ids]
    rows: list[tuple[int, int, int]] = []
    async with session_scope() as session:
        for start in range(0, len(wanted), 500):
            chunk = wanted[start : start + 500]
            result = await session.execute(
                select(User.id, User.shop_balance, User.coins).where(User.id.in_(chunk))
            )
            rows.extend((int(r[0]), int(r[1] or 0), int(r[2] or 0)) for r in result.all())
    return rows


async def _all_balances() -> list[tuple[int, int, int]]:
    async with session_scope() as session:
        result = await session.execute(select(User.id, User.shop_balance, User.coins))
        return [(int(r[0]), int(r[1] or 0), int(r[2] or 0)) for r in result.all()]


async def _push_rows(rows: list[tuple[int, int, int]]) -> bool:
    """Đẩy một lô ví. Trả về True khi mọi lô con đều thành công."""
    if not rows:
        return True
    stamp = _now_iso()
    ok = True
    for start in range(0, len(rows), CHUNK_SIZE):
        chunk = rows[start : start + CHUNK_SIZE]
        payload = {
            "users": [
                {
                    "telegram_id": uid,
                    "shop_balance": shop_balance,
                    "coins": coins,
                    "updated_at": stamp,
                }
                for uid, shop_balance, coins in chunk
            ]
        }
        data = await _request("POST", "/api/admin/balances", payload)
        if not data or not data.get("ok"):
            ok = False
            break
    return ok


async def flush_pending() -> int:
    """Đẩy các ví đang chờ. Trả về số ví đã đẩy thành công."""
    if not enabled() or not _pending:
        return 0
    async with _flush_lock:
        ids = list(_pending)
        _pending.clear()
        if not ids:
            return 0
        rows = await _balances_of(ids)
        if not rows:
            return 0
        if await _push_rows(rows):
            _remember(rows)
            return len(rows)
        # Đẩy lỗi: giữ lại để lần sau thử tiếp (job 15s + full sync sẽ cứu).
        _pending.update(ids)
        return 0


async def full_sync(force: bool = False) -> int:
    """Đẩy toàn bộ ví (chỉ các ví đã thay đổi so với lần đẩy thành công trước)."""
    if not enabled():
        return 0
    rows = await _all_balances()
    if not rows:
        return 0
    state = _load_state()
    todo: list[tuple[int, int, int]] = []
    for row in rows:
        if force or state.get(str(row[0])) != [row[1], row[2]]:
            todo.append(row)
    if not todo:
        return 0
    pushed = 0
    for start in range(0, len(todo), CHUNK_SIZE):
        chunk = todo[start : start + CHUNK_SIZE]
        if not await _push_rows(chunk):
            break
        _remember(chunk)
        pushed += len(chunk)
    if pushed:
        log.info("Balance sync: full sync đẩy %s/%s ví", pushed, len(rows))
    return pushed


# ----------------------------------------------------------------- web deposits
async def push_deposit_status(
    code: str,
    status: str,
    credited_amount: int | None = None,
    note: str = "",
) -> bool:
    """Báo trạng thái lệnh nạp (approved/rejected) về Worker để web hiển thị."""
    if not enabled() or not code:
        return False
    payload: dict[str, Any] = {"code": str(code).upper(), "status": str(status)}
    if credited_amount is not None:
        payload["credited_amount"] = int(credited_amount)
    if note:
        payload["note"] = str(note)[:255]
    data = await _request("POST", "/api/admin/deposits", payload)
    return bool(data and data.get("ok"))


async def fetch_pending_deposits(limit: int = 100) -> list[dict]:
    """Các lệnh nạp tạo từ web còn chờ bot xử lý."""
    if not enabled():
        return []
    data = await _request(
        "GET",
        "/api/admin/deposits",
        params={"status": "pending", "limit": str(limit)},
    )
    if not data or not data.get("ok"):
        return []
    deposits = data.get("deposits")
    return [item for item in deposits if isinstance(item, dict)] if isinstance(deposits, list) else []


async def adopt_web_deposits(bot=None) -> int:
    """Tạo Deposit trong bot cho lệnh nạp tạo từ web + đẩy ngược trạng thái.

    Lệnh nạp web dùng mã NAP<telegram_id>T<4hex> nên SePay (webhook hoặc
    poller) tự đối soát và cộng tiền y như lệnh nạp tạo trong bot. Nếu admin
    đã duyệt/từ chối trong bot thì trạng thái được đẩy lại Worker.
    """
    items = await fetch_pending_deposits()
    if not items:
        return 0

    created: list[tuple[str, int, int]] = []
    stale_status: list[tuple[str, str, int]] = []
    new_users: list[int] = []
    async with session_scope() as session:
        for item in items:
            code = str(item.get("code") or "").strip().upper()
            if not WEB_DEPOSIT_CODE_RE.match(code):
                continue
            try:
                telegram_id = int(item.get("telegram_id"))
                amount = int(item.get("amount"))
            except (TypeError, ValueError):
                continue
            if telegram_id <= 0 or amount <= 0:
                continue
            existing = (
                await session.execute(select(Deposit).where(Deposit.code == code))
            ).scalar_one_or_none()
            if existing is not None:
                # Bot đã xử lý nhưng lần đẩy trạng thái trước bị lỡ: đẩy lại
                # sau khi commit (không gọi mạng trong transaction).
                if existing.status in ("approved", "rejected"):
                    stale_status.append((existing.code, existing.status, existing.amount))
                continue
            if await session.get(User, telegram_id) is None:
                # Người dùng chưa /start bot. Vẫn tạo user tối thiểu (ví 0đ) để
                # lệnh nạp không bị bỏ mất: SePay cứ cộng tiền vào Deposit này,
                # khách mở bot là thấy số dư trong ví.
                raw_name = str(item.get("full_name") or item.get("username") or "").strip()
                session.add(
                    User(
                        id=telegram_id,
                        username=None,
                        full_name=(raw_name or "Khách web store")[:255],
                    )
                )
                new_users.append(telegram_id)
                log.info(
                    "Balance sync: tạo user %s (chưa /start bot) cho lệnh nạp web %s",
                    telegram_id,
                    code,
                )
            session.add(
                Deposit(
                    user_id=telegram_id,
                    amount=amount,
                    method="bank",
                    code=code,
                    status="pending",
                    note="Nạp từ web store",
                )
            )
            created.append((code, telegram_id, amount))

    for code, status, amount in stale_status:
        await push_deposit_status(code, status, amount)

    # Ví mới tạo: đẩy lên Worker để web không còn hiển thị "chưa đồng bộ".
    for telegram_id in new_users:
        queue_push(telegram_id)

    for code, telegram_id, amount in created:
        log.info("Balance sync: nhận lệnh nạp web %s (%sđ) của %s", code, amount, telegram_id)
    if created and bot is not None:
        try:
            from utils.notifications import notify_admins

            lines = "\n".join(
                f"• <code>{code}</code> · {amount:,}đ · user <code>{telegram_id}</code>".replace(",", ".")
                for code, telegram_id, amount in created
            )
            extra = ""
            if new_users:
                ids = ", ".join(f"<code>{uid}</code>" for uid in new_users)
                extra = f"\n\n🆕 User mới (chưa /start bot): {ids}"
            await notify_admins(
                bot,
                "🌐 <b>Lệnh nạp mới từ web store</b>\n"
                f"{lines}{extra}\n\n"
                "SePay sẽ tự cộng khi đúng nội dung; nếu khách báo đã chuyển, "
                "duyệt trong mục Nạp tiền.",
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("Balance sync: không báo được admin: %s", exc)
    return len(created)

