"""AI assistant (OpenAI-compatible) that manages the shop and support with live tools.

The assistant never invents numbers: every answer about stock, prices, orders,
wallet or bets comes from a tool call that reads the real database. Bets are
placed only when the player asks for a specific round, and refunds are executed
directly for admins while normal players get a warranty ticket for an admin.

Works with any OpenAI-compatible endpoint (OpenAI, Groq, Gemini compat, OpenRouter,
local Ollama...) by changing ``AI_BASE_URL`` / ``AI_MODEL``.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import secrets
import time
from collections import deque

import aiohttp

from config import (
    AI_API_KEYS,
    AI_BASE_URL,
    AI_HISTORY_CHARS,
    AI_KEY_COOLDOWN,
    AI_MAX_CONCURRENCY,
    AI_MAX_TOKENS,
    AI_MAX_TOKENS_EXTRACT,
    AI_MODEL,
    AI_MODEL_CHAT,
    AI_MODEL_COOLDOWN,
    AI_MODEL_EXTRACT,
    AI_MODELS,
    AI_REASONING_EFFORT,
    AI_REQUESTS_PER_MINUTE,
    AI_TIMEOUT,
)
from database.models import Ticket, TicketMessage
from database.session import session_scope
from services import casino_service, shop_service
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils.logger import get_logger
from utils.money import fmt_coin, fmt_vnd
from utils.notifications import notify_admins

log = get_logger(__name__)

DEFAULT_PROMPT = (
    "Bạn là trợ lý AI của bot Telegram: shop acc Liên Quân + casino xu ảo + hỗ trợ khách.\n"
    "Quy tắc:\n"
    "- Luôn trả lời bằng tiếng Việt, thân thiện, thật ngắn (tối đa 6 dòng), dùng gạch đầu dòng.\n"
    "- Số liệu (giá, số lượng acc, đơn hàng, số dư, kết quả cược) phải lấy từ công cụ. Không bịa.\n"
    "- Shop có 2 kho: acc sẵn thông tin (hiện rank/skin/ban/UID) và kho random (ẩn thông tin, mua ngẫu nhiên).\n"
    "- Chỉ đặt cược khi người dùng yêu cầu rõ game, số xu và cửa cược. Báo lại kết quả thật.\n"
    "- Hoàn tiền: admin thì hoàn trực tiếp; người chơi thường thì tạo yêu cầu bảo hành gửi admin.\n"
    "- Xu casino là tiền ảo giải trí, không mua bằng tiền và không đổi ra tiền. Nhắc 18+ khi phù hợp.\n"
    "- Không có dữ liệu hoặc không chắc chắn thì hướng dẫn mở 🆘 Hỗ trợ tạo ticket.\n"
    "- Không dùng bảng markdown, không chèn HTML."
)

MAX_ROUNDS = 2
MAX_HISTORY = 8
MAX_ATTEMPTS = 6
MAX_QUESTION_CHARS = 1200
MAX_CHUNKS = 4

# Descriptions stay terse on purpose: the schema is re-sent with every round, so
# every extra sentence costs tokens on each message. Names + params are enough
# for the model to pick the right tool.
TOOLS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "kho_acc",
            "description": "Acc đang bán, lọc theo giá/rank.",
            "parameters": {
                "type": "object",
                "properties": {
                    "gia_min": {"type": "integer", "description": "Giá từ (VNĐ)"},
                    "gia_max": {"type": "integer", "description": "Giá đến (VNĐ)"},
                    "rank": {"type": "string", "description": "Rank"},
                    "so_luong": {"type": "integer", "description": "Số acc, max 10"},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "chi_tiet_acc",
            "description": "Chi tiết một acc theo mã (LQ0007).",
            "parameters": {
                "type": "object",
                "properties": {"ma_acc": {"type": "string", "description": "Mã acc"}},
                "required": ["ma_acc"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "thong_ke_kho",
            "description": "Tồn kho, giá min/max, các rank.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "vi_cua_toi",
            "description": "Số dư shop, xu, VIP của người chat.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "don_hang_cua_toi",
            "description": "Đơn mua acc gần đây của người chat.",
            "parameters": {
                "type": "object",
                "properties": {"so_luong": {"type": "integer", "description": "Số đơn, mặc định 5"}},
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "dat_cuoc",
            "description": "Đặt cược xu ảo khi người dùng yêu cầu rõ game, xu, cửa.",
            "parameters": {
                "type": "object",
                "properties": {
                    "game": {"type": "string", "description": "taixiu, chanle, xocdia, baucua, rongho, baccarat, blackjack, slots, roulette, highlow, numberguess, mysterybox"},
                    "so_xu": {"type": "integer", "description": "Số xu"},
                    "cua": {"type": "string", "description": "Mã cửa, vd TAI, XIU, CHAN, LE"},
                },
                "required": ["game", "so_xu"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "hoan_tien_don",
            "description": "Hoàn tiền đơn; admin hoàn ngay, người chơi tạo ticket.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ma_don": {"type": "integer", "description": "ID đơn"},
                    "ly_do": {"type": "string", "description": "Lý do"},
                },
                "required": ["ma_don"],
            },
        },
    },
]

_TAG_RE = re.compile(r"<[^>]+>")


def _plain(text: str) -> str:
    return _TAG_RE.sub("", text or "")


def configured() -> bool:
    return bool(AI_API_KEYS)


async def available() -> bool:
    settings = await all_settings()
    return bool(settings.get("ai_enabled")) and configured()


async def model_name() -> str:
    settings = await all_settings()
    return (settings.get("ai_model") or AI_MODEL or "gpt-4o-mini").strip()


async def system_prompt() -> str:
    settings = await all_settings()
    return (settings.get("ai_system_prompt") or DEFAULT_PROMPT).strip()


# --------------------------------------------------------------------------- tools
def _game_list() -> str:
    return ", ".join(f"{key} ({meta['name']})" for key, meta in casino_service.GAMES.items())


async def _tool_kho_acc(ctx: dict, args: dict) -> dict:
    min_price = args.get("gia_min")
    max_price = args.get("gia_max")
    limit = max(1, min(10, int(args.get("so_luong") or 5)))
    accounts, total = await shop_service.list_accounts(
        page=0,
        per_page=limit,
        sort="cheap",
        rank=args.get("rank") or None,
        min_price=int(min_price) if min_price else None,
        max_price=int(max_price) if max_price else None,
    )
    return {
        "tong_phu_hop": total,
        "acc": [
            {
                "ma": a.code,
                "gia": fmt_vnd(a.price),
                "loai": a.category or a.kind,
                "rank": a.rank,
                "level": a.level,
                "tuong": a.heroes,
                "skin": a.skins,
                "skin_cao_cap": {"SS": a.ss_count, "S+": a.splus_count, "Anime": a.anime_count, "EVO": a.evo_count},
                "ban": a.is_banned,
                "bao_hanh_ngay": a.warranty_days,
            }
            for a in accounts
        ],
    }


async def _tool_chi_tiet_acc(ctx: dict, args: dict) -> dict:
    code = str(args.get("ma_acc") or "").strip().upper()
    account = await shop_service.get_account_by_code(code)
    if account is None:
        return {"loi": f"Không tìm thấy acc {code}."}
    if account.is_hidden or account.status == "deleted":
        return {"loi": f"Acc {code} hiện không còn bán."}
    return {
        "ma": account.code,
        "loai": account.category or account.kind,
        "gia": fmt_vnd(account.price),
        "rank": account.rank,
        "level": account.level,
        "tuong": account.heroes,
        "skin": account.skins,
        "skin_hien": account.rare_skins,
        "dang_nhap": account.login_type,
        "bao_hanh_ngay": account.warranty_days,
        "trang_thai": account.status,
        "uid": account.uid,
        "region": account.region,
        "so": account.shells,
        "nap_so": account.shells_note,
        "email": account.email_info,
        "sdt": account.phone_info,
        "ban": account.is_banned,
        "tinh_trang": account.ban_note or ("BAN" if account.is_banned else "không ban"),
        "2fa": account.twofa,
        "cccd": account.has_cccd,
        "skin_cao_cap": {"SS": account.ss_count, "S+": account.splus_count, "S": account.s_count, "Anime": account.anime_count, "EVO": account.evo_count},
        "luot_xem": account.views,
        "mo_ta": _plain(account.description or "")[:300],
    }


async def _tool_thong_ke_kho(ctx: dict, args: dict) -> dict:
    stats = await shop_service.stock_overview()
    return stats


async def _tool_vi(ctx: dict, args: dict) -> dict:
    user = await wallet.get_user(ctx["user_id"])
    if user is None:
        return {"loi": "Không tìm thấy người dùng."}
    return {
        "so_du_shop": fmt_vnd(user.shop_balance),
        "xu_casino": fmt_coin(user.coins),
        "vip": user.vip_level,
        "tong_da_nap": fmt_vnd(user.total_deposited),
        "tong_da_mua": fmt_vnd(user.total_purchased),
    }


async def _tool_don_hang(ctx: dict, args: dict) -> dict:
    limit = max(1, min(10, int(args.get("so_luong") or 5)))
    orders = await shop_service.orders_of(ctx["user_id"], limit=limit)
    return {
        "don": [
            {
                "ma_don": o.id,
                "acc": o.account_code,
                "gia": fmt_vnd(o.price),
                "trang_thai": o.status,
                "ngay": o.created_at.strftime("%d/%m/%Y"),
                "bao_hanh_den": o.warranty_until.strftime("%d/%m/%Y") if o.warranty_until else "không có",
            }
            for o in orders
        ]
    }


# A bet proposed by the model is parked here until the player presses the
# confirmation button. The assistant also reads account text, so a manipulated
# description could ask it to "bet everything"; nothing is charged until the
# human taps the button.
_PENDING_BETS: dict[int, dict] = {}
_BET_TTL = 120.0


def stage_bet(user_id: int, game: str, bet: int, choice: str | None) -> dict | None:
    meta = casino_service.GAMES.get(game)
    if meta is None or game == "blackjack" or int(bet) <= 0:
        return None
    if meta.get("choices") and str(choice) not in meta["choices"]:
        return None
    staged = {
        "token": secrets.token_hex(4),
        "game": game,
        "bet": int(bet),
        "choice": choice,
        "at": time.monotonic(),
    }
    _PENDING_BETS[int(user_id)] = staged
    return staged


def take_staged_bet(user_id: int, token: str) -> dict | None:
    """Consume a staged bet exactly once (expired tokens are rejected)."""
    staged = _PENDING_BETS.get(int(user_id))
    if not staged or staged.get("token") != token:
        return None
    _PENDING_BETS.pop(int(user_id), None)
    if time.monotonic() - staged.get("at", 0.0) > _BET_TTL:
        return None
    return staged


async def _tool_dat_cuoc(ctx: dict, args: dict) -> dict:
    game = str(args.get("game") or "").strip().lower()
    try:
        bet = int(args.get("so_xu") or 0)
    except (TypeError, ValueError):
        return {"loi": "Số xu không hợp lệ."}
    choice = args.get("cua")
    choice = str(choice).strip().upper() if choice not in (None, "") else None
    if game == "baucua" and choice and not choice.isdigit():
        names = {name.upper(): str(index) for index, name in enumerate(casino_service.BAU_SYMBOLS)}
        choice = names.get(choice, choice)
    if game == "numberguess" and choice and choice.isdigit():
        choice = str(int(choice))

    staged = stage_bet(ctx["user_id"], game, bet, choice)
    if staged is None:
        return {"loi": "Thông tin cược không hợp lệ. Cần nêu rõ game, số xu và cửa cược hợp lệ."}

    user = await wallet.get_user(ctx["user_id"])
    coins = int(user.coins) if user is not None else 0
    label = casino_service.GAMES[game]["name"]
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"✅ Cược {fmt_coin(bet)} · {label}",
                    callback_data=f"ai:betok:{staged['token']}",
                )
            ],
            [InlineKeyboardButton(text="❌ Huỷ", callback_data=f"ai:betno:{staged['token']}")],
        ]
    )
    lines = [
        "🎰 <b>Xác nhận đặt cược</b>",
        f"• Game: <b>{label}</b>",
        f"• Số xu: <b>{fmt_coin(bet)}</b>",
    ]
    if staged["choice"]:
        lines.append(f"• Cửa: <b>{staged['choice']}</b>")
    lines.append(f"• Xu hiện có: <b>{fmt_coin(coins)}</b>")
    try:
        await ctx["bot"].send_message(
            ctx["user_id"], "\n".join(lines), parse_mode="HTML", reply_markup=keyboard
        )
    except Exception as exc:  # user blocked the bot etc.
        log.warning("Cannot send AI bet confirmation: %s", exc)
        return {"loi": "Không gửi được xác nhận cược, thử lại sau."}

    return {
        "cho_xac_nhan": True,
        "ghi_chu": (
            "Đã gửi nút xác nhận cho người chơi. Chưa trừ xu và chưa có kết quả; "
            "chỉ báo kết quả sau khi người chơi bấm xác nhận."
        ),
    }


async def _tool_hoan_tien(ctx: dict, args: dict) -> dict:
    try:
        order_id = int(args.get("ma_don") or 0)
    except (TypeError, ValueError):
        return {"loi": "Mã đơn không hợp lệ."}
    reason = str(args.get("ly_do") or "Yêu cầu hoàn tiền qua trợ lý AI")[:400]

    orders = await shop_service.recent_orders(limit=200)
    order = next((o for o in orders if o.id == order_id), None)
    if order is None:
        return {"loi": f"Không tìm thấy đơn #{order_id}."}

    if ctx.get("is_admin"):
        refunded = await shop_service.refund_order(order_id, ctx["user_id"], reason)
        if refunded is None:
            return {"loi": f"Đơn #{order_id} không hoàn tiền được (đã hoàn trước đó?)."}
        try:
            await ctx["bot"].send_message(
                refunded.user_id,
                f"💰 Đơn #{refunded.id} ({refunded.account_code}) đã được hoàn {fmt_vnd(refunded.price)}.",
                parse_mode="HTML",
            )
        except Exception:
            pass
        return {"ok": True, "da_hoan": fmt_vnd(order.price), "nguoi_mua": order.user_id}

    if order.user_id != ctx["user_id"]:
        return {"loi": "Đơn này không thuộc về bạn."}
    if order.status == "refunded":
        return {"loi": f"Đơn #{order_id} đã được hoàn tiền trước đó."}

    async with session_scope() as session:
        ticket = Ticket(
            user_id=ctx["user_id"],
            type="warranty",
            subject=f"Hoàn tiền đơn #{order_id} ({order.account_code})",
        )
        session.add(ticket)
        await session.flush()
        session.add(
            TicketMessage(
                ticket_id=ticket.id,
                sender_id=ctx["user_id"],
                is_admin=False,
                text=reason,
            )
        )
        ticket_id = ticket.id
    await notify_admins(
        ctx["bot"],
        f"🤖 <b>AI chuyển yêu cầu hoàn tiền</b>\n• Đơn: #{order_id} · {order.account_code} · "
        f"{fmt_vnd(order.price)}\n• User: <code>{ctx['user_id']}</code>\n• Lý do: {reason[:200]}\n"
        f"• Ticket: #{ticket_id}",
    )
    return {
        "da_tao_yeu_cau": True,
        "ticket": ticket_id,
        "ghi_chu": "Admin sẽ duyệt. Người chơi chưa được cộng tiền ngay.",
    }


_HANDLERS = {
    "kho_acc": _tool_kho_acc,
    "chi_tiet_acc": _tool_chi_tiet_acc,
    "thong_ke_kho": _tool_thong_ke_kho,
    "vi_cua_toi": _tool_vi,
    "don_hang_cua_toi": _tool_don_hang,
    "dat_cuoc": _tool_dat_cuoc,
    "hoan_tien_don": _tool_hoan_tien,
}


async def _run_tool(name: str, arguments: str, ctx: dict) -> str:
    handler = _HANDLERS.get(name)
    if handler is None:
        return json.dumps({"loi": f"Công cụ {name} không tồn tại."}, ensure_ascii=False)
    try:
        args = json.loads(arguments or "{}")
        if not isinstance(args, dict):
            args = {}
    except ValueError:
        args = {}
    try:
        result = await handler(ctx, args)
    except Exception as exc:  # a broken tool must never crash the chat
        log.warning("AI tool %s failed: %s", name, exc)
        return json.dumps({"loi": f"Lỗi khi chạy {name}."}, ensure_ascii=False)
    return json.dumps(result, ensure_ascii=False, default=str)


# --------------------------------------------------------------------------- chat
async def _context_block(ctx: dict) -> str:
    stats = await shop_service.stock_overview()
    games = _game_list()
    return (
        f"Người dùng: id {ctx['user_id']}, tên {ctx.get('name') or 'khách'}, "
        f"admin: {'có' if ctx.get('is_admin') else 'không'}.\n"
        f"Kho hiện có {stats['dang_ban']} acc đang bán ({stats['info']} acc sẵn thông tin, "
        f"{stats['random']} acc random), {stats['cho_duyet']} chờ duyệt, "
        f"giá từ {fmt_vnd(stats['gia_min'])} đến {fmt_vnd(stats['gia_max'])}.\n"
        f"Game casino: {games}."
    )


# --------------------------------------------------------------------------- routing
# Every call goes through a small router instead of one fixed model+key:
#   * ``chat`` answers short questions -> cheap model, tiny token budget;
#   * ``extract`` reads account files -> stronger model, few calls;
#   * 429/401 rotates the API key, a dead model moves to the next model;
#   * cooling keys/models are skipped so a dead quota never costs time or tokens.
_stats: dict = {
    "calls": 0,
    "ok": 0,
    "failed": 0,
    "rate_limited": 0,
    "switched": 0,
    "tokens_in": 0,
    "tokens_out": 0,
    "last_error": "",
}
_key_until: dict[int, float] = {}
_model_until: dict[str, float] = {}
_rate_window: deque[float] = deque()
_semaphore: asyncio.Semaphore | None = None


def _key_label(index: int) -> str:
    return f"key#{index + 1}"


def _cooling(deadline: dict, key) -> bool:
    return deadline.get(key, 0.0) > time.monotonic()


def _semaphore_for_calls() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(max(1, AI_MAX_CONCURRENCY))
    return _semaphore


def _allow_request() -> bool:
    """Global requests-per-minute budget, shared by chat and extraction."""
    limit = max(1, AI_REQUESTS_PER_MINUTE)
    now = time.monotonic()
    while _rate_window and now - _rate_window[0] > 60:
        _rate_window.popleft()
    if len(_rate_window) >= limit:
        return False
    _rate_window.append(now)
    return True


def _effort_params() -> dict:
    """Reasoning-effort hint, only when the deployment opted in."""
    return {"reasoning_effort": AI_REASONING_EFFORT} if AI_REASONING_EFFORT else {}


def model_chain(route: str = "chat", preferred: str | None = None) -> list[str]:
    """Models to try, best fit for the route first, then fallbacks."""
    candidates = [preferred or "", AI_MODEL_CHAT if route == "chat" else AI_MODEL_EXTRACT, AI_MODEL, *AI_MODELS]
    chain: list[str] = []
    for model in candidates:
        model = (model or "").strip()
        if model and model not in chain:
            chain.append(model)
    return chain


def status() -> dict:
    """Health snapshot for the admin screen (never exposes the keys themselves)."""
    now = time.monotonic()
    return {
        "keys": [
            {
                "label": _key_label(index),
                "ready": _key_until.get(index, 0.0) <= now,
                "retry_in": max(0, int(_key_until.get(index, 0.0) - now)),
            }
            for index in range(len(AI_API_KEYS))
        ],
        "models": [
            {
                "name": model,
                "ready": _model_until.get(model, 0.0) <= now,
                "retry_in": max(0, int(_model_until.get(model, 0.0) - now)),
            }
            for model in model_chain("chat")
        ],
        "stats": dict(_stats),
        "budget": AI_REQUESTS_PER_MINUTE,
        "concurrency": AI_MAX_CONCURRENCY,
    }


def reset_cooldowns() -> None:
    _key_until.clear()
    _model_until.clear()


async def _http(body: dict, key: str) -> tuple[dict | None, int, str]:
    url = f"{AI_BASE_URL.rstrip('/')}/chat/completions"
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
    if "generativelanguage.googleapis.com" in url or key.startswith("AQ.") or key.startswith("AIza"):
        headers["x-goog-api-key"] = key
        if "key=" not in url:
            sep = "&" if "?" in url else "?"
            url = f"{url}{sep}key={key}"
    timeout = aiohttp.ClientTimeout(total=AI_TIMEOUT)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, json=body, headers=headers) as response:
                data = await response.json(content_type=None)
                if response.status >= 400:
                    return None, response.status, str(data)[:300]
                return (data if isinstance(data, dict) else None), response.status, ""
    except Exception as exc:  # timeout, DNS, TLS...
        return None, 0, str(exc)[:200]


async def _call(route: str, payload: dict, preferred: str | None = None) -> dict | None:
    """Send a request with key + model failover, respecting the global budget."""
    if not AI_API_KEYS:
        return None

    chain = model_chain(route, preferred)
    attempts = 0
    last_error = ""

    for model in chain:
        if _cooling(_model_until, model):
            continue
        for index, key in enumerate(AI_API_KEYS):
            if attempts >= MAX_ATTEMPTS:
                break
            if _cooling(_key_until, index):
                continue
            if not _allow_request():
                _stats["failed"] += 1
                _stats["last_error"] = "vượt hạn mức AI_REQUESTS_PER_MINUTE"
                log.warning("AI: vượt hạn mức %s request/phút, bỏ qua lượt này", AI_REQUESTS_PER_MINUTE)
                return None

            attempts += 1
            body = dict(payload)
            body["model"] = model
            async with _semaphore_for_calls():
                data, code, error = await _http(body, key)
            _stats["calls"] += 1

            if data is not None and code < 400:
                _stats["ok"] += 1
                usage = data.get("usage") or {}
                _stats["tokens_in"] += int(usage.get("prompt_tokens") or 0)
                _stats["tokens_out"] += int(usage.get("completion_tokens") or 0)
                return data

            last_error = f"{code}: {error}"
            _stats["last_error"] = last_error
            lowered = (error or "").lower()

            if code == 429:
                _stats["rate_limited"] += 1
                _stats["switched"] += 1
                _key_until[index] = time.monotonic() + max(5, AI_KEY_COOLDOWN)
                log.warning("AI %s bị rate limit, đổi key/model khác", _key_label(index))
                continue
            if code in (401, 403):
                _stats["switched"] += 1
                _key_until[index] = time.monotonic() + 60
                log.warning("AI %s bị từ chối (%s), tạm khoá 60s", _key_label(index), code)
                continue
            if code == 400 and "reasoning" in lowered and "reasoning_effort" in body:
                # Provider does not accept the hint: drop it and retry once.
                payload.pop("reasoning_effort", None)
                log.info("AI không hỗ trợ reasoning_effort, bỏ tham số và thử lại")
                continue
            if code == 404 or (code == 400 and "model" in lowered):
                _stats["switched"] += 1
                _model_until[model] = time.monotonic() + max(60, AI_MODEL_COOLDOWN)
                log.warning("AI model %s không dùng được (%s), chuyển model dự phòng", model, code)
                break
            if code == 0 or code >= 500:
                _key_until[index] = time.monotonic() + 15
                _model_until[model] = time.monotonic() + 15
                log.warning("AI lỗi tạm thời (%s), thử key/model khác", last_error)
                break
            log.warning("AI API error %s: %s", code, error)
            return None
        if attempts >= MAX_ATTEMPTS:
            break

    _stats["failed"] += 1
    if last_error:
        log.warning(
            "AI hết lựa chọn (keys=%s, models=%s): %s", len(AI_API_KEYS), len(chain), last_error
        )
    return None


async def _smart_fallback(user_id: int, message: str, ctx: dict) -> str:
    """Local intelligent fallback that queries live database when external LLM is offline or 401."""
    text = (message or "").lower()

    # 1. Kho acc & giá & tìm kiếm
    if any(k in text for k in ["kho", "acc", "giá", "gia", "mua", "rank", "skin", "tướng", "tuong", "vip", "random"]):
        stats = await shop_service.stock_overview()
        accounts, _ = await shop_service.list_accounts(page=0, per_page=3, kind="info")
        lines = [
            "🤖 <b>Trợ lý AI (Thông tin Kho Acc Liên Quân):</b>",
            f"• <b>Kho Random:</b> {stats.get('random', 0):,} acc (đồng giá <b>3.000đ</b> hoặc <b>15.000 xu</b>)",
            f"• <b>Acc Sẵn Thông Tin (VIP):</b> {stats.get('info', 0):,} acc (từ <b>{fmt_vnd(stats.get('gia_min', 16000))}</b> - xem full info)",
            f"• <b>Acc Trắng Thông Tin:</b> <b>7.000đ</b> (chưa liên kết SĐT/Gmail)",
        ]
        if accounts:
            lines.append("\n<b>Một số acc sẵn thông tin nổi bật:</b>")
            for a in accounts[:3]:
                lines.append(f"• <b>{a.code}</b> · Rank {a.rank} · {a.heroes} tướng, {a.skins} skin · <b>{fmt_vnd(a.price)}</b>")
        lines.append("\n👉 Bạn có thể mở menu <b>🛒 Shop Acc</b> hoặc nhập mã acc (ví dụ: <code>LQ0006</code>) để xem và mua ngay!")
        return "\n".join(lines)

    # 2. Ví tiền & Số dư
    if any(k in text for k in ["ví", "vi", "tiền", "tien", "số dư", "so du", "xu", "nạp", "nap"]):
        user = await wallet.get_user(user_id)
        bal = user.shop_balance if user else 0
        coins = user.coins if user else 0
        vip = user.vip_level if user else 0
        return (
            "🤖 <b>Trợ lý AI (Thông tin Ví của bạn):</b>\n"
            f"• 💵 <b>Số dư ví shop:</b> <b>{fmt_vnd(bal)}</b>\n"
            f"• 🪙 <b>Ví xu Casino:</b> <b>{fmt_coin(coins)}</b>\n"
            f"• 👑 <b>Cấp độ VIP:</b> {vip}\n\n"
            "👉 Để nạp tiền vào ví shop, hãy mở menu <b>💳 Nạp tiền</b> (hỗ trợ VietQR quét mã tự động)."
        )

    # 3. Đơn hàng & Bảo hành
    if any(k in text for k in ["đơn", "don", "lịch sử", "lich su", "bảo hành", "bao hanh", "hoàn tiền", "hoan tien"]):
        orders = await shop_service.orders_of(user_id, limit=3)
        if not orders:
            return (
                "🤖 <b>Trợ lý AI:</b>\n"
                "Bạn chưa có đơn mua acc nào gần đây. Hãy vào <b>🛒 Shop Acc</b> để chọn mua tài khoản ưng ý nhé!"
            )
        lines = ["🤖 <b>Trợ lý AI (Đơn hàng gần đây của bạn):</b>"]
        for o in orders:
            lines.append(f"• Đơn #{o.id} · Acc <b>{o.account_code}</b> · {fmt_vnd(o.price)} · Trạng thái: {o.status}")
        lines.append("\n💡 Để xem lại tài khoản & mật khẩu của acc đã mua, bấm vào đơn hàng hoặc dùng mã acc.")
        return "\n".join(lines)

    # 4. Casino & Giải trí
    if any(k in text for k in ["casino", "tài xỉu", "tai xiu", "chẵn lẻ", "chan le", "cược", "cuoc", "game"]):
        games = _game_list()
        return (
            "🤖 <b>Trợ lý AI (Sảnh Casino Xu Ảo):</b>\n"
            f"Các trò chơi đang mở: {games}.\n"
            "• Xu dùng để giải trí, nhận miễn phí hàng ngày tại <b>🎁 Điểm danh</b> và vòng quay may mắn.\n"
            "👉 Mở menu <b>🎰 Casino</b> để bắt đầu chơi!"
        )

    # 5. Mặc định
    return (
        "🤖 <b>Trợ lý AI xin chào bạn!</b>\n"
        "Tôi có thể hỗ trợ bạn:\n"
        "• 🛒 <b>Tư vấn acc:</b> tra cứu acc theo giá, rank, skin trong kho.\n"
        "• 💵 <b>Ví & Nạp tiền:</b> kiểm tra số dư ví shop, xu casino.\n"
        "• 📦 <b>Đơn hàng:</b> kiểm tra acc đã mua và thời hạn bảo hành.\n\n"
        "Bạn cần tìm acc thế nào hoặc cần hỗ trợ gì cứ nhắn cho tôi nhé!"
    )


async def reply(
    user_id: int,
    message: str,
    history: list[dict] | None = None,
    is_admin: bool = False,
    name: str = "",
    bot=None,
) -> str | None:
    """Ask the assistant and return its answer as plain text (None when unavailable)."""
    ctx = {"user_id": int(user_id), "is_admin": bool(is_admin), "name": name, "bot": bot}
    if not configured():
        return await _smart_fallback(user_id, message, ctx)

    try:
        messages: list[dict] = [
            {"role": "system", "content": await system_prompt()},
            {"role": "system", "content": await _context_block(ctx)},
        ]
        for item in (history or [])[-MAX_HISTORY:]:
            if item.get("role") in ("user", "assistant") and item.get("content"):
                messages.append({"role": item["role"], "content": str(item["content"])[:AI_HISTORY_CHARS]})
        messages.append({"role": "user", "content": message[:MAX_QUESTION_CHARS]})

        preferred = await model_name()
        for _round in range(MAX_ROUNDS):
            payload = {
                "messages": messages,
                "tools": TOOLS,
                "tool_choice": "auto",
                "temperature": 0.4,
                "max_tokens": AI_MAX_TOKENS,
                **_effort_params(),
            }
            data = await _call("chat", payload, preferred=preferred)
            if not data:
                return await _smart_fallback(user_id, message, ctx)
            choices = data.get("choices") or []
            if not choices:
                return await _smart_fallback(user_id, message, ctx)
            answer = choices[0].get("message") or {}
            tool_calls = answer.get("tool_calls") or []
            if not tool_calls:
                text = (answer.get("content") or "").strip()
                return text or await _smart_fallback(user_id, message, ctx)

            messages.append(
                {
                    "role": "assistant",
                    "content": answer.get("content") or "",
                    "tool_calls": tool_calls,
                }
            )
            for call in tool_calls:
                function = call.get("function") or {}
                output = await _run_tool(function.get("name", ""), function.get("arguments", "{}"), ctx)
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.get("id", ""),
                        "name": function.get("name", ""),
                        "content": output,
                    }
                )

        return await _smart_fallback(user_id, message, ctx)
    except Exception as exc:
        log.warning("AI reply error: %s, using smart fallback", exc)
        return await _smart_fallback(user_id, message, ctx)


EXTRACT_PROMPT = (
    "Bạn là công cụ trích xuất dữ liệu acc game Liên Quân Mobile từ văn bản thô "
    "(file checker, file Excel copy ra, tin nhắn lộn xộn, nhiều acc trong một file).\n"
    "Trả về DUY NHẤT một JSON object dạng {\"accounts\": [ {...}, {...} ]}, không giải thích, không markdown.\n"
    "Mỗi object dùng đúng các khóa sau (bỏ trống nếu không có dữ liệu):\n"
    '- price: số nguyên VNĐ (ví dụ 500000). Nếu file ghi \"500k\" thì đổi thành 500000.\n'
    '- rank: hạng/khung rank (Kim Cương, Bạch Kim, 3S...).\n'
    "- level: số nguyên cấp độ.\n"
    "- heroes: số tướng.\n"
    "- skins: tổng số skin.\n"
    '- login_type: Facebook / Google / Riot / Garena.\n'
    "- username: tài khoản đăng nhập acc (user, email, UID đăng nhập).\n"
    "- password: mật khẩu acc.\n"
    '- warranty_days: số ngày bảo hành (mặc định 3).\n'
    '- description: mô tả ngắn gọn còn lại (tên acc, ghi chú, skin hiếm).\n'
    '- category: loại kho (3S, 2S, 1S, Anime, SS, Random...).\n'
    '- is_banned: true nếu acc bị ban, false nếu không.\n'
    '- uid, fb_uid, email_info, phone_info, last_login, ban_note: thông tin phụ nếu có.\n'
    "Không bịa tài khoản/mật khẩu/giá không có trong văn bản. Nếu không tìm thấy acc nào, "
    "trả về {\"accounts\": []}."
)

MAX_EXTRACT_CHUNKS = MAX_CHUNKS
CHUNK_CHARS = 6000
_EXTRACT_CACHE: dict[str, tuple[float, dict]] = {}
_EXTRACT_TTL = 300.0


def _chunks(text: str, size: int = CHUNK_CHARS) -> list[str]:
    """Split a long dump on line boundaries so each chunk fits a model call."""
    lines = (text or "").splitlines()
    out: list[str] = []
    current: list[str] = []
    length = 0
    for line in lines:
        if length + len(line) + 1 > size and current:
            out.append("\n".join(current))
            current, length = [], 0
        current.append(line)
        length += len(line) + 1
    if current:
        out.append("\n".join(current))
    return [chunk for chunk in out if chunk.strip()]


def _loads_json(content: str):
    """Read JSON from a model answer that may be wrapped in prose or code fences."""
    cleaned = (content or "").strip()
    cleaned = re.sub(r"^```(?:json)?|```$", "", cleaned).strip()
    for opener, closer in (("{", "}"), ("[", "]")):
        start = cleaned.find(opener)
        end = cleaned.rfind(closer)
        if start == -1 or end <= start:
            continue
        try:
            return json.loads(cleaned[start : end + 1])
        except ValueError:
            continue
    return None


async def extract_accounts(text: str) -> dict:
    """Turn a messy account file into shop rows with the model.

    Returns ``{"ok": bool, "records": [...], "errors": [...], "chunks": int}``.
    Prices and credentials are never invented: the model is told to output only
    what the file contains, and ``shop_service.import_ai_accounts`` validates
    every row before it reaches the database.
    """
    raw = (text or "").strip()
    if not raw:
        return {"ok": False, "records": [], "errors": ["Nội dung file rỗng."], "chunks": 0}
    if not configured():
        return {
            "ok": False,
            "records": [],
            "errors": ["Chưa cấu hình AI_API_KEY nên không đọc được file bằng AI."],
            "chunks": 0,
        }

    digest = hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()
    cached = _EXTRACT_CACHE.get(digest)
    if cached and time.monotonic() - cached[0] < _EXTRACT_TTL:
        log.info("AI extract cache hit, không gọi lại API")
        return cached[1]

    chunks = _chunks(raw)[:MAX_EXTRACT_CHUNKS]
    records: list[dict] = []
    errors: list[str] = []
    for index, chunk in enumerate(chunks, start=1):
        if len(records) >= 300:  # IMPORT_MAX_ROWS ceiling
            break
        data = await _call(
            "extract",
            {
                "messages": [
                    {"role": "system", "content": EXTRACT_PROMPT},
                    {"role": "user", "content": chunk},
                ],
                "temperature": 0,
                "max_tokens": AI_MAX_TOKENS_EXTRACT,
                "response_format": {"type": "json_object"},
                **_effort_params(),
            },
        )
        if not data:
            errors.append(f"phần {index}: AI không phản hồi")
            continue
        choices = data.get("choices") or []
        content = ((choices[0].get("message") or {}).get("content") if choices else "") or ""
        parsed = _loads_json(content)
        if isinstance(parsed, dict):
            parsed = parsed.get("accounts") or parsed.get("acc") or []
        if not isinstance(parsed, list):
            errors.append(f"phần {index}: AI trả về dữ liệu không đọc được")
            continue
        for item in parsed:
            if isinstance(item, dict):
                records.append(item)

    if not records and not errors:
        errors.append("AI không tìm thấy acc nào trong nội dung này.")
    result = {"ok": True, "records": records, "errors": errors, "chunks": len(chunks)}
    if records:
        # Remember the result for a few minutes: re-sending the same file is free.
        if len(_EXTRACT_CACHE) > 20:
            _EXTRACT_CACHE.clear()
        _EXTRACT_CACHE[digest] = (time.monotonic(), result)
    return result


def to_html(text: str) -> str:
    """Convert a small markdown subset from the model into safe Telegram HTML."""
    from handlers.ui import esc

    safe = esc(text or "")
    safe = re.sub(r"`([^`\n]{1,200})`", r"<code>\1</code>", safe)
    safe = re.sub(r"\*\*([^*\n]{1,200})\*\*", r"<b>\1</b>", safe)
    safe = re.sub(r"(?m)^\s*[-*]\s+", "• ", safe)
    safe = re.sub(r"(?m)^#{1,6}\s*(.+)$", r"<b>\1</b>", safe)
    return safe.strip()
