"""Fernet encryption for account credentials (never stored in plain text)."""

from __future__ import annotations

import os

from cryptography.fernet import Fernet, InvalidToken

from config import DATA_DIR, FERNET_KEY
from utils.logger import get_logger

log = get_logger(__name__)

_KEY_FILE = DATA_DIR / "fernet.key"
_fernet: Fernet | None = None


def _load_key() -> bytes:
    if FERNET_KEY:
        return FERNET_KEY.encode()
    if _KEY_FILE.exists():
        return _KEY_FILE.read_bytes().strip()
    key = Fernet.generate_key()
    _KEY_FILE.write_bytes(key)
    try:
        os.chmod(_KEY_FILE, 0o600)
    except OSError:
        pass
    log.warning("FERNET_KEY is not set; generated a local key at %s", _KEY_FILE)
    return key


def fernet() -> Fernet:
    global _fernet
    if _fernet is None:
        _fernet = Fernet(_load_key())
    return _fernet


def encrypt(value: str) -> str:
    if not value:
        return ""
    return fernet().encrypt(value.encode("utf-8")).decode("utf-8")


def decrypt(token: str) -> str:
    if not token:
        return ""
    try:
        return fernet().decrypt(token.encode("utf-8")).decode("utf-8")
    except (InvalidToken, ValueError):
        log.error("Cannot decrypt a stored credential; FERNET_KEY may have changed")
        return ""
