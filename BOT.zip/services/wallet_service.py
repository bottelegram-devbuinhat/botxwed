"""Wallet logic: balances, deposits and withdrawals (all amounts are integers)."""

from __future__ import annotations

import secrets
from datetime import datetime

from sqlalchemy import select, update

from database.models import Deposit, Transaction, User, Withdrawal
from database.session import session_scope
from services.settings_service import all_settings
from utils.logger import get_logger

log = get_logger(__name__)

VIP_THRESHOLDS = [
    (30_000_000, 5),
    (10_000_000, 4),
    (3_000_000, 3),
    (1_000_000, 2),
    (200_000, 1),
]


def vip_for(total_deposited: int) -> int:
    for threshold, level in VIP_THRESHOLDS:
        if total_deposited >= threshold:
            return level
    return 0


async def _apply(
    session,
    user: User,
    amount: int,
    kind: str,
    currency: str = "vnd",
    note: str = "",
    ref: str | None = None,
) -> int:
    """Apply a signed balance change and record a transaction. Must run in a session."""
    if currency == "coin":
        user.coins = max(0, int(user.coins) + amount)
        balance_after = user.coins
    else:
        user.shop_balance = max(0, int(user.shop_balance) + amount)
        balance_after = user.shop_balance
    session.add(
        Transaction(
            user_id=user.id,
            kind=kind,
            currency=currency,
            amount=amount,
            balance_after=balance_after,
            note=(note or "")[:255],
            ref=ref,
        )
    )
    return balance_after


async def ensure_user(
    tg_id: int,
    username: str | None = None,
    full_name: str | None = None,
    referrer_id: int | None = None,
) -> User:
    async with session_scope() as session:
        user = await session.get(User, int(tg_id))
        if user is None:
            ref = None
            if referrer_id and int(referrer_id) != int(tg_id):
                ref_user = await session.get(User, int(referrer_id))
                ref = ref_user.id if ref_user else None
            user = User(
                id=int(tg_id),
                username=(username or None),
                full_name=(full_name or "")[:255],
                referrer_id=ref,
            )
            session.add(user)
            await session.flush()
            return user
        if username is not None and user.username != username:
            user.username = username
        if full_name and user.full_name != full_name:
            user.full_name = full_name[:255]
        return user


async def get_user(tg_id: int) -> User | None:
    async with session_scope() as session:
        return await session.get(User, int(tg_id))


async def update_user(user_id: int, **fields) -> bool:
    """Update simple user columns (language, flags, referrer...)."""
    allowed = {
        "language",
        "hide_name",
        "notifications",
        "referrer_id",
        "is_muted_casino",
        "is_banned",
        "vip_level",
    }
    clean = {key: value for key, value in fields.items() if key in allowed}
    if not clean:
        return False
    async with session_scope() as session:
        user = await session.get(User, int(user_id))
        if user is None:
            return False
        for key, value in clean.items():
            setattr(user, key, value)
    return True


async def add_balance(
    user_id: int,
    amount: int,
    kind: str,
    currency: str = "vnd",
    note: str = "",
    ref: str | None = None,
) -> bool:
    if amount <= 0:
        return False
    async with session_scope() as session:
        if ref:
            exists = (await session.execute(select(Transaction.id).where(Transaction.ref == ref))).first()
            if exists:
                log.info("Duplicate transaction ref %s ignored", ref)
                return False
        user = await session.get(User, int(user_id))
        if user is None:
            return False
        await _apply(session, user, amount, kind, currency, note, ref)
    return True


async def spend(
    user_id: int,
    amount: int,
    kind: str,
    currency: str = "vnd",
    note: str = "",
    ref: str | None = None,
) -> bool:
    """Atomically deduct ``amount``; returns False when the balance is insufficient."""
    if amount <= 0:
        return False
    async with session_scope() as session:
        if ref:
            exists = (await session.execute(select(Transaction.id).where(Transaction.ref == ref))).first()
            if exists:
                return False
        column = User.coins if currency == "coin" else User.shop_balance
        result = await session.execute(
            update(User)
            .where(User.id == int(user_id), column >= amount)
            .values({column: column - amount})
        )
        if result.rowcount != 1:
            return False
        user = await session.get(User, int(user_id))
        if user is None:
            return False
        await session.refresh(user)
        balance_after = user.coins if currency == "coin" else user.shop_balance
        session.add(
            Transaction(
                user_id=user.id,
                kind=kind,
                currency=currency,
                amount=-amount,
                balance_after=balance_after,
                note=(note or "")[:255],
                ref=ref,
            )
        )
    return True


# --------------------------------------------------------------------------- deposits
async def create_deposit(user_id: int, amount: int, method: str = "bank") -> Deposit | None:
    settings = await all_settings()
    if amount < int(settings["min_deposit"]) or amount > int(settings["max_deposit"]):
        return None
    code = f"NAP{user_id}T{secrets.token_hex(2).upper()}"
    async with session_scope() as session:
        deposit = Deposit(user_id=int(user_id), amount=amount, method=method, code=code)
        session.add(deposit)
        await session.flush()
        return deposit


async def find_deposit_by_code(code: str) -> Deposit | None:
    async with session_scope() as session:
        return (
            await session.execute(select(Deposit).where(Deposit.code == code))
        ).scalar_one_or_none()


async def approve_deposit(deposit_id: int, admin_id: int | None = None) -> Deposit | None:
    settings = await all_settings()
    async with session_scope() as session:
        deposit = await session.get(Deposit, int(deposit_id))
        if deposit is None or deposit.status != "pending":
            return None
        user = await session.get(User, deposit.user_id)
        if user is None:
            return None

        deposit.status = "approved"
        deposit.admin_id = admin_id
        await _apply(
            session,
            user,
            deposit.amount,
            "deposit",
            "vnd",
            f"Nạp tiền #{deposit.id}",
            ref=f"deposit:{deposit.id}",
        )
        user.total_deposited = int(user.total_deposited) + deposit.amount

        promo = settings.get("deposit_promotion") or {}
        if promo.get("enabled") and deposit.amount >= int(promo.get("threshold", 0)):
            bonus = deposit.amount * int(promo.get("percent", 0)) // 100
            if bonus > 0:
                await _apply(
                    session,
                    user,
                    bonus,
                    "deposit_bonus",
                    "vnd",
                    f"Khuyến mãi nạp {promo.get('percent')}%",
                    ref=f"deposit_bonus:{deposit.id}",
                )
        user.vip_level = vip_for(user.total_deposited)
        return deposit


async def reject_deposit(deposit_id: int, admin_id: int | None = None, reason: str = "") -> Deposit | None:
    async with session_scope() as session:
        deposit = await session.get(Deposit, int(deposit_id))
        if deposit is None or deposit.status != "pending":
            return None
        deposit.status = "rejected"
        deposit.admin_id = admin_id
        deposit.note = (reason or "")[:255]
        return deposit


async def pending_deposits(limit: int = 10):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Deposit).where(Deposit.status == "pending").order_by(Deposit.created_at.desc()).limit(limit)
            )
        ).scalars().all()


async def deposits_of(user_id: int, limit: int = 20):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Deposit).where(Deposit.user_id == int(user_id)).order_by(Deposit.created_at.desc()).limit(limit)
            )
        ).scalars().all()


# --------------------------------------------------------------------------- withdrawals
async def request_withdraw(
    user_id: int, amount: int, bank: str, account_number: str, account_name: str
) -> Withdrawal | None:
    settings = await all_settings()
    if amount < int(settings["min_withdraw"]) or amount > int(settings["max_withdraw"]):
        return None
    fee = amount * int(settings.get("withdraw_fee_percent", 0)) // 100
    total = amount + fee
    async with session_scope() as session:
        # Atomic hold: two confirmations in flight must not both pass the check
        # and let the user withdraw the same money twice.
        held = await session.execute(
            update(User)
            .where(User.id == int(user_id), User.shop_balance >= total)
            .values(shop_balance=User.shop_balance - total)
        )
        if held.rowcount != 1:
            return None
        user = await session.get(User, int(user_id))
        if user is None:
            return None
        await session.refresh(user)
        withdrawal = Withdrawal(
            user_id=int(user_id),
            amount=amount,
            bank=bank[:64],
            account_number=account_number[:64],
            account_name=account_name[:128],
        )
        session.add(withdrawal)
        await session.flush()
        session.add(
            Transaction(
                user_id=user.id,
                kind="withdraw_hold",
                currency="vnd",
                amount=-total,
                balance_after=user.shop_balance,
                note=f"Yêu cầu rút #{withdrawal.id}",
            )
        )
        return withdrawal


async def approve_withdraw(withdrawal_id: int, admin_id: int) -> Withdrawal | None:
    async with session_scope() as session:
        withdrawal = await session.get(Withdrawal, int(withdrawal_id))
        if withdrawal is None or withdrawal.status != "pending":
            return None
        withdrawal.status = "approved"
        withdrawal.admin_id = admin_id
        return withdrawal


async def reject_withdraw(withdrawal_id: int, admin_id: int, reason: str = "") -> Withdrawal | None:
    async with session_scope() as session:
        withdrawal = await session.get(Withdrawal, int(withdrawal_id))
        if withdrawal is None or withdrawal.status != "pending":
            return None
        withdrawal.status = "rejected"
        withdrawal.admin_id = admin_id
        withdrawal.note = (reason or "")[:255]
        user = await session.get(User, withdrawal.user_id)
        if user is not None:
            settings = await all_settings()
            fee = withdrawal.amount * int(settings.get("withdraw_fee_percent", 0)) // 100
            await _apply(
                session,
                user,
                withdrawal.amount + fee,
                "withdraw_refund",
                "vnd",
                f"Hoàn tiền rút #{withdrawal.id}",
                ref=f"withdraw_refund:{withdrawal.id}",
            )
        return withdrawal


async def pending_withdrawals(limit: int = 10):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Withdrawal).where(Withdrawal.status == "pending").order_by(Withdrawal.created_at.asc()).limit(limit)
            )
        ).scalars().all()


async def transactions_of(user_id: int, limit: int = 10):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Transaction).where(Transaction.user_id == int(user_id)).order_by(Transaction.created_at.desc()).limit(limit)
            )
        ).scalars().all()


async def credit_deposit_direct(
    user_id: int, amount: int, note: str, ref: str | None = None
) -> bool:
    """Credit a deposit already confirmed by an external provider (e.g. prepaid card)."""
    if amount <= 0:
        return False
    async with session_scope() as session:
        if ref:
            exists = (await session.execute(select(Transaction.id).where(Transaction.ref == ref))).first()
            if exists:
                return False
        user = await session.get(User, int(user_id))
        if user is None:
            return False
        await _apply(session, user, amount, "deposit", "vnd", note, ref)
        user.total_deposited = int(user.total_deposited) + amount
        user.vip_level = vip_for(user.total_deposited)
    return True
