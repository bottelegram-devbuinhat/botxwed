"""Direct orders: buy now and pay by VietQR/SePay without pre-funding the wallet.

Ported from telegram-sales-bot (orderHandler.js + deliveryHandler.js +
webhookHandler.js). The old bot only sold from the wallet balance
(shop_service.buy_account). This adds the repo's one-step flow:

  create order -> VietQR with the exact amount + order code as the transfer
  content -> SePay webhook (or the poller) matches the code -> order paid
  -> auto-delivery of the account / credentials.

Order code format is the repo's: "ORD" + millisecond timestamp + 4 random
digits (e.g. ORD17637123456781234). Orders expire after ORDER_EXPIRY_MINUTES
(default 5) and the held account is released.
"""

from __future__ import annotations

import os
import random
import time
from datetime import datetime, timedelta

from sqlalchemy import select, update

from database.models import Account, Order, OrderItem, Product, User
from database.session import session_scope
from services import catalog_service, crypto_service, discount_service, shop_service
from services import payment_service
from utils.logger import get_logger
from utils.money import fmt_vnd

log = get_logger(__name__)

ORDER_EXPIRY_MINUTES = max(1, int(os.getenv("ORDER_EXPIRY_MINUTES", "5") or 5))


def generate_order_code() -> str:
    return f"ORD{int(time.time() * 1000)}{random.randint(0, 9999):04d}"


async def _bank_for_qr() -> tuple[str, str, str]:
    """Active saved bank account, else the env BANK_* values (repo: getBankConfig)."""
    active = await catalog_service.active_bank()
    if active:
        return active["bank_code"], active["account_no"], active["account_name"]
    from config import BANK_ACCOUNT, BANK_CODE, BANK_HOLDER

    return BANK_CODE, BANK_ACCOUNT, BANK_HOLDER


async def create_direct_order(
    user_id: int,
    items: list[dict],
    discount_code: str | None = None,
    payment_method: str = "vietqr",
    customer_email: str = "",
    bot=None,
) -> dict:
    """Create a pending direct order.

    items: [{"account_code": "LQ0001"}] for a unique Liên Quân account, or
    [{"product_id": 3, "quantity": 2}] for fungible products. Mixed lines are
    allowed. Returns {"ok": True, "order": Order-like dict} or
    {"ok": False, "error": ...}. The shop feature flag is checked by the
    handler before an order is created.
    """
    now = datetime.utcnow()
    expires_at = now + timedelta(minutes=ORDER_EXPIRY_MINUTES)

    lines: list[dict] = []
    account_codes: list[str] = []
    subtotal = 0

    async with session_scope() as session:
        user = await session.get(User, int(user_id))
        if user is None:
            return {"ok": False, "error": "Không tìm thấy người dùng."}

        for item in items:
            if item.get("account_code"):
                code = str(item["account_code"]).strip().upper()
                account = (
                    await session.execute(select(Account).where(Account.code == code))
                ).scalar_one_or_none()
                if account is None or account.status != "available" or account.is_hidden:
                    return {"ok": False, "error": f"Acc {code} đã được bán hoặc đang ẩn."}
                if account.held_by and account.held_by != int(user_id) and account.held_until and account.held_until > now:
                    return {"ok": False, "error": f"Acc {code} đang được người khác giữ."}
                price = await shop_service.price_for(user_id, account)
                lines.append(
                    {
                        "kind": "account",
                        "account_id": account.id,
                        "account_code": code,
                        "product_name": f"Acc {code}",
                        "quantity": 1,
                        "unit_price": int(price),
                        "subtotal": int(price),
                    }
                )
                account_codes.append(code)
                subtotal += int(price)
            elif item.get("product_id"):
                product = await session.get(Product, int(item["product_id"]))
                if product is None or not product.is_active or product.is_hidden:
                    return {"ok": False, "error": "Sản phẩm không còn bán."}
                qty = max(1, int(item.get("quantity") or 1))
                stock = await catalog_service._stock_of(session, product)
                if stock < qty:
                    return {"ok": False, "error": f"{product.name} chỉ còn {stock} (bạn chọn {qty})."}
                lines.append(
                    {
                        "kind": "product",
                        "product_id": product.id,
                        "product_name": product.name,
                        "quantity": qty,
                        "unit_price": int(product.price),
                        "subtotal": int(product.price) * qty,
                    }
                )
                subtotal += int(product.price) * qty
            else:
                return {"ok": False, "error": "Mục hàng không hợp lệ."}

    if not lines:
        return {"ok": False, "error": "Đơn hàng trống."}

    # Discount (repo: validateDiscountCode before creating the order).
    discount_amount = 0
    discount_row = None
    if discount_code:
        first = lines[0]
        check = await discount_service.validate_discount(
            discount_code,
            user_id,
            subtotal,
            product_id=first.get("product_id"),
            quantity=first.get("quantity", 1),
            unit_price=first.get("unit_price"),
        )
        if not check.get("valid"):
            return {"ok": False, "error": check.get("reason", "Mã giảm giá không hợp lệ.")}
        discount_amount = int(check["discount_amount"])
        discount_row = check["discount"]

    total = max(0, subtotal - discount_amount)
    code = generate_order_code()
    bank_code, bank_account, bank_holder = await _bank_for_qr()
    qr_url = payment_service.vietqr_url_bank(total, code, bank_code, bank_account, bank_holder)
    sub_days = None
    for line in lines:
        if line["kind"] == "product":
            async with session_scope() as session:
                prod = await session.get(Product, int(line["product_id"]))
                if prod is not None and prod.subscription_days:
                    sub_days = int(prod.subscription_days)
                    break

    primary = lines[0]
    async with session_scope() as session:
        order = Order(
            user_id=int(user_id),
            account_id=primary.get("account_id"),
            account_code=primary.get("account_code") or "",
            price=int(total),
            status="pending",
            order_code=code,
            product_id=primary.get("product_id"),
            product_name=primary["product_name"] if len(lines) == 1 else f"{len(lines)} sản phẩm",
            quantity=sum(line["quantity"] for line in lines),
            unit_price=int(primary["unit_price"]),
            total_amount=int(total),
            payment_code=code,
            qr_url=qr_url,
            expires_at=expires_at,
            discount_code=(discount_code or "").upper() if discount_code else "",
            discount_amount=discount_amount,
            payment_method=payment_method or "vietqr",
            customer_email=(customer_email or "")[:255],
            source="bot",
            subscription_days=sub_days,
        )
        session.add(order)
        await session.flush()
        for line in lines:
            if line["kind"] == "product":
                session.add(
                    OrderItem(
                        order_id=order.id,
                        product_id=line["product_id"],
                        product_name=line["product_name"],
                        quantity=line["quantity"],
                        unit_price=line["unit_price"],
                        subtotal=line["subtotal"],
                    )
                )
        # Hold the unique account(s) for the payment window (repo: the order
        # holds the stock; the old bot's release_holds_job frees it on expiry).
        for line in lines:
            if line["kind"] == "account":
                await session.execute(
                    update(Account)
                    .where(Account.id == line["account_id"], Account.status == "available")
                    .values(held_by=int(user_id), held_until=expires_at)
                )
        await session.refresh(order)
        order_id = order.id

    # A 100% discount makes the order free: pay + deliver immediately.
    if total <= 0:
        ok, paid_order = await confirm_order_payment(code, 0, "discount-free")
        if ok and paid_order is not None and bot is not None:
            await deliver_order(bot, paid_order)
        return {"ok": ok, "order_id": order_id, "order_code": code, "free": True}

    return {
        "ok": True,
        "order_id": order_id,
        "order_code": code,
        "total": int(total),
        "subtotal": int(subtotal),
        "discount_amount": int(discount_amount),
        "qr_url": qr_url,
        "expires_at": expires_at,
        "bank_code": bank_code,
        "bank_account": bank_account,
        "bank_holder": bank_holder,
    }


async def cancel_direct_order(order_code: str, user_id: int) -> bool:
    """Cancel a pending direct order (buyer pressed Hủy) and release the held account."""
    now = datetime.utcnow()
    async with session_scope() as session:
        order = (
            await session.execute(select(Order).where(Order.order_code == str(order_code or "").strip().upper()))
        ).scalar_one_or_none()
        if order is None or order.status != "pending" or order.user_id != int(user_id):
            return False
        order.status = "cancelled"
        if order.account_id:
            await session.execute(
                update(Account).where(Account.id == order.account_id).values(held_by=None, held_until=None)
            )
        return True


async def get_order_by_code(code: str) -> Order | None:
    async with session_scope() as session:
        row = (
            await session.execute(select(Order).where(Order.order_code == str(code or "").strip().upper()))
        ).scalar_one_or_none()
        return row


async def get_order(order_id: int) -> Order | None:
    async with session_scope() as session:
        return await session.get(Order, int(order_id))


async def pending_orders() -> list[Order]:
    async with session_scope() as session:
        return list(
            (await session.execute(select(Order).where(Order.status == "pending").order_by(Order.created_at.asc())))
            .scalars()
            .all()
        )


async def get_order_items(order_id: int) -> list[OrderItem]:
    async with session_scope() as session:
        return list(
            (await session.execute(select(OrderItem).where(OrderItem.order_id == int(order_id)).order_by(OrderItem.id.asc())))
            .scalars()
            .all()
        )


async def expire_orders(bot=None) -> int:
    """Cancel pending orders past their payment window and release held
    accounts (repo: orderExpiry checker; old bot: release_holds_job)."""
    now = datetime.utcnow()
    expired: list[Order] = []
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(Order).where(Order.status == "pending", Order.expires_at.is_not(None), Order.expires_at < now)
            )
        ).scalars().all()
        for order in rows:
            order.status = "expired"
            expired.append(order)
            if order.account_id:
                await session.execute(
                    update(Account)
                    .where(Account.id == order.account_id)
                    .values(held_by=None, held_until=None)
                )
    for order in expired:
        log.info("Order %s expired", order.order_code)
        if bot is not None:
            try:
                await bot.send_message(
                    order.user_id,
                    f"⏰ Đơn hàng <code>{order.order_code}</code> đã hết hạn thanh toán.\n"
                    f"Sản phẩm: {order.product_name}\n"
                    f"Số tiền: {fmt_vnd(order.total_amount)}\n\n"
                    "Bạn có thể tạo đơn hàng mới.",
                    parse_mode="HTML",
                )
            except Exception:
                pass
    return len(expired)


async def confirm_order_payment(order_code: str, amount: int, reference: str) -> tuple[bool, Order | None]:
    """Mark a pending direct order paid and deliver it. Idempotent: calling
    it twice for the same order does nothing the second time. Used by the
    SePay webhook AND the SePay poller (same logic, repo: webhookHandler +
    sepayPoller processMatchedPayment)."""
    code = str(order_code or "").strip().upper()
    async with session_scope() as session:
        order = (
            await session.execute(select(Order).where(Order.order_code == code))
        ).scalar_one_or_none()
        if order is None or order.status != "pending":
            return False, order
        if int(amount) < int(order.total_amount):
            log.warning("Underpaid direct order %s: %s < %s", code, amount, order.total_amount)
            return False, order
        order.status = "paid"
        order.paid_at = datetime.utcnow()
        order_id = order.id
        discount_id = None
        if order.discount_code:
            discount = await discount_service.get_discount_by_code(order.discount_code)
            discount_id = discount.id if discount else None
    if discount_id:
        await discount_service.use_discount(discount_id, order.user_id, code)
    order = await get_order(order_id)
    return True, order


async def deliver_order(bot, order: Order) -> bool:
    """Auto-delivery after payment (repo: deliverCredentials). Returns True
    when everything was delivered; False when manual admin handling is needed
    (e.g. a product ran out of credentials mid-order)."""
    if order is None:
        return False
    async with session_scope() as session:
        row = await session.get(Order, order.id)
        if row is None or row.status not in ("paid", "delivering"):
            return False
        row.status = "delivering"
        order_id = row.id
        user_id = row.user_id
        account_id = row.account_id
        account_code = row.account_code
        product_name = row.product_name
        total = int(row.total_amount)

    all_ok = True
    if account_id:
        all_ok = await _deliver_account(bot, order_id, user_id, account_id, account_code, product_name, total)
    else:
        items = await get_order_items(order_id)
        for item in items:
            ok = await _deliver_product_item(bot, order_id, user_id, item)
            all_ok = all_ok and ok

    async with session_scope() as session:
        row = await session.get(Order, order_id)
        if row is None:
            return False
        if all_ok:
            row.status = "delivered"
            row.delivered_at = datetime.utcnow()
            if row.subscription_expires_at is None and row.subscription_days:
                row.subscription_expires_at = datetime.utcnow() + timedelta(days=int(row.subscription_days))
        else:
            row.status = "delivering"  # admin handles the rest manually
    return all_ok


async def _deliver_account(bot, order_id: int, user_id: int, account_id: int, account_code: str, product_name: str, total: int) -> bool:
    """Deliver a unique Liên Quân account: mark it sold and send the
    decrypted credentials to the buyer (same message shape as the old
    wallet buy, so buyers see a familiar delivery)."""
    now = datetime.utcnow()
    username = password = ""
    warranty_days = 3
    login_type = ""
    async with session_scope() as session:
        account = await session.get(Account, int(account_id))
        if account is None:
            return False
        locked = await session.execute(
            update(Account)
            .where(Account.id == account.id, Account.status == "available")
            .values(status="sold", sold_at=now, held_by=None, held_until=None)
        )
        if locked.rowcount != 1:
            return False
        username = crypto_service.decrypt(account.username_enc)
        password = crypto_service.decrypt(account.password_enc)
        warranty_days = int(account.warranty_days or 3)
        login_type = account.login_type or ""
        order = await session.get(Order, int(order_id))
        if order is not None and order.warranty_until is None:
            order.warranty_until = now + timedelta(days=max(1, warranty_days))
    from handlers.ui import esc

    text = (
        f"🎉 <b>ĐƠN HÀNG ĐÃ THANH TOÁN — {esc(account_code)}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"👤 Tài khoản: <code>{esc(username)}</code>\n"
        f"🔑 Mật khẩu: <code>{esc(password)}</code>\n"
        + (f"🔐 Đăng nhập: {esc(login_type)}\n" if login_type else "")
        + f"💲 Đã thanh toán: <b>{fmt_vnd(total)}</b>\n"
        f"🛡 Bảo hành đến: <b>{(now + timedelta(days=max(1, warranty_days))):%d/%m/%Y}</b>\n"
        "▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        "<b>Việc cần làm ngay:</b>\n"
        "1. Đăng nhập và đổi mật khẩu.\n"
        "2. Gỡ liên kết Facebook/Google cũ (nếu có).\n"
        "3. Bật xác thực 2 lớp.\n\n"
        "⚠️ Không chia sẻ thông tin acc cho người khác."
    )
    try:
        await bot.send_message(user_id, text, parse_mode="HTML")
    except Exception as exc:  # noqa: BLE001 - delivery is recorded even if the DM fails
        log.warning("Cannot DM delivery for order %s: %s", order_id, exc)
        return False
    return True


async def _deliver_product_item(bot, order_id: int, user_id: int, item: OrderItem) -> bool:
    """Deliver one product line. Credential products take N unused credential
    rows and send them; invite/preorder products notify the admin to fulfil
    (repo: deliverCredential / deliverInvite / deliverPreorder)."""
    async with session_scope() as session:
        product = await session.get(Product, int(item.product_id))
        order = await session.get(Order, int(order_id))
    if product is None or order is None:
        return False

    if product.product_type == "credential":
        creds = await catalog_service.take_credentials(product.id, item.quantity, order_id)
        if len(creds) < int(item.quantity):
            log.error("Not enough credentials for order %s (need %s)", order.order_code, item.quantity)
            try:
                await bot.send_message(
                    user_id,
                    f"⚠️ Đơn hàng <code>{order.order_code}</code> đã được thanh toán.\n\n"
                    "Tuy nhiên, sản phẩm tạm thời hết stock. Admin sẽ liên hệ bạn sớm nhất!",
                    parse_mode="HTML",
                )
            except Exception:
                pass
            return False
        from handlers.ui import esc

        fields = []
        try:
            import json as _json

            fields = _json.loads(product.credential_fields or "[]")
        except ValueError:
            fields = []
        lines = [f"🎉 <b>ĐÃ GIAO — {esc(item.product_name)} × {item.quantity}</b>", "▰▰▰▰▰▰▰▰▰▰▰▰▰▰"]
        for index, cred in enumerate(creds, start=1):
            lines.append(f"<b>— Tài khoản {index} —</b>")
            for field in fields or [{"key": "username"}, {"key": "password"}]:
                key = field.get("key", "")
                label = field.get("label", key)
                value = str(cred.get(key, "") or "")
                if value:
                    lines.append(f"{esc(label)}: <code>{esc(value)}</code>")
        lines.append("▰▰▰▰▰▰▰▰▰▰▰▰▰▰")
        lines.append("Hãy đổi mật khẩu ngay sau khi đăng nhập.")
        try:
            await bot.send_message(user_id, "\n".join(lines), parse_mode="HTML")
        except Exception as exc:  # noqa: BLE001
            log.warning("Cannot DM delivery for order %s: %s", order_id, exc)
            return False
        async with session_scope() as session:
            row = await session.get(OrderItem, int(item.id))
            if row is not None:
                row.delivery_status = "delivered"
                row.delivered_at = datetime.utcnow()
        return True

    # invite / preorder: admin fulfils manually (repo flow).
    hours = int(product.delivery_hours or 24)
    from config import ADMIN_IDS
    from handlers.ui import esc

    admin_text = (
        f"📦 <b>ĐƠN {product.product_type.upper()} CẦN XỬ LÝ</b>\n\n"
        f"🆔 Đơn: <code>{esc(order.order_code)}</code>\n"
        f"📦 SP: <b>{esc(item.product_name)}</b> × {item.quantity}\n"
        f"👤 Khách: <code>{user_id}</code>\n"
        + (f"📧 Email: <b>{esc(order.customer_email)}</b>\n" if order.customer_email else "")
        + f"💰 Số tiền: {fmt_vnd(order.total_amount)}\n"
        f"⏰ Hẹn giao trong: <b>{hours} giờ</b>"
    )
    for admin_id in list(ADMIN_IDS)[:5]:
        try:
            await bot.send_message(admin_id, admin_text, parse_mode="HTML")
        except Exception:
            pass
    try:
        await bot.send_message(
            user_id,
            f"✅ <b>Đơn {esc(order.order_code)} đã thanh toán!</b>\n\n"
            f"📦 SP: <b>{esc(item.product_name)}</b>\n"
            f"⏰ Tài khoản sẽ được gửi trong vòng <b>{hours} giờ</b>.\n\n"
            "Bạn sẽ nhận thông báo khi hoàn tất. Cảm ơn bạn!",
            parse_mode="HTML",
        )
    except Exception:
        pass
    async with session_scope() as session:
        row = await session.get(OrderItem, int(item.id))
        if row is not None:
            row.delivery_status = "delivering"
    return True
