"""Parse AOV checker dumps ("HIT" info blocks) into account records.

Admins paste the output of their account checker and the bot turns each block
into a full-info shop account: rank, region, shells, ban state, email/phone
verification flags, skin tiers (SS, S+, S, EVO, Anime, Dreamer, Other) and more.

Example block::

    🔑 <code>shoseyye:a0121210</code>
    👤 UID: 466307155
    🌐 Region: VN
    💲 Sò: 0
    💰 Nạp sò: Chưa có
    📩 EMAIL: Chưa Xác Thực [vov****@gmail.com]
    📱 SĐT: Yes [****3851]
    🛡 PASS: Yes
    🔗 FB: 🔵 [Gốc: FB] {'fb_username': '', 'fb_uid': '834634410234791'} | 350791651640893
    🚫 BAND: YES 🚫
    ⏰ Login cuối: Hôm Nay (18:51:29 14/11/2026)
    👑 RANK: B.Kim I
    ✨ LEVEL: 30
    💎 SKIN: 190
    💪 HERO: 101
    ✨ SS: 6 [Valhein Vũ khí tối thượng, ...]
    📋 Tình Trạng: Full Info [BAN]
"""

from __future__ import annotations

import ast
import json
import re

SEPARATOR_RE = re.compile(r"^[\s━─—=_~\-]{5,}$")
TAG_RE = re.compile(r"</?[a-zA-Z][^>]{0,40}>")
LINE_RE = re.compile(r"^(?P<label>[^\s:][^:]{0,28}?)\s*:\s*(?P<value>.*)$")
CREDS_RE = re.compile(r"([^\s<>]+)\s*[:|]\s*([^\s<>]+)")

TIER_KEYS = {
    "ss": "SS",
    "s+": "S+",
    "s": "S",
    "evo": "EVO",
    "anime": "Anime",
    "s-dreamer": "S-Dreamer",
    "s dreamer": "S-Dreamer",
    "dreamer": "S-Dreamer",
    "other": "Other",
}

LABELS = {
    "uid": "uid",
    "id": "uid",
    "region": "region",
    "sv": "region",
    "sò": "shells",
    "so": "shells",
    "nạp sò": "shells_note",
    "nap so": "shells_note",
    "email": "email_info",
    "mail": "email_info",
    "sđt": "phone_info",
    "sdt": "phone_info",
    "số điện thoại": "phone_info",
    "phone": "phone_info",
    "pass": "has_pass",
    "password": "has_pass",
    "fb": "fb",
    "facebook": "fb",
    "band": "ban",
    "ban": "ban",
    "banned": "ban",
    "login cuối": "last_login",
    "login cuoi": "last_login",
    "last login": "last_login",
    "tạo gr": "gr",
    "tao gr": "gr",
    "name": "name",
    "tên": "name",
    "rank": "rank",
    "level": "level",
    "ngày tạo tk": "account_created",
    "ngay tao tk": "account_created",
    "skin": "skins",
    "hero": "heroes",
    "qh": "qh",
    "cccd": "has_cccd",
    "authen": "twofa",
    "auth": "twofa",
    "tình trạng": "status",
    "tinh trang": "status",
    "giá": "price",
    "gia": "price",
    "price": "price",
    "loại": "category",
    "loai": "category",
    "category": "category",
}


def _clean(value: str) -> str:
    return TAG_RE.sub("", str(value or "")).strip()


def _strip_prefix(line: str) -> str:
    """Drop leading emoji/markers, keep the label text (S+, UID, ...)."""
    return re.sub(r"^[^0-9A-Za-zÀ-ỹĐđ+]+", "", line.strip()).strip()


def _yes(value: str) -> bool:
    text = _clean(value).lower()
    if "chưa" in text or "chua" in text or "no " == text[:3]:
        return False
    return any(marker in text for marker in ("yes", "có", "co ", "✅", "true", "2fa"))


def _first_int(value: str) -> int:
    match = re.search(r"(\d[\d\.,]*)", _clean(value))
    if not match:
        return 0
    digits = re.sub(r"[^\d]", "", match.group(1))
    return int(digits) if digits else 0


def _bracket_names(value: str) -> list[str]:
    match = re.search(r"\[(.*)\]", _clean(value), re.S)
    if not match:
        return []
    names = [name.strip() for name in match.group(1).split(",")]
    return [name for name in names if name]


def _split_blocks(text: str) -> list[list[str]]:
    blocks: list[list[str]] = []
    current: list[str] = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if SEPARATOR_RE.match(line) or set(line) <= set("━─—=_- "):
            if current:
                blocks.append(current)
                current = []
            continue
        if line.startswith("🔑") and current and any("uid" in item.lower() for item in current):
            blocks.append(current)
            current = []
        current.append(line)
    if current:
        blocks.append(current)
    return [block for block in blocks if any(":" in item or "🔑" in item for item in block)]


def looks_like_hit(text: str) -> bool:
    lowered = (text or "").lower()
    return "🔑" in text or ("tình trạng" in lowered and ("skin" in lowered or "hero" in lowered)) or (
        "region" in lowered and "rank" in lowered and "skin" in lowered
    )


def _parse_fb(value: str, record: dict) -> None:
    text = _clean(value)
    match = re.search(r"\{.*\}", text)
    if match:
        try:
            data = ast.literal_eval(match.group(0))
        except (ValueError, SyntaxError):
            data = {}
        if isinstance(data, dict):
            record["fb_username"] = str(data.get("fb_username") or "")[:80]
            record["fb_uid"] = str(data.get("fb_uid") or "")[:80]
    link = text.split("|")[-1].strip() if "|" in text else ""
    record["fb_link"] = link[:80]


def _parse_creds(line: str, record: dict) -> None:
    text = _clean(line)
    if "🔑" in line:
        text = _clean(line.split("🔑", 1)[1])
    match = CREDS_RE.search(text)
    if match:
        record["username"] = match.group(1)[:255]
        record["password"] = match.group(2)[:255]


def infer_category(record: dict) -> str:
    """Guess a shop category (3S, 2S, Anime...) from the skin tiers."""
    if record.get("anime_count"):
        return "Anime"
    splus = int(record.get("splus_count") or 0)
    if splus >= 3:
        return "3S"
    if splus == 2:
        return "2S"
    if splus == 1:
        return "1S"
    if record.get("ss_count"):
        return "SS"
    return "Acc thường"


def parse_block(lines: list[str]) -> dict | None:
    record: dict = {"skin_lists": {}, "username": "", "password": ""}
    for line in lines:
        if "🔑" in line:
            _parse_creds(line, record)
            continue
        cleaned = _strip_prefix(line)
        match = LINE_RE.match(cleaned)
        if not match:
            continue
        label = match.group("label").strip().lower()
        value = match.group("value").strip()

        tier = TIER_KEYS.get(label)
        if tier:
            record["skin_lists"][tier] = _bracket_names(value)[:60]
            counts = {"SS": "ss_count", "S+": "splus_count", "S": "s_count", "EVO": "evo_count",
                      "Anime": "anime_count", "S-Dreamer": "dreamer_count", "Other": "other_count"}
            record[counts[tier]] = _first_int(value) or len(record["skin_lists"][tier])
            continue

        field = LABELS.get(label)
        if field is None:
            continue
        if field == "fb":
            _parse_fb(value, record)
        elif field == "ban":
            record["is_banned"] = _yes(value)
            record["ban_note"] = _clean(value)[:80]
        elif field in ("has_pass", "has_cccd", "twofa"):
            record[field] = _yes(value)
        elif field == "shells":
            record["shells"] = _first_int(value)
        elif field in ("skins", "heroes", "level", "qh", "price"):
            key = {"skins": "skins", "heroes": "heroes", "level": "level", "qh": "qh", "price": "price"}[field]
            record[key] = _first_int(value)
        elif field == "status":
            record["status_info"] = _clean(value)[:120]
        elif field == "category":
            record["category"] = _clean(value)[:32]
        else:
            record[field] = _clean(value)[:160]

    if not record.get("username") or not record.get("password"):
        return None
    if not record.get("rank") and not record.get("uid"):
        return None
    record["category"] = record.get("category") or infer_category(record)
    record["status_info"] = record.get("status_info") or ("Full Info [BAN]" if record.get("is_banned") else "Full Info")
    if record.get("is_banned"):
        # The BAND line only says YES/NO; show the checker verdict instead.
        record["ban_note"] = record["status_info"][:80]
    return record


def parse_hit_text(text: str) -> tuple[list[dict], list[str]]:
    """Return (records, errors). Records carry the full-info account fields."""
    records: list[dict] = []
    errors: list[str] = []
    for index, block in enumerate(_split_blocks(text), start=1):
        record = parse_block(block)
        if record is None:
            errors.append(f"acc {index}: thiếu tài khoản/mật khẩu hoặc rank")
            continue
        records.append(record)
    if not records and not errors:
        errors.append("Không tìm thấy block acc nào trong nội dung.")
    return records, errors


def skin_lists_json(record: dict) -> str:
    return json.dumps(record.get("skin_lists") or {}, ensure_ascii=False)[:6000]
