"""Liên Quân account shop: catalog, purchases, consignments, reviews."""

from __future__ import annotations

import csv
import io
import json
import secrets
from datetime import datetime, timedelta

from sqlalchemy import func, select, update

from config import ACCOUNT_HOLD_MINUTES, IMPORT_MAX_ROWS
from database.models import Account, Favorite, Order, Review, Transaction, User
from database.session import session_scope
from services import crypto_service
from services.settings_service import all_settings
from utils.logger import get_logger

log = get_logger(__name__)


async def _unique_code(session, account_id: int) -> str:
    """Build the public code from the row id, which is unique by construction.

    The old ``MAX(id) + 1`` scheme handed the same code to two simultaneous
    imports, and the second INSERT failed on the unique constraint. Deriving the
    code from the already-flushed id cannot collide; a numeric suffix only skips
    codes left behind by older rows.
    """
    base = f"LQ{int(account_id):04d}"
    code = base
    suffix = 0
    while True:
        taken = (
            await session.execute(
                select(Account.id).where(Account.code == code, Account.id != int(account_id))
            )
        ).first()
        if not taken:
            return code
        suffix += 1
        code = f"{base}X{suffix}"


DETAIL_FIELDS = (
    "kind",
    "category",
    "uid",
    "region",
    "shells",
    "shells_note",
    "email_info",
    "phone_info",
    "has_pass",
    "fb_username",
    "fb_uid",
    "fb_link",
    "is_banned",
    "ban_note",
    "last_login",
    "account_created",
    "has_cccd",
    "twofa",
    "ss_count",
    "splus_count",
    "s_count",
    "evo_count",
    "anime_count",
    "dreamer_count",
    "other_count",
    "skin_lists",
    "extra",
)


async def create_account(
    price: int,
    rank: str = "",
    level: int = 0,
    heroes: int = 0,
    skins: int = 0,
    rare_skins: str = "",
    login_type: str = "Facebook",
    warranty_days: int = 3,
    description: str = "",
    photos: list[str] | None = None,
    username: str = "",
    password: str = "",
    seller_id: int | None = None,
    status: str = "available",
    kind: str = "info",
    category: str = "",
    details: dict | None = None,
) -> Account:
    async with session_scope() as session:
        account = Account(
            code=secrets.token_hex(8),
            seller_id=seller_id,
            price=int(price),
            rank=rank[:64],
            level=int(level),
            heroes=int(heroes),
            skins=int(skins),
            rare_skins=rare_skins[:255],
            login_type=login_type[:32],
            warranty_days=int(warranty_days),
            description=description,
            photos=json.dumps(photos or []),
            username_enc=crypto_service.encrypt(username),
            password_enc=crypto_service.encrypt(password),
            status=status,
            kind=kind,
            category=category[:32],
        )
        for field, value in (details or {}).items():
            if field in DETAIL_FIELDS and value not in (None, ""):
                setattr(account, field, value)
        session.add(account)
        await session.flush()
        account.code = await _unique_code(session, account.id)
        await session.flush()
    try:
        from services.stock_sync_service import trigger_stock_sync
        trigger_stock_sync()
    except Exception:
        pass
    return account


async def _insert_accounts(rows: list[dict], seller_id: int | None = None) -> list[str]:
    """Insert many accounts in one transaction, generating continuous LQ codes."""
    codes: list[str] = []
    if not rows:
        return codes
    async with session_scope() as session:
        for row in rows:
            # Placeholder until the row id exists; then derive the final code.
            account = Account(
                code=secrets.token_hex(8),
                seller_id=seller_id,
                price=int(row.get("price") or 0),
                rank=str(row.get("rank") or "")[:64],
                level=int(row.get("level") or 0),
                heroes=int(row.get("heroes") or 0),
                skins=int(row.get("skins") or 0),
                login_type=str(row.get("login_type") or "Facebook")[:32],
                warranty_days=int(row.get("warranty_days") or 3),
                description=str(row.get("description") or "")[:4000],
                username_enc=crypto_service.encrypt(str(row.get("username") or "")),
                password_enc=crypto_service.encrypt(str(row.get("password") or "")),
                status="available",
            )
            for field in DETAIL_FIELDS:
                if field in row:
                    setattr(account, field, row[field])
            session.add(account)
            await session.flush()
            account.code = await _unique_code(session, account.id)
            codes.append(account.code)
        await session.flush()
    if codes:
        try:
            from services.stock_sync_service import trigger_stock_sync
            trigger_stock_sync()
        except Exception:
            pass
    return codes


async def get_account_by_code(code: str) -> Account | None:
    async with session_scope() as session:
        return (
            await session.execute(select(Account).where(Account.code == code.strip().upper()))
        ).scalar_one_or_none()


async def get_account(account_id: int) -> Account | None:
    async with session_scope() as session:
        return await session.get(Account, int(account_id))


async def list_accounts(
    page: int = 0,
    per_page: int = 6,
    sort: str = "newest",
    rank: str | None = None,
    min_price: int | None = None,
    max_price: int | None = None,
    search: str | None = None,
    favorites_of: int | None = None,
    status: str = "available",
    include_hidden: bool = False,
    kind: str | None = None,
    category: str | None = None,
) -> tuple[list[Account], int]:
    async with session_scope() as session:
        query = select(Account)
        if favorites_of:
            query = query.join(Favorite, Favorite.account_id == Account.id).where(Favorite.user_id == int(favorites_of))
        if status != "all":
            query = query.where(Account.status == status)
        if not include_hidden:
            query = query.where(Account.is_hidden.is_(False))
        if kind:
            query = query.where(Account.kind == kind)
        if category:
            query = query.where(Account.category == category)
        if rank:
            query = query.where(Account.rank == rank)
        if min_price is not None:
            query = query.where(Account.price >= min_price)
        if max_price is not None:
            query = query.where(Account.price <= max_price)
        if search:
            clean = search.strip()
            term = f"%{clean}%"
            query = query.where(
                Account.code.ilike(term)
                | Account.description.ilike(term)
                | Account.extra.ilike(term)
                | Account.rank.ilike(term)
                | Account.category.ilike(term)
                | Account.rare_skins.ilike(term)
                | Account.skin_lists.ilike(term)
            )

        total = (await session.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        ordering = {
            "newest": Account.created_at.desc(),
            "cheap": Account.price.asc(),
            "expensive": Account.price.desc(),
            "popular": Account.views.desc(),
        }.get(sort, Account.created_at.desc())
        rows = (
            await session.execute(query.order_by(ordering).offset(page * per_page).limit(per_page))
        ).scalars().all()
        return list(rows), int(total)


async def available_ranks() -> list[str]:
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(Account.rank).where(Account.status == "available", Account.is_hidden.is_(False)).distinct()
            )
        ).scalars().all()
        return [r for r in rows if r]


async def stock_overview() -> dict:
    """Totals used by the admin panel and the AI assistant (counts, price range, ranks)."""
    async with session_scope() as session:
        rows = (
            await session.execute(select(Account.status, func.count()).group_by(Account.status))
        ).all()
        counts = {str(status): int(count) for status, count in rows}
        price_min, price_max = (
            await session.execute(
                select(func.min(Account.price), func.max(Account.price)).where(
                    Account.status == "available", Account.is_hidden.is_(False)
                )
            )
        ).one()
        ranks = (
            await session.execute(
                select(Account.rank)
                .where(Account.status == "available", Account.is_hidden.is_(False), Account.rank != "")
                .distinct()
                .limit(12)
            )
        ).scalars().all()
    kinds = await count_by_kind()
    return {
        "dang_ban": counts.get("available", 0),
        "cho_duyet": counts.get("pending_approval", 0),
        "da_ban": counts.get("sold", 0),
        "tong_acc": sum(count for status, count in counts.items() if status != "deleted"),
        "random": kinds["random"],
        "info": kinds["info"],
        "gia_min": int(price_min or 0),
        "gia_max": int(price_max or 0),
        "rank": [rank for rank in ranks if rank],
    }


async def hold_account(user_id: int, code: str) -> tuple[bool, str]:
    """Temporarily lock an account while the buyer is confirming."""
    async with session_scope() as session:
        account = (
            await session.execute(select(Account).where(Account.code == code))
        ).scalar_one_or_none()
        if account is None:
            return False, "Không tìm thấy acc."
        if account.status != "available" or account.is_hidden:
            return False, "Acc đã được bán hoặc đang ẩn."
        now = datetime.utcnow()
        if account.held_by and account.held_by != user_id and account.held_until and account.held_until > now:
            return False, "Acc đang được người khác giữ, vui lòng chọn acc khác."
        account.held_by = user_id
        account.held_until = now + timedelta(minutes=ACCOUNT_HOLD_MINUTES)
        return True, ""


async def release_expired_holds() -> int:
    now = datetime.utcnow()
    async with session_scope() as session:
        result = await session.execute(
            update(Account)
            .where(Account.status == "available", Account.held_until.is_not(None), Account.held_until < now)
            .values(held_by=None, held_until=None)
        )
        return result.rowcount or 0


async def price_for(user_id: int, account: Account) -> int:
    settings = await all_settings()
    async with session_scope() as session:
        user = await session.get(User, int(user_id))
    vip = user.vip_level if user else 0
    discount = int((settings.get("vip_discount") or {}).get(str(vip), 0))
    return max(0, account.price - account.price * discount // 100)


async def buy_account(user_id: int, code: str, currency: str = "vnd") -> dict:
    """Purchase an account atomically with VND or Coins. Returns a result dict."""
    settings = await all_settings()
    async with session_scope() as session:
        account = (
            await session.execute(select(Account).where(Account.code == code))
        ).scalar_one_or_none()
        if account is None:
            return {"ok": False, "error": "Không tìm thấy acc."}
        if account.status != "available" or account.is_hidden:
            return {"ok": False, "error": "Acc vừa được bán hoặc đang ẩn."}

        now = datetime.utcnow()
        if account.held_by and account.held_by != user_id and account.held_until and account.held_until > now:
            return {"ok": False, "error": "Acc đang được người khác giữ."}

        user = await session.get(User, int(user_id))
        if user is None:
            return {"ok": False, "error": "Không tìm thấy người dùng."}

        vip_discount = int((settings.get("vip_discount") or {}).get(str(user.vip_level), 0))
        price_vnd = max(0, account.price - account.price * vip_discount // 100)
        multiplier = 4 if account.kind == "info" else 5
        coin_price = price_vnd * multiplier

        if currency == "coin":
            if user.coins < coin_price:
                return {
                    "ok": False,
                    "error": f"Số xu không đủ. Cần {coin_price:,} xu, bạn đang có {user.coins:,} xu.",
                    "code": "insufficient_coins",
                    "price": coin_price,
                    "coin_price": coin_price,
                }

            locked = await session.execute(
                update(Account)
                .where(Account.id == account.id, Account.status == "available")
                .values(status="sold", sold_at=now, held_by=None, held_until=None, views=Account.views + 1)
            )
            if locked.rowcount != 1:
                return {"ok": False, "error": "Acc vừa được người khác mua."}

            paid = await session.execute(
                update(User)
                .where(User.id == user.id, User.coins >= coin_price)
                .values(coins=User.coins - coin_price)
            )
            if paid.rowcount != 1:
                raise RuntimeError("coins_changed_during_purchase")

            await session.refresh(user)
            warranty_until = now + timedelta(days=max(1, account.warranty_days))
            order = Order(
                user_id=user.id,
                account_id=account.id,
                account_code=account.code,
                price=coin_price,
                status="completed",
                warranty_until=warranty_until,
            )
            session.add(order)
            await session.flush()
            session.add(
                Transaction(
                    user_id=user.id,
                    kind="purchase",
                    currency="coin",
                    amount=-coin_price,
                    balance_after=user.coins,
                    note=f"Mua acc {account.code} bằng xu",
                )
            )
            final_price = coin_price

        else:
            if user.shop_balance < price_vnd:
                return {
                    "ok": False,
                    "error": "Số dư không đủ để mua acc này.",
                    "code": "insufficient_balance",
                    "price": price_vnd,
                }

            locked = await session.execute(
                update(Account)
                .where(Account.id == account.id, Account.status == "available")
                .values(status="sold", sold_at=now, held_by=None, held_until=None, views=Account.views + 1)
            )
            if locked.rowcount != 1:
                return {"ok": False, "error": "Acc vừa được người khác mua."}

            paid = await session.execute(
                update(User)
                .where(User.id == user.id, User.shop_balance >= price_vnd)
                .values(shop_balance=User.shop_balance - price_vnd, total_purchased=User.total_purchased + price_vnd)
            )
            if paid.rowcount != 1:
                raise RuntimeError("balance_changed_during_purchase")

            await session.refresh(user)
            warranty_until = now + timedelta(days=max(1, account.warranty_days))
            order = Order(
                user_id=user.id,
                account_id=account.id,
                account_code=account.code,
                price=price_vnd,
                status="completed",
                warranty_until=warranty_until,
            )
            session.add(order)
            await session.flush()
            session.add(
                Transaction(
                    user_id=user.id,
                    kind="purchase",
                    currency="vnd",
                    amount=-price_vnd,
                    balance_after=user.shop_balance,
                    note=f"Mua acc {account.code}",
                )
            )
            final_price = price_vnd

        seller_credit = 0
        if account.seller_id and account.seller_id != user.id:
            commission = price_vnd * int(settings.get("commission_percent", 0)) // 100
            seller_credit = price_vnd - commission
            seller = await session.get(User, account.seller_id)
            if seller is not None:
                seller.shop_balance += seller_credit
                session.add(
                    Transaction(
                        user_id=seller.id,
                        kind="sale_credit",
                        currency="vnd",
                        amount=seller_credit,
                        balance_after=seller.shop_balance,
                        note=f"Bán acc {account.code} (phí {commission:,}đ)".replace(",", "."),
                    )
                )

        try:
            from services.stock_sync_service import trigger_stock_sync
            trigger_stock_sync()
        except Exception:
            pass

        # Số dư người mua (và người bán nếu có) vừa đổi: đẩy lên Cloudflare.
        try:
            from services.cloud_sync import queue_push

            queue_push(user.id)
            if seller_credit and account.seller_id:
                queue_push(account.seller_id)
        except Exception:
            pass

        return {
            "ok": True,
            "order_id": order.id,
            "account": account,
            "price": final_price,
            "currency": currency,
            "discount_percent": vip_discount,
            "username": crypto_service.decrypt(account.username_enc),
            "password": crypto_service.decrypt(account.password_enc),
            "seller_credit": seller_credit,
            "warranty_until": warranty_until,
        }


async def toggle_favorite(user_id: int, account_id: int) -> bool:
    async with session_scope() as session:
        row = (
            await session.execute(
                select(Favorite).where(Favorite.user_id == int(user_id), Favorite.account_id == int(account_id))
            )
        ).scalar_one_or_none()
        if row:
            await session.delete(row)
            return False
        session.add(Favorite(user_id=int(user_id), account_id=int(account_id)))
        return True


async def is_favorite(user_id: int, account_id: int) -> bool:
    async with session_scope() as session:
        row = (
            await session.execute(
                select(Favorite.id).where(Favorite.user_id == int(user_id), Favorite.account_id == int(account_id))
            )
        ).first()
        return bool(row)


async def add_review(user_id: int, account_id: int, rating: int, text: str) -> Review:
    async with session_scope() as session:
        review = Review(user_id=int(user_id), account_id=int(account_id), rating=max(1, min(5, rating)), text=text[:1000])
        session.add(review)
        await session.flush()
        return review


async def reviews_of(account_id: int, limit: int = 5):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Review).where(Review.account_id == int(account_id)).order_by(Review.created_at.desc()).limit(limit)
            )
        ).scalars().all()


async def average_rating(account_id: int) -> float:
    async with session_scope() as session:
        value = (
            await session.execute(select(func.avg(Review.rating)).where(Review.account_id == int(account_id)))
        ).scalar()
        return round(float(value or 0), 1)


# --------------------------------------------------------------------------- bulk import
_FIELD_ALIASES: dict[str, set[str]] = {
    "price": {"price", "gia", "gia ban", "giaban", "giá", "giá bán"},
    "rank": {"rank", "hang", "hạng", "khung rank"},
    "level": {"level", "cap", "cấp", "cap do", "cấp độ"},
    "heroes": {"heroes", "tuong", "tướng", "so tuong", "số tướng"},
    "skins": {"skins", "skin", "so skin", "số skin"},
    "login_type": {"login type", "login", "dang nhap", "đăng nhập", "loai dang nhap", "loại đăng nhập"},
    "warranty_days": {"warranty days", "warranty", "bao hanh", "bảo hành", "so ngay bao hanh"},
    "username": {"username", "user", "tai khoan", "tài khoản", "account", "ten dang nhap"},
    "password": {"password", "pass", "mat khau", "mật khẩu"},
    "description": {"description", "mo ta", "mô tả", "ghi chu", "ghi chú", "note"},
}


def _norm_key(raw) -> str:
    key = str(raw or "").strip().lower().replace("_", " ").replace("-", " ")
    return " ".join(key.split())


def _field_of(cell: str) -> str | None:
    key = _norm_key(cell)
    for field, aliases in _FIELD_ALIASES.items():
        if key in aliases:
            return field
    return None


def _to_int(raw, default: int = 0) -> int:
    from utils.money import parse_amount

    if raw is None or str(raw).strip() == "":
        return default
    if isinstance(raw, bool):
        return default
    if isinstance(raw, (int, float)):
        return int(raw)
    value = parse_amount(str(raw))
    if value is None:
        raise ValueError(raw)
    return int(value)


def _clean_row(raw: dict, label: str, errors: list[str], warranty_default: int = 3) -> dict | None:
    try:
        price = _to_int(raw.get("price"), 0)
        level = _to_int(raw.get("level"), 0)
        heroes = _to_int(raw.get("heroes"), 0)
        skins = _to_int(raw.get("skins"), 0)
        warranty = _to_int(raw.get("warranty_days"), warranty_default) or warranty_default
    except ValueError:
        errors.append(f"{label}: giá/level/tướng/skin/bảo hành không hợp lệ")
        return None
    username = str(raw.get("username") or "").strip()
    password = str(raw.get("password") or "").strip()
    if price <= 0:
        errors.append(f"{label}: giá phải lớn hơn 0")
        return None
    if not username or not password:
        errors.append(f"{label}: thiếu tài khoản hoặc mật khẩu acc")
        return None
    return {
        "price": price,
        "rank": str(raw.get("rank") or "")[:64],
        "level": max(0, level),
        "heroes": max(0, heroes),
        "skins": max(0, skins),
        "login_type": (str(raw.get("login_type") or "Facebook").strip() or "Facebook")[:32],
        "warranty_days": max(1, min(365, warranty)),
        "description": str(raw.get("description") or "")[:4000],
        "username": username[:255],
        "password": password[:255],
    }


def _parse_table(rows: list[list[str]], errors: list[str], lines: list[int] | None = None) -> list[dict]:
    """Parse pipe/tab/comma tables, with or without a header row."""
    prepared: list[list[str]] = []
    numbers: list[int] = []
    for position, row in enumerate(rows):
        cells = [str(cell or "").strip() for cell in row]
        if not any(cells) or (cells and cells[0].startswith("#")):
            continue
        prepared.append(cells)
        numbers.append(lines[position] if lines and position < len(lines) else position + 1)
    rows = prepared
    if not rows:
        return []

    mapping: list[str | None] = [_field_of(cell) for cell in rows[0]]
    has_header = "price" in mapping and any(field in mapping for field in ("username", "password"))
    if has_header:
        rows = rows[1:]
        numbers = numbers[1:]
    else:
        # Positional layout: giá | rank | tướng | skin | đăng nhập | user | pass | mô tả
        mapping = ["price", "rank", "heroes", "skins", "login_type", "username", "password", "description"]

    parsed: list[dict] = []
    for index, row in enumerate(rows):
        label = f"dòng {numbers[index]}"
        if len(row) < 2:
            errors.append(f"{label}: không đủ cột")
            continue
        record: dict[str, str] = {"_line": label}
        for position, value in enumerate(row):
            if position < len(mapping) and mapping[position]:
                record[mapping[position]] = value
        if not has_header and len(row) < 7:
            errors.append(f"{label}: cần ít nhất 7 phần (giá | rank | tướng | skin | đăng nhập | user | pass)")
            continue
        parsed.append(record)
    return parsed


def _parse_lines(text: str, errors: list[str]) -> list[dict]:
    rows: list[list[str]] = []
    numbers: list[int] = []
    for number, line in enumerate(text.splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "|" in line:
            rows.append(line.split("|"))
            numbers.append(number)
        elif "\t" in line:
            rows.append(line.split("\t"))
            numbers.append(number)
        else:
            parts = [part.strip() for part in line.split(",")]
            if len(parts) >= 7:
                rows.append(parts)
                numbers.append(number)
            else:
                errors.append(f"dòng {number}: thiếu dấu | hoặc , để tách cột")
    return _parse_table(rows, errors, numbers)


def _parse_import(text: str, filename: str, errors: list[str]) -> list[dict]:
    cleaned = (text or "").lstrip("\ufeff").strip()
    if not cleaned:
        errors.append("Nội dung file rỗng.")
        return []
    name = (filename or "").lower()
    if name.endswith(".json") or cleaned.startswith("[") or cleaned.startswith("{"):
        try:
            data = json.loads(cleaned)
        except ValueError:
            errors.append("File JSON không hợp lệ.")
            return []
        if isinstance(data, dict):
            data = data.get("accounts") or data.get("acc") or [data]
        if not isinstance(data, list):
            errors.append("JSON phải là danh sách acc.")
            return []
        records: list[dict] = []
        for index, item in enumerate(data, start=1):
            if not isinstance(item, dict):
                errors.append(f"mục {index}: không phải object")
                continue
            record = {_field_of(key) or _norm_key(key): value for key, value in item.items()}
            record["_line"] = f"mục {index}"
            records.append(record)
        return records
    if name.endswith(".csv"):
        sample = cleaned.splitlines()[0]
        delimiter = "|" if "|" in sample else (";" if ";" in sample else ",")
        reader = csv.reader(io.StringIO(cleaned), delimiter=delimiter)
        table = [row for row in reader]
        return _parse_table(table, errors, list(range(1, len(table) + 1)))
    return _parse_lines(cleaned, errors)


async def import_accounts(text: str, filename: str = "", seller_id: int | None = None) -> dict:
    """Bulk-create accounts from a .txt/.csv/.json file uploaded by an admin."""
    from services.settings_service import all_settings

    settings = await all_settings()
    warranty_default = max(1, int(settings.get("warranty_days_default", 3) or 3))

    errors: list[str] = []
    records = _parse_import(text, filename, errors)[:IMPORT_MAX_ROWS]
    valid: list[dict] = []
    for index, record in enumerate(records, start=1):
        row = _clean_row(record, record.get("_line") or f"mục {index}", errors, warranty_default)
        if row is not None:
            valid.append(row)

    if not valid:
        return {"created": 0, "codes": [], "errors": errors, "total": len(errors)}

    kind = "info"
    for record in valid:
        record.setdefault("kind", kind)
    codes = await _insert_accounts(valid, seller_id=seller_id)
    return {"created": len(codes), "codes": codes, "errors": errors, "total": len(codes) + len(errors)}


async def import_hit_accounts(
    text: str,
    price: int = 0,
    category: str = "",
    seller_id: int | None = None,
    warranty_days: int = 3,
) -> dict:
    """Create full-info accounts from pasted checker dumps (see services/hit_parser)."""
    from services.hit_parser import parse_hit_text, skin_lists_json

    records, errors = parse_hit_text(text)
    rows: list[dict] = []
    for index, record in enumerate(records, start=1):
        if price <= 0 and not record.get("price"):
            errors.append(f"acc {index}: thiếu giá bán")
            continue
        rows.append(
            {
                "price": int(price or record.get("price") or 0),
                "rank": record.get("rank") or "",
                "level": int(record.get("level") or 0),
                "heroes": int(record.get("heroes") or 0),
                "skins": int(record.get("skins") or 0),
                "login_type": "Facebook" if record.get("fb_uid") else "Riot",
                "warranty_days": max(1, int(warranty_days or 3)),
                "description": f"Name: {record['name']}" if record.get("name") else "",
                "username": record.get("username") or "",
                "password": record.get("password") or "",
                "kind": "info",
                "category": (category or record.get("category") or "")[:32],
                "uid": record.get("uid") or "",
                "region": record.get("region") or "VN",
                "shells": int(record.get("shells") or 0),
                "shells_note": record.get("shells_note") or "",
                "email_info": record.get("email_info") or "",
                "phone_info": record.get("phone_info") or "",
                "has_pass": bool(record.get("has_pass")),
                "fb_username": record.get("fb_username") or "",
                "fb_uid": record.get("fb_uid") or "",
                "fb_link": record.get("fb_link") or "",
                "is_banned": bool(record.get("is_banned")),
                "ban_note": record.get("ban_note") or "",
                "last_login": record.get("last_login") or "",
                "account_created": record.get("account_created") or "",
                "has_cccd": bool(record.get("has_cccd")),
                "twofa": bool(record.get("twofa")),
                "ss_count": int(record.get("ss_count") or 0),
                "splus_count": int(record.get("splus_count") or 0),
                "s_count": int(record.get("s_count") or 0),
                "evo_count": int(record.get("evo_count") or 0),
                "anime_count": int(record.get("anime_count") or 0),
                "dreamer_count": int(record.get("dreamer_count") or 0),
                "other_count": int(record.get("other_count") or 0),
                "skin_lists": skin_lists_json(record),
                "extra": f"QH: {record['qh']}" if record.get("qh") else "",
            }
        )
    codes = await _insert_accounts(rows, seller_id=seller_id)
    return {"created": len(codes), "codes": codes, "errors": errors, "total": len(codes) + len(errors)}


async def import_random_accounts(
    text: str,
    price: int,
    category: str = "Random",
    seller_id: int | None = None,
    warranty_days: int = 1,
) -> dict:
    """Create random-pool accounts from lines like ``user:pass`` (optionally ``user:pass | rank``)."""
    if int(price) <= 0:
        return {"created": 0, "codes": [], "errors": ["Giá bán phải lớn hơn 0."], "total": 1}

    rows: list[dict] = []
    errors: list[str] = []
    for number, raw in enumerate((text or "").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        rank = ""
        if "|" in line:
            head, *tail = [part.strip() for part in line.split("|")]
            rank = tail[-1][:64] if tail else ""
            line = head
        if ":" not in line:
            errors.append(f"dòng {number}: thiếu dấu : giữa user và pass")
            continue
        username, password = line.split(":", 1)
        username, password = username.strip(), password.strip()
        if not username or not password:
            errors.append(f"dòng {number}: user/pass trống")
            continue
        rows.append(
            {
                "price": int(price),
                "rank": rank,
                "kind": "random",
                "category": (category or "Random")[:32],
                "warranty_days": max(1, int(warranty_days or 1)),
                "username": username[:255],
                "password": password[:255],
                "login_type": "Riot",
            }
        )
    codes = await _insert_accounts(rows, seller_id=seller_id)
    return {"created": len(codes), "codes": codes, "errors": errors, "total": len(codes) + len(errors)}


AI_DETAIL_FIELDS = (
    "uid",
    "region",
    "category",
    "is_banned",
    "ban_note",
    "email_info",
    "phone_info",
    "last_login",
    "has_pass",
    "twofa",
    "fb_username",
    "fb_uid",
)


def _ai_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in ("1", "true", "yes", "co", "có", "ban", "banned")


def clean_ai_records(records: list[dict]) -> tuple[list[dict], list[str]]:
    """Validate rows produced by the AI extractor (same rules as a manual import)."""
    rows: list[dict] = []
    errors: list[str] = []
    for index, record in enumerate(records or [], start=1):
        if not isinstance(record, dict):
            errors.append(f"mục {index}: không phải object")
            continue
        row = _clean_row(record, f"mục {index}", errors, 3)
        if row is None:
            continue
        for field in AI_DETAIL_FIELDS:
            value = record.get(field)
            if field in ("is_banned", "has_pass", "twofa"):
                row[field] = _ai_bool(value)
            elif value not in (None, ""):
                row[field] = str(value)[: 32 if field == "category" else 255]
        row["kind"] = "info"
        rows.append(row)
    return rows, errors


async def import_ai_accounts(records: list[dict], seller_id: int | None = None) -> dict:
    """Insert accounts parsed by the AI assistant from an arbitrary file."""
    rows, errors = clean_ai_records(records)
    if not rows:
        return {"created": 0, "codes": [], "errors": errors, "total": len(errors)}
    codes = await _insert_accounts(rows, seller_id=seller_id)
    return {"created": len(codes), "codes": codes, "errors": errors, "total": len(codes) + len(errors)}


async def count_by_kind() -> dict:
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(Account.kind, func.count())
                .where(Account.status == "available", Account.is_hidden.is_(False))
                .group_by(Account.kind)
            )
        ).all()
    counts = {str(kind): int(total) for kind, total in rows}
    return {
        "random": counts.get("random", 0),
        "info": counts.get("info", 0),
        "white": counts.get("white", 0),
    }


async def random_pools() -> list[dict]:
    """Available random accounts grouped by price for the shop screen."""
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(Account.price, Account.category, func.count())
                .where(Account.status == "available", Account.is_hidden.is_(False), Account.kind == "random")
                .group_by(Account.price, Account.category)
                .order_by(Account.price.asc())
            )
        ).all()
    return [
        {"price": int(price), "category": str(category or "Random"), "count": int(total)}
        for price, category, total in rows
    ]


async def buy_random(user_id: int, price: int) -> dict:
    """Sell one random available account at the given price."""
    async with session_scope() as session:
        code = (
            await session.execute(
                select(Account.code)
                .where(
                    Account.status == "available",
                    Account.is_hidden.is_(False),
                    Account.kind == "random",
                    Account.price == int(price),
                )
                .order_by(func.random())
                .limit(1)
            )
        ).scalar_one_or_none()
    if not code:
        return {"ok": False, "error": "Kho random đã hết acc ở mức giá này."}
    return await buy_account(user_id, code)


# --------------------------------------------------------------------------- consignments
async def accounts_of_seller(user_id: int):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Account).where(Account.seller_id == int(user_id)).order_by(Account.created_at.desc())
            )
        ).scalars().all()


async def update_price(account_id: int, price: int) -> bool:
    async with session_scope() as session:
        account = await session.get(Account, int(account_id))
        if account is None:
            return False
        account.price = max(0, int(price))
    try:
        from services.stock_sync_service import trigger_stock_sync
        trigger_stock_sync()
    except Exception:
        pass
    return True


async def set_visibility(account_id: int, hidden: bool) -> bool:
    async with session_scope() as session:
        account = await session.get(Account, int(account_id))
        if account is None:
            return False
        account.is_hidden = hidden
    try:
        from services.stock_sync_service import trigger_stock_sync
        trigger_stock_sync()
    except Exception:
        pass
    return True


async def remove_account(account_id: int) -> bool:
    async with session_scope() as session:
        account = await session.get(Account, int(account_id))
        if account is None:
            return False
        account.status = "deleted"
        account.is_hidden = True
    try:
        from services.stock_sync_service import trigger_stock_sync
        trigger_stock_sync()
    except Exception:
        pass
    return True


async def pending_consignments(limit: int = 10):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Account)
                .where(Account.status == "pending_approval")
                .order_by(Account.created_at.asc())
                .limit(limit)
            )
        ).scalars().all()


async def approve_consignment(account_id: int, price: int | None = None) -> bool:
    async with session_scope() as session:
        account = await session.get(Account, int(account_id))
        if account is None or account.status != "pending_approval":
            return False
        if price is not None and price > 0:
            account.price = int(price)
        account.status = "available"
        return True


async def reject_consignment(account_id: int, reason: str = "") -> bool:
    async with session_scope() as session:
        account = await session.get(Account, int(account_id))
        if account is None or account.status != "pending_approval":
            return False
        account.status = "rejected"
        account.description = (account.description + f"\n[Admin] Từ chối: {reason}")[:4000]
        return True


async def orders_of(user_id: int, limit: int = 10):
    async with session_scope() as session:
        return (
            await session.execute(
                select(Order).where(Order.user_id == int(user_id)).order_by(Order.created_at.desc()).limit(limit)
            )
        ).scalars().all()


async def recent_orders(limit: int = 10, status: str | None = None):
    async with session_scope() as session:
        query = select(Order)
        if status:
            query = query.where(Order.status == status)
        return (
            await session.execute(query.order_by(Order.created_at.desc()).limit(limit))
        ).scalars().all()


async def refund_order(order_id: int, admin_id: int, note: str = "") -> Order | None:
    """Refund an order completely: buyer, seller payout and the account itself.

    A plain balance refund left the seller with the money and the account marked
    sold, so the same acc could never be resold and the admin lost the payout.
    """
    async with session_scope() as session:
        order = await session.get(Order, int(order_id))
        if order is None or order.status == "refunded":
            return None
        account = await session.get(Account, order.account_id)
        order.status = "refunded"
        order.note = (note or "")[:4000]

        user = await session.get(User, order.user_id)
        if user is not None:
            user.shop_balance += order.price
            session.add(
                Transaction(
                    user_id=user.id,
                    kind="refund",
                    currency="vnd",
                    amount=order.price,
                    balance_after=user.shop_balance,
                    note=f"Hoàn tiền đơn #{order.id}",
                    ref=f"refund:{order.id}",
                )
            )

        # Take back what the seller was paid, otherwise a refund prints money.
        if account is not None and account.seller_id and account.seller_id != order.user_id:
            settings = await all_settings()
            commission = order.price * int(settings.get("commission_percent", 0)) // 100
            seller_credit = order.price - commission
            seller = await session.get(User, account.seller_id)
            if seller is not None and seller_credit > 0:
                seller.shop_balance = max(0, int(seller.shop_balance) - seller_credit)
                session.add(
                    Transaction(
                        user_id=seller.id,
                        kind="refund_seller_reclaim",
                        currency="vnd",
                        amount=-seller_credit,
                        balance_after=seller.shop_balance,
                        note=f"Thu hồi tiền bán đơn #{order.id} (hoàn tiền)",
                        ref=f"refund_seller:{order.id}",
                    )
                )

        # Put the account back on sale so it can be bought again.
        if account is not None and account.status == "sold":
            account.status = "available"
            account.sold_at = None
            account.held_by = None
            account.held_until = None

        try:
            from services.cloud_sync import queue_push

            queue_push(order.user_id)
            if account is not None and account.seller_id and account.seller_id != order.user_id:
                queue_push(account.seller_id)
        except Exception:
            pass
        return order


async def complete_order(order_id: int) -> Order | None:
    async with session_scope() as session:
        order = await session.get(Order, int(order_id))
        if order is None:
            return None
        order.status = "completed"
        return order


async def set_order_note(order_id: int, note: str) -> bool:
    async with session_scope() as session:
        order = await session.get(Order, int(order_id))
        if order is None:
            return False
        order.note = note[:4000]
        return True
