"""Discount codes (ported from telegram-sales-bot database.js
validateDiscountCode / useDiscountCode + discountHandler.js).

The old bot only had VIP % discounts. This adds the repo's code-based
discounts: percent or fixed amount, optional product restriction (one or
many), minimum order, maximum discount, total + per-user use limits, date
window, new-user-only, hidden codes, and per-user restriction.
"""

from __future__ import annotations

import json
from datetime import datetime

from sqlalchemy import func, select

from database.models import DiscountCode, DiscountUsage, Order
from database.session import session_scope
from utils.logger import get_logger

log = get_logger(__name__)


def _applicable_ids(code: DiscountCode) -> list[int]:
    if code.product_ids:
        try:
            ids = json.loads(code.product_ids)
            if isinstance(ids, list):
                return [int(i) for i in ids if int(i) > 0]
        except (ValueError, TypeError):
            pass
    if code.product_id:
        return [int(code.product_id)]
    return []


async def create_discount_code(data: dict) -> DiscountCode:
    product_ids = data.get("product_ids") or []
    product_id = data.get("product_id")
    if isinstance(product_ids, list) and len(product_ids) == 1:
        product_id = int(product_ids[0])
        product_ids = []
    async with session_scope() as session:
        row = DiscountCode(
            code=str(data["code"]).upper().strip()[:32],
            type="fixed" if str(data.get("type", "percent")).lower() == "fixed" else "percent",
            value=max(0, int(data.get("value") or 0)),
            product_id=int(product_id) if product_id else None,
            product_ids=json.dumps([int(i) for i in product_ids]) if product_ids else "",
            min_order_amount=max(0, int(data.get("min_order_amount") or 0)),
            max_discount_amount=int(data["max_discount_amount"]) if data.get("max_discount_amount") else None,
            max_uses=max(0, int(data.get("max_uses") or 0)),
            max_uses_per_user=max(0, int(data.get("max_uses_per_user") or 0)),
            starts_at=data.get("starts_at"),
            expires_at=data.get("expires_at"),
            is_active=bool(data.get("is_active", True)),
            is_hidden=bool(data.get("is_hidden", False)),
            is_new_user_only=bool(data.get("is_new_user_only", False)),
            allowed_user_id=int(data["allowed_user_id"]) if data.get("allowed_user_id") else None,
        )
        session.add(row)
        await session.flush()
        return row


async def get_discount_by_code(code: str) -> DiscountCode | None:
    async with session_scope() as session:
        row = (
            await session.execute(
                select(DiscountCode).where(DiscountCode.code == str(code or "").upper().strip())
            )
        ).scalar_one_or_none()
        return row


async def list_discount_codes() -> list[DiscountCode]:
    async with session_scope() as session:
        return list(
            (await session.execute(select(DiscountCode).order_by(DiscountCode.created_at.desc()))).scalars().all()
        )


async def _is_new_user(session, user_id: int) -> bool:
    paid = (
        await session.execute(
            select(func.count())
            .select_from(Order)
            .where(Order.user_id == int(user_id), Order.status.in_(("paid", "delivered", "completed")))
        )
    ).scalar() or 0
    return int(paid) == 0


async def validate_discount(
    code: str,
    user_id: int,
    order_amount: int,
    product_id: int | None = None,
    quantity: int = 1,
    unit_price: int | None = None,
) -> dict:
    """Returns {"valid": True, "discount": row, "discount_amount": n} or
    {"valid": False, "reason": "..."} — same rules as the repo."""
    row = await get_discount_by_code(code)
    if row is None:
        return {"valid": False, "reason": "Mã giảm giá không tồn tại."}
    if not row.is_active:
        return {"valid": False, "reason": "Mã giảm giá đã bị vô hiệu hóa."}
    now = datetime.utcnow()
    if row.starts_at and row.starts_at > now:
        return {"valid": False, "reason": "Mã giảm giá chưa đến thời gian áp dụng."}
    if row.expires_at and row.expires_at < now:
        return {"valid": False, "reason": "Mã giảm giá đã hết hạn."}
    if row.max_uses > 0 and row.used_count >= row.max_uses:
        return {"valid": False, "reason": "Mã giảm giá đã hết lượt sử dụng."}
    if row.allowed_user_id and int(row.allowed_user_id) != int(user_id):
        return {"valid": False, "reason": "Mã này chỉ dành cho một người dùng cụ thể."}

    async with session_scope() as session:
        if row.max_uses_per_user > 0:
            used = (
                await session.execute(
                    select(func.count())
                    .select_from(DiscountUsage)
                    .where(
                        DiscountUsage.discount_code_id == row.id,
                        DiscountUsage.telegram_user_id == int(user_id),
                    )
                )
            ).scalar() or 0
            if int(used) >= row.max_uses_per_user:
                return {"valid": False, "reason": "Bạn đã sử dụng mã này đạt giới hạn."}
        if row.is_new_user_only and not await _is_new_user(session, user_id):
            return {"valid": False, "reason": "Mã này chỉ dành cho khách hàng mới."}

    applicable = _applicable_ids(row)
    if applicable and product_id is not None and int(product_id) not in applicable:
        return {"valid": False, "reason": "Mã này không áp dụng cho sản phẩm này."}
    if row.min_order_amount > 0 and int(order_amount) < row.min_order_amount:
        return {
            "valid": False,
            "reason": f"Đơn hàng tối thiểu {row.min_order_amount:,}đ để áp dụng mã này.".replace(",", "."),
        }

    qty = max(1, int(quantity or 1))
    base = int(unit_price) * qty if unit_price is not None else int(order_amount)
    if row.type == "percent":
        amount = base * int(row.value) // 100
        if row.max_discount_amount is not None:
            amount = min(amount, int(row.max_discount_amount))
    else:
        amount = min(int(row.value) * qty, int(order_amount))
    return {"valid": True, "discount": row, "discount_amount": max(0, int(amount))}


async def use_discount(discount_id: int, user_id: int, order_code: str) -> None:
    async with session_scope() as session:
        row = await session.get(DiscountCode, int(discount_id))
        if row is None:
            return
        row.used_count = int(row.used_count or 0) + 1
        session.add(
            DiscountUsage(
                discount_code_id=int(discount_id),
                telegram_user_id=int(user_id),
                order_code=str(order_code or ""),
            )
        )


async def active_public_discounts() -> list[DiscountCode]:
    """Non-hidden, active, in-date codes for the /discount list (repo: getActiveDiscountCodes)."""
    now = datetime.utcnow()
    rows = await list_discount_codes()
    out = []
    for row in rows:
        if not row.is_active or row.is_hidden:
            continue
        if row.max_uses > 0 and row.used_count >= row.max_uses:
            continue
        if row.starts_at and row.starts_at > now:
            continue
        if row.expires_at and row.expires_at < now:
            continue
        out.append(row)
    return out
