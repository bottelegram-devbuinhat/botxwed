"""Daily check-in, missions, giftcodes and referral helpers."""

from __future__ import annotations

from datetime import date, datetime, timedelta

from sqlalchemy import func, select, update

from database.models import Deposit, GameHistory, Giftcode, GiftcodeUse, Transaction, User
from database.session import session_scope
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils.money import fmt_coin, fmt_vnd


async def checkin(user_id: int) -> dict:
    settings = await all_settings()
    today = date.today()
    async with session_scope() as session:
        user = await session.get(User, int(user_id))
        if user is None:
            return {"ok": False, "error": "Không tìm thấy người dùng."}
        if user.last_checkin == today:
            return {"ok": False, "error": "Hôm nay bạn đã điểm danh rồi."}
        yesterday = today - timedelta(days=1)
        user.checkin_streak = user.checkin_streak + 1 if user.last_checkin == yesterday else 1
        user.last_checkin = today
        reward = int(settings.get("checkin_base_coins", 200)) + user.vip_level * int(
            settings.get("checkin_vip_bonus", 100)
        )
        streak = user.checkin_streak

    await wallet.add_balance(user_id, reward, "checkin", "coin", f"Điểm danh ngày {today}")
    return {"ok": True, "reward": reward, "streak": streak}


MISSIONS = {
    "checkin": {"title": "📅 Điểm danh hôm nay", "target": 1, "reward": 100},
    "play": {"title": "🎰 Chơi 5 ván casino hôm nay", "target": 5, "reward": 200},
    "deposit": {"title": "💳 Nạp tiền hôm nay", "target": 1, "reward": 300},
    "invite": {"title": "👥 Mời 1 người bạn", "target": 1, "reward": 500},
}


async def mission_progress(user_id: int) -> list[dict]:
    today_start = datetime.combine(date.today(), datetime.min.time())
    async with session_scope() as session:
        user = await session.get(User, int(user_id))
        played = (
            await session.execute(
                select(func.count(GameHistory.id)).where(
                    GameHistory.user_id == int(user_id), GameHistory.created_at >= today_start
                )
            )
        ).scalar() or 0
        deposited = (
            await session.execute(
                select(func.count(Deposit.id)).where(
                    Deposit.user_id == int(user_id),
                    Deposit.status == "approved",
                    Deposit.created_at >= today_start,
                )
            )
        ).scalar() or 0
        invited = (
            await session.execute(select(func.count(User.id)).where(User.referrer_id == int(user_id)))
        ).scalar() or 0
        progress = {
            "checkin": 1 if user and user.last_checkin == date.today() else 0,
            "play": int(played),
            "deposit": int(deposited),
            "invite": int(invited),
        }
    result = []
    for key, meta in MISSIONS.items():
        result.append({"key": key, **meta, "progress": min(progress[key], meta["target"])})
    return result


async def claim_mission(user_id: int, kind: str) -> dict:
    meta = MISSIONS.get(kind)
    if not meta:
        return {"ok": False, "error": "Nhiệm vụ không tồn tại."}
    progress = {m["key"]: m for m in await mission_progress(user_id)}
    current = progress.get(kind)
    if current is None or current["progress"] < meta["target"]:
        return {"ok": False, "error": "Bạn chưa hoàn thành nhiệm vụ này."}
    ref = f"mission:{kind}:{date.today().isoformat()}:{user_id}"
    added = await wallet.add_balance(user_id, meta["reward"], "mission", "coin", f"Nhiệm vụ {meta['title']}", ref=ref)
    if not added:
        return {"ok": False, "error": "Bạn đã nhận thưởng nhiệm vụ này hôm nay."}
    return {"ok": True, "reward": meta["reward"]}


async def claim_all_missions(user_id: int) -> dict:
    claimed = 0
    total = 0
    for key, meta in MISSIONS.items():
        result = await claim_mission(user_id, key)
        if result.get("ok"):
            claimed += 1
            total += int(result["reward"])
    if not claimed:
        return {"ok": False, "error": "Không có nhiệm vụ nào đủ điều kiện nhận thưởng."}
    return {"ok": True, "claimed": claimed, "total": total}


async def redeem_giftcode(user_id: int, raw_code: str) -> dict:
    code = (raw_code or "").strip().upper()
    if not code:
        return {"ok": False, "error": "Vui lòng nhập mã."}
    async with session_scope() as session:
        giftcode = (
            await session.execute(select(Giftcode).where(Giftcode.code == code))
        ).scalar_one_or_none()
        if giftcode is None:
            return {"ok": False, "error": "Mã không tồn tại."}
        if not giftcode.is_active:
            return {"ok": False, "error": "Mã đã bị tạm dừng."}
        if giftcode.used >= giftcode.max_uses:
            return {"ok": False, "error": "Mã đã hết lượt sử dụng."}
        if giftcode.expires_at and giftcode.expires_at < datetime.utcnow():
            return {"ok": False, "error": "Mã đã hết hạn."}
        already = (
            await session.execute(
                select(GiftcodeUse.id).where(
                    GiftcodeUse.giftcode_id == giftcode.id, GiftcodeUse.user_id == int(user_id)
                )
            )
        ).first()
        if already:
            return {"ok": False, "error": "Bạn đã sử dụng mã này rồi."}
        # Atomic claim so the last use cannot be handed to two users at once.
        claimed = await session.execute(
            update(Giftcode)
            .where(Giftcode.id == giftcode.id, Giftcode.used < Giftcode.max_uses)
            .values(used=Giftcode.used + 1)
        )
        if claimed.rowcount != 1:
            return {"ok": False, "error": "Mã đã hết lượt sử dụng."}
        session.add(GiftcodeUse(giftcode_id=giftcode.id, user_id=int(user_id)))
        amount = giftcode.amount
        currency = giftcode.currency

    await wallet.add_balance(user_id, amount, "giftcode", currency, f"Nhập mã {code}", ref=f"giftcode:{code}:{user_id}")
    return {
        "ok": True,
        "amount": amount,
        "currency": currency,
        "text": fmt_vnd(amount) if currency == "vnd" else fmt_coin(amount),
    }


async def create_giftcode(
    code: str,
    amount: int,
    currency: str = "coin",
    max_uses: int = 1,
    expires_days: int | None = None,
    created_by: int | None = None,
) -> Giftcode | None:
    clean = (code or "").strip().upper()
    if not clean or amount <= 0 or max_uses <= 0:
        return None
    async with session_scope() as session:
        existing = (await session.execute(select(Giftcode.id).where(Giftcode.code == clean))).first()
        if existing:
            return None
        giftcode = Giftcode(
            code=clean,
            amount=int(amount),
            currency="vnd" if currency == "vnd" else "coin",
            max_uses=int(max_uses),
            expires_at=datetime.utcnow() + timedelta(days=expires_days) if expires_days else None,
            created_by=created_by,
        )
        session.add(giftcode)
        await session.flush()
        return giftcode


async def list_giftcodes(limit: int = 10):
    async with session_scope() as session:
        return (
            await session.execute(select(Giftcode).order_by(Giftcode.created_at.desc()).limit(limit))
        ).scalars().all()


async def set_giftcode_active(code: str, active: bool) -> bool:
    async with session_scope() as session:
        giftcode = (
            await session.execute(select(Giftcode).where(Giftcode.code == code))
        ).scalar_one_or_none()
        if giftcode is None:
            return False
        giftcode.is_active = active
        return True


async def referral_count(user_id: int) -> int:
    async with session_scope() as session:
        return int(
            (await session.execute(select(func.count(User.id)).where(User.referrer_id == int(user_id)))).scalar() or 0
        )


async def referral_earnings(user_id: int) -> int:
    async with session_scope() as session:
        return int(
            (
                await session.execute(
                    select(func.coalesce(func.sum(Transaction.amount), 0)).where(
                        Transaction.user_id == int(user_id), Transaction.kind == "referral"
                    )
                )
            ).scalar()
            or 0
        )
