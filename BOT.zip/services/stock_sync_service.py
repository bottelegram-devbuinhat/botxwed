"""Automatic stock exporter & GitHub sync service for AnhDev Store Mini App."""

from __future__ import annotations

import asyncio
import base64
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import aiohttp

from config import (
    BASE_DIR,
    DATA_DIR,
    GITHUB_STOCK_BRANCH,
    GITHUB_STOCK_PATH,
    GITHUB_STOCK_REPO,
    GITHUB_TOKEN,
)
from export_stock import export_stock
from utils.logger import get_logger

log = get_logger(__name__)

_sync_task: asyncio.Task | None = None
_debounce_delay: float = 3.0
_lock = asyncio.Lock()


async def sync_stock_now() -> bool:
    """Generate public stock.json and push to GitHub repository if GITHUB_TOKEN is configured."""
    async with _lock:
        db_path = DATA_DIR / "bot.db"
        if not db_path.exists():
            log.warning("Stock sync: bot.db không tồn tại tại %s", db_path)
            return False

        # 1. Export stock using existing export_stock logic (pure read-only, safe, no credentials)
        try:
            stock_data = await asyncio.to_thread(export_stock, db_path)
            json_text = json.dumps(stock_data, ensure_ascii=False, indent=2) + "\n"
            json_bytes = json_text.encode("utf-8")
        except Exception as exc:
            log.warning("Stock sync: Lỗi khi xuất dữ liệu kho từ bot.db: %s", exc)
            return False

        # 2. Write to local stock.json files
        try:
            local_paths = [
                BASE_DIR / "stock.json",
                BASE_DIR.parent / "stock.json",
            ]
            for p in local_paths:
                p.write_text(json_text, encoding="utf-8")
        except Exception as exc:
            log.warning("Stock sync: Lỗi ghi file stock.json cục bộ: %s", exc)

        # 3. Push to GitHub Contents API if GITHUB_TOKEN is configured
        token = GITHUB_TOKEN or os.getenv("GITHUB_TOKEN", "").strip()
        repo = GITHUB_STOCK_REPO or os.getenv("GITHUB_STOCK_REPO", "bottelegram-devbuinhat/anhdev-store").strip()
        branch = GITHUB_STOCK_BRANCH or os.getenv("GITHUB_STOCK_BRANCH", "main").strip()
        file_path = GITHUB_STOCK_PATH or os.getenv("GITHUB_STOCK_PATH", "stock.json").strip()

        if not token:
            log.info(
                "Stock sync: GITHUB_TOKEN chưa cấu hình. Đã xuất stock.json cục bộ (%s acc). "
                "Để tự động đẩy lên GitHub, vui lòng cấu hình GITHUB_TOKEN trong file .env.",
                stock_data.get("total", 0),
            )
            return True

        api_url = f"https://api.github.com/repos/{repo}/contents/{file_path}"
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "AnhDevStore-BotSync/1.0",
        }

        try:
            timeout = aiohttp.ClientTimeout(total=20)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                # Get existing file SHA if present
                sha = None
                async with session.get(f"{api_url}?ref={branch}", headers=headers) as resp:
                    if resp.status == 200:
                        existing = await resp.json()
                        sha = existing.get("sha")
                    elif resp.status not in (404,):
                        body = await resp.text()
                        log.warning("Stock sync: GitHub GET contents trả về HTTP %s: %s", resp.status, body[:200])

                # PUT updated stock.json
                content_b64 = base64.b64encode(json_bytes).decode("utf-8")
                commit_msg = f"Auto-sync stock.json ({datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC) [{stock_data.get('total', 0)} acc]"
                put_data = {
                    "message": commit_msg,
                    "content": content_b64,
                    "branch": branch,
                }
                if sha:
                    put_data["sha"] = sha

                async with session.put(api_url, json=put_data, headers=headers) as resp:
                    if resp.status in (200, 201):
                        log.info("Stock sync: Đẩy stock.json lên GitHub %s thành công (%s acc)!", repo, stock_data.get("total", 0))
                        return True
                    else:
                        resp_text = await resp.text()
                        log.warning(
                            "Stock sync: Đẩy stock.json lên GitHub thất bại (HTTP %s): %s",
                            resp.status,
                            resp_text[:300],
                        )
                        return False
        except Exception as exc:
            log.warning("Stock sync: Lỗi kết nối mạng khi đẩy lên GitHub: %s", exc)
            return False


def trigger_stock_sync() -> None:
    """Trigger debounced stock synchronization in background."""
    global _sync_task

    async def _debounced():
        try:
            await asyncio.sleep(_debounce_delay)
            await sync_stock_now()
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            log.warning("Stock sync background task error: %s", exc)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return

    if _sync_task and not _sync_task.done():
        _sync_task.cancel()

    _sync_task = loop.create_task(_debounced())
