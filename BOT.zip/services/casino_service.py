"""Casino games played with virtual coins only.

Coins cannot be bought with money and cannot be exchanged back, by design.
Every round is resolved on the server with a verifiable seed.
"""

from __future__ import annotations

import asyncio
import hashlib
import secrets
from datetime import datetime, timedelta

from sqlalchemy import or_, update

from database.models import GameHistory, User
from database.session import session_scope
from services import wallet_service as wallet
from services.settings_service import all_settings, get, set_value
from utils.logger import get_logger
from utils.money import fmt_coin

log = get_logger(__name__)

_RNG = secrets.SystemRandom()

# The jackpot lives in the settings JSON blob, so a read-modify-write needs a
# lock: two simultaneous bets used to overwrite each other's contribution and
# the jackpot silently lost coins.
_JACKPOT_LOCK = asyncio.Lock()

TAI_XIU_RULES = "3 xúc xắc, tổng 11-18 là TÀI, 4-10 là XỈU. Trả thưởng 1.95 lần."
CHAN_LE_RULES = "Tổng 3 xúc xắc chẵn hoặc lẻ. Trả thưởng 1.95 lần."
XOC_DIA_RULES = "4 đồng xu, đếm số mặt đỏ: chẵn (0/2/4) hoặc lẻ (1/3). Trả thưởng 1.95 lần."
BAU_CUA_RULES = "3 xúc xắc 6 mặt Bầu/Cua/Tôm/Cá/Gà/Nai. Trúng 1 mặt x1, 2 mặt x2, 3 mặt x3 (cộng vốn)."
RONG_HO_RULES = "Rồng và Hổ mỗi bên 1 lá bài, bên lớn hơn thắng. Hoà trả 8 lần."
BACCARAT_RULES = "Player và Banker, điểm gần 9 thắng. Player/Banker trả 1.95, Hoà trả 8."
BLACKJACK_RULES = "Gần 21 điểm hơn nhà cái mà không vượt. Blackjack trả 2.5 lần, thắng thường 2 lần, hoà hoàn vốn."
SLOTS_RULES = "3 guồng, 3 biểu tượng giống nhau thắng lớn. 7️⃣ 7️⃣ 7️⃣ nổ hũ."
ROULETTE_RULES = "Đặt Đỏ/Đen/Chẵn/Lẻ, trả 2 lần. Ra số 0 là nhà cái thắng."
HIGH_LOW_RULES = "Đoán lá bài tiếp theo cao hay thấp hơn. Trả 1.9 lần, bằng nhau hoàn vốn."
NUMBER_RULES = "Đoán đúng 1 con số từ 1 đến 6, trả 5 lần."
MYSTERY_RULES = "Mở hộp quà may mắn, nhận ngẫu nhiên 0 - 10 lần cược."
UNKNOWN_GAME_TEXT = "Game không hợp lệ."

GAMES: dict[str, dict] = {
    "taixiu": {
        "name": "🎲 Tài Xỉu",
        "choices": {"TAI": "Tài", "XIU": "Xỉu"},
        "rules": TAI_XIU_RULES,
    },
    "chanle": {"name": "🔢 Chẵn Lẻ", "choices": {"CHAN": "Chẵn", "LE": "Lẻ"}, "rules": CHAN_LE_RULES},
    "xocdia": {"name": "🔴 Xóc Đĩa", "choices": {"CHAN": "Chẵn", "LE": "Lẻ"}, "rules": XOC_DIA_RULES},
    "baucua": {
        "name": "🦀 Bầu Cua",
        "choices": {"0": "Bầu", "1": "Cua", "2": "Tôm", "3": "Cá", "4": "Gà", "5": "Nai"},
        "rules": BAU_CUA_RULES,
    },
    "rongho": {"name": "🐉 Rồng Hổ", "choices": {"RONG": "Rồng", "HO": "Hổ", "HOA": "Hoà"}, "rules": RONG_HO_RULES},
    "baccarat": {
        "name": "🃏 Baccarat",
        "choices": {"PLAYER": "Player", "BANKER": "Banker", "TIE": "Hoà"},
        "rules": BACCARAT_RULES,
    },
    "blackjack": {"name": "♠️ Blackjack", "choices": None, "rules": BLACKJACK_RULES},
    "slots": {"name": "🎰 Slots", "choices": None, "rules": SLOTS_RULES},
    "roulette": {
        "name": "🎡 Roulette",
        "choices": {"RED": "Đỏ", "BLACK": "Đen", "EVEN": "Chẵn", "ODD": "Lẻ"},
        "rules": ROULETTE_RULES,
    },
    "highlow": {"name": "🃏 Cao Thấp", "choices": {"HIGH": "Cao", "LOW": "Thấp"}, "rules": HIGH_LOW_RULES},
    "numberguess": {
        "name": "🔟 Đoán Số",
        "choices": {str(i): str(i) for i in range(1, 7)},
        "rules": NUMBER_RULES,
    },
    "mysterybox": {"name": "🎁 Hộp Quà", "choices": None, "rules": MYSTERY_RULES},
}

SLOT_SYMBOLS = ["🍒", "🍋", "🔔", "⭐", "💎", "7️⃣"]
SLOT_JACKPOT_SYMBOL = "7️⃣"
BAU_SYMBOLS = ["Bầu", "Cua", "Tôm", "Cá", "Gà", "Nai"]
CARD_RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
SUITS = ["♠️", "♥️", "♦️", "♣️"]
RED_NUMBERS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}


def _seed_hash(seed: str) -> str:
    return hashlib.sha256(seed.encode()).hexdigest()[:16]


def _roll(seed: str, faces: int, count: int) -> list[int]:
    """Deterministic rolls derived from the round seed (provably fair).

    Bytes at or above the largest multiple of ``faces`` are discarded so every
    face has exactly the same chance (a plain ``byte % faces`` would favour the
    first ``256 % faces`` faces).
    """
    rolls: list[int] = []
    counter = 0
    limit = 256 - (256 % faces)
    while len(rolls) < count:
        digest = hashlib.sha256(f"{seed}:{counter}".encode()).digest()
        for byte in digest:
            if byte >= limit:
                continue
            rolls.append(byte % faces + 1)
            if len(rolls) == count:
                break
        counter += 1
    return rolls


def _multiplier(base: float, settings: dict) -> float:
    rtp = float(settings.get("casino_rtp", 0.96))
    scale = max(0.5, min(1.5, rtp / 0.96))
    return round(base * scale, 2)


def new_deck() -> list[tuple[int, str]]:
    deck = [(rank, suit) for rank in range(2, 15) for suit in SUITS]
    _RNG.shuffle(deck)
    return deck


def card_str(card: tuple[int, str]) -> str:
    label = {11: "J", 12: "Q", 13: "K", 14: "A"}.get(card[0], str(card[0]))
    return f"{label}{card[1]}"


def hand_value(cards: list[tuple[int, str]]) -> int:
    total = 0
    aces = 0
    for rank, _suit in cards:
        if rank == 14:
            total += 11
            aces += 1
        elif rank >= 10:
            total += 10
        else:
            total += rank
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


async def log_game(user_id: int, game: str, bet: int, payout: int, result: str, detail: str = "") -> None:
    async with session_scope() as session:
        session.add(
            GameHistory(
                user_id=int(user_id),
                game=game[:32],
                bet=int(bet),
                payout=int(payout),
                result=result[:16],
                detail=detail[:255],
            )
        )


async def game_history(user_id: int, limit: int = 10):
    from sqlalchemy import select

    async with session_scope() as session:
        return (
            await session.execute(
                select(GameHistory)
                .where(GameHistory.user_id == int(user_id))
                .order_by(GameHistory.created_at.desc())
                .limit(limit)
            )
        ).scalars().all()


def _resolve(game: str, bet: int, choice: str | None, settings: dict, seed: str) -> tuple[str, int, str]:
    """Return (result, payout, detail_html)."""
    if game == "taixiu":
        dice = _roll(seed, 6, 3)
        total = sum(dice)
        outcome = "TAI" if total >= 11 else "XIU"
        win = choice == outcome
        payout = int(bet * _multiplier(1.95, settings)) if win else 0
        detail = f"🎲 Xúc xắc: <b>{dice[0]} - {dice[1]} - {dice[2]}</b> (tổng <b>{total}</b>)\nKết quả: <b>{'TÀI' if outcome == 'TAI' else 'XỈU'}</b>"
        return ("win" if win else "lose", payout, detail)

    if game == "chanle":
        dice = _roll(seed, 6, 3)
        total = sum(dice)
        outcome = "CHAN" if total % 2 == 0 else "LE"
        win = choice == outcome
        payout = int(bet * _multiplier(1.95, settings)) if win else 0
        detail = f"🎲 Xúc xắc: <b>{dice[0]} - {dice[1]} - {dice[2]}</b> (tổng <b>{total}</b>)\nKết quả: <b>{'CHẴN' if outcome == 'CHAN' else 'LẺ'}</b>"
        return ("win" if win else "lose", payout, detail)

    if game == "xocdia":
        coins = _roll(seed, 2, 4)
        reds = sum(1 for c in coins if c == 1)
        outcome = "CHAN" if reds % 2 == 0 else "LE"
        win = choice == outcome
        payout = int(bet * _multiplier(1.95, settings)) if win else 0
        faces = " ".join("🔴" if c == 1 else "⚪" for c in coins)
        detail = f"🪙 Đồng xu: {faces}\nSố đỏ: <b>{reds}</b> — <b>{'CHẴN' if outcome == 'CHAN' else 'LẺ'}</b>"
        return ("win" if win else "lose", payout, detail)

    if game == "baucua":
        dice = _roll(seed, 6, 3)
        symbols = [BAU_SYMBOLS[d - 1] for d in dice]
        index = int(choice or 0)
        matches = sum(1 for d in dice if d - 1 == index)
        payout = bet * (1 + matches) if matches else 0
        detail = f"🎲 Kết quả: <b>{' - '.join(symbols)}</b>\nBạn chọn <b>{BAU_SYMBOLS[index]}</b> — trúng <b>{matches}</b> mặt"
        return ("win" if payout else "lose", payout, detail)

    if game in ("rongho",):
        deck = new_deck()
        dragon, tiger = deck[0], deck[1]
        dv = 10 if dragon[0] >= 10 else dragon[0]
        tv = 10 if tiger[0] >= 10 else tiger[0]
        if dv > tv:
            outcome = "RONG"
        elif tv > dv:
            outcome = "HO"
        else:
            outcome = "HOA"
        if outcome == "HOA":
            payout = int(bet * 8) if choice == "HOA" else 0
        else:
            payout = int(bet * _multiplier(1.95, settings)) if choice == outcome else 0
        detail = f"🐉 Rồng: <b>{card_str(dragon)}</b> ({dv})\n🐯 Hổ: <b>{card_str(tiger)}</b> ({tv})\nKết quả: <b>{'RỒNG' if outcome == 'RONG' else 'HỔ' if outcome == 'HO' else 'HOÀ'}</b>"
        return ("win" if payout else "lose", payout, detail)

    if game == "baccarat":
        deck = new_deck()
        player, banker = deck[:2], deck[2:4]
        pv, bv = hand_value(player) % 10, hand_value(banker) % 10
        if pv <= 5:
            player.append(deck[4])
            pv = hand_value(player) % 10
        if bv <= 5:
            banker.append(deck[5])
            bv = hand_value(banker) % 10
        outcome = "PLAYER" if pv > bv else "BANKER" if bv > pv else "TIE"
        if outcome == "TIE":
            payout = int(bet * 8) if choice == "TIE" else 0
        else:
            payout = int(bet * _multiplier(1.95, settings)) if choice == outcome else 0
        detail = (
            f"🃏 Player: <b>{' '.join(card_str(c) for c in player)}</b> = {pv}\n"
            f"🃏 Banker: <b>{' '.join(card_str(c) for c in banker)}</b> = {bv}\n"
            f"Kết quả: <b>{'PLAYER' if outcome == 'PLAYER' else 'BANKER' if outcome == 'BANKER' else 'HOÀ'}</b>"
        )
        return ("win" if payout else "lose", payout, detail)

    if game == "slots":
        symbols = [_RNG.choice(SLOT_SYMBOLS) for _ in range(3)]
        if symbols[0] == symbols[1] == symbols[2]:
            if symbols[0] == SLOT_JACKPOT_SYMBOL:
                return ("jackpot", 0, "3️⃣ guồng: <b>7️⃣ 7️⃣ 7️⃣</b> — NỔ HŨ!")
            payout = int(bet * _multiplier(20 if symbols[0] == "💎" else 10, settings))
            return ("win", payout, f"3️⃣ guồng: <b>{' '.join(symbols)}</b> — trúng lớn!")
        if symbols[0] == symbols[1] or symbols[1] == symbols[2] or symbols[0] == symbols[2]:
            return ("win", int(bet * _multiplier(1.5, settings)), f"3️⃣ guồng: <b>{' '.join(symbols)}</b> — trúng 2 biểu tượng.")
        return ("lose", 0, f"3️⃣ guồng: <b>{' '.join(symbols)}</b> — chúc may mắn lần sau.")

    if game == "roulette":
        number = _RNG.randint(0, 36)
        if number == 0:
            outcome = "GREEN"
        elif number in RED_NUMBERS:
            outcome = "RED"
        else:
            outcome = "BLACK"
        if choice in ("EVEN", "ODD"):
            win = number != 0 and ((number % 2 == 0) == (choice == "EVEN"))
        elif choice in ("RED", "BLACK"):
            win = outcome == choice
        else:
            win = False
        payout = int(bet * _multiplier(2.0, settings)) if win else 0
        color = "🟢" if number == 0 else "🔴" if number in RED_NUMBERS else "⚫"
        detail = f"🎡 Số ra: <b>{number}</b> {color}"
        return ("win" if win else "lose", payout, detail)

    if game == "highlow":
        deck = new_deck()
        first, second = deck[0], deck[1]
        fv = min(first[0], 10)
        sv = min(second[0], 10)
        if fv == sv:
            return ("push", bet, f"🃏 Lá đầu: <b>{card_str(first)}</b>\n🃏 Lá sau: <b>{card_str(second)}</b>\nHoà — hoàn vốn.")
        outcome = "HIGH" if sv > fv else "LOW"
        win = choice == outcome
        payout = int(bet * _multiplier(1.9, settings)) if win else 0
        detail = f"🃏 Lá đầu: <b>{card_str(first)}</b>\n🃏 Lá sau: <b>{card_str(second)}</b>\nKết quả: <b>{'CAO' if outcome == 'HIGH' else 'THẤP'}</b>"
        return ("win" if win else "lose", payout, detail)

    if game == "numberguess":
        number = _RNG.randint(1, 6)
        win = str(number) == str(choice)
        payout = int(bet * _multiplier(5.0, settings)) if win else 0
        detail = f"🎯 Số may mắn: <b>{number}</b>"
        return ("win" if win else "lose", payout, detail)

    if game == "mysterybox":
        prizes = [0, 0, 0.5, 1, 2, 5, 10]
        multiplier = _RNG.choices(prizes, weights=[30, 25, 15, 12, 10, 6, 2], k=1)[0]
        payout = int(bet * multiplier)
        detail = f"🎁 Bạn mở được <b>x{multiplier}</b> giá trị cược."
        return ("win" if payout > 0 else "lose", payout, detail)

    return ("lose", 0, UNKNOWN_GAME_TEXT)


async def place_bet(user_id: int, game: str, bet: int, choice: str | None = None) -> dict:
    meta = GAMES.get(game)
    if not meta:
        return {"ok": False, "error": "Game không tồn tại."}
    # Blackjack is a multi-turn hand played from its own keyboard; _resolve has no
    # blackjack branch, so a bet placed here would be taken without a result.
    if game == "blackjack":
        return {"ok": False, "error": "Blackjack chơi bằng nút 🃏 trong sảnh casino."}

    settings = await all_settings()
    if not (settings.get("game_enabled") or {}).get(game, False):
        return {"ok": False, "error": "Game này đang tạm đóng."}

    min_bet = int(settings.get("casino_min_bet", 100))
    max_bet = int(settings.get("casino_max_bet", 100000))
    if bet < min_bet or bet > max_bet:
        return {"ok": False, "error": f"Cược tối thiểu {fmt_coin(min_bet)}, tối đa {fmt_coin(max_bet)}."}
    if meta["choices"] and str(choice) not in meta["choices"]:
        return {"ok": False, "error": "Cửa cược không hợp lệ."}

    user = await wallet.get_user(user_id)
    if user is None:
        return {"ok": False, "error": "Không tìm thấy người dùng."}
    if user.is_muted_casino:
        return {"ok": False, "error": "Bạn đang bị tạm khoá khu vực casino."}

    if not await wallet.spend(user_id, bet, f"casino_{game}", "coin", f"Cược {meta['name']}"):
        current = await wallet.get_user(user_id)
        return {
            "ok": False,
            "error": "Bạn không đủ xu để đặt cược.",
            "code": "insufficient_coins",
            "bet": bet,
            "coins": int(current.coins) if current is not None else 0,
        }

    seed = secrets.token_hex(16)
    result, payout, detail = _resolve(game, bet, str(choice) if choice is not None else None, settings, seed)
    if detail == UNKNOWN_GAME_TEXT:
        # Never keep a bet the resolver could not settle.
        await wallet.add_balance(user_id, bet, f"casino_{game}_refund", "coin", "Hoàn cược")
        return {"ok": False, "error": "Game không hợp lệ."}

    jackpot_won = 0
    contribution = bet * int(settings.get("jackpot_contribution_percent", 2)) // 100
    async with _JACKPOT_LOCK:
        # Re-read under the lock so the contribution always builds on the value
        # another bet may have written a moment ago.
        current_settings = await all_settings(force=True)
        jackpot = int(current_settings.get("jackpot", 0) or 0)
        if result == "jackpot":
            jackpot_won = jackpot
            payout = jackpot
            await set_value("jackpot", contribution)
        elif contribution:
            await set_value("jackpot", jackpot + contribution)

    if payout > 0:
        await wallet.add_balance(
            user_id, payout, f"casino_{game}_win", "coin", f"Thắng {meta['name']}"
        )
    if result == "push" and payout == 0:
        await wallet.add_balance(user_id, bet, f"casino_{game}_push", "coin", "Hoàn vốn")

    await log_game(user_id, game, bet, payout, "win" if payout > bet else ("push" if payout == bet else "lose"), detail)

    updated = await wallet.get_user(user_id)
    net = payout - bet
    text = (
        f"{meta['name']} — cược <b>{fmt_coin(bet)}</b>\n"
        f"▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"{detail}\n"
        f"▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n"
        f"{'🎉 Thắng' if net > 0 else '➖ Hoà vốn' if net == 0 else '❌ Thua'}: "
        f"<b>{'+' if net > 0 else ''}{fmt_coin(net)}</b>\n"
        f"👛 Số dư: <b>{fmt_coin(updated.coins if updated else 0)}</b>"
    )
    if jackpot_won:
        text += f"\n💎 <b>NỔ HŨ {fmt_coin(jackpot_won)}!</b>"
    text += f"\n\n🔐 Seed: <code>{seed}</code> | hash <code>{_seed_hash(seed)}</code>"

    return {
        "ok": True,
        "result": result,
        "payout": payout,
        "net": net,
        "text": text,
        "coins": updated.coins if updated else 0,
        "jackpot": jackpot_won,
    }


WHEEL_PRIZES = [(50, 30), (100, 25), (200, 20), (500, 12), (1000, 8), (2000, 4), (5000, 1)]


async def spin_wheel(user_id: int) -> dict:
    """Free daily lucky wheel for coins."""
    user = await wallet.get_user(user_id)
    if user is None:
        return {"ok": False, "error": "Không tìm thấy người dùng."}
    now = datetime.utcnow()
    if user.last_wheel and now - user.last_wheel < timedelta(hours=24):
        next_at = user.last_wheel + timedelta(hours=24)
        return {"ok": False, "error": f"Bạn đã quay hôm nay. Lần tiếp theo: {next_at:%H:%M %d/%m} (UTC)."}

    # Claim the wheel atomically: two rapid taps must not both get a prize.
    async with session_scope() as session:
        claimed = await session.execute(
            update(User)
            .where(
                User.id == int(user_id),
                or_(User.last_wheel.is_(None), User.last_wheel <= now - timedelta(hours=24)),
            )
            .values(last_wheel=now)
        )
        if claimed.rowcount != 1:
            return {"ok": False, "error": "Bạn đã quay hôm nay rồi."}

    prizes = [p for p, _w in WHEEL_PRIZES]
    weights = [w for _p, w in WHEEL_PRIZES]
    prize = _RNG.choices(prizes, weights=weights, k=1)[0]

    await wallet.add_balance(user_id, prize, "wheel", "coin", "Vòng quay may mắn")
    return {"ok": True, "prize": prize}
