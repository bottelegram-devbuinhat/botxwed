"""Runtime settings stored in the database, merged over config defaults."""

from __future__ import annotations

import copy
import json
import time

from config import DEFAULT_SETTINGS
from database.models import Setting
from database.session import session_scope
from utils.logger import get_logger

log = get_logger(__name__)

_CACHE: dict | None = None
_CACHE_AT: float = 0.0
_TTL = 10.0


def _merge(base: dict, override: dict) -> dict:
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            base[key] = _merge(base[key], value)
        else:
            base[key] = value
    return base


async def all_settings(force: bool = False) -> dict:
    global _CACHE, _CACHE_AT
    now = time.monotonic()
    if _CACHE is not None and not force and now - _CACHE_AT < _TTL:
        return _CACHE
    data = copy.deepcopy(DEFAULT_SETTINGS)
    try:
        async with session_scope() as session:
            rows = (await session.execute(Setting.__table__.select())).all()
        overrides = {}
        for row in rows:
            try:
                overrides[row.key] = json.loads(row.value)
            except (TypeError, ValueError):
                log.warning("Invalid setting value for %s", row.key)
        data = _merge(data, overrides)
    except Exception as exc:  # never let settings break the bot
        log.error("Cannot load settings: %s", exc)
    _CACHE = data
    _CACHE_AT = now
    return data


async def get(key: str, default=None):
    settings = await all_settings()
    return settings.get(key, default)


async def set_value(key: str, value) -> None:
    global _CACHE
    async with session_scope() as session:
        row = await session.get(Setting, key)
        if row is None:
            session.add(Setting(key=key, value=json.dumps(value, ensure_ascii=False)))
        else:
            row.value = json.dumps(value, ensure_ascii=False)
    _CACHE = None


async def toggle(key: str) -> bool:
    settings = await all_settings(force=True)
    new_value = not bool(settings.get(key))
    await set_value(key, new_value)
    return new_value


async def update_dict(key: str, updates: dict) -> dict:
    settings = await all_settings(force=True)
    current = dict(settings.get(key) or {})
    current.update(updates)
    await set_value(key, current)
    return current


async def is_game_enabled(game: str) -> bool:
    settings = await all_settings()
    return bool((settings.get("game_enabled") or {}).get(game, False))
