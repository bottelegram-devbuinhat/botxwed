"""Leaderboards and ranking queries."""

from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import desc, func, select

from database.models import Deposit, GameHistory, Order, User
from database.session import session_scope

PERIODS = {"day": 1, "week": 7, "month": 30}
RANKING_TYPES = {
    "deposits": "💰 Nạp nhiều nhất",
    "purchases": "🛒 Mua nhiều nhất",
    "coins": "🪙 Nhiều xu nhất",
    "wins": "🎯 Thắng nhiều nhất",
    "biggest_win": "💥 Thắng lớn nhất",
    "referrals": "👥 Mời nhiều nhất",
    "streak": "🔥 Chuỗi điểm danh",
}


def _since(period: str) -> datetime | None:
    days = PERIODS.get(period)
    if not days:
        return None
    return datetime.utcnow() - timedelta(days=days)


async def _names(session, ids: list[int]) -> dict[int, User]:
    if not ids:
        return {}
    rows = (await session.execute(select(User).where(User.id.in_(ids)))).scalars().all()
    return {u.id: u for u in rows}


async def top(kind: str, period: str = "all", limit: int = 10) -> list[tuple[int, str, int]]:
    """Return [(user_id, display_name, value)] ordered best first."""
    since = _since(period)
    async with session_scope() as session:
        rows: list[tuple[int, int]] = []
        if kind == "deposits":
            query = select(Deposit.user_id, func.sum(Deposit.amount)).where(Deposit.status == "approved")
            if since:
                query = query.where(Deposit.created_at >= since)
            rows = (await session.execute(query.group_by(Deposit.user_id).order_by(desc(func.sum(Deposit.amount))).limit(limit))).all()
        elif kind == "purchases":
            query = select(Order.user_id, func.sum(Order.price)).where(Order.status != "refunded")
            if since:
                query = query.where(Order.created_at >= since)
            rows = (await session.execute(query.group_by(Order.user_id).order_by(desc(func.sum(Order.price))).limit(limit))).all()
        elif kind == "coins":
            rows = (await session.execute(select(User.id, User.coins).order_by(User.coins.desc()).limit(limit))).all()
        elif kind == "wins":
            query = select(GameHistory.user_id, func.count(GameHistory.id)).where(GameHistory.result == "win")
            if since:
                query = query.where(GameHistory.created_at >= since)
            rows = (await session.execute(query.group_by(GameHistory.user_id).order_by(desc(func.count(GameHistory.id))).limit(limit))).all()
        elif kind == "biggest_win":
            query = select(GameHistory.user_id, func.max(GameHistory.payout - GameHistory.bet)).where(
                GameHistory.result == "win"
            )
            if since:
                query = query.where(GameHistory.created_at >= since)
            rows = (
                await session.execute(query.group_by(GameHistory.user_id).order_by(desc(func.max(GameHistory.payout - GameHistory.bet))).limit(limit))
            ).all()
        elif kind == "referrals":
            rows = (
                await session.execute(
                    select(User.referrer_id, func.count(User.id))
                    .where(User.referrer_id.is_not(None))
                    .group_by(User.referrer_id)
                    .order_by(desc(func.count(User.id)))
                    .limit(limit)
                )
            ).all()
        elif kind == "streak":
            rows = (
                await session.execute(select(User.id, User.checkin_streak).order_by(User.checkin_streak.desc()).limit(limit))
            ).all()

        ids = [int(r[0]) for r in rows if r[0] is not None]
        users = await _names(session, ids)
        result = []
        for user_id, value in rows:
            if user_id is None:
                continue
            user = users.get(int(user_id))
            name = (user.full_name or user.username or f"ID {user_id}") if user else f"ID {user_id}"
            if user and user.hide_name:
                from utils.money import mask_name

                name = mask_name(name)
            result.append((int(user_id), name, int(value or 0)))
        return result


async def my_rank(kind: str, user_id: int, period: str = "all") -> tuple[int | None, int]:
    """Return (1-based rank or None, value) for a user."""
    rows = await top(kind, period, limit=1000)
    value = 0
    for index, (uid, _name, amount) in enumerate(rows, start=1):
        if uid == int(user_id):
            return index, amount
        value = amount
    async with session_scope() as session:
        if kind == "coins":
            user = await session.get(User, int(user_id))
            return None, int(user.coins if user else 0)
    return None, value
