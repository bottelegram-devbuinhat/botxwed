"""Catalog: categories, fungible products and their credential pools.

Ported from telegram-sales-bot (src/database.js) into the old bot's Python
structure. The old bot's unique Liên Quân accounts (Account model) stay as
they are; this module adds the repo's second sales model — one Product with
many Credential rows (Capcut, ChatGPT, Netflix, Spotify, ...). Buying N units
takes N unused credential rows.

Credential data is a JSON dict of arbitrary fields (username, password,
email_password, ...). It is Fernet-encrypted with the bot's existing
crypto_service before storage, exactly like Account.username_enc /
password_enc — never stored in plain text.
"""

from __future__ import annotations

import json

from sqlalchemy import func, select, update

from database.models import BankAccount, Category, Credential, Order, Product
from database.session import session_scope
from services import crypto_service
from utils.logger import get_logger

log = get_logger(__name__)

DEFAULT_CREDENTIAL_FIELDS = [
    {"key": "username", "label": "Tài khoản", "icon": "👤"},
    {"key": "password", "label": "Mật khẩu", "icon": "🔑"},
]


# --------------------------------------------------------------------------- categories
async def list_categories(active_only: bool = True, with_stock: bool = False) -> list[Category]:
    async with session_scope() as session:
        query = select(Category).order_by(Category.sort_order.asc(), Category.name.asc())
        if active_only:
            query = query.where(Category.is_active.is_(True))
        return list((await session.execute(query)).scalars().all())


async def add_category(name: str, emoji: str = "📦") -> Category:
    async with session_scope() as session:
        row = Category(name=name.strip()[:64], emoji=(emoji or "📦")[:16])
        session.add(row)
        await session.flush()
        return row


async def get_category(category_id: int) -> Category | None:
    async with session_scope() as session:
        return await session.get(Category, int(category_id))


# --------------------------------------------------------------------------- products
def _public_product(row: Product, stock: int) -> dict:
    return {
        "id": row.id,
        "category_id": row.category_id,
        "name": row.name,
        "price": int(row.price),
        "description": row.description or "",
        "note": row.note or "",
        "product_type": row.product_type,
        "delivery_hours": int(row.delivery_hours or 24),
        "subscription_days": row.subscription_days,
        "warranty_days": row.warranty_days,
        "stock": int(stock),
    }


async def product_stock(product_id: int) -> int:
    """Available units for a product (repo: getAllProductsStock logic)."""
    async with session_scope() as session:
        product = await session.get(Product, int(product_id))
        if product is None:
            return 0
        if product.product_type == "invite":
            sold = await _sold_qty(session, product.id)
            return max(0, int(product.invite_slots or 0) - sold)
        if product.product_type == "preorder":
            sold = await _sold_qty(session, product.id)
            return max(0, int(product.preorder_stock or 0) - sold)
        count = (
            await session.execute(
                select(func.count())
                .select_from(Credential)
                .where(Credential.product_id == product.id, Credential.is_sold.is_(False))
            )
        ).scalar() or 0
        return int(count)


async def _sold_qty(session, product_id: int) -> int:
    total = (
        await session.execute(
            select(func.coalesce(func.sum(Order.quantity), 0)).where(
                Order.product_id == int(product_id), Order.status.in_(("paid", "delivered"))
            )
        )
    ).scalar() or 0
    return int(total)


async def list_products(
    category_id: int | None = None, active_only: bool = True
) -> list[dict]:
    """All products with their live stock (repo: getProducts)."""
    async with session_scope() as session:
        query = select(Product).order_by(Product.sort_order.asc(), Product.name.asc())
        if active_only:
            query = query.where(Product.is_active.is_(True), Product.is_hidden.is_(False))
        if category_id:
            query = query.where(Product.category_id == int(category_id))
        rows = list((await session.execute(query)).scalars().all())
        out = []
        for row in rows:
            out.append(_public_product(row, await _stock_of(session, row)))
        return out


async def _stock_of(session, product: Product) -> int:
    if product.product_type == "invite":
        return max(0, int(product.invite_slots or 0) - await _sold_qty(session, product.id))
    if product.product_type == "preorder":
        return max(0, int(product.preorder_stock or 0) - await _sold_qty(session, product.id))
    count = (
        await session.execute(
            select(func.count())
            .select_from(Credential)
            .where(Credential.product_id == product.id, Credential.is_sold.is_(False))
        )
    ).scalar() or 0
    return int(count)


async def get_product(product_id: int) -> Product | None:
    async with session_scope() as session:
        return await session.get(Product, int(product_id))


async def get_product_with_stock(product_id: int) -> dict | None:
    async with session_scope() as session:
        row = await session.get(Product, int(product_id))
        if row is None:
            return None
        return _public_product(row, await _stock_of(session, row))


async def add_product(
    name: str,
    price: int,
    description: str = "",
    note: str = "",
    category_id: int | None = None,
    product_type: str = "credential",
    credential_fields: list[dict] | None = None,
    invite_slots: int = 0,
    preorder_stock: int = 0,
    delivery_hours: int = 24,
    subscription_days: int | None = None,
    warranty_days: int | None = None,
) -> Product:
    async with session_scope() as session:
        row = Product(
            name=name.strip()[:255],
            price=max(0, int(price)),
            description=description or "",
            note=(note or "")[:255],
            category_id=int(category_id) if category_id else None,
            product_type=product_type if product_type in ("credential", "invite", "preorder") else "credential",
            credential_fields=json.dumps(credential_fields or DEFAULT_CREDENTIAL_FIELDS, ensure_ascii=False),
            invite_slots=max(0, int(invite_slots or 0)),
            preorder_stock=max(0, int(preorder_stock or 0)),
            delivery_hours=max(1, int(delivery_hours or 24)),
            subscription_days=subscription_days,
            warranty_days=warranty_days,
        )
        session.add(row)
        await session.flush()
        return row


async def update_product(product_id: int, **fields) -> bool:
    allowed = {
        "name", "price", "description", "note", "category_id", "product_type",
        "invite_slots", "preorder_stock", "delivery_hours", "subscription_days",
        "warranty_days", "is_active", "is_hidden", "is_featured", "sort_order",
        "cost_price",
    }
    updates = {k: v for k, v in fields.items() if k in allowed}
    if not updates:
        return False
    async with session_scope() as session:
        row = await session.get(Product, int(product_id))
        if row is None:
            return False
        for key, value in updates.items():
            setattr(row, key, value)
        return True


async def delete_product(product_id: int) -> dict:
    """Soft-delete when the product already has orders (repo: deleteProduct)."""
    async with session_scope() as session:
        row = await session.get(Product, int(product_id))
        if row is None:
            return {"action": "missing"}
        order_count = (
            await session.execute(
                select(func.count()).select_from(Order).where(Order.product_id == int(product_id))
            )
        ).scalar() or 0
        if order_count > 0:
            row.is_active = False
            return {"action": "deactivated", "order_count": int(order_count)}
        await session.execute(
            Credential.__table__.delete().where(Credential.product_id == int(product_id))
        )
        await session.delete(row)
        return {"action": "deleted"}


# --------------------------------------------------------------------------- credentials
def _encrypt_data(data: dict) -> str:
    return crypto_service.encrypt(json.dumps(data, ensure_ascii=False))


def _decrypt_data(token: str) -> dict:
    raw = crypto_service.decrypt(token or "")
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except ValueError:
        return {}


async def add_credential(product_id: int, data: dict) -> Credential | None:
    async with session_scope() as session:
        row = await session.get(Product, int(product_id))
        if row is None:
            return None
        cred = Credential(product_id=int(product_id), data_enc=_encrypt_data(data or {}))
        session.add(cred)
        await session.flush()
        return cred


async def bulk_add_credentials(product_id: int, rows: list[dict]) -> int:
    """Insert many credentials at once (repo: bulkAddCredentials / /bulkcred)."""
    if not rows:
        return 0
    async with session_scope() as session:
        product = await session.get(Product, int(product_id))
        if product is None:
            return 0
        for data in rows:
            session.add(Credential(product_id=int(product_id), data_enc=_encrypt_data(data or {})))
        await session.flush()
        return len(rows)


async def take_credentials(product_id: int, quantity: int, order_id: int) -> list[dict]:
    """Atomically take N unused credentials for an order and mark them sold
    (repo: getAvailableCredentials + markCredentialsSold). Returns the
    decrypted credential dicts, in the order they were taken."""
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(Credential)
                .where(Credential.product_id == int(product_id), Credential.is_sold.is_(False))
                .order_by(Credential.id.asc())
                .limit(int(quantity))
                .with_for_update()
            )
        ).scalars().all()
        if len(rows) < int(quantity):
            return []
        taken: list[dict] = []
        for row in rows:
            row.is_sold = True
            row.order_id = int(order_id)
            taken.append(_decrypt_data(row.data_enc))
        return taken


async def count_credentials(product_id: int) -> dict:
    async with session_scope() as session:
        total = (
            await session.execute(
                select(func.count()).select_from(Credential).where(Credential.product_id == int(product_id))
            )
        ).scalar() or 0
        sold = (
            await session.execute(
                select(func.count())
                .select_from(Credential)
                .where(Credential.product_id == int(product_id), Credential.is_sold.is_(True))
            )
        ).scalar() or 0
        return {"total": int(total), "sold": int(sold), "available": int(total) - int(sold)}


# --------------------------------------------------------------------------- bank accounts
async def active_bank() -> dict | None:
    """The active saved bank account (repo: getBankConfig), or None to use env."""
    async with session_scope() as session:
        row = (
            await session.execute(
                select(BankAccount).where(BankAccount.is_active.is_(True)).order_by(BankAccount.id.asc()).limit(1)
            )
        ).scalar_one_or_none()
        if row is None:
            return None
        return {
            "bank_id": row.bank_id,
            "bank_code": row.bank_code,
            "bank_name": row.bank_name,
            "account_no": row.account_no,
            "account_name": row.account_name,
        }


async def add_bank_account(bank_id: str, bank_code: str, bank_name: str, account_no: str, account_name: str) -> BankAccount:
    async with session_scope() as session:
        row = BankAccount(
            bank_id=(bank_id or "").strip()[:16],
            bank_code=(bank_code or "").strip().upper()[:16],
            bank_name=(bank_name or "").strip()[:64],
            account_no=(account_no or "").strip()[:32],
            account_name=(account_name or "").strip().upper()[:128],
        )
        session.add(row)
        await session.flush()
        total = (await session.execute(select(func.count()).select_from(BankAccount))).scalar() or 0
        if total == 1:
            row.is_active = True
        return row


async def set_active_bank_account(bank_id: int) -> bool:
    async with session_scope() as session:
        row = await session.get(BankAccount, int(bank_id))
        if row is None:
            return False
        await session.execute(update(BankAccount).values(is_active=False))
        row.is_active = True
        return True
