"""Payments: VietQR generation, SePay webhook crediting and prepaid card redemption."""

from __future__ import annotations

import hmac
import re
from urllib.parse import quote

import aiohttp
from aiohttp import web

from config import (
    BANK_ACCOUNT,
    BANK_CODE,
    BANK_HOLDER,
    CARD_API_KEY,
    CARD_API_URL,
    SEPAY_API_KEY,
    SEPAY_ENABLED,
    WEBHOOK_HOST,
    WEBHOOK_PORT,
)
from services import wallet_service as wallet
from utils.logger import get_logger
from utils.money import fmt_vnd

log = get_logger(__name__)

_DEPOSIT_CODE_RE = re.compile(r"NAP\d+T[0-9A-F]{4}")


BANK_BIN_MAP = {
    "MB": "970422",
    "MBBANK": "970422",
    "VCB": "970436",
    "VIETCOMBANK": "970436",
    "TCB": "970407",
    "TECHCOMBANK": "970407",
    "VPB": "970432",
    "VPBANK": "970432",
    "ACB": "970416",
    "TPB": "970423",
    "TPBANK": "970423",
    "BIDV": "970418",
    "CTG": "970415",
    "VIETINBANK": "970415",
    "STB": "970403",
    "SACOMBANK": "970403",
}


def _crc16_ccitt(data: str) -> str:
    crc = 0xFFFF
    for c in data.encode("utf-8"):
        crc = ((crc >> 8) | (crc << 8)) & 0xFFFF
        crc ^= c
        crc ^= (crc & 0xFF) >> 4
        crc ^= (crc << 12) & 0xFFFF
        crc ^= ((crc & 0xFF) << 5) & 0xFFFF
    return f"{crc:04X}"


def _tlv(tag: str, val: str) -> str:
    return f"{tag}{len(val):02d}{val}"


def vietqr_payload(
    amount: int,
    add_info: str,
    bank_code: str = BANK_CODE,
    bank_account: str = BANK_ACCOUNT,
) -> str:
    """Build official VietQR EMVCo payload string for banking apps."""
    bank_bin = BANK_BIN_MAP.get(str(bank_code).upper().strip(), "970422")
    sub01 = _tlv("00", bank_bin) + _tlv("01", str(bank_account).strip())
    sub38 = _tlv("00", "A000000727") + _tlv("01", sub01) + _tlv("02", "QRIBFTTA")
    field62 = _tlv("08", str(add_info).strip())
    raw = (
        _tlv("00", "01")
        + _tlv("01", "12")
        + _tlv("38", sub38)
        + _tlv("53", "704")
        + _tlv("54", str(int(amount)))
        + _tlv("58", "VN")
        + _tlv("62", field62)
        + "6304"
    )
    return raw + _crc16_ccitt(raw)


def qr_png(payload: str) -> bytes | None:
    """Synchronous QR generator fallback."""
    if not payload:
        return None
    try:
        import qrcode
        import io
        img = qrcode.make(payload)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        pass

    try:
        import urllib.request
        url = f"https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={quote(payload)}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                return resp.read()
    except Exception as exc:
        log.warning("qr_png fallback error: %s", exc)
    return None


async def get_qr_bytes(
    amount: int,
    add_info: str,
    bank_code: str = BANK_CODE,
    bank_account: str = BANK_ACCOUNT,
    bank_holder: str = BANK_HOLDER,
) -> bytes | None:
    """Fetch official VietQR PNG image bytes or fallback cleanly."""
    import base64
    # 1. Try VietQR official generation API
    try:
        bank_bin = BANK_BIN_MAP.get(str(bank_code).upper().strip(), "970422")
        api_data = {
            "accountNo": str(bank_account).strip(),
            "accountName": str(bank_holder).strip(),
            "acqId": bank_bin,
            "amount": int(amount),
            "addInfo": str(add_info).strip(),
            "format": "text",
            "template": "compact2",
        }
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=4)) as session:
            async with session.post("https://api.vietqr.io/v2/generate", json=api_data) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    qr_data_url = (data.get("data") or {}).get("qrDataURL", "")
                    if "base64," in qr_data_url:
                        b64_str = qr_data_url.split("base64,", 1)[1]
                        return base64.b64decode(b64_str)
    except Exception as exc:
        log.debug("api.vietqr.io error: %s", exc)

    # 2. Build local EMVCo payload and get PNG
    payload = vietqr_payload(amount, add_info, bank_code, bank_account)
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=4)) as session:
            url = f"https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={quote(payload)}"
            async with session.get(url) as resp:
                if resp.status == 200:
                    return await resp.read()
    except Exception as exc:
        log.warning("api.qrserver.com error: %s", exc)

    return await asyncio.to_thread(qr_png, payload)


def vietqr_url(amount: int, add_info: str) -> str:
    return vietqr_url_bank(amount, add_info, BANK_CODE, BANK_ACCOUNT, BANK_HOLDER)


def vietqr_url_bank(amount: int, add_info: str, bank_code: str, bank_account: str, bank_holder: str) -> str:
    """VietQR image URL for an exact amount + transfer content.

    MERGE (repo: utils/vietqr.js generateQRUrl): direct orders put the order
    code (ORD...) in addInfo so SePay can match the payment to the order.
    The bank comes from the active saved BankAccount, else the env BANK_*.
    """
    return (
        f"https://img.vietqr.io/image/{bank_code}-{bank_account}-compact2.png"
        f"?amount={int(amount)}&addInfo={quote(add_info)}&accountName={quote(bank_holder)}"
    )


def extract_deposit_code(content: str) -> str | None:
    if not content:
        return None
    match = _DEPOSIT_CODE_RE.search((content or "").upper().replace(" ", ""))
    return match.group(0) if match else None


async def credit_bank_transfer(content: str, amount: int, reference: str) -> tuple[bool, int | None]:
    """Credit the deposit referenced by the transfer note. Idempotent by reference."""
    code = extract_deposit_code(content)
    if not code:
        return False, None
    deposit = await wallet.find_deposit_by_code(code)
    if deposit is None or deposit.status != "pending":
        return False, None
    if amount + 1 < deposit.amount:
        log.warning("Underpaid transfer %s: %s < %s", reference, amount, deposit.amount)
        return False, None
    approved = await wallet.approve_deposit(deposit.id, None)
    if approved is None:
        return False, None
    return True, approved.user_id


_ORDER_CODE_RE = re.compile(r"ORD\d{13,20}")


def extract_order_code(content: str) -> str | None:
    """Find a direct-order code (ORD...) in a transfer note (repo: webhookHandler)."""
    if not content:
        return None
    match = _ORDER_CODE_RE.search((content or "").upper().replace(" ", ""))
    return match.group(0) if match else None


async def credit_direct_order(content: str, amount: int, reference: str, bot=None) -> tuple[bool, str | None]:
    """Credit a direct order referenced by the transfer note. Idempotent:
    an order that is no longer pending is ignored (the webhook and the
    poller both call this, so a payment is never delivered twice)."""
    from services import order_service

    code = extract_order_code(content)
    if not code:
        return False, None
    ok, order = await order_service.confirm_order_payment(code, amount, reference)
    if not ok or order is None:
        return False, code
    if bot is not None:
        await order_service.deliver_order(bot, order)
    return True, code


async def redeem_card(serial: str, card_code: str, declared_amount: int) -> tuple[bool, str, int]:
    """Redeem a prepaid card through the configured provider.

    Returns (ok, message, credited_amount).
    """
    if not CARD_API_URL or not CARD_API_KEY:
        return False, "Cổng đổi thẻ chưa được cấu hình. Vui lòng chọn chuyển khoản.", 0
    payload = {
        "serial": serial.strip(),
        "code": card_code.strip(),
        "amount": int(declared_amount),
    }
    headers = {"Authorization": f"Bearer {CARD_API_KEY}", "X-API-KEY": CARD_API_KEY}
    timeout = aiohttp.ClientTimeout(total=30)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(CARD_API_URL, json=payload, headers=headers) as response:
                data = await response.json(content_type=None)
                if response.status >= 400:
                    return False, f"Cổng thẻ trả lỗi {response.status}.", 0
    except (aiohttp.ClientError, ValueError, TimeoutError) as exc:
        log.error("Card provider error: %s", exc)
        return False, "Không kết nối được cổng đổi thẻ, thử lại sau.", 0

    if not isinstance(data, dict):
        return False, "Phản hồi cổng thẻ không hợp lệ.", 0
    status = str(data.get("status", data.get("success", ""))).lower()
    if status not in ("success", "1", "true", "ok"):
        message = data.get("message") or data.get("msg") or "Thẻ không hợp lệ hoặc đã được sử dụng."
        return False, str(message)[:200], 0
    amount = int(data.get("amount") or data.get("value") or declared_amount or 0)
    if amount <= 0:
        return False, "Cổng thẻ không trả về mệnh giá hợp lệ.", 0
    return True, "Đổi thẻ thành công.", amount


def build_webhook_app(bot) -> web.Application:
    """SePay-compatible webhook: POST /sepay/webhook."""

    async def handle(request: web.Request) -> web.Response:
        if SEPAY_API_KEY:
            auth = request.headers.get("Authorization", "")
            expected = f"Apikey {SEPAY_API_KEY}"
            if not hmac.compare_digest(auth, expected):
                return web.json_response({"success": False, "message": "unauthorized"}, status=401)
        try:
            payload = await request.json()
        except ValueError:
            return web.json_response({"success": False, "message": "invalid json"}, status=400)

        if str(payload.get("transferType", "in")).lower() not in ("in", "1"):
            return web.json_response({"success": True, "message": "ignored transfer out"})

        try:
            amount = int(payload.get("transferAmount") or 0)
        except (TypeError, ValueError):
            amount = 0
        content = str(payload.get("content") or payload.get("description") or "")
        reference = str(payload.get("referenceCode") or payload.get("id") or "")
        if amount <= 0:
            return web.json_response({"success": True, "message": "ignored zero amount"})

        # MERGE (repo: webhookHandler): a direct order pays with its ORD code
        # as the transfer content. Try that first; fall back to the wallet
        # deposit (NAP code) path below.
        ok, order_code = await credit_direct_order(content, amount, reference, bot=bot)
        if ok:
            return web.json_response({"success": True, "message": "order paid", "order_code": order_code})

        ok, user_id = await credit_bank_transfer(content, amount, reference)
        if ok and user_id:
            try:
                await bot.send_message(
                    user_id,
                    f"✅ <b>Nạp tiền thành công</b>\nSố tiền: <b>{fmt_vnd(amount)}</b>\nMã giao dịch: <code>{reference}</code>",
                    parse_mode="HTML",
                )
            except Exception as exc:  # user may have blocked the bot
                log.warning("Cannot notify deposit user %s: %s", user_id, exc)
        return web.json_response(
            {"success": ok, "message": "credited" if ok else "no matching pending order/deposit"}
        )

    app = web.Application()
    app.router.add_post("/sepay/webhook", handle)
    app.router.add_get("/health", lambda _r: web.json_response({"ok": True}))
    return app


async def start_webhook_server(bot) -> web.AppRunner | None:
    if not SEPAY_ENABLED or not SEPAY_API_KEY:
        return None
    runner = web.AppRunner(build_webhook_app(bot))
    await runner.setup()
    site = web.TCPSite(runner, WEBHOOK_HOST, WEBHOOK_PORT)
    await site.start()
    log.info("SePay webhook listening on %s:%s", WEBHOOK_HOST, WEBHOOK_PORT)
    return runner
