"""Multi-item shopping cart (ported from telegram-sales-bot cartHandler.js
+ database.js cart functions). The old bot had no cart — every purchase was
a single account. The cart holds Product rows; checkout creates one direct
order with one OrderItem per line (repo: createOrderWithItems)."""

from __future__ import annotations

from sqlalchemy import func, select

from database.models import CartItem, Product
from database.session import session_scope
from services import catalog_service
from utils.logger import get_logger

log = get_logger(__name__)

MAX_QTY = 999


async def add_to_cart(user_id: int, product_id: int, quantity: int = 1) -> bool:
    quantity = max(1, min(MAX_QTY, int(quantity or 1)))
    async with session_scope() as session:
        product = await session.get(Product, int(product_id))
        if product is None or not product.is_active or product.is_hidden:
            return False
        row = (
            await session.execute(
                select(CartItem).where(
                    CartItem.user_id == int(user_id), CartItem.product_id == int(product_id)
                )
            )
        ).scalar_one_or_none()
        if row is None:
            session.add(CartItem(user_id=int(user_id), product_id=int(product_id), quantity=quantity))
        else:
            row.quantity = max(1, min(MAX_QTY, int(row.quantity) + quantity))
        return True


async def get_cart(user_id: int) -> list[dict]:
    """Cart lines with the live product + stock (repo: getCart)."""
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(CartItem).where(CartItem.user_id == int(user_id)).order_by(CartItem.created_at.asc())
            )
        ).scalars().all()
        out: list[dict] = []
        for row in rows:
            product = await session.get(Product, row.product_id)
            if product is None or not product.is_active:
                continue
            stock = await catalog_service._stock_of(session, product)
            out.append(
                {
                    "product_id": product.id,
                    "name": product.name,
                    "price": int(product.price),
                    "quantity": int(row.quantity),
                    "subtotal": int(product.price) * int(row.quantity),
                    "stock": stock,
                    "product_type": product.product_type,
                }
            )
        return out


async def cart_count(user_id: int) -> int:
    async with session_scope() as session:
        total = (
            await session.execute(
                select(func.coalesce(func.sum(CartItem.quantity), 0)).where(CartItem.user_id == int(user_id))
            )
        ).scalar() or 0
        return int(total)


async def cart_total(user_id: int) -> int:
    lines = await get_cart(user_id)
    return sum(line["subtotal"] for line in lines)


async def update_cart_qty(user_id: int, product_id: int, quantity: int) -> bool:
    if int(quantity) <= 0:
        return await remove_from_cart(user_id, product_id)
    async with session_scope() as session:
        row = (
            await session.execute(
                select(CartItem).where(
                    CartItem.user_id == int(user_id), CartItem.product_id == int(product_id)
                )
            )
        ).scalar_one_or_none()
        if row is None:
            return False
        row.quantity = max(1, min(MAX_QTY, int(quantity)))
        return True


async def remove_from_cart(user_id: int, product_id: int) -> bool:
    async with session_scope() as session:
        row = (
            await session.execute(
                select(CartItem).where(
                    CartItem.user_id == int(user_id), CartItem.product_id == int(product_id)
                )
            )
        ).scalar_one_or_none()
        if row is None:
            return False
        await session.delete(row)
        return True


async def clear_cart(user_id: int) -> None:
    async with session_scope() as session:
        await session.execute(CartItem.__table__.delete().where(CartItem.user_id == int(user_id)))
