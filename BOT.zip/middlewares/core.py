"""Core middlewares: user context, ban/maintenance guard, channel gate, throttle."""

from __future__ import annotations

import time
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from config import OWNER_IDS
from services import wallet_service as wallet
from services.settings_service import all_settings
from utils.logger import get_logger
from utils.permissions import is_admin
from utils.ratelimit import callback_limiter

log = get_logger(__name__)

_JOIN_CACHE: dict[tuple[int, str], float] = {}
_JOIN_TTL = 300


async def _reply(event: TelegramObject, text: str) -> None:
    if isinstance(event, CallbackQuery):
        try:
            await event.answer(text, show_alert=True)
        except Exception:
            pass
    elif isinstance(event, Message):
        try:
            await event.answer(text)
        except Exception:
            pass


class ContextMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is None or getattr(user, "is_bot", True):
            return await handler(event, data)

        db_user = await wallet.ensure_user(user.id, user.username, user.full_name)
        data["db_user"] = db_user

        if db_user.is_banned and not await is_admin(user.id):
            await _reply(event, "🚫 Tài khoản của bạn đã bị khoá. Liên hệ hỗ trợ để biết thêm.")
            return None

        settings = await all_settings()
        if settings.get("maintenance") and not await is_admin(user.id):
            await _reply(event, settings.get("maintenance_text") or "🛠 Bot đang bảo trì.")
            return None

        return await handler(event, data)


class ChannelGateMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is None or user.id in OWNER_IDS:
            return await handler(event, data)

        # /start, /menu and /help must always work: otherwise a new user is
        # locked out before they can even read the join prompt.
        if isinstance(event, Message):
            command = (event.text or "").strip().split(" ", 1)[0].split("@", 1)[0].lower()
            if command in ("/start", "/menu", "/help"):
                return await handler(event, data)

        settings = await all_settings()
        channels = [c for c in (settings.get("required_channels") or []) if c]
        if not channels:
            return await handler(event, data)

        now = time.monotonic()
        missing = []
        for channel in channels:
            key = (user.id, channel)
            if _JOIN_CACHE.get(key, 0) > now:
                continue
            try:
                member = await event.bot.get_chat_member(channel, user.id)  # type: ignore[union-attr]
                status = str(getattr(member, "status", ""))
                if status in ("left", "kicked"):
                    missing.append(channel)
                else:
                    _JOIN_CACHE[key] = now + _JOIN_TTL
            except Exception as exc:
                log.warning("Cannot check membership in %s: %s", channel, exc)

        if not missing:
            return await handler(event, data)

        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

        buttons = [
            [InlineKeyboardButton(text=f"📢 Tham gia {channel}", url=f"https://t.me/{channel.lstrip('@')}")]
            for channel in missing[:3]
        ]
        text = "📢 Bạn cần tham gia kênh/nhóm sau để tiếp tục sử dụng bot:"
        if isinstance(event, CallbackQuery):
            try:
                await event.answer("Vui lòng tham gia kênh bắt buộc!", show_alert=True)
            except Exception:
                pass
            await event.bot.send_message(user.id, text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
        elif isinstance(event, Message):
            await event.answer(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
        return None


class ThrottleMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        if isinstance(event, CallbackQuery):
            user = data.get("event_from_user")
            key = f"{getattr(user, 'id', 0)}:{event.data}"
            if not callback_limiter.allow(key):
                try:
                    await event.answer("⏳ Chậm thôi nào…")
                except Exception:
                    pass
                return None
        return await handler(event, data)


def register(dp) -> None:
    dp.message.middleware(ThrottleMiddleware())
    dp.callback_query.middleware(ThrottleMiddleware())
    dp.message.middleware(ChannelGateMiddleware())
    dp.callback_query.middleware(ChannelGateMiddleware())
    dp.message.middleware(ContextMiddleware())
    dp.callback_query.middleware(ContextMiddleware())
