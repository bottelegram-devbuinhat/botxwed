"""Tiny locale system with Vietnamese as the default and English as an option."""

from __future__ import annotations

from locales.en import STRINGS as EN
from locales.vi import STRINGS as VI

DEFAULT_LANGUAGE = "vi"
LANGUAGES = {"vi": VI, "en": EN}


def t(key: str, language: str = DEFAULT_LANGUAGE, **kwargs) -> str:
    """Return the localized string for ``key`` falling back to Vietnamese."""
    table = LANGUAGES.get(language or DEFAULT_LANGUAGE, VI)
    text = table.get(key) or VI.get(key) or key
    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, IndexError):
            return text
    return text


def language_name(code: str) -> str:
    return {"vi": "🇻🇳 Tiếng Việt", "en": "🇬🇧 English"}.get(code, code)
