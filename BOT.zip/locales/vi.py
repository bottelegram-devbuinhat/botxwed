"""Vietnamese strings (default language)."""

STRINGS = {
    # Navigation
    "btn_back": "⬅️ Quay lại",
    "btn_home": "🏠 Menu chính",
    "btn_admin": "🛠 Admin",
    "btn_confirm": "✅ Xác nhận",
    "btn_cancel": "❌ Huỷ",
    "btn_prev": "◀️",
    "btn_next": "▶️",
    "btn_first": "⏮",
    "btn_last": "⏭",
    "search": "🔍 Tìm kiếm",
    "filter": "🔃 Lọc / Sắp xếp",
    # Main menu
    "menu_title": "🏠 <b>MENU CHÍNH</b>",
    "menu_buy": "🛒 Mua Acc",
    "menu_sell": "💰 Bán / Ký gửi",
    "menu_casino": "🎰 Casino",
    "menu_deposit": "💳 Nạp tiền",
    "menu_account": "👤 Tài khoản",
    "menu_leaderboard": "🏆 Bảng xếp hạng",
    "menu_rewards": "🎁 Phần thưởng",
    "menu_support": "🆘 Hỗ trợ",
    "menu_guide": "📖 Hướng dẫn",
    "menu_ai": "🤖 Trợ lý AI",
    # Casino
    "casino_title": "🎰 <b>SẢNH CASINO (XU ẢO)</b>",
    "casino_warning": (
        "⚠️ <b>18+</b> — Xu chỉ là tiền ảo giải trí, không mua bằng tiền thật và "
        "không quy đổi ra tiền/acc. Hãy chơi có trách nhiệm."
    ),
    "casino_rules": "📖 Luật chơi",
    "casino_history": "📜 Lịch sử",
    "casino_play": "🎲 Chơi",
    "casino_repeat": "🔁 Cược lại",
    "casino_double": "✖️2 Gấp đôi",
    "casino_other": "⬅️ Chọn game khác",
    "bet": "Số xu cược",
    # Common status
    "on": "🟢 Bật",
    "off": "🔴 Tắt",
    "loading": "⏳ Đang xử lý...",
    "session_expired": "⌛ Phiên đã hết hạn, hãy mở lại từ menu.",
    "no_permission": "⛔ Bạn không có quyền dùng chức năng này.",
    "cancelled": "❌ Đã huỷ.",
    "not_enough_balance": "❌ Số dư không đủ.",
    "not_enough_coins": "❌ Bạn không đủ xu.",
    "maintenance": "🛠 Bot đang bảo trì, vui lòng quay lại sau.",
}
