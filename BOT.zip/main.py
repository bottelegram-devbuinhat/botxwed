"""Bot entry point: `python main.py` (long polling)."""

from __future__ import annotations

import asyncio
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramConflictError, TelegramUnauthorizedError
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand

from config import BOT_TOKEN
from database.seed import seed_if_empty
from database.session import init_db
from handlers import ai, guide, leaderboard, profile, rewards, sell, shop, shop_merge, start, support, wallet
from handlers.admin import router as admin_router
from handlers.casino import router as casino_router
from handlers.errors import on_error
from middlewares.core import register
from scheduler.jobs import start_scheduler
from services.payment_service import start_webhook_server
from services.sepay_poller import start_sepay_poller
from utils.logger import get_logger, setup_logging

log = get_logger(__name__)

BOT_COMMANDS = [
    BotCommand(command="start", description="Mở menu chính"),
    BotCommand(command="menu", description="Menu chức năng"),
    BotCommand(command="ai", description="Trợ lý AI hỗ trợ"),
    BotCommand(command="admin", description="Bảng điều khiển admin"),
    BotCommand(command="catalog", description="Danh mục sản phẩm"),
]


def build_dispatcher() -> Dispatcher:
    dp = Dispatcher(storage=MemoryStorage())
    register(dp)
    dp.errors.register(on_error)
    dp.include_router(admin_router)
    dp.include_router(casino_router)
    dp.include_router(shop.router)
    dp.include_router(shop_merge.router)
    dp.include_router(wallet.router)
    dp.include_router(sell.router)
    dp.include_router(rewards.router)
    dp.include_router(leaderboard.router)
    dp.include_router(ai.router)
    dp.include_router(support.router)
    dp.include_router(guide.router)
    dp.include_router(profile.router)
    dp.include_router(start.router)
    return dp


async def _clear_webhook(bot: Bot) -> None:
    """Long polling cannot work while a Telegram webhook is still set (409 Conflict)."""
    try:
        info = await bot.get_webhook_info()
    except Exception as exc:  # noqa: BLE001 - a probe must never block startup
        log.warning("Không kiểm tra được webhook: %s", exc)
        return
    if not info.url:
        return
    log.warning("Bot đang có webhook (%s); xoá để chuyển sang long polling", info.url)
    try:
        await bot.delete_webhook(drop_pending_updates=False)
    except Exception as exc:  # noqa: BLE001
        log.error("Không xoá được webhook: %s", exc)


async def main() -> None:
    setup_logging()
    if not BOT_TOKEN:
        log.error("BOT_TOKEN chưa được cấu hình. Tạo file .env từ .env.example và điền token.")
        sys.exit(1)

    await init_db()
    await seed_if_empty()

    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = build_dispatcher()

    try:
        me = await bot.get_me()
    except TelegramUnauthorizedError:
        log.error("BOT_TOKEN không hợp lệ (401 Unauthorized). Kiểm tra lại token trong .env.")
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001 - network hiccup, polling may still work
        log.warning("Không gọi được getMe: %s", exc)
    else:
        log.info("Đăng nhập bot @%s (id=%s)", me.username, me.id)
        try:
            await bot.set_my_commands(BOT_COMMANDS)
        except Exception as exc:  # noqa: BLE001
            log.warning("Cannot set bot commands: %s", exc)

    await _clear_webhook(bot)

    webhook_runner = None
    try:
        webhook_runner = await start_webhook_server(bot)
    except Exception as exc:  # noqa: BLE001 - the payment webhook is optional
        log.error("Không mở được webhook server thanh toán: %s", exc)

    poller_task = None
    try:
        poller_task = start_sepay_poller(bot)
    except Exception as exc:  # noqa: BLE001 - SePay poller is optional
        log.error("Không khởi động được SePay poller: %s", exc)

    try:
        scheduler = start_scheduler(bot)
    except Exception as exc:  # noqa: BLE001 - jobs are optional, polling is not
        scheduler = None
        log.error("Không khởi động được scheduler: %s", exc)

    log.info("Bot đang chạy (long polling)")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    except TelegramConflictError:
        log.error(
            "409 Conflict: đang có tiến trình khác chạy cùng BOT_TOKEN. "
            "Tắt tiến trình cũ (hoặc container cũ) rồi chạy lại."
        )
        raise
    finally:
        if scheduler is not None:
            scheduler.shutdown(wait=False)
        if webhook_runner is not None:
            await webhook_runner.cleanup()
        if poller_task is not None:
            poller_task.cancel()
        await bot.session.close()
        log.info("Bot đã dừng")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
